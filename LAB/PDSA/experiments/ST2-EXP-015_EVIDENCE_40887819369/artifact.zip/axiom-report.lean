/-
BOMA R-B N-Core candidate 001 — unified backend payload.

This file IMPLEMENTS the formal candidate N-RB-CAND-001 under
BOMA-RB-FORMAL-001 plus the V5 scope correction recorded after
PDSA-N-007-V5-FAILURE-001. It is not the canonical pre-numerical TCT
definition. It deliberately defines a fresh carrier and does not use Lean's
built-in Nat as the N-Core carrier.

Any TCTNF datatype below REPRESENTS selected TCT normal forms for backend
verification only.
-/

namespace BOMA.NCore.RB001

universe u

/-! ## Fresh R-B carrier -/

inductive BOMANat where
  | z : BOMANat
  | s : BOMANat → BOMANat

open BOMANat

/-! ## No-confusion obligations -/

theorem s_ne_z (n : BOMANat) : s n ≠ z := by
  intro h
  cases h

theorem s_injective {a b : BOMANat} (h : s a = s b) : a = b := by
  cases h
  rfl

/-! ## Dependent elimination / induction -/

/-- Sort-polymorphic eliminator: covers proposition-valued induction and
    Type-valued dependent elimination without conflating their scopes. -/
def ind {P : BOMANat → Sort u}
    (hz : P z)
    (hs : ∀ n, P n → P (s n)) :
    ∀ n, P n
  | z => hz
  | s n => hs n (ind hz hs n)

theorem induction_adequacy
    (P : BOMANat → Prop)
    (hz : P z)
    (hs : ∀ n, P n → P (s n)) :
    ∀ n, P n :=
  ind hz hs

/-! ## Nondependent recursion and pointwise uniqueness -/

def fold {X : Type u} (x0 : X) (step : X → X) : BOMANat → X
  | z => x0
  | s n => step (fold x0 step n)

@[simp] theorem fold_z {X : Type u} (x0 : X) (step : X → X) :
    fold x0 step z = x0 := rfl

@[simp] theorem fold_s {X : Type u} (x0 : X) (step : X → X) (n : BOMANat) :
    fold x0 step (s n) = step (fold x0 step n) := rfl

theorem fold_unique
    {X : Type u}
    (x0 : X)
    (step : X → X)
    (h : BOMANat → X)
    (hz : h z = x0)
    (hs : ∀ n, h (s n) = step (h n)) :
    ∀ n, h n = fold x0 step n := by
  intro n
  induction n with
  | z => exact hz
  | s n ih =>
      calc
        h (s n) = step (h n) := hs n
        _ = step (fold x0 step n) := congrArg step ih
        _ = fold x0 step (s n) := by rfl

/-! ## Backend representation of selected TCT normal forms -/

inductive TCTNFPlus where
  | unit : TCTNFPlus
  | ext : TCTNFPlus → TCTNFPlus

inductive TCTNF where
  | eps : TCTNF
  | nonempty : TCTNFPlus → TCTNF

open TCTNFPlus TCTNF

/-- REPRESENTS selected-presentation terminal extension. -/
def extU : TCTNF → TCTNF
  | eps => nonempty unit
  | nonempty p => nonempty (ext p)

/-- Formal realization of non-empty selected TCT presentation syntax. -/
def realizePlus : TCTNFPlus → BOMANat
  | unit => s z
  | ext p => s (realizePlus p)

/-- RB-B01/RB-B02 realization of selected TCT presentation syntax. -/
def realize : TCTNF → BOMANat
  | eps => z
  | nonempty p => realizePlus p

@[simp] theorem realize_eps : realize eps = z := rfl

@[simp] theorem realize_extU (a : TCTNF) :
    realize (extU a) = s (realize a) := by
  cases a <;> rfl

/-- Structural reification used to prove selected-NF bridge faithfulness. -/
def reify : BOMANat → TCTNF
  | z => eps
  | s n => extU (reify n)

@[simp] theorem realize_reify (n : BOMANat) :
    realize (reify n) = n := by
  induction n with
  | z => rfl
  | s n ih => simp [reify, ih]

@[simp] theorem reify_realizePlus (p : TCTNFPlus) :
    reify (realizePlus p) = nonempty p := by
  induction p with
  | unit => rfl
  | ext p ih => simp [realizePlus, reify, extU, ih]

@[simp] theorem reify_realize (a : TCTNF) :
    reify (realize a) = a := by
  cases a with
  | eps => rfl
  | nonempty p => exact reify_realizePlus p

theorem realize_injective {a b : TCTNF} (h : realize a = realize b) : a = b := by
  have h' := congrArg reify h
  simpa using h'

/-!
For selected normal forms only, canonical PDSA-TCT-004 proves that BR-010
structural equivalence is equivalent to selected-presentation identity.
Therefore backend equality on TCTNF represents ≈ in this restricted scope.
-/

theorem bridge_preserves_selected_identity {a b : TCTNF} (h : a = b) :
    realize a = realize b := by
  cases h
  rfl

theorem bridge_reflects_formal_identity {a b : TCTNF}
    (h : realize a = realize b) : a = b :=
  realize_injective h

/-! ## Unary-algebra initiality / recursion characterization -/

/-- Universe-polymorphic algebra record. The canonical BOMA initiality theorem
    below is intentionally specialized to Type 0 for Stage One; the generic
    comparison theorem remains same-universe polymorphic. -/
structure UnaryAlgebra where
  Carrier : Type u
  base : Carrier
  step : Carrier → Carrier

structure Hom (A B : UnaryAlgebra.{u}) where
  toFun : A.Carrier → B.Carrier
  map_base : toFun A.base = B.base
  map_step : ∀ x, toFun (A.step x) = B.step (toFun x)

/-- The formal BOMA candidate viewed as a Type-0 unary algebra. -/
def bomaAlg : UnaryAlgebra.{0} where
  Carrier := BOMANat
  base := z
  step := s

def idHom (A : UnaryAlgebra.{u}) : Hom A A where
  toFun := fun x => x
  map_base := rfl
  map_step := by intro x; rfl

def compHom {A B C : UnaryAlgebra.{u}} (g : Hom B C) (f : Hom A B) : Hom A C where
  toFun := fun x => g.toFun (f.toFun x)
  map_base := by
    calc
      g.toFun (f.toFun A.base) = g.toFun B.base := congrArg g.toFun f.map_base
      _ = C.base := g.map_base
  map_step := by
    intro x
    calc
      g.toFun (f.toFun (A.step x)) = g.toFun (B.step (f.toFun x)) :=
        congrArg g.toFun (f.map_step x)
      _ = C.step (g.toFun (f.toFun x)) := g.map_step (f.toFun x)

/-- Existence of the canonical homomorphism from the BOMA candidate to a
    Type-0 target unary algebra. -/
def foldHom (A : UnaryAlgebra.{0}) : Hom bomaAlg A where
  toFun := fold A.base A.step
  map_base := rfl
  map_step := by intro n; rfl

/-- Pointwise uniqueness of homomorphisms from the BOMA candidate in the
    selected Type-0 unary-algebra scope. -/
theorem foldHom_unique (A : UnaryAlgebra.{0}) (h : Hom bomaAlg A) :
    ∀ n, h.toFun n = (foldHom A).toFun n :=
  fold_unique A.base A.step h.toFun h.map_base h.map_step

/-- Same-universe pointwise initiality avoids requiring function extensionality. -/
def PointwiseInitial (A : UnaryAlgebra.{u}) : Prop :=
  ∀ B : UnaryAlgebra.{u},
    ∃ h : Hom A B,
      ∀ k : Hom A B, ∀ x, k.toFun x = h.toFun x

/-- Stage-One BOMA initiality is explicitly scoped to Type-0 unary algebras. -/
theorem boma_pointwise_initial : PointwiseInitial bomaAlg := by
  intro B
  refine ⟨foldHom B, ?_⟩
  intro k x
  exact foldHom_unique B k x

/-- Any two same-universe pointwise-initial unary algebras are pointwise
    inverse-isomorphic. -/
theorem pointwise_initial_unique
    (A B : UnaryAlgebra.{u})
    (hA : PointwiseInitial A)
    (hB : PointwiseInitial B) :
    ∃ f : Hom A B, ∃ g : Hom B A,
      (∀ x, g.toFun (f.toFun x) = x) ∧
      (∀ y, f.toFun (g.toFun y) = y) := by
  obtain ⟨f, _hf⟩ := hA B
  obtain ⟨g, _hg⟩ := hB A
  refine ⟨f, g, ?_, ?_⟩
  · obtain ⟨hAA, huniqA⟩ := hA A
    intro x
    have hcomp := huniqA (compHom g f) x
    have hid := huniqA (idHom A) x
    exact hcomp.trans hid.symm
  · obtain ⟨hBB, huniqB⟩ := hB B
    intro y
    have hcomp := huniqB (compHom f g) y
    have hid := huniqB (idHom B) y
    exact hcomp.trans hid.symm

end BOMA.NCore.RB001

/- Route R fragment: concatenate after NCoreRB001.lean. -/
namespace BOMA.NArithmetic.Addition001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

def addR (a b : BOMANat) : BOMANat := fold a s b

@[simp] theorem addR_z (a : BOMANat) : addR a z = a := rfl
@[simp] theorem addR_s (a b : BOMANat) : addR a (s b) = s (addR a b) := rfl

end BOMA.NArithmetic.Addition001

/- Route L fragment: concatenate after NCoreRB001.lean. Independent of AddRight. -/
namespace BOMA.NArithmetic.Addition001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

def addL (a b : BOMANat) : BOMANat := fold b s a

@[simp] theorem addL_z (b : BOMANat) : addL z b = b := rfl
@[simp] theorem addL_s (a b : BOMANat) : addL (s a) b = s (addL a b) := rfl

end BOMA.NArithmetic.Addition001

/- Convergence fragment: concatenate after NCore + AddRight + AddLeft. -/
namespace BOMA.NArithmetic.Addition001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

/-- Opposite-side zero equation for Route R, derived rather than definitional. -/
theorem addR_z_left (b : BOMANat) : addR z b = b := by
  induction b with
  | z => rfl
  | s b ih =>
      change s (addR z b) = s b
      exact congrArg s ih

/-- Opposite-side successor equation for Route R. -/
theorem addR_s_left (a b : BOMANat) : addR (s a) b = s (addR a b) := by
  induction b with
  | z => rfl
  | s b ih =>
      change s (addR (s a) b) = s (s (addR a b))
      exact congrArg s ih

/-- N-ADD-J-001 mathematical convergence theorem. -/
theorem add_routes_converge (a b : BOMANat) : addL a b = addR a b := by
  induction a with
  | z =>
      change b = addR z b
      exact (addR_z_left b).symm
  | s a ih =>
      change s (addL a b) = addR (s a) b
      rw [addR_s_left]
      exact congrArg s ih

end BOMA.NArithmetic.Addition001

/- Canonical addition laws: concatenate after NCore + both routes + convergence. -/
namespace BOMA.NArithmetic.Addition001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

/-- Canonical spelling selected after route equivalence. -/
def add : BOMANat → BOMANat → BOMANat := addR

@[simp] theorem add_z_right (a : BOMANat) : add a z = a := rfl
@[simp] theorem add_z_left (a : BOMANat) : add z a = a := addR_z_left a
@[simp] theorem add_s_right (a b : BOMANat) : add a (s b) = s (add a b) := rfl
@[simp] theorem add_s_left (a b : BOMANat) : add (s a) b = s (add a b) := addR_s_left a b

theorem add_comm (a b : BOMANat) : add a b = add b a := by
  change addR a b = addR b a
  simpa [addL, addR] using add_routes_converge b a

theorem add_assoc (a b c : BOMANat) : add (add a b) c = add a (add b c) := by
  induction c with
  | z => rfl
  | s c ih =>
      change s (add (add a b) c) = s (add a (add b c))
      exact congrArg s ih

theorem add_right_cancel (a b c : BOMANat) : add a c = add b c → a = b := by
  induction c with
  | z =>
      intro h
      exact h
  | s c ih =>
      intro h
      apply ih
      exact s_injective h

theorem add_left_cancel (c a b : BOMANat) : add c a = add c b → a = b := by
  intro h
  apply add_right_cancel a b c
  calc
    add a c = add c a := add_comm a c
    _ = add c b := h
    _ = add b c := (add_comm b c).symm

end BOMA.NArithmetic.Addition001

/- Route R fragment: concatenate after NCore + accepted addition fragments. -/
namespace BOMA.NArithmetic.Multiplication001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

def mulR (a b : BOMANat) : BOMANat := fold z (fun x => add x a) b

@[simp] theorem mulR_z (a : BOMANat) : mulR a z = z := rfl
@[simp] theorem mulR_s (a b : BOMANat) : mulR a (s b) = add (mulR a b) a := rfl

end BOMA.NArithmetic.Multiplication001

/- Route L fragment: independent of MulRight. -/
namespace BOMA.NArithmetic.Multiplication001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

def mulL (a b : BOMANat) : BOMANat := fold z (fun x => add x b) a

@[simp] theorem mulL_z (b : BOMANat) : mulL z b = z := rfl
@[simp] theorem mulL_s (a b : BOMANat) : mulL (s a) b = add (mulL a b) b := rfl

end BOMA.NArithmetic.Multiplication001

/- Convergence fragment: after NCore + all addition + MulRight + MulLeft. -/
namespace BOMA.NArithmetic.Multiplication001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

/-- Zero on the opposite side of Route R. -/
theorem mulR_z_left (b : BOMANat) : mulR z b = z := by
  induction b with
  | z => rfl
  | s b ih =>
      change add (mulR z b) z = z
      rw [ih]
      exact add_z_right z

/-- Successor on the opposite side of Route R. -/
theorem mulR_s_left (a b : BOMANat) : mulR (s a) b = add (mulR a b) b := by
  induction b with
  | z => rfl
  | s b ih =>
      calc
        mulR (s a) (s b) = add (mulR (s a) b) (s a) := rfl
        _ = add (add (mulR a b) b) (s a) := congrArg (fun x => add x (s a)) ih
        _ = s (add (add (mulR a b) b) a) := add_s_right (add (mulR a b) b) a
        _ = s (add (mulR a b) (add b a)) := congrArg s (add_assoc (mulR a b) b a)
        _ = s (add (mulR a b) (add a b)) := congrArg s (congrArg (fun x => add (mulR a b) x) (add_comm b a))
        _ = s (add (add (mulR a b) a) b) := congrArg s (add_assoc (mulR a b) a b).symm
        _ = add (add (mulR a b) a) (s b) := (add_s_right (add (mulR a b) a) b).symm
        _ = add (mulR a (s b)) (s b) := by rfl

/-- N-MUL-J-001 convergence theorem. -/
theorem mul_routes_converge (a b : BOMANat) : mulL a b = mulR a b := by
  induction a with
  | z =>
      change z = mulR z b
      exact (mulR_z_left b).symm
  | s a ih =>
      change add (mulL a b) b = mulR (s a) b
      rw [mulR_s_left]
      exact congrArg (fun x => add x b) ih

end BOMA.NArithmetic.Multiplication001

/- Canonical multiplication laws: after routes + convergence. -/
namespace BOMA.NArithmetic.Multiplication001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

def one : BOMANat := s z
def mul : BOMANat → BOMANat → BOMANat := mulR

@[simp] theorem mul_z_right (a : BOMANat) : mul a z = z := rfl
@[simp] theorem mul_z_left (a : BOMANat) : mul z a = z := mulR_z_left a
@[simp] theorem mul_s_right (a b : BOMANat) : mul a (s b) = add (mul a b) a := rfl
@[simp] theorem mul_s_left (a b : BOMANat) : mul (s a) b = add (mul a b) b := mulR_s_left a b

theorem mul_comm (a b : BOMANat) : mul a b = mul b a := by
  change mulR a b = mulR b a
  simpa [mulL, mulR] using mul_routes_converge b a

@[simp] theorem mul_one_right (a : BOMANat) : mul a one = a := by
  change add z a = a
  exact add_z_left a

@[simp] theorem mul_one_left (a : BOMANat) : mul one a = a := by
  calc
    mul one a = mul a one := mul_comm one a
    _ = a := mul_one_right a

/-- Right distributivity over addition in the recursive multiplier argument. -/
theorem mul_add_right (a b c : BOMANat) :
    mul a (add b c) = add (mul a b) (mul a c) := by
  induction c with
  | z => rfl
  | s c ih =>
      change add (mul a (add b c)) a = add (mul a b) (add (mul a c) a)
      rw [ih]
      exact add_assoc (mul a b) (mul a c) a

/-- Left distributivity follows by multiplication commutativity. -/
theorem mul_add_left (a b c : BOMANat) :
    mul (add a b) c = add (mul a c) (mul b c) := by
  calc
    mul (add a b) c = mul c (add a b) := mul_comm (add a b) c
    _ = add (mul c a) (mul c b) := mul_add_right c a b
    _ = add (mul a c) (mul b c) := by rw [mul_comm c a, mul_comm c b]

theorem mul_assoc (a b c : BOMANat) : mul (mul a b) c = mul a (mul b c) := by
  induction c with
  | z => rfl
  | s c ih =>
      change add (mul (mul a b) c) (mul a b) = mul a (add (mul b c) b)
      rw [mul_add_right]
      rw [ih]

end BOMA.NArithmetic.Multiplication001

/- Additive-witness order route. Requires accepted addition; independent of LEInd. -/
namespace BOMA.NArithmetic.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

def LEAdd (a b : BOMANat) : Prop := ∃ k, add a k = b

theorem leAdd_refl (a : BOMANat) : LEAdd a a := ⟨z, rfl⟩

theorem leAdd_trans {a b c : BOMANat} (hab : LEAdd a b) (hbc : LEAdd b c) : LEAdd a c := by
  rcases hab with ⟨k, hk⟩
  rcases hbc with ⟨l, hl⟩
  refine ⟨add k l, ?_⟩
  calc
    add a (add k l) = add (add a k) l := (add_assoc a k l).symm
    _ = add b l := congrArg (fun x => add x l) hk
    _ = c := hl

theorem leAdd_z (b : BOMANat) : LEAdd z b := ⟨b, add_z_left b⟩

theorem leAdd_s {a b : BOMANat} (h : LEAdd a b) : LEAdd (s a) (s b) := by
  rcases h with ⟨k, hk⟩
  refine ⟨k, ?_⟩
  calc
    add (s a) k = s (add a k) := add_s_left a k
    _ = s b := congrArg s hk

end BOMA.NArithmetic.Order001

/- Structural order route. Concatenate after NCore only; no arithmetic dependency. -/
namespace BOMA.NArithmetic.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

inductive LEInd : BOMANat → BOMANat → Prop where
  | z (b : BOMANat) : LEInd z b
  | s {a b : BOMANat} : LEInd a b → LEInd (s a) (s b)

theorem leInd_refl : ∀ a : BOMANat, LEInd a a
  | z => LEInd.z z
  | s a => LEInd.s (leInd_refl a)

theorem leInd_succ_right {a b : BOMANat} : LEInd a b → LEInd a (s b)
  | LEInd.z _ => LEInd.z _
  | LEInd.s h => LEInd.s (leInd_succ_right h)

theorem leInd_trans {a b c : BOMANat} (hab : LEInd a b) (hbc : LEInd b c) : LEInd a c := by
  induction hab generalizing c with
  | z b => exact LEInd.z c
  | s hab ih =>
      cases hbc with
      | s hbc' => exact LEInd.s (ih hbc')

theorem leInd_antisymm {a b : BOMANat} (hab : LEInd a b) (hba : LEInd b a) : a = b := by
  induction a generalizing b with
  | z =>
      cases b with
      | z => rfl
      | s b => cases hba
  | s a ih =>
      cases b with
      | z => cases hab
      | s b =>
          cases hab with
          | s hab' =>
              cases hba with
              | s hba' => exact congrArg s (ih hab' hba')

theorem leInd_total (a b : BOMANat) : LEInd a b ∨ LEInd b a := by
  induction a generalizing b with
  | z => exact Or.inl (LEInd.z b)
  | s a ih =>
      cases b with
      | z => exact Or.inr (LEInd.z (s a))
      | s b =>
          cases ih b with
          | inl h => exact Or.inl (LEInd.s h)
          | inr h => exact Or.inr (LEInd.s h)

theorem leInd_s_iff {a b : BOMANat} : LEInd (s a) (s b) ↔ LEInd a b := by
  constructor
  · intro h
    cases h with
    | s h' => exact h'
  · exact LEInd.s

end BOMA.NArithmetic.Order001

/- Convergence: after NCore + addition + OrderAdditive + OrderInductive. -/
namespace BOMA.NArithmetic.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

theorem leInd_to_leAdd {a b : BOMANat} (h : LEInd a b) : LEAdd a b := by
  induction h with
  | z b => exact ⟨b, add_z_left b⟩
  | s h ih =>
      rcases ih with ⟨k, hk⟩
      refine ⟨k, ?_⟩
      simpa using congrArg s hk

theorem leInd_add_right (a k : BOMANat) : LEInd a (add a k) := by
  induction k with
  | z => simpa using leInd_refl a
  | s k ih =>
      change LEInd a (s (add a k))
      exact leInd_succ_right ih

theorem leAdd_to_leInd {a b : BOMANat} (h : LEAdd a b) : LEInd a b := by
  rcases h with ⟨k, hk⟩
  have hi : LEInd a (add a k) := leInd_add_right a k
  rw [hk] at hi
  exact hi

theorem order_routes_converge (a b : BOMANat) : LEAdd a b ↔ LEInd a b :=
  ⟨leAdd_to_leInd, leInd_to_leAdd⟩

end BOMA.NArithmetic.Order001

/- Canonical order laws after route convergence. Requires accepted arithmetic packages. -/
namespace BOMA.NArithmetic.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001

def LE : BOMANat → BOMANat → Prop := LEAdd

theorem le_refl (a : BOMANat) : LE a a := leAdd_refl a

theorem le_trans {a b c : BOMANat} : LE a b → LE b c → LE a c := leAdd_trans

theorem le_antisymm {a b : BOMANat} (hab : LE a b) (hba : LE b a) : a = b :=
  leInd_antisymm (leAdd_to_leInd hab) (leAdd_to_leInd hba)

theorem le_total (a b : BOMANat) : LE a b ∨ LE b a := by
  cases leInd_total a b with
  | inl h => exact Or.inl (leInd_to_leAdd h)
  | inr h => exact Or.inr (leInd_to_leAdd h)

@[simp] theorem z_le (b : BOMANat) : LE z b := leAdd_z b

theorem not_s_le_z (a : BOMANat) : ¬ LE (s a) z := by
  intro h
  have hi := leAdd_to_leInd h
  cases hi

theorem le_s_iff {a b : BOMANat} : LE (s a) (s b) ↔ LE a b := by
  constructor
  · intro h
    have hi := leAdd_to_leInd h
    have hp : LEInd a b := (leInd_s_iff).mp hi
    exact leInd_to_leAdd hp
  · intro h
    exact leAdd_s h

theorem add_mono_right {a b : BOMANat} (h : LE a b) (c : BOMANat) : LE (add a c) (add b c) := by
  rcases h with ⟨k, hk⟩
  refine ⟨k, ?_⟩
  calc
    add (add a c) k = add a (add c k) := add_assoc a c k
    _ = add a (add k c) := congrArg (fun x => add a x) (add_comm c k)
    _ = add (add a k) c := (add_assoc a k c).symm
    _ = add b c := congrArg (fun x => add x c) hk

theorem add_mono_left {a b : BOMANat} (h : LE a b) (c : BOMANat) : LE (add c a) (add c b) := by
  have hr := add_mono_right h c
  simpa [add_comm c a, add_comm c b] using hr

theorem mul_mono_right {a b : BOMANat} (h : LE a b) (c : BOMANat) : LE (mul a c) (mul b c) := by
  rcases h with ⟨k, hk⟩
  refine ⟨mul k c, ?_⟩
  calc
    add (mul a c) (mul k c) = mul (add a k) c := (mul_add_left a k c).symm
    _ = mul b c := congrArg (fun x => mul x c) hk

theorem mul_mono_left {a b : BOMANat} (h : LE a b) (c : BOMANat) : LE (mul c a) (mul c b) := by
  have hr := mul_mono_right h c
  simpa [mul_comm c a, mul_comm c b] using hr

end BOMA.NArithmetic.Order001

/- Signed integer representation route. Concatenate after NCore only. -/
namespace BOMA.Z.Rep001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

inductive ZSigned where
  | zero : ZSigned
  | pos : BOMANat → ZSigned
  | neg : BOMANat → ZSigned

open ZSigned

def embedN : BOMANat → ZSigned
  | z => zero
  | s n => pos n

def zneg : ZSigned → ZSigned
  | zero => zero
  | pos n => neg n
  | neg n => pos n

/-- Structural difference without integer subtraction or numeric depth. -/
def diff : BOMANat → BOMANat → ZSigned
  | z, z => zero
  | s a, z => pos a
  | z, s b => neg b
  | s a, s b => diff a b

@[simp] theorem zneg_involutive (x : ZSigned) : zneg (zneg x) = x := by
  cases x <;> rfl

theorem embedN_injective {a b : BOMANat} (h : embedN a = embedN b) : a = b := by
  cases a <;> cases b <;> simp_all [embedN]

end BOMA.Z.Rep001

/- Difference-pair route. Requires accepted natural addition. -/
namespace BOMA.Z.Rep001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

structure ZPair where
  p : BOMANat
  n : BOMANat

/-- (a,b) ~ (c,d) iff a+d=c+b. -/
def ZEquiv (x y : ZPair) : Prop := add x.p y.n = add y.p x.n

theorem zeq_refl (x : ZPair) : ZEquiv x x := rfl

theorem zeq_symm {x y : ZPair} (h : ZEquiv x y) : ZEquiv y x := h.symm

theorem zeq_trans {x y w : ZPair} (hxy : ZEquiv x y) (hyw : ZEquiv y w) : ZEquiv x w := by
  cases x with
  | mk a b =>
    cases y with
    | mk c d =>
      cases w with
      | mk e f =>
        apply add_right_cancel (add a f) (add e b) d
        calc
          add (add a f) d = add a (add f d) := add_assoc a f d
          _ = add a (add d f) := congrArg (fun q => add a q) (add_comm f d)
          _ = add (add a d) f := (add_assoc a d f).symm
          _ = add (add c b) f := congrArg (fun q => add q f) hxy
          _ = add c (add b f) := add_assoc c b f
          _ = add c (add f b) := congrArg (fun q => add c q) (add_comm b f)
          _ = add (add c f) b := (add_assoc c f b).symm
          _ = add (add e d) b := congrArg (fun q => add q b) hyw
          _ = add e (add d b) := add_assoc e d b
          _ = add e (add b d) := congrArg (fun q => add e q) (add_comm d b)
          _ = add (add e b) d := (add_assoc e b d).symm

end BOMA.Z.Rep001

/- Representation convergence after signed + pair routes. -/
namespace BOMA.Z.Rep001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open ZSigned


def pairOfSigned : ZSigned → ZPair
  | zero => ⟨z, z⟩
  | pos n => ⟨s n, z⟩
  | neg n => ⟨z, s n⟩

def normalizePair (x : ZPair) : ZSigned := diff x.p x.n

@[simp] theorem signed_roundtrip (x : ZSigned) : normalizePair (pairOfSigned x) = x := by
  cases x <;> rfl

/-- Adding one common successor to both coordinates preserves the represented difference. -/
theorem zeq_common_s {q : ZPair} {a b : BOMANat}
    (h : ZEquiv q ⟨a,b⟩) : ZEquiv q ⟨s a, s b⟩ := by
  cases q with
  | mk p n =>
    calc
      add p (s b) = s (add p b) := add_s_right p b
      _ = s (add a n) := congrArg s h
      _ = add (s a) n := (add_s_left a n).symm

/-- Every pair normalizes to a canonical signed representative equivalent to it. -/
theorem pair_roundtrip (x : ZPair) : ZEquiv (pairOfSigned (normalizePair x)) x := by
  cases x with
  | mk p n =>
    induction p generalizing n with
    | z =>
        cases n <;> rfl
    | s p ih =>
        cases n with
        | z => rfl
        | s n =>
            exact zeq_common_s (ih n)

/-- Distinct signed normal forms cannot have equivalent canonical pairs. -/
theorem canonical_pair_separates {x y : ZSigned}
    (h : ZEquiv (pairOfSigned x) (pairOfSigned y)) : x = y := by
  cases x <;> cases y <;> simp_all [ZEquiv, pairOfSigned]

/-- Pair equivalence implies equality of signed normal forms. -/
theorem normalize_eq_of_equiv {x y : ZPair} (h : ZEquiv x y) :
    normalizePair x = normalizePair y := by
  apply canonical_pair_separates
  exact zeq_trans (zeq_trans (pair_roundtrip x) h) (zeq_symm (pair_roundtrip y))

/-- Equality of normal forms implies pair equivalence. -/
theorem equiv_of_normalize_eq {x y : ZPair}
    (h : normalizePair x = normalizePair y) : ZEquiv x y := by
  have hx : ZEquiv x (pairOfSigned (normalizePair x)) := zeq_symm (pair_roundtrip x)
  have hy : ZEquiv (pairOfSigned (normalizePair y)) y := pair_roundtrip y
  have hc : ZEquiv (pairOfSigned (normalizePair x)) (pairOfSigned (normalizePair y)) := by
    rw [h]
    exact zeq_refl _
  exact zeq_trans (zeq_trans hx hc) hy

theorem representation_converges (x y : ZPair) :
    ZEquiv x y ↔ normalizePair x = normalizePair y :=
  ⟨normalize_eq_of_equiv, equiv_of_normalize_eq⟩

end BOMA.Z.Rep001

/- Difference-pair arithmetic used as a retained semantic/producer route.
   This file does not create a quotient carrier. -/
namespace BOMA.Z.Rep001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001

/-- Useful commutative-monoid reassociation lemmas for the accepted N addition. -/
theorem z_add_left_comm (a b c : BOMANat) : add a (add b c) = add b (add a c) := by
  calc
    add a (add b c) = add (add a b) c := (add_assoc a b c).symm
    _ = add (add b a) c := congrArg (fun t => add t c) (add_comm a b)
    _ = add b (add a c) := add_assoc b a c

theorem z_add4_swap_middle (a b c d : BOMANat) :
    add (add a b) (add c d) = add (add a c) (add b d) := by
  calc
    add (add a b) (add c d) = add a (add b (add c d)) := add_assoc a b (add c d)
    _ = add a (add c (add b d)) := congrArg (fun t => add a t) (z_add_left_comm b c d)
    _ = add (add a c) (add b d) := (add_assoc a c (add b d)).symm

theorem z_add4_swap_last (a b c d : BOMANat) :
    add (add a b) (add c d) = add (add a d) (add b c) := by
  calc
    add (add a b) (add c d) = add (add a b) (add d c) :=
      congrArg (fun t => add (add a b) t) (add_comm c d)
    _ = add (add a d) (add b c) := z_add4_swap_middle a b d c

/-- Left commutativity for accepted N multiplication, made explicit so the
proof backend can normalize triple products without guessing an AC normal form. -/
theorem z_mul_left_comm (a b c : BOMANat) : mul a (mul b c) = mul b (mul a c) := by
  calc
    mul a (mul b c) = mul (mul a b) c := (mul_assoc a b c).symm
    _ = mul (mul b a) c := congrArg (fun t => mul t c) (mul_comm a b)
    _ = mul b (mul a c) := mul_assoc b a c

def pairZero : ZPair := ⟨z, z⟩
def pairOne : ZPair := ⟨s z, z⟩
def pairNeg (x : ZPair) : ZPair := ⟨x.n, x.p⟩
def pairAdd (x y : ZPair) : ZPair := ⟨add x.p y.p, add x.n y.n⟩
def pairMul (x y : ZPair) : ZPair :=
  ⟨add (mul x.p y.p) (mul x.n y.n),
   add (mul x.p y.n) (mul x.n y.p)⟩

@[simp] theorem pairAdd_zero_left (x : ZPair) : pairAdd pairZero x = x := by
  cases x <;> simp [pairAdd, pairZero]

@[simp] theorem pairAdd_zero_right (x : ZPair) : pairAdd x pairZero = x := by
  cases x <;> simp [pairAdd, pairZero]

theorem pairAdd_comm (x y : ZPair) : pairAdd x y = pairAdd y x := by
  cases x <;> cases y <;> simp [pairAdd, add_comm]

theorem pairAdd_assoc (x y w : ZPair) : pairAdd (pairAdd x y) w = pairAdd x (pairAdd y w) := by
  cases x <;> cases y <;> cases w <;> simp [pairAdd, add_assoc]

@[simp] theorem pairNeg_involutive (x : ZPair) : pairNeg (pairNeg x) = x := by
  cases x <;> rfl

theorem pairNeg_respects {x y : ZPair} (h : ZEquiv x y) : ZEquiv (pairNeg x) (pairNeg y) := by
  change add x.n y.p = add y.n x.p
  calc
    add x.n y.p = add y.p x.n := add_comm _ _
    _ = add x.p y.n := h.symm
    _ = add y.n x.p := add_comm _ _

/-- Pair addition is well-defined modulo the explicit difference relation. -/
theorem pairAdd_respects {x x' y y' : ZPair}
    (hx : ZEquiv x x') (hy : ZEquiv y y') :
    ZEquiv (pairAdd x y) (pairAdd x' y') := by
  cases x with
  | mk a b =>
    cases x' with
    | mk c d =>
      cases y with
      | mk e f =>
        cases y' with
        | mk g h =>
          change add (add a e) (add d h) = add (add c g) (add b f)
          calc
            add (add a e) (add d h) = add (add a d) (add e h) :=
              z_add4_swap_middle a e d h
            _ = add (add c b) (add e h) := congrArg (fun t => add t (add e h)) hx
            _ = add (add c b) (add g f) := congrArg (fun t => add (add c b) t) hy
            _ = add (add c g) (add b f) := z_add4_swap_middle c b g f

/-- Multiplication on pairs is exactly commutative before quotienting. -/
theorem pairMul_comm (x y : ZPair) : pairMul x y = pairMul y x := by
  cases x <;> cases y <;>
    simp [pairMul, mul_comm, add_comm]

/-- Respect of multiplication in the first representative argument. -/
theorem pairMul_respects_left {x x' y : ZPair}
    (hx : ZEquiv x x') : ZEquiv (pairMul x y) (pairMul x' y) := by
  cases x with
  | mk a b =>
    cases x' with
    | mk c d =>
      cases y with
      | mk e f =>
        have he : add (mul a e) (mul d e) = add (mul c e) (mul b e) := by
          calc
            add (mul a e) (mul d e) = mul (add a d) e := (mul_add_left a d e).symm
            _ = mul (add c b) e := congrArg (fun t => mul t e) hx
            _ = add (mul c e) (mul b e) := mul_add_left c b e
        have hf : add (mul a f) (mul d f) = add (mul c f) (mul b f) := by
          calc
            add (mul a f) (mul d f) = mul (add a d) f := (mul_add_left a d f).symm
            _ = mul (add c b) f := congrArg (fun t => mul t f) hx
            _ = add (mul c f) (mul b f) := mul_add_left c b f
        have hf' : add (mul b f) (mul c f) = add (mul d f) (mul a f) := by
          calc
            add (mul b f) (mul c f) = add (mul c f) (mul b f) := add_comm _ _
            _ = add (mul a f) (mul d f) := hf.symm
            _ = add (mul d f) (mul a f) := add_comm _ _
        change
          add (add (mul a e) (mul b f)) (add (mul c f) (mul d e)) =
          add (add (mul c e) (mul d f)) (add (mul a f) (mul b e))
        calc
          add (add (mul a e) (mul b f)) (add (mul c f) (mul d e)) =
              add (add (mul a e) (mul d e)) (add (mul b f) (mul c f)) :=
            z_add4_swap_last (mul a e) (mul b f) (mul c f) (mul d e)
          _ = add (add (mul c e) (mul b e)) (add (mul b f) (mul c f)) :=
            congrArg (fun t => add t (add (mul b f) (mul c f))) he
          _ = add (add (mul c e) (mul b e)) (add (mul d f) (mul a f)) :=
            congrArg (fun t => add (add (mul c e) (mul b e)) t) hf'
          _ = add (add (mul c e) (mul d f)) (add (mul b e) (mul a f)) :=
            z_add4_swap_middle (mul c e) (mul b e) (mul d f) (mul a f)
          _ = add (add (mul c e) (mul d f)) (add (mul a f) (mul b e)) :=
            congrArg (fun t => add (add (mul c e) (mul d f)) t) (add_comm _ _)

/-- Respect in the second argument follows from exact pair multiplication commutativity. -/
theorem pairMul_respects_right {x y y' : ZPair}
    (hy : ZEquiv y y') : ZEquiv (pairMul x y) (pairMul x y') := by
  rw [pairMul_comm x y, pairMul_comm x y']
  exact pairMul_respects_left hy

theorem pairMul_respects {x x' y y' : ZPair}
    (hx : ZEquiv x x') (hy : ZEquiv y y') :
    ZEquiv (pairMul x y) (pairMul x' y') := by
  exact zeq_trans (pairMul_respects_left hx) (pairMul_respects_right hy)

/-- Raw pair multiplication is associative by the accepted N commutative-semiring laws. -/
theorem pairMul_assoc (x y w : ZPair) : pairMul (pairMul x y) w = pairMul x (pairMul y w) := by
  cases x <;> cases y <;> cases w <;>
    simp [pairMul, mul_add_left, mul_add_right, mul_assoc, mul_comm, z_mul_left_comm,
      add_assoc, add_comm, z_add_left_comm]

/-- Raw pair multiplication distributes over raw pair addition. -/
theorem pairMul_add_right (x y w : ZPair) :
    pairMul x (pairAdd y w) = pairAdd (pairMul x y) (pairMul x w) := by
  cases x <;> cases y <;> cases w <;>
    simp [pairMul, pairAdd, mul_add_left, mul_add_right, mul_assoc, mul_comm, z_mul_left_comm,
      add_assoc, add_comm, z_add_left_comm]

/-- Additive inverse is represented by coordinate swap. -/
theorem pair_add_neg_equiv_zero (x : ZPair) : ZEquiv (pairAdd x (pairNeg x)) pairZero := by
  cases x with
  | mk a b =>
    change add (add a b) z = add z (add b a)
    simpa [add_comm]

end BOMA.Z.Rep001

/- Direct arithmetic route on the selected signed normal-form carrier. -/
namespace BOMA.Z.Arithmetic001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- Structural difference of equal naturals is canonical integer zero. -/
theorem diff_self (n : BOMANat) : diff n n = zero := by
  induction n with
  | z => rfl
  | s n ih => exact ih

/-- Difference against zero is exactly the natural embedding. -/
theorem diff_nat_zero (n : BOMANat) : diff n z = embedN n := by
  cases n <;> rfl

/-- Zero minus a natural is the negation of the natural embedding. -/
theorem diff_zero_nat (n : BOMANat) : diff z n = zneg (embedN n) := by
  cases n <;> rfl

/-- Direct sign-case addition. Cross-sign cases use only the already-defined
structural natural difference, not any external integer subtraction. -/
def zaddD : ZSigned → ZSigned → ZSigned
  | zero, y => y
  | x, zero => x
  | pos a, pos b => pos (add a (s b))
  | neg a, neg b => neg (add a (s b))
  | pos a, neg b => diff (s a) (s b)
  | neg a, pos b => diff (s b) (s a)

/-- Direct sign-case multiplication. Magnitudes use accepted N multiplication. -/
def zmulD : ZSigned → ZSigned → ZSigned
  | zero, _ => zero
  | _, zero => zero
  | pos a, pos b => embedN (mul (s a) (s b))
  | pos a, neg b => zneg (embedN (mul (s a) (s b)))
  | neg a, pos b => zneg (embedN (mul (s a) (s b)))
  | neg a, neg b => embedN (mul (s a) (s b))

@[simp] theorem zaddD_zero_left (x : ZSigned) : zaddD zero x = x := rfl
@[simp] theorem zaddD_zero_right (x : ZSigned) : zaddD x zero = x := by
  cases x <;> rfl

@[simp] theorem zmulD_zero_left (x : ZSigned) : zmulD zero x = zero := rfl
@[simp] theorem zmulD_zero_right (x : ZSigned) : zmulD x zero = zero := by
  cases x <;> rfl

end BOMA.Z.Arithmetic001

/- Pair-mediated arithmetic route on the selected signed normal-form carrier. -/
namespace BOMA.Z.Arithmetic001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- Add canonical signed integers by translating to retained difference pairs,
performing raw pair addition, then normalizing back. -/
def zaddP (x y : ZSigned) : ZSigned :=
  normalizePair (pairAdd (pairOfSigned x) (pairOfSigned y))

/-- Multiply canonical signed integers by the retained pair product and normalize. -/
def zmulP (x y : ZSigned) : ZSigned :=
  normalizePair (pairMul (pairOfSigned x) (pairOfSigned y))

end BOMA.Z.Arithmetic001

/- Cross-route convergence for signed integer addition and multiplication. -/
namespace BOMA.Z.Arithmetic001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- The direct and pair-mediated addition routes agree pointwise. -/
theorem zadd_routes_converge (x y : ZSigned) : zaddD x y = zaddP x y := by
  cases x <;> cases y <;>
    simp [zaddD, zaddP, pairAdd, pairOfSigned, normalizePair,
      diff, embedN, add_s_left, add_s_right]

/-- Pair normalization of a natural product against zero is the direct embedded product. -/
theorem normalize_positive_pair (n : BOMANat) :
    normalizePair ⟨n, z⟩ = embedN n := by
  exact diff_nat_zero n

/-- Pair normalization of zero against a natural is its signed negation. -/
theorem normalize_negative_pair (n : BOMANat) :
    normalizePair ⟨z, n⟩ = zneg (embedN n) := by
  exact diff_zero_nat n

/-- The direct and pair-mediated multiplication routes agree pointwise. -/
theorem zmul_routes_converge (x y : ZSigned) : zmulD x y = zmulP x y := by
  cases x <;> cases y <;>
    simp [zmulD, zmulP, pairMul, pairOfSigned, normalizePair,
      normalize_positive_pair, normalize_negative_pair,
      diff_nat_zero, diff_zero_nat, embedN]

end BOMA.Z.Arithmetic001

/- Canonical integer arithmetic laws after direct/pair route convergence. -/
namespace BOMA.Z.Arithmetic001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- Canonical arithmetic spellings on the selected signed carrier.
The direct route is selected as the executable spelling only after route convergence. -/
def zadd : ZSigned → ZSigned → ZSigned := zaddD
def zmul : ZSigned → ZSigned → ZSigned := zmulD
def zzero : ZSigned := zero
def zone : ZSigned := embedN (s z)

/-- Semantic certificate for canonical addition in the retained pair model. -/
theorem zadd_pair_semantics (x y : ZSigned) :
    ZEquiv (pairOfSigned (zadd x y)) (pairAdd (pairOfSigned x) (pairOfSigned y)) := by
  unfold zadd
  rw [zadd_routes_converge]
  exact pair_roundtrip (pairAdd (pairOfSigned x) (pairOfSigned y))

/-- Semantic certificate for canonical multiplication in the retained pair model. -/
theorem zmul_pair_semantics (x y : ZSigned) :
    ZEquiv (pairOfSigned (zmul x y)) (pairMul (pairOfSigned x) (pairOfSigned y)) := by
  unfold zmul
  rw [zmul_routes_converge]
  exact pair_roundtrip (pairMul (pairOfSigned x) (pairOfSigned y))

/-- Equality of pair semantics gives equality on the selected canonical carrier. -/
theorem signed_eq_of_pair_equiv {x y : ZSigned}
    (h : ZEquiv (pairOfSigned x) (pairOfSigned y)) : x = y :=
  canonical_pair_separates h

@[simp] theorem zadd_zero_left (x : ZSigned) : zadd zzero x = x := by
  cases x <;> rfl

@[simp] theorem zadd_zero_right (x : ZSigned) : zadd x zzero = x := by
  cases x <;> rfl

theorem zadd_comm (x y : ZSigned) : zadd x y = zadd y x := by
  apply signed_eq_of_pair_equiv
  exact zeq_trans
    (zadd_pair_semantics x y)
    (zeq_trans
      (by rw [pairAdd_comm (pairOfSigned x) (pairOfSigned y)]; exact zeq_refl _)
      (zeq_symm (zadd_pair_semantics y x)))

theorem zadd_assoc (x y w : ZSigned) : zadd (zadd x y) w = zadd x (zadd y w) := by
  apply signed_eq_of_pair_equiv
  have hxy : ZEquiv (pairOfSigned (zadd x y))
      (pairAdd (pairOfSigned x) (pairOfSigned y)) := zadd_pair_semantics x y
  have hyw : ZEquiv (pairOfSigned (zadd y w))
      (pairAdd (pairOfSigned y) (pairOfSigned w)) := zadd_pair_semantics y w
  have hL : ZEquiv
      (pairAdd (pairOfSigned (zadd x y)) (pairOfSigned w))
      (pairAdd (pairAdd (pairOfSigned x) (pairOfSigned y)) (pairOfSigned w)) :=
    pairAdd_respects hxy (zeq_refl _)
  have hA : ZEquiv
      (pairAdd (pairAdd (pairOfSigned x) (pairOfSigned y)) (pairOfSigned w))
      (pairAdd (pairOfSigned x) (pairAdd (pairOfSigned y) (pairOfSigned w))) := by
    rw [pairAdd_assoc]
    exact zeq_refl _
  have hR : ZEquiv
      (pairAdd (pairOfSigned x) (pairAdd (pairOfSigned y) (pairOfSigned w)))
      (pairAdd (pairOfSigned x) (pairOfSigned (zadd y w))) :=
    pairAdd_respects (zeq_refl _) (zeq_symm hyw)
  exact zeq_trans (zadd_pair_semantics (zadd x y) w)
    (zeq_trans hL (zeq_trans hA (zeq_trans hR (zeq_symm (zadd_pair_semantics x (zadd y w))))))

@[simp] theorem zadd_neg_right (x : ZSigned) : zadd x (zneg x) = zzero := by
  cases x with
  | zero => rfl
  | pos n =>
      change diff (s n) (s n) = zero
      exact diff_self (s n)
  | neg n =>
      change diff (s n) (s n) = zero
      exact diff_self (s n)

@[simp] theorem zadd_neg_left (x : ZSigned) : zadd (zneg x) x = zzero := by
  rw [zadd_comm]
  exact zadd_neg_right x

/-- Natural one is preserved by the selected signed embedding. -/
@[simp] theorem zone_def : zone = pos z := rfl

@[simp] theorem zmul_zero_left (x : ZSigned) : zmul zzero x = zzero := by
  cases x <;> rfl

@[simp] theorem zmul_zero_right (x : ZSigned) : zmul x zzero = zzero := by
  cases x <;> rfl

theorem zmul_comm (x y : ZSigned) : zmul x y = zmul y x := by
  apply signed_eq_of_pair_equiv
  exact zeq_trans
    (zmul_pair_semantics x y)
    (zeq_trans
      (by rw [pairMul_comm (pairOfSigned x) (pairOfSigned y)]; exact zeq_refl _)
      (zeq_symm (zmul_pair_semantics y x)))

theorem zmul_assoc (x y w : ZSigned) : zmul (zmul x y) w = zmul x (zmul y w) := by
  apply signed_eq_of_pair_equiv
  have hxy := zmul_pair_semantics x y
  have hyw := zmul_pair_semantics y w
  have hL := pairMul_respects hxy (zeq_refl (pairOfSigned w))
  have hA : ZEquiv
      (pairMul (pairMul (pairOfSigned x) (pairOfSigned y)) (pairOfSigned w))
      (pairMul (pairOfSigned x) (pairMul (pairOfSigned y) (pairOfSigned w))) := by
    rw [pairMul_assoc]
    exact zeq_refl _
  have hR := pairMul_respects (zeq_refl (pairOfSigned x)) (zeq_symm hyw)
  exact zeq_trans (zmul_pair_semantics (zmul x y) w)
    (zeq_trans hL (zeq_trans hA (zeq_trans hR (zeq_symm (zmul_pair_semantics x (zmul y w))))))

@[simp] theorem zmul_one_right (x : ZSigned) : zmul x zone = x := by
  cases x with
  | zero => rfl
  | pos n =>
      simp [zmul, zmulD, zone, embedN, mul_one_right]
  | neg n =>
      simp [zmul, zmulD, zone, embedN, zneg, mul_one_right]

@[simp] theorem zmul_one_left (x : ZSigned) : zmul zone x = x := by
  rw [zmul_comm]
  exact zmul_one_right x

/-- Right distributivity is transferred through the retained pair semantics. -/
theorem zmul_add_right (x y w : ZSigned) :
    zmul x (zadd y w) = zadd (zmul x y) (zmul x w) := by
  apply signed_eq_of_pair_equiv
  have hyw := zadd_pair_semantics y w
  have hxy := zmul_pair_semantics x y
  have hxw := zmul_pair_semantics x w
  have h1 := pairMul_respects (zeq_refl (pairOfSigned x)) hyw
  have h2 : ZEquiv
      (pairMul (pairOfSigned x) (pairAdd (pairOfSigned y) (pairOfSigned w)))
      (pairAdd (pairMul (pairOfSigned x) (pairOfSigned y))
               (pairMul (pairOfSigned x) (pairOfSigned w))) := by
    rw [pairMul_add_right]
    exact zeq_refl _
  have h3 := pairAdd_respects (zeq_symm hxy) (zeq_symm hxw)
  exact zeq_trans (zmul_pair_semantics x (zadd y w))
    (zeq_trans h1 (zeq_trans h2 (zeq_trans h3
      (zeq_symm (zadd_pair_semantics (zmul x y) (zmul x w))))))

theorem zmul_add_left (x y w : ZSigned) :
    zmul (zadd x y) w = zadd (zmul x w) (zmul y w) := by
  calc
    zmul (zadd x y) w = zmul w (zadd x y) := zmul_comm _ _
    _ = zadd (zmul w x) (zmul w y) := zmul_add_right w x y
    _ = zadd (zmul x w) (zmul y w) := by rw [zmul_comm w x, zmul_comm w y]

/-- The accepted N embedding preserves zero. -/
@[simp] theorem embedN_zero : embedN z = zzero := rfl

/-- The accepted N embedding preserves one. -/
@[simp] theorem embedN_one : embedN (s z) = zone := rfl

/-- The accepted N embedding preserves addition. -/
theorem embedN_add (a b : BOMANat) : embedN (add a b) = zadd (embedN a) (embedN b) := by
  cases a with
  | z => simp [zadd, zzero, embedN]
  | s a =>
      cases b with
      | z => simp [zadd, zzero, embedN]
      | s b =>
          simp [zadd, zaddD, embedN, add_s_left, add_s_right]

/-- The accepted N embedding preserves multiplication. -/
theorem embedN_mul (a b : BOMANat) : embedN (mul a b) = zmul (embedN a) (embedN b) := by
  cases a with
  | z => simp [zmul, zzero, embedN]
  | s a =>
      cases b with
      | z => simp [zmul, zzero, embedN]
      | s b => rfl

/-- Every selected signed integer is explicitly a difference of embedded naturals. -/
theorem generated_by_natural_difference (x : ZSigned) :
    ∃ a b : BOMANat, x = zadd (embedN a) (zneg (embedN b)) := by
  cases x with
  | zero => exact ⟨z, z, rfl⟩
  | pos n => exact ⟨s n, z, rfl⟩
  | neg n => exact ⟨z, s n, rfl⟩

end BOMA.Z.Arithmetic001

/- Direct sign/magnitude order route on the selected signed carrier. -/
namespace BOMA.Z.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- Direct signed order. The payload of `pos a`/`neg a` is the predecessor
of the positive magnitude, so same-sign comparison uses the accepted N order
on those payloads; the negative case reverses it. -/
def zLEd : ZSigned → ZSigned → Prop
  | neg a, neg b => LE b a
  | neg _, zero => True
  | neg _, pos _ => True
  | zero, neg _ => False
  | zero, zero => True
  | zero, pos _ => True
  | pos _, neg _ => False
  | pos _, zero => False
  | pos a, pos b => LE a b

end BOMA.Z.Order001

/- Pair cross-sum order route. -/
namespace BOMA.Z.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001

/-- Order of represented differences: p-n ≤ q-m iff p+m ≤ q+n. -/
def pairLE (x y : ZPair) : Prop :=
  LE (add x.p y.n) (add y.p x.n)

/-- Pull the pair order back to the selected signed carrier. -/
def zLEp (x y : ZSigned) : Prop :=
  pairLE (pairOfSigned x) (pairOfSigned y)

end BOMA.Z.Order001

/- Convergence of direct signed order and pair cross-sum order. -/
namespace BOMA.Z.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- The direct sign/magnitude order and pair cross-sum order agree pointwise.

The proof is deliberately case-explicit. Earlier `simp`-based closure rewrote
Iff-valued order lemmas through proposition extensionality. Here every Iff is
consumed with `.mp`/`.mpr`, so convergence itself does not require `propext`. -/
theorem zorder_routes_converge (x y : ZSigned) : zLEd x y ↔ zLEp x y := by
  cases x with
  | zero =>
      cases y with
      | zero =>
          change True ↔ LE z z
          constructor
          · intro _
            exact le_refl z
          · intro _
            exact True.intro
      | pos b =>
          change True ↔ LE z (s b)
          constructor
          · intro _
            exact z_le (s b)
          · intro _
            exact True.intro
      | neg b =>
          change False ↔ LE (s (add z b)) z
          constructor
          · intro h
            exact False.elim h
          · intro h
            exact (not_s_le_z (add z b)) h
  | pos a =>
      cases y with
      | zero =>
          change False ↔ LE (s a) z
          constructor
          · intro h
            exact False.elim h
          · intro h
            exact (not_s_le_z a) h
      | pos b =>
          change LE a b ↔ LE (s a) (s b)
          exact le_s_iff.symm
      | neg b =>
          change False ↔ LE (s (add (s a) b)) z
          constructor
          · intro h
            exact False.elim h
          · intro h
            exact (not_s_le_z (add (s a) b)) h
  | neg a =>
      cases y with
      | zero =>
          change True ↔ LE z (s (add z a))
          constructor
          · intro _
            exact z_le (s (add z a))
          · intro _
            exact True.intro
      | pos b =>
          change True ↔ LE z (s (add (s b) a))
          constructor
          · intro _
            exact z_le (s (add (s b) a))
          · intro _
            exact True.intro
      | neg b =>
          change LE b a ↔ LE (s (add z b)) (s (add z a))
          constructor
          · intro h
            apply le_s_iff.mpr
            rw [add_z_left b, add_z_left a]
            exact h
          · intro h
            have hbase : LE (add z b) (add z a) := le_s_iff.mp h
            rw [add_z_left b, add_z_left a] at hbase
            exact hbase

end BOMA.Z.Order001

/- Canonical integer order laws after direct/pair route convergence. -/
namespace BOMA.Z.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- Canonical integer order spelling after route convergence. -/
def zLE : ZSigned → ZSigned → Prop := zLEd

def NonNeg (x : ZSigned) : Prop := zLE zzero x

/-- Canonical order is exactly the pair cross-sum order on canonical representatives. -/
theorem zle_iff_pair (x y : ZSigned) :
    zLE x y ↔ pairLE (pairOfSigned x) (pairOfSigned y) := by
  change zLEd x y ↔ zLEp x y
  exact zorder_routes_converge x y

/-- Natural-order cancellation by a common right addend. -/
theorem n_le_cancel_right {a b c : BOMANat}
    (h : LE (add a c) (add b c)) : LE a b := by
  change LEAdd (add a c) (add b c) at h
  change LEAdd a b
  rcases h with ⟨k, hk⟩
  refine ⟨k, ?_⟩
  apply add_right_cancel (add a k) b c
  calc
    add (add a k) c = add a (add k c) := add_assoc a k c
    _ = add a (add c k) := congrArg (fun t => add a t) (add_comm k c)
    _ = add (add a c) k := (add_assoc a c k).symm
    _ = add b c := hk

/-- Pair cross-sum order is invariant when its left representative changes within `~`. -/
theorem pairLE_respects_left {x x' y : ZPair}
    (hx : ZEquiv x x') (h : pairLE x y) : pairLE x' y := by
  cases x with
  | mk a b =>
    cases x' with
    | mk c d =>
      cases y with
      | mk e f =>
        change add a d = add c b at hx
        change LE (add a f) (add e b) at h
        change LE (add c f) (add e d)
        have hm : LE (add (add a f) d) (add (add e b) d) :=
          add_mono_right h d
        have hl : add (add a f) d = add (add c f) b := by
          calc
            add (add a f) d = add a (add f d) := add_assoc a f d
            _ = add a (add d f) := congrArg (fun t => add a t) (add_comm f d)
            _ = add (add a d) f := (add_assoc a d f).symm
            _ = add (add c b) f := congrArg (fun t => add t f) hx
            _ = add c (add b f) := add_assoc c b f
            _ = add c (add f b) := congrArg (fun t => add c t) (add_comm b f)
            _ = add (add c f) b := (add_assoc c f b).symm
        have hr : add (add e b) d = add (add e d) b := by
          calc
            add (add e b) d = add e (add b d) := add_assoc e b d
            _ = add e (add d b) := congrArg (fun t => add e t) (add_comm b d)
            _ = add (add e d) b := (add_assoc e d b).symm
        rw [hl, hr] at hm
        exact n_le_cancel_right hm

/-- Negation of pair representatives reverses pair order. -/
theorem pairLE_neg_flip (x y : ZPair) :
    pairLE x y ↔ pairLE (pairNeg y) (pairNeg x) := by
  cases x with
  | mk a b =>
    cases y with
    | mk c d =>
      simp [pairLE, pairNeg, add_comm]

/-- Pair cross-sum order is invariant when its right representative changes within `~`. -/
theorem pairLE_respects_right {x y y' : ZPair}
    (hy : ZEquiv y y') (h : pairLE x y) : pairLE x y' := by
  have hflip : pairLE (pairNeg y) (pairNeg x) :=
    (pairLE_neg_flip x y).mp h
  have hchanged : pairLE (pairNeg y') (pairNeg x) :=
    pairLE_respects_left (pairNeg_respects hy) hflip
  exact (pairLE_neg_flip x y').mpr hchanged

theorem pairLE_respects {x x' y y' : ZPair}
    (hx : ZEquiv x x') (hy : ZEquiv y y') (h : pairLE x y) : pairLE x' y' :=
  pairLE_respects_right hy (pairLE_respects_left hx h)

/-- The canonical pair of an embedded natural is exactly `(n,0)`. -/
theorem pairOfSigned_embedN (n : BOMANat) :
    pairOfSigned (embedN n) = ⟨n, z⟩ := by
  cases n <;> rfl

/-- Every pair is below itself plus an embedded natural gap. -/
theorem pairLE_add_embedded (x : ZPair) (k : BOMANat) :
    pairLE x (pairAdd x (pairOfSigned (embedN k))) := by
  rw [pairOfSigned_embedN]
  cases x with
  | mk a b =>
    change LE (add a (add b z)) (add (add a k) b)
    change LEAdd (add a b) (add (add a k) b)
    refine ⟨k, ?_⟩
    calc
      add (add a b) k = add a (add b k) := add_assoc a b k
      _ = add a (add k b) := congrArg (fun t => add a t) (add_comm b k)
      _ = add (add a k) b := (add_assoc a k b).symm

/-- Pair cross-sum order itself has an explicit natural-gap witness. -/
theorem pairLE_to_gap {x y : ZSigned}
    (h : pairLE (pairOfSigned x) (pairOfSigned y)) :
    ∃ k : BOMANat, zadd x (embedN k) = y := by
  change LEAdd
    (add (pairOfSigned x).p (pairOfSigned y).n)
    (add (pairOfSigned y).p (pairOfSigned x).n) at h
  rcases h with ⟨k, hk⟩
  refine ⟨k, ?_⟩
  apply signed_eq_of_pair_equiv
  have hs := zadd_pair_semantics x (embedN k)
  have hrel : ZEquiv
      (pairAdd (pairOfSigned x) (pairOfSigned (embedN k)))
      (pairOfSigned y) := by
    rw [pairOfSigned_embedN]
    change add (add (pairOfSigned x).p k) (pairOfSigned y).n =
      add (pairOfSigned y).p (add (pairOfSigned x).n z)
    calc
      add (add (pairOfSigned x).p k) (pairOfSigned y).n =
          add (add (pairOfSigned x).p (pairOfSigned y).n) k := by
            rw [add_assoc, add_assoc]
            exact congrArg (fun t => add (pairOfSigned x).p t)
              (add_comm k (pairOfSigned y).n)
      _ = add (pairOfSigned y).p (pairOfSigned x).n := hk
      _ = add (pairOfSigned y).p (add (pairOfSigned x).n z) := by
        rw [add_z_right]
  exact zeq_trans hs hrel

/-- Integer order is equivalent to existence of an embedded natural additive gap. -/
theorem zle_iff_natural_gap (x y : ZSigned) :
    zLE x y ↔ ∃ k : BOMANat, zadd x (embedN k) = y := by
  constructor
  · intro h
    exact pairLE_to_gap ((zle_iff_pair x y).mp h)
  · rintro ⟨k, hk⟩
    have hp : pairLE (pairOfSigned x)
        (pairAdd (pairOfSigned x) (pairOfSigned (embedN k))) :=
      pairLE_add_embedded (pairOfSigned x) k
    have hs := zadd_pair_semantics x (embedN k)
    have hp' : pairLE (pairOfSigned x) (pairOfSigned (zadd x (embedN k))) :=
      pairLE_respects_right (zeq_symm hs) hp
    have hz : zLE x (zadd x (embedN k)) := (zle_iff_pair _ _).mpr hp'
    rw [hk] at hz
    exact hz

theorem zle_refl (x : ZSigned) : zLE x x := by
  apply (zle_iff_natural_gap x x).mpr
  exact ⟨z, by simp [embedN_zero]⟩

theorem zle_trans {x y w : ZSigned} (hxy : zLE x y) (hyw : zLE y w) : zLE x w := by
  rcases (zle_iff_natural_gap x y).mp hxy with ⟨k, hk⟩
  rcases (zle_iff_natural_gap y w).mp hyw with ⟨l, hl⟩
  apply (zle_iff_natural_gap x w).mpr
  refine ⟨add k l, ?_⟩
  calc
    zadd x (embedN (add k l)) = zadd x (zadd (embedN k) (embedN l)) :=
      congrArg (fun t => zadd x t) (embedN_add k l)
    _ = zadd (zadd x (embedN k)) (embedN l) := (zadd_assoc x (embedN k) (embedN l)).symm
    _ = zadd y (embedN l) := congrArg (fun t => zadd t (embedN l)) hk
    _ = w := hl

theorem zle_antisymm {x y : ZSigned} (hxy : zLE x y) (hyx : zLE y x) : x = y := by
  cases x with
  | zero =>
      cases y with
      | zero => rfl
      | pos b =>
          change False at hyx
          contradiction
      | neg b =>
          change False at hxy
          contradiction
  | pos a =>
      cases y with
      | zero =>
          change False at hxy
          contradiction
      | neg b =>
          change False at hxy
          contradiction
      | pos b =>
          change LE a b at hxy
          change LE b a at hyx
          exact congrArg pos (le_antisymm hxy hyx)
  | neg a =>
      cases y with
      | zero =>
          change False at hyx
          contradiction
      | pos b =>
          change False at hyx
          contradiction
      | neg b =>
          change LE b a at hxy
          change LE a b at hyx
          exact congrArg neg (le_antisymm hyx hxy)

theorem zle_total (x y : ZSigned) : zLE x y ∨ zLE y x := by
  cases x with
  | zero =>
      cases y with
      | zero => exact Or.inl True.intro
      | pos b => exact Or.inl True.intro
      | neg b => exact Or.inr True.intro
  | pos a =>
      cases y with
      | zero => exact Or.inr True.intro
      | neg b => exact Or.inr True.intro
      | pos b => exact le_total a b
  | neg a =>
      cases y with
      | zero => exact Or.inl True.intro
      | pos b => exact Or.inl True.intro
      | neg b => exact le_total b a

/-- The selected integer order exactly extends the accepted natural order.
The proof is case-explicit so the Iff-valued successor-order lemma is consumed
by `.mp`/`.mpr` instead of being used as a simp rewrite through `propext`. -/
theorem embedN_order (a b : BOMANat) :
    zLE (embedN a) (embedN b) ↔ LE a b := by
  cases a with
  | z =>
      cases b with
      | z =>
          change True ↔ LE z z
          constructor
          · intro _
            exact le_refl z
          · intro _
            exact True.intro
      | s b =>
          change True ↔ LE z (s b)
          constructor
          · intro _
            exact z_le (s b)
          · intro _
            exact True.intro
  | s a =>
      cases b with
      | z =>
          change False ↔ LE (s a) z
          constructor
          · intro h
            exact False.elim h
          · intro h
            exact (not_s_le_z a) h
      | s b =>
          change LE a b ↔ LE (s a) (s b)
          exact le_s_iff.symm

/-- Translation invariance / right addition monotonicity. -/
theorem zadd_mono_right {x y : ZSigned} (h : zLE x y) (c : ZSigned) :
    zLE (zadd x c) (zadd y c) := by
  rcases (zle_iff_natural_gap x y).mp h with ⟨k, hk⟩
  apply (zle_iff_natural_gap _ _).mpr
  refine ⟨k, ?_⟩
  calc
    zadd (zadd x c) (embedN k) = zadd x (zadd c (embedN k)) := zadd_assoc x c (embedN k)
    _ = zadd x (zadd (embedN k) c) :=
      congrArg (fun t => zadd x t) (zadd_comm c (embedN k))
    _ = zadd (zadd x (embedN k)) c := (zadd_assoc x (embedN k) c).symm
    _ = zadd y c := congrArg (fun t => zadd t c) hk

theorem zadd_mono_left {x y : ZSigned} (h : zLE x y) (c : ZSigned) :
    zLE (zadd c x) (zadd c y) := by
  simpa [zadd_comm c x, zadd_comm c y] using zadd_mono_right h c

/-- Negation reverses order. -/
theorem zneg_reverses {x y : ZSigned} (h : zLE x y) :
    zLE (zneg y) (zneg x) := by
  cases x <;> cases y <;> simp_all [zLE, zLEd, zneg]

/-- Nonnegative signed integers are exactly embedded naturals. -/
theorem nonneg_is_embedded (c : ZSigned) (h : NonNeg c) :
    ∃ n : BOMANat, c = embedN n := by
  cases c with
  | zero => exact ⟨z, rfl⟩
  | pos n => exact ⟨s n, rfl⟩
  | neg n =>
      change False at h
      contradiction

/-- Multiplication by a nonnegative integer preserves order on the right. -/
theorem zmul_mono_right_nonneg {x y c : ZSigned}
    (hxy : zLE x y) (hc : NonNeg c) :
    zLE (zmul x c) (zmul y c) := by
  rcases (zle_iff_natural_gap x y).mp hxy with ⟨k, hk⟩
  rcases nonneg_is_embedded c hc with ⟨m, rfl⟩
  apply (zle_iff_natural_gap _ _).mpr
  refine ⟨mul k m, ?_⟩
  calc
    zadd (zmul x (embedN m)) (embedN (mul k m)) =
        zadd (zmul x (embedN m)) (zmul (embedN k) (embedN m)) :=
      congrArg (fun t => zadd (zmul x (embedN m)) t) (embedN_mul k m)
    _ = zmul (zadd x (embedN k)) (embedN m) :=
      (zmul_add_left x (embedN k) (embedN m)).symm
    _ = zmul y (embedN m) := congrArg (fun t => zmul t (embedN m)) hk

theorem zmul_mono_left_nonneg {x y c : ZSigned}
    (hxy : zLE x y) (hc : NonNeg c) :
    zLE (zmul c x) (zmul c y) := by
  simpa [zmul_comm c x, zmul_comm c y] using zmul_mono_right_nonneg hxy hc

end BOMA.Z.Order001

/- Pre-rational gateway: derive no-zero-divisor and nonzero cancellation
   from the accepted BOMA N/Z packages before fraction equivalence is formed. -/
namespace BOMA.Q.Gateway001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- A natural sum can be zero only when both summands are zero. -/
theorem n_add_eq_zero {a b : BOMANat} (h : add a b = z) : a = z ∧ b = z := by
  cases b with
  | z =>
      change a = z at h
      exact ⟨h, rfl⟩
  | s b =>
      change s (add a b) = z at h
      exact False.elim (s_ne_z (add a b) h)

/-- No zero divisors for the accepted natural multiplication. -/
theorem n_mul_eq_zero {a b : BOMANat} (h : mul a b = z) : a = z ∨ b = z := by
  cases b with
  | z => exact Or.inr rfl
  | s b =>
      change add (mul a b) a = z at h
      exact Or.inl (n_add_eq_zero h).2

/-- A product of two natural successors is nonzero. -/
theorem n_mul_succ_succ_ne_zero (a b : BOMANat) : mul (s a) (s b) ≠ z := by
  intro h
  rcases n_mul_eq_zero h with ha | hb
  · exact s_ne_z a ha
  · exact s_ne_z b hb

/-- A nonzero natural embeds to a nonzero selected integer. -/
theorem embedN_ne_zero_of_ne {n : BOMANat} (hn : n ≠ z) : embedN n ≠ zzero := by
  cases n with
  | z => exact False.elim (hn rfl)
  | s n =>
      intro h
      cases h

/-- Its signed negation is also nonzero. -/
theorem neg_embedN_ne_zero_of_ne {n : BOMANat} (hn : n ≠ z) :
    zneg (embedN n) ≠ zzero := by
  cases n with
  | z => exact False.elim (hn rfl)
  | s n =>
      intro h
      cases h

/-- Accepted integer multiplication has no zero divisors. -/
theorem zmul_eq_zero {x y : ZSigned} (h : zmul x y = zzero) :
    x = zzero ∨ y = zzero := by
  cases x with
  | zero => exact Or.inl rfl
  | pos a =>
      cases y with
      | zero => exact Or.inr rfl
      | pos b =>
          change embedN (mul (s a) (s b)) = zzero at h
          exact False.elim (embedN_ne_zero_of_ne (n_mul_succ_succ_ne_zero a b) h)
      | neg b =>
          change zneg (embedN (mul (s a) (s b))) = zzero at h
          exact False.elim (neg_embedN_ne_zero_of_ne (n_mul_succ_succ_ne_zero a b) h)
  | neg a =>
      cases y with
      | zero => exact Or.inr rfl
      | pos b =>
          change zneg (embedN (mul (s a) (s b))) = zzero at h
          exact False.elim (neg_embedN_ne_zero_of_ne (n_mul_succ_succ_ne_zero a b) h)
      | neg b =>
          change embedN (mul (s a) (s b)) = zzero at h
          exact False.elim (embedN_ne_zero_of_ne (n_mul_succ_succ_ne_zero a b) h)

/-- Left cancellation in the accepted additive group. -/
theorem zadd_left_cancel {a b c : ZSigned}
    (h : zadd a b = zadd a c) : b = c := by
  have h' := congrArg (fun t => zadd (zneg a) t) h
  calc
    b = zadd zzero b := (zadd_zero_left b).symm
    _ = zadd (zadd (zneg a) a) b := by rw [zadd_neg_left]
    _ = zadd (zneg a) (zadd a b) := zadd_assoc (zneg a) a b
    _ = zadd (zneg a) (zadd a c) := h'
    _ = zadd (zadd (zneg a) a) c := (zadd_assoc (zneg a) a c).symm
    _ = zadd zzero c := by rw [zadd_neg_left]
    _ = c := zadd_zero_left c

/-- Right cancellation in the accepted additive group. -/
theorem zadd_right_cancel {a b c : ZSigned}
    (h : zadd a c = zadd b c) : a = b := by
  apply zadd_left_cancel (a := c)
  calc
    zadd c a = zadd a c := zadd_comm c a
    _ = zadd b c := h
    _ = zadd c b := zadd_comm b c

/-- Any additive inverse is the selected negation. -/
theorem additive_inverse_unique {x y : ZSigned}
    (h : zadd x y = zzero) : y = zneg x := by
  apply zadd_left_cancel (a := x)
  calc
    zadd x y = zzero := h
    _ = zadd x (zneg x) := (zadd_neg_right x).symm

/-- Multiplication by a negated left factor is the negation of the product. -/
theorem zmul_neg_left (x c : ZSigned) :
    zmul (zneg x) c = zneg (zmul x c) := by
  apply additive_inverse_unique (x := zmul x c)
  calc
    zadd (zmul x c) (zmul (zneg x) c) =
        zmul (zadd x (zneg x)) c := (zmul_add_left x (zneg x) c).symm
    _ = zmul zzero c := congrArg (fun t => zmul t c) (zadd_neg_right x)
    _ = zzero := zmul_zero_left c

/-- Multiplication by a negated right factor. -/
theorem zmul_neg_right (x c : ZSigned) :
    zmul x (zneg c) = zneg (zmul x c) := by
  calc
    zmul x (zneg c) = zmul (zneg c) x := zmul_comm x (zneg c)
    _ = zneg (zmul c x) := zmul_neg_left c x
    _ = zneg (zmul x c) := congrArg zneg (zmul_comm c x)

/-- QG-01: cancellation by a nonzero right integer factor. -/
theorem zmul_right_cancel_nonzero {a b c : ZSigned}
    (hc : c ≠ zzero) (h : zmul a c = zmul b c) : a = b := by
  have hzero : zmul (zadd a (zneg b)) c = zzero := by
    calc
      zmul (zadd a (zneg b)) c =
          zadd (zmul a c) (zmul (zneg b) c) := zmul_add_left a (zneg b) c
      _ = zadd (zmul a c) (zneg (zmul b c)) :=
          congrArg (fun t => zadd (zmul a c) t) (zmul_neg_left b c)
      _ = zadd (zmul b c) (zneg (zmul b c)) :=
          congrArg (fun t => zadd t (zneg (zmul b c))) h
      _ = zzero := zadd_neg_right (zmul b c)
  rcases zmul_eq_zero hzero with hab | hc0
  · apply zadd_right_cancel (c := zneg b)
    calc
      zadd a (zneg b) = zzero := hab
      _ = zadd b (zneg b) := (zadd_neg_right b).symm
  · exact False.elim (hc hc0)

/-- Left-factor cancellation follows from commutativity. -/
theorem zmul_left_cancel_nonzero {a b c : ZSigned}
    (hc : c ≠ zzero) (h : zmul c a = zmul c b) : a = b := by
  apply zmul_right_cancel_nonzero hc
  calc
    zmul a c = zmul c a := zmul_comm a c
    _ = zmul c b := h
    _ = zmul b c := zmul_comm c b

/-- Product nonzeroness, the convenient fraction-denominator form. -/
theorem zmul_ne_zero {a b : ZSigned} (ha : a ≠ zzero) (hb : b ≠ zzero) :
    zmul a b ≠ zzero := by
  intro h
  rcases zmul_eq_zero h with ha0 | hb0
  · exact ha ha0
  · exact hb hb0

end BOMA.Q.Gateway001

/- Rational Route F: raw integer fractions with structurally positive natural denominators.
   No quotient carrier is formed in this file. -/
namespace BOMA.Q.Fraction001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Q.Gateway001

/-- A denominator is positive by syntax: its natural value is always `s pred`.
This avoids a proof-bearing `d ≠ 0` field and prevents signed-denominator duplication. -/
structure PosDen where
  pred : BOMANat

/-- Positive natural denominator value. -/
def denNat (d : PosDen) : BOMANat := s d.pred

/-- Denominator interpreted in the accepted integer carrier. -/
def denZ (d : PosDen) : ZSigned := embedN (denNat d)

/-- Every structurally positive denominator is nonzero in Z. -/
theorem denZ_ne_zero (d : PosDen) : denZ d ≠ zzero := by
  apply embedN_ne_zero_of_ne
  exact s_ne_z d.pred

/-- Raw valid fraction representation. -/
structure RawFrac where
  num : ZSigned
  den : PosDen

/-- Cross-product representation equivalence. -/
def FracEquiv (x y : RawFrac) : Prop :=
  zmul x.num (denZ y.den) = zmul y.num (denZ x.den)

/-- Swap the last two factors in a triple product. -/
theorem zmul_swap_last (a b c : ZSigned) :
    zmul (zmul a b) c = zmul (zmul a c) b := by
  calc
    zmul (zmul a b) c = zmul a (zmul b c) := zmul_assoc a b c
    _ = zmul a (zmul c b) := congrArg (fun t => zmul a t) (zmul_comm b c)
    _ = zmul (zmul a c) b := (zmul_assoc a c b).symm

theorem frac_refl (x : RawFrac) : FracEquiv x x := rfl

theorem frac_symm {x y : RawFrac} (h : FracEquiv x y) : FracEquiv y x :=
  h.symm

/-- Transitivity is exactly where the pre-rational nonzero cancellation gateway
is consumed. It is not a free property of cross multiplication. -/
theorem frac_trans {x y w : RawFrac}
    (hxy : FracEquiv x y) (hyw : FracEquiv y w) : FracEquiv x w := by
  change zmul x.num (denZ y.den) = zmul y.num (denZ x.den) at hxy
  change zmul y.num (denZ w.den) = zmul w.num (denZ y.den) at hyw
  change zmul x.num (denZ w.den) = zmul w.num (denZ x.den)
  have h1 := congrArg (fun t => zmul t (denZ w.den)) hxy
  have h2 := congrArg (fun t => zmul t (denZ x.den)) hyw
  apply zmul_right_cancel_nonzero (denZ_ne_zero y.den)
  calc
    zmul (zmul x.num (denZ w.den)) (denZ y.den) =
        zmul (zmul x.num (denZ y.den)) (denZ w.den) :=
      (zmul_swap_last x.num (denZ y.den) (denZ w.den)).symm
    _ = zmul (zmul y.num (denZ x.den)) (denZ w.den) := h1
    _ = zmul (zmul y.num (denZ w.den)) (denZ x.den) :=
      zmul_swap_last y.num (denZ x.den) (denZ w.den)
    _ = zmul (zmul w.num (denZ y.den)) (denZ x.den) := h2
    _ = zmul (zmul w.num (denZ x.den)) (denZ y.den) :=
      zmul_swap_last w.num (denZ y.den) (denZ x.den)

/-- Integer embedding into raw fractions uses denominator 1. -/
def oneDen : PosDen := ⟨z⟩

def fracOfZ (a : ZSigned) : RawFrac := ⟨a, oneDen⟩

@[simp] theorem denNat_one : denNat oneDen = s z := rfl
@[simp] theorem denZ_one : denZ oneDen = zone := rfl

/-- The raw-fraction embedding is faithful modulo fraction equivalence. -/
theorem fracOfZ_reflects {a b : ZSigned}
    (h : FracEquiv (fracOfZ a) (fracOfZ b)) : a = b := by
  change zmul a zone = zmul b zone at h
  calc
    a = zmul a zone := (zmul_one_right a).symm
    _ = zmul b zone := h
    _ = b := zmul_one_right b

/-- Exact preservation of equality by the raw-fraction embedding. -/
theorem fracOfZ_preserves {a b : ZSigned} (h : a = b) :
    FracEquiv (fracOfZ a) (fracOfZ b) := by
  cases h
  exact frac_refl _

end BOMA.Q.Fraction001

/- Arithmetic on raw valid rational fractions, before any quotient identity commitment. -/
namespace BOMA.Q.Fraction001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- Multiplication of structurally positive denominators remains structurally positive. -/
def denMul (d e : PosDen) : PosDen :=
  ⟨add (mul (s d.pred) e.pred) d.pred⟩

/-- The denominator syntax computes exactly to natural multiplication. -/
theorem denNat_mul (d e : PosDen) :
    denNat (denMul d e) = mul (denNat d) (denNat e) := by
  rfl

/-- Integer interpretation of denominator multiplication. -/
theorem denZ_mul (d e : PosDen) :
    denZ (denMul d e) = zmul (denZ d) (denZ e) := by
  change embedN (denNat (denMul d e)) = zmul (embedN (denNat d)) (embedN (denNat e))
  rw [denNat_mul]
  exact embedN_mul (denNat d) (denNat e)

/-- Raw rational zero and one. -/
def rawZero : RawFrac := fracOfZ zzero
def rawOne : RawFrac := fracOfZ zone

/-- Raw negation. -/
def rawNeg (x : RawFrac) : RawFrac := ⟨zneg x.num, x.den⟩

/-- Standard cross-denominator raw addition. -/
def rawAdd (x y : RawFrac) : RawFrac :=
  ⟨zadd (zmul x.num (denZ y.den))
         (zmul y.num (denZ x.den)),
   denMul x.den y.den⟩

/-- Standard raw multiplication. -/
def rawMul (x y : RawFrac) : RawFrac :=
  ⟨zmul x.num y.num, denMul x.den y.den⟩

/-- Four-factor interchange in the accepted commutative multiplication. -/
theorem zmul4_swap_middle (a b c d : ZSigned) :
    zmul (zmul a b) (zmul c d) =
    zmul (zmul a c) (zmul b d) := by
  calc
    zmul (zmul a b) (zmul c d) = zmul a (zmul b (zmul c d)) :=
      zmul_assoc a b (zmul c d)
    _ = zmul a (zmul (zmul b c) d) :=
      congrArg (fun t => zmul a t) (zmul_assoc b c d).symm
    _ = zmul a (zmul (zmul c b) d) :=
      congrArg (fun t => zmul a (zmul t d)) (zmul_comm b c)
    _ = zmul a (zmul c (zmul b d)) :=
      congrArg (fun t => zmul a t) (zmul_assoc c b d)
    _ = zmul (zmul a c) (zmul b d) :=
      (zmul_assoc a c (zmul b d)).symm

/-- Raw negation respects fraction equivalence. -/
theorem rawNeg_respects {x y : RawFrac} (h : FracEquiv x y) :
    FracEquiv (rawNeg x) (rawNeg y) := by
  change zmul (zneg x.num) (denZ y.den) =
    zmul (zneg y.num) (denZ x.den)
  calc
    zmul (zneg x.num) (denZ y.den) = zneg (zmul x.num (denZ y.den)) :=
      BOMA.Q.Gateway001.zmul_neg_left x.num (denZ y.den)
    _ = zneg (zmul y.num (denZ x.den)) := congrArg zneg h
    _ = zmul (zneg y.num) (denZ x.den) :=
      (BOMA.Q.Gateway001.zmul_neg_left y.num (denZ x.den)).symm

/-- Raw multiplication respects fraction equivalence in both arguments. -/
theorem rawMul_respects {x x' y y' : RawFrac}
    (hx : FracEquiv x x') (hy : FracEquiv y y') :
    FracEquiv (rawMul x y) (rawMul x' y') := by
  change zmul x.num (denZ x'.den) = zmul x'.num (denZ x.den) at hx
  change zmul y.num (denZ y'.den) = zmul y'.num (denZ y.den) at hy
  change
    zmul (zmul x.num y.num) (denZ (denMul x'.den y'.den)) =
    zmul (zmul x'.num y'.num) (denZ (denMul x.den y.den))
  rw [denZ_mul, denZ_mul]
  calc
    zmul (zmul x.num y.num) (zmul (denZ x'.den) (denZ y'.den)) =
        zmul (zmul x.num (denZ x'.den)) (zmul y.num (denZ y'.den)) :=
      zmul4_swap_middle x.num y.num (denZ x'.den) (denZ y'.den)
    _ = zmul (zmul x'.num (denZ x.den)) (zmul y.num (denZ y'.den)) :=
      congrArg (fun t => zmul t (zmul y.num (denZ y'.den))) hx
    _ = zmul (zmul x'.num (denZ x.den)) (zmul y'.num (denZ y.den)) :=
      congrArg (fun t => zmul (zmul x'.num (denZ x.den)) t) hy
    _ = zmul (zmul x'.num y'.num) (zmul (denZ x.den) (denZ y.den)) :=
      zmul4_swap_middle x'.num (denZ x.den) y'.num (denZ y.den)

/-- First scaled numerator term used in addition well-definedness. -/
theorem rawAdd_term_left {x x' y y' : RawFrac}
    (hx : FracEquiv x x') :
    zmul (zmul x.num (denZ y.den))
      (zmul (denZ x'.den) (denZ y'.den)) =
    zmul (zmul x'.num (denZ y'.den))
      (zmul (denZ x.den) (denZ y.den)) := by
  change zmul x.num (denZ x'.den) = zmul x'.num (denZ x.den) at hx
  calc
    zmul (zmul x.num (denZ y.den))
        (zmul (denZ x'.den) (denZ y'.den)) =
      zmul (zmul x.num (denZ x'.den))
        (zmul (denZ y.den) (denZ y'.den)) :=
      zmul4_swap_middle x.num (denZ y.den) (denZ x'.den) (denZ y'.den)
    _ = zmul (zmul x'.num (denZ x.den))
        (zmul (denZ y.den) (denZ y'.den)) :=
      congrArg (fun t => zmul t (zmul (denZ y.den) (denZ y'.den))) hx
    _ = zmul (zmul x'.num (denZ x.den))
        (zmul (denZ y'.den) (denZ y.den)) :=
      congrArg (fun t => zmul (zmul x'.num (denZ x.den)) t)
        (zmul_comm (denZ y.den) (denZ y'.den))
    _ = zmul (zmul x'.num (denZ y'.den))
        (zmul (denZ x.den) (denZ y.den)) :=
      zmul4_swap_middle x'.num (denZ x.den) (denZ y'.den) (denZ y.den)

/-- Second scaled numerator term used in addition well-definedness. -/
theorem rawAdd_term_right {x x' y y' : RawFrac}
    (hy : FracEquiv y y') :
    zmul (zmul y.num (denZ x.den))
      (zmul (denZ x'.den) (denZ y'.den)) =
    zmul (zmul y'.num (denZ x'.den))
      (zmul (denZ x.den) (denZ y.den)) := by
  change zmul y.num (denZ y'.den) = zmul y'.num (denZ y.den) at hy
  calc
    zmul (zmul y.num (denZ x.den))
        (zmul (denZ x'.den) (denZ y'.den)) =
      zmul (zmul y.num (denZ x.den))
        (zmul (denZ y'.den) (denZ x'.den)) :=
      congrArg (fun t => zmul (zmul y.num (denZ x.den)) t)
        (zmul_comm (denZ x'.den) (denZ y'.den))
    _ = zmul (zmul y.num (denZ y'.den))
        (zmul (denZ x.den) (denZ x'.den)) :=
      zmul4_swap_middle y.num (denZ x.den) (denZ y'.den) (denZ x'.den)
    _ = zmul (zmul y'.num (denZ y.den))
        (zmul (denZ x.den) (denZ x'.den)) :=
      congrArg (fun t => zmul t (zmul (denZ x.den) (denZ x'.den))) hy
    _ = zmul (zmul y'.num (denZ y.den))
        (zmul (denZ x'.den) (denZ x.den)) :=
      congrArg (fun t => zmul (zmul y'.num (denZ y.den)) t)
        (zmul_comm (denZ x.den) (denZ x'.den))
    _ = zmul (zmul y'.num (denZ x'.den))
        (zmul (denZ y.den) (denZ x.den)) :=
      zmul4_swap_middle y'.num (denZ y.den) (denZ x'.den) (denZ x.den)
    _ = zmul (zmul y'.num (denZ x'.den))
        (zmul (denZ x.den) (denZ y.den)) :=
      congrArg (fun t => zmul (zmul y'.num (denZ x'.den)) t)
        (zmul_comm (denZ y.den) (denZ x.den))

/-- Raw addition respects fraction equivalence in both arguments. -/
theorem rawAdd_respects {x x' y y' : RawFrac}
    (hx : FracEquiv x x') (hy : FracEquiv y y') :
    FracEquiv (rawAdd x y) (rawAdd x' y') := by
  change
    zmul
      (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
      (denZ (denMul x'.den y'.den)) =
    zmul
      (zadd (zmul x'.num (denZ y'.den)) (zmul y'.num (denZ x'.den)))
      (denZ (denMul x.den y.den))
  rw [denZ_mul, denZ_mul]
  calc
    zmul
        (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
        (zmul (denZ x'.den) (denZ y'.den)) =
      zadd
        (zmul (zmul x.num (denZ y.den))
          (zmul (denZ x'.den) (denZ y'.den)))
        (zmul (zmul y.num (denZ x.den))
          (zmul (denZ x'.den) (denZ y'.den))) :=
      zmul_add_left
        (zmul x.num (denZ y.den))
        (zmul y.num (denZ x.den))
        (zmul (denZ x'.den) (denZ y'.den))
    _ = zadd
        (zmul (zmul x'.num (denZ y'.den))
          (zmul (denZ x.den) (denZ y.den)))
        (zmul (zmul y.num (denZ x.den))
          (zmul (denZ x'.den) (denZ y'.den))) :=
      congrArg
        (fun t => zadd t
          (zmul (zmul y.num (denZ x.den))
            (zmul (denZ x'.den) (denZ y'.den))))
        (rawAdd_term_left hx)
    _ = zadd
        (zmul (zmul x'.num (denZ y'.den))
          (zmul (denZ x.den) (denZ y.den)))
        (zmul (zmul y'.num (denZ x'.den))
          (zmul (denZ x.den) (denZ y.den))) :=
      congrArg
        (fun t => zadd
          (zmul (zmul x'.num (denZ y'.den))
            (zmul (denZ x.den) (denZ y.den))) t)
        (rawAdd_term_right hy)
    _ = zmul
        (zadd (zmul x'.num (denZ y'.den)) (zmul y'.num (denZ x'.den)))
        (zmul (denZ x.den) (denZ y.den)) :=
      (zmul_add_left
        (zmul x'.num (denZ y'.den))
        (zmul y'.num (denZ x'.den))
        (zmul (denZ x.den) (denZ y.den))).symm

end BOMA.Q.Fraction001

/- Additive laws on raw fractions modulo FracEquiv, before quotient lifting. -/
namespace BOMA.Q.Fraction001

open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- Raw zero is a left additive identity modulo fraction equivalence. -/
theorem rawAdd_zero_left_equiv (x : RawFrac) :
    FracEquiv (rawAdd rawZero x) x := by
  change
    zmul
      (zadd (zmul zzero (denZ x.den)) (zmul x.num zone))
      (denZ x.den) =
    zmul x.num (denZ (denMul oneDen x.den))
  rw [zmul_zero_left, zmul_one_right, zadd_zero_left, denZ_mul, denZ_one, zmul_one_left]

/-- Raw zero is a right identity modulo equivalence. -/
theorem rawAdd_zero_right_equiv (x : RawFrac) :
    FracEquiv (rawAdd x rawZero) x := by
  change
    zmul
      (zadd (zmul x.num zone) (zmul zzero (denZ x.den)))
      (denZ x.den) =
    zmul x.num (denZ (denMul x.den oneDen))
  rw [zmul_one_right, zmul_zero_left, zadd_zero_right, denZ_mul, denZ_one, zmul_one_right]

/-- Raw addition is commutative modulo equivalence. -/
theorem rawAdd_comm_equiv (x y : RawFrac) :
    FracEquiv (rawAdd x y) (rawAdd y x) := by
  change
    zmul
      (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
      (denZ (denMul y.den x.den)) =
    zmul
      (zadd (zmul y.num (denZ x.den)) (zmul x.num (denZ y.den)))
      (denZ (denMul x.den y.den))
  rw [denZ_mul, denZ_mul]
  rw [zadd_comm (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den))]
  rw [zmul_comm (denZ y.den) (denZ x.den)]

/-- Raw addition is associative modulo equivalence. -/
theorem rawAdd_assoc_equiv (x y w : RawFrac) :
    FracEquiv (rawAdd (rawAdd x y) w) (rawAdd x (rawAdd y w)) := by
  have hxTerm :
      zmul (zmul x.num (denZ y.den)) (denZ w.den) =
      zmul x.num (zmul (denZ y.den) (denZ w.den)) :=
    zmul_assoc x.num (denZ y.den) (denZ w.den)

  have hyTerm :
      zmul (zmul y.num (denZ x.den)) (denZ w.den) =
      zmul (zmul y.num (denZ w.den)) (denZ x.den) :=
    zmul_swap_last y.num (denZ x.den) (denZ w.den)

  have hwTerm :
      zmul w.num (zmul (denZ x.den) (denZ y.den)) =
      zmul (zmul w.num (denZ y.den)) (denZ x.den) := by
    calc
      zmul w.num (zmul (denZ x.den) (denZ y.den)) =
          zmul (zmul w.num (denZ x.den)) (denZ y.den) :=
        (zmul_assoc w.num (denZ x.den) (denZ y.den)).symm
      _ = zmul (zmul w.num (denZ y.den)) (denZ x.den) :=
        zmul_swap_last w.num (denZ x.den) (denZ y.den)

  have hxyTerms :
      zadd
        (zmul (zmul x.num (denZ y.den)) (denZ w.den))
        (zmul (zmul y.num (denZ x.den)) (denZ w.den)) =
      zadd
        (zmul x.num (zmul (denZ y.den) (denZ w.den)))
        (zmul (zmul y.num (denZ w.den)) (denZ x.den)) := by
    calc
      zadd
          (zmul (zmul x.num (denZ y.den)) (denZ w.den))
          (zmul (zmul y.num (denZ x.den)) (denZ w.den)) =
        zadd
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zmul (zmul y.num (denZ x.den)) (denZ w.den)) :=
        congrArg
          (fun t => zadd t (zmul (zmul y.num (denZ x.den)) (denZ w.den)))
          hxTerm
      _ = zadd
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zmul (zmul y.num (denZ w.den)) (denZ x.den)) :=
        congrArg
          (fun t => zadd (zmul x.num (zmul (denZ y.den) (denZ w.den))) t)
          hyTerm

  have hnum :
      zadd
        (zmul
          (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
          (denZ w.den))
        (zmul w.num (zmul (denZ x.den) (denZ y.den))) =
      zadd
        (zmul x.num (zmul (denZ y.den) (denZ w.den)))
        (zmul
          (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
          (denZ x.den)) := by
    calc
      zadd
          (zmul
            (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
            (denZ w.den))
          (zmul w.num (zmul (denZ x.den) (denZ y.den))) =
        zadd
          (zadd
            (zmul (zmul x.num (denZ y.den)) (denZ w.den))
            (zmul (zmul y.num (denZ x.den)) (denZ w.den)))
          (zmul w.num (zmul (denZ x.den) (denZ y.den))) :=
        congrArg
          (fun t => zadd t (zmul w.num (zmul (denZ x.den) (denZ y.den))))
          (zmul_add_left
            (zmul x.num (denZ y.den))
            (zmul y.num (denZ x.den))
            (denZ w.den))
      _ = zadd
          (zadd
            (zmul x.num (zmul (denZ y.den) (denZ w.den)))
            (zmul (zmul y.num (denZ w.den)) (denZ x.den)))
          (zmul w.num (zmul (denZ x.den) (denZ y.den))) :=
        congrArg
          (fun t => zadd t (zmul w.num (zmul (denZ x.den) (denZ y.den))))
          hxyTerms
      _ = zadd
          (zadd
            (zmul x.num (zmul (denZ y.den) (denZ w.den)))
            (zmul (zmul y.num (denZ w.den)) (denZ x.den)))
          (zmul (zmul w.num (denZ y.den)) (denZ x.den)) :=
        congrArg
          (fun t => zadd
            (zadd
              (zmul x.num (zmul (denZ y.den) (denZ w.den)))
              (zmul (zmul y.num (denZ w.den)) (denZ x.den))) t)
          hwTerm
      _ = zadd
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zadd
            (zmul (zmul y.num (denZ w.den)) (denZ x.den))
            (zmul (zmul w.num (denZ y.den)) (denZ x.den))) :=
        zadd_assoc
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zmul (zmul y.num (denZ w.den)) (denZ x.den))
          (zmul (zmul w.num (denZ y.den)) (denZ x.den))
      _ = zadd
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zmul
            (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
            (denZ x.den)) :=
        congrArg
          (fun t => zadd (zmul x.num (zmul (denZ y.den) (denZ w.den))) t)
          (zmul_add_left
            (zmul y.num (denZ w.den))
            (zmul w.num (denZ y.den))
            (denZ x.den)).symm

  have hden :
      denZ (denMul (denMul x.den y.den) w.den) =
      denZ (denMul x.den (denMul y.den w.den)) := by
    rw [denZ_mul, denZ_mul, denZ_mul, denZ_mul]
    exact zmul_assoc (denZ x.den) (denZ y.den) (denZ w.den)

  change
    zmul
      (zadd
        (zmul
          (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
          (denZ w.den))
        (zmul w.num (denZ (denMul x.den y.den))))
      (denZ (denMul x.den (denMul y.den w.den))) =
    zmul
      (zadd
        (zmul x.num (denZ (denMul y.den w.den)))
        (zmul
          (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
          (denZ x.den)))
      (denZ (denMul (denMul x.den y.den) w.den))
  rw [denZ_mul x.den y.den, denZ_mul y.den w.den]
  rw [hnum, hden]

/-- Raw negation supplies additive inverse modulo equivalence. -/
theorem rawAdd_neg_equiv_zero (x : RawFrac) :
    FracEquiv (rawAdd x (rawNeg x)) rawZero := by
  let a := zmul x.num (denZ x.den)
  change
    zmul
      (zadd a (zmul (zneg x.num) (denZ x.den)))
      zone =
    zmul zzero (denZ (denMul x.den x.den))
  calc
    zmul
        (zadd a (zmul (zneg x.num) (denZ x.den)))
        zone =
      zmul (zadd a (zneg a)) zone :=
        congrArg
          (fun t => zmul (zadd a t) zone)
          (BOMA.Q.Gateway001.zmul_neg_left x.num (denZ x.den))
    _ = zmul zzero zone :=
      congrArg (fun t => zmul t zone) (zadd_neg_right a)
    _ = zzero := zmul_zero_left zone
    _ = zmul zzero (denZ (denMul x.den x.den)) :=
      (zmul_zero_left (denZ (denMul x.den x.den))).symm

end BOMA.Q.Fraction001

/- Multiplicative laws on raw fractions modulo FracEquiv, before quotient lifting. -/
namespace BOMA.Q.Fraction001

open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- Raw zero absorbs multiplication on the left modulo equivalence. -/
theorem rawMul_zero_left_equiv (x : RawFrac) :
    FracEquiv (rawMul rawZero x) rawZero := by
  change
    zmul (zmul zzero x.num) zone =
    zmul zzero (denZ (denMul oneDen x.den))
  rw [zmul_zero_left, zmul_zero_left, zmul_zero_left]

/-- Raw zero absorbs multiplication on the right modulo equivalence. -/
theorem rawMul_zero_right_equiv (x : RawFrac) :
    FracEquiv (rawMul x rawZero) rawZero := by
  change
    zmul (zmul x.num zzero) zone =
    zmul zzero (denZ (denMul x.den oneDen))
  rw [zmul_zero_right, zmul_zero_left, zmul_zero_left]

/-- Raw one is a left multiplicative identity modulo equivalence. -/
theorem rawMul_one_left_equiv (x : RawFrac) :
    FracEquiv (rawMul rawOne x) x := by
  change
    zmul (zmul zone x.num) (denZ x.den) =
    zmul x.num (denZ (denMul oneDen x.den))
  rw [zmul_one_left, denZ_mul, denZ_one, zmul_one_left]

/-- Raw one is a right multiplicative identity modulo equivalence. -/
theorem rawMul_one_right_equiv (x : RawFrac) :
    FracEquiv (rawMul x rawOne) x := by
  change
    zmul (zmul x.num zone) (denZ x.den) =
    zmul x.num (denZ (denMul x.den oneDen))
  rw [zmul_one_right, denZ_mul, denZ_one, zmul_one_right]

/-- Raw multiplication is commutative modulo equivalence. -/
theorem rawMul_comm_equiv (x y : RawFrac) :
    FracEquiv (rawMul x y) (rawMul y x) := by
  change
    zmul (zmul x.num y.num) (denZ (denMul y.den x.den)) =
    zmul (zmul y.num x.num) (denZ (denMul x.den y.den))
  rw [denZ_mul, denZ_mul]
  rw [zmul_comm x.num y.num]
  rw [zmul_comm (denZ y.den) (denZ x.den)]

/-- Raw multiplication is associative modulo equivalence. -/
theorem rawMul_assoc_equiv (x y w : RawFrac) :
    FracEquiv (rawMul (rawMul x y) w) (rawMul x (rawMul y w)) := by
  have hnum :
      zmul (zmul x.num y.num) w.num =
      zmul x.num (zmul y.num w.num) :=
    zmul_assoc x.num y.num w.num
  have hden :
      denZ (denMul (denMul x.den y.den) w.den) =
      denZ (denMul x.den (denMul y.den w.den)) := by
    rw [denZ_mul, denZ_mul, denZ_mul, denZ_mul]
    exact zmul_assoc (denZ x.den) (denZ y.den) (denZ w.den)
  change
    zmul
      (zmul (zmul x.num y.num) w.num)
      (denZ (denMul x.den (denMul y.den w.den))) =
    zmul
      (zmul x.num (zmul y.num w.num))
      (denZ (denMul (denMul x.den y.den) w.den))
  rw [hnum, hden]

end BOMA.Q.Fraction001

/- Right distributivity on raw fractions modulo FracEquiv. -/
namespace BOMA.Q.Fraction001

open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- The raw numerator on the expanded side is the left raw numerator multiplied
by the common denominator factor from x. -/
theorem raw_distrib_num_factor (x y w : RawFrac) :
    zadd
      (zmul (zmul x.num y.num) (zmul (denZ x.den) (denZ w.den)))
      (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))) =
    zmul (denZ x.den)
      (zmul x.num
        (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))) := by
  calc
    zadd
        (zmul (zmul x.num y.num) (zmul (denZ x.den) (denZ w.den)))
        (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))) =
      zadd
        (zmul (zmul x.num (denZ x.den)) (zmul y.num (denZ w.den)))
        (zmul (zmul x.num (denZ x.den)) (zmul w.num (denZ y.den))) := by
      have h1 :=
        zmul4_swap_middle x.num y.num (denZ x.den) (denZ w.den)
      have h2 :=
        zmul4_swap_middle x.num w.num (denZ x.den) (denZ y.den)
      calc
        zadd
            (zmul (zmul x.num y.num) (zmul (denZ x.den) (denZ w.den)))
            (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))) =
          zadd
            (zmul (zmul x.num (denZ x.den)) (zmul y.num (denZ w.den)))
            (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))) :=
          congrArg
            (fun t => zadd t
              (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))))
            h1
        _ = zadd
            (zmul (zmul x.num (denZ x.den)) (zmul y.num (denZ w.den)))
            (zmul (zmul x.num (denZ x.den)) (zmul w.num (denZ y.den))) :=
          congrArg
            (fun t => zadd
              (zmul (zmul x.num (denZ x.den)) (zmul y.num (denZ w.den))) t)
            h2
    _ = zmul (zmul x.num (denZ x.den))
        (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den))) :=
      (zmul_add_right
        (zmul x.num (denZ x.den))
        (zmul y.num (denZ w.den))
        (zmul w.num (denZ y.den))).symm
    _ = zmul (denZ x.den)
        (zmul x.num
          (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))) := by
      calc
        zmul (zmul x.num (denZ x.den))
            (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den))) =
          zmul x.num
            (zmul (denZ x.den)
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))) :=
          zmul_assoc x.num (denZ x.den) _
        _ = zmul x.num
            (zmul
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
              (denZ x.den)) :=
          congrArg (fun t => zmul x.num t)
            (zmul_comm (denZ x.den)
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den))))
        _ = zmul
            (zmul x.num
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den))))
            (denZ x.den) :=
          (zmul_assoc x.num _ (denZ x.den)).symm
        _ = zmul (denZ x.den)
            (zmul x.num
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))) :=
          zmul_comm _ _

/-- The expanded denominator carries the same extra x-denominator factor. -/
theorem raw_distrib_den_factor (x y w : RawFrac) :
    denZ (denMul (denMul x.den y.den) (denMul x.den w.den)) =
    zmul (denZ x.den)
      (denZ (denMul x.den (denMul y.den w.den))) := by
  rw [denZ_mul, denZ_mul, denZ_mul, denZ_mul, denZ_mul]
  calc
    zmul (zmul (denZ x.den) (denZ y.den))
        (zmul (denZ x.den) (denZ w.den)) =
      zmul (zmul (denZ x.den) (denZ x.den))
        (zmul (denZ y.den) (denZ w.den)) :=
      zmul4_swap_middle
        (denZ x.den) (denZ y.den) (denZ x.den) (denZ w.den)
    _ = zmul (denZ x.den)
        (zmul (denZ x.den) (zmul (denZ y.den) (denZ w.den))) :=
      zmul_assoc (denZ x.den) (denZ x.den)
        (zmul (denZ y.den) (denZ w.den))

/-- Raw multiplication distributes over raw addition modulo fraction equivalence. -/
theorem rawMul_add_right_equiv (x y w : RawFrac) :
    FracEquiv
      (rawMul x (rawAdd y w))
      (rawAdd (rawMul x y) (rawMul x w)) := by
  let nL :=
    zmul x.num
      (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
  let dL := denZ (denMul x.den (denMul y.den w.den))
  let nR :=
    zadd
      (zmul (zmul x.num y.num) (denZ (denMul x.den w.den)))
      (zmul (zmul x.num w.num) (denZ (denMul x.den y.den)))
  let dR := denZ (denMul (denMul x.den y.den) (denMul x.den w.den))

  have hn : nR = zmul (denZ x.den) nL := by
    unfold nR nL
    rw [denZ_mul, denZ_mul]
    exact raw_distrib_num_factor x y w

  have hd : dR = zmul (denZ x.den) dL := by
    unfold dR dL
    exact raw_distrib_den_factor x y w

  change zmul nL dR = zmul nR dL
  rw [hn, hd]
  calc
    zmul nL (zmul (denZ x.den) dL) =
      zmul (zmul nL (denZ x.den)) dL :=
      (zmul_assoc nL (denZ x.den) dL).symm
    _ = zmul (zmul (denZ x.den) nL) dL :=
      congrArg (fun t => zmul t dL) (zmul_comm nL (denZ x.den))

end BOMA.Q.Fraction001

/- Stage-One rational formal identity: explicit quotient of verified raw fractions.
   This is the first accepted number-stage candidate to use quotient carrier formation. -/
namespace BOMA.Q.Quotient001

open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Q.Fraction001

/-- The verified fraction equivalence packaged as a formal Setoid. -/
def fracSetoid : Setoid RawFrac where
  r := FracEquiv
  iseqv := ⟨frac_refl, @frac_symm, @frac_trans⟩

/-- Candidate Stage-One rational carrier. -/
def QBOMA : Type := Quotient fracSetoid

/-- Canonical injection of a raw valid fraction into the quotient carrier. -/
def qmk (x : RawFrac) : QBOMA := Quotient.mk fracSetoid x

/-- Representation-equivalent raw fractions become formally equal in QBOMA. -/
theorem qmk_sound {x y : RawFrac} (h : FracEquiv x y) : qmk x = qmk y :=
  Quotient.sound h

/-- Conversely, quotient equality reflects the verified raw equivalence. -/
theorem qmk_eq_iff {x y : RawFrac} : qmk x = qmk y ↔ FracEquiv x y := by
  constructor
  · intro h
    exact Quotient.exact h
  · exact qmk_sound

/-- Lift raw negation through the verified respect proof. -/
def qNeg : QBOMA → QBOMA :=
  Quotient.lift
    (fun a => qmk (rawNeg a))
    (fun _ _ h => qmk_sound (rawNeg_respects h))

/-- Lift raw addition through the verified binary respect proof. -/
def qAdd : QBOMA → QBOMA → QBOMA :=
  Quotient.lift₂
    (fun a b => qmk (rawAdd a b))
    (fun _ _ _ _ ha hb => qmk_sound (rawAdd_respects ha hb))

/-- Lift raw multiplication through the verified binary respect proof. -/
def qMul : QBOMA → QBOMA → QBOMA :=
  Quotient.lift₂
    (fun a b => qmk (rawMul a b))
    (fun _ _ _ _ ha hb => qmk_sound (rawMul_respects ha hb))

/-- Quotient zero and one. -/
def qZero : QBOMA := qmk rawZero
def qOne : QBOMA := qmk rawOne

/-- Accepted integer embedding into the quotient rational carrier. -/
def qOfZ (a : ZSigned) : QBOMA := qmk (fracOfZ a)

/-- Integer embedding remains injective after quotienting. -/
theorem qOfZ_injective {a b : ZSigned} (h : qOfZ a = qOfZ b) : a = b := by
  apply fracOfZ_reflects
  exact Quotient.exact h

/-- Quotient operations compute on raw representatives exactly as intended. -/
@[simp] theorem qNeg_mk (x : RawFrac) : qNeg (qmk x) = qmk (rawNeg x) := rfl

@[simp] theorem qAdd_mk (x y : RawFrac) :
    qAdd (qmk x) (qmk y) = qmk (rawAdd x y) := rfl

@[simp] theorem qMul_mk (x y : RawFrac) :
    qMul (qmk x) (qmk y) = qmk (rawMul x y) := rfl

end BOMA.Q.Quotient001

/- Lift the already-proved raw additive laws to formal QBOMA equality. -/
namespace BOMA.Q.Quotient001

open BOMA.Q.Fraction001

@[simp] theorem qAdd_zero_left (x : QBOMA) : qAdd qZero x = x := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawAdd rawZero a) = qmk a
  exact qmk_sound (rawAdd_zero_left_equiv a)

@[simp] theorem qAdd_zero_right (x : QBOMA) : qAdd x qZero = x := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawAdd a rawZero) = qmk a
  exact qmk_sound (rawAdd_zero_right_equiv a)

theorem qAdd_comm (x y : QBOMA) : qAdd x y = qAdd y x := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  change qmk (rawAdd a b) = qmk (rawAdd b a)
  exact qmk_sound (rawAdd_comm_equiv a b)

theorem qAdd_assoc (x y w : QBOMA) :
    qAdd (qAdd x y) w = qAdd x (qAdd y w) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn w ?_
  intro c
  change qmk (rawAdd (rawAdd a b) c) = qmk (rawAdd a (rawAdd b c))
  exact qmk_sound (rawAdd_assoc_equiv a b c)

@[simp] theorem qAdd_neg_right (x : QBOMA) : qAdd x (qNeg x) = qZero := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawAdd a (rawNeg a)) = qmk rawZero
  exact qmk_sound (rawAdd_neg_equiv_zero a)

@[simp] theorem qAdd_neg_left (x : QBOMA) : qAdd (qNeg x) x = qZero := by
  rw [qAdd_comm]
  exact qAdd_neg_right x

end BOMA.Q.Quotient001

/- Lift the already-proved raw multiplicative laws to formal QBOMA equality. -/
namespace BOMA.Q.Quotient001

open BOMA.Q.Fraction001

@[simp] theorem qMul_zero_left (x : QBOMA) : qMul qZero x = qZero := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawMul rawZero a) = qmk rawZero
  exact qmk_sound (rawMul_zero_left_equiv a)

@[simp] theorem qMul_zero_right (x : QBOMA) : qMul x qZero = qZero := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawMul a rawZero) = qmk rawZero
  exact qmk_sound (rawMul_zero_right_equiv a)

@[simp] theorem qMul_one_left (x : QBOMA) : qMul qOne x = x := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawMul rawOne a) = qmk a
  exact qmk_sound (rawMul_one_left_equiv a)

@[simp] theorem qMul_one_right (x : QBOMA) : qMul x qOne = x := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawMul a rawOne) = qmk a
  exact qmk_sound (rawMul_one_right_equiv a)

theorem qMul_comm (x y : QBOMA) : qMul x y = qMul y x := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  change qmk (rawMul a b) = qmk (rawMul b a)
  exact qmk_sound (rawMul_comm_equiv a b)

theorem qMul_assoc (x y w : QBOMA) :
    qMul (qMul x y) w = qMul x (qMul y w) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn w ?_
  intro c
  change qmk (rawMul (rawMul a b) c) = qmk (rawMul a (rawMul b c))
  exact qmk_sound (rawMul_assoc_equiv a b c)

end BOMA.Q.Quotient001

/- Lift verified raw distributivity to formal QBOMA equality. -/
namespace BOMA.Q.Quotient001

open BOMA.Q.Fraction001

/-- Right distributivity on the selected quotient carrier. -/
theorem qMul_add_right (x y w : QBOMA) :
    qMul x (qAdd y w) = qAdd (qMul x y) (qMul x w) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn w ?_
  intro c
  change qmk (rawMul a (rawAdd b c)) =
    qmk (rawAdd (rawMul a b) (rawMul a c))
  exact qmk_sound (rawMul_add_right_equiv a b c)

/-- Left distributivity follows from quotient multiplication commutativity. -/
theorem qMul_add_left (x y w : QBOMA) :
    qMul (qAdd x y) w = qAdd (qMul x w) (qMul y w) := by
  calc
    qMul (qAdd x y) w = qMul w (qAdd x y) := qMul_comm _ _
    _ = qAdd (qMul w x) (qMul w y) := qMul_add_right w x y
    _ = qAdd (qMul x w) (qMul y w) := by
      rw [qMul_comm w x, qMul_comm w y]

end BOMA.Q.Quotient001

/- Nonzero rational inverses as unique witnesses, avoiding any Choice commitment. -/
namespace BOMA.Q.Inverse001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Q.Gateway001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001

/-- A raw positive-denominator fraction is equivalent to zero exactly when its
integer numerator is zero. -/
theorem raw_equiv_zero_iff_num_zero (x : RawFrac) :
    FracEquiv x rawZero ↔ x.num = zzero := by
  constructor
  · intro h
    change zmul x.num zone = zmul zzero (denZ x.den) at h
    rw [zmul_one_right, zmul_zero_left] at h
    exact h
  · intro h
    change zmul x.num zone = zmul zzero (denZ x.den)
    rw [h, zmul_zero_left, zmul_zero_left]

/-- Reciprocal raw witness for a positive signed numerator `+(n+1)`. -/
def rawRecipPos (d : PosDen) (n : BOMANat) : RawFrac :=
  ⟨denZ d, ⟨n⟩⟩

/-- Reciprocal raw witness for a negative signed numerator `-(n+1)`. -/
def rawRecipNeg (d : PosDen) (n : BOMANat) : RawFrac :=
  ⟨zneg (denZ d), ⟨n⟩⟩

/-- A positive raw fraction times its reciprocal witness is one modulo FracEquiv. -/
theorem rawMul_recip_pos_equiv_one (d : PosDen) (n : BOMANat) :
    FracEquiv
      (rawMul ⟨pos n, d⟩ (rawRecipPos d n))
      rawOne := by
  change
    zmul (zmul (pos n) (denZ d)) zone =
    zmul zone (denZ (denMul d ⟨n⟩))
  rw [zmul_one_right, zmul_one_left, denZ_mul]
  change zmul (pos n) (denZ d) = zmul (denZ d) (pos n)
  exact zmul_comm _ _

/-- A negative raw fraction times its sign-normalized reciprocal witness is one. -/
theorem rawMul_recip_neg_equiv_one (d : PosDen) (n : BOMANat) :
    FracEquiv
      (rawMul ⟨neg n, d⟩ (rawRecipNeg d n))
      rawOne := by
  change
    zmul (zmul (neg n) (zneg (denZ d))) zone =
    zmul zone (denZ (denMul d ⟨n⟩))
  rw [zmul_one_right, zmul_one_left, denZ_mul]
  change zmul (neg n) (zneg (denZ d)) = zmul (denZ d) (pos n)
  calc
    zmul (neg n) (zneg (denZ d)) =
        zneg (zmul (pos n) (zneg (denZ d))) :=
      zmul_neg_left (pos n) (zneg (denZ d))
    _ = zneg (zneg (zmul (pos n) (denZ d))) :=
      congrArg zneg (zmul_neg_right (pos n) (denZ d))
    _ = zmul (pos n) (denZ d) := zneg_involutive _
    _ = zmul (denZ d) (pos n) := zmul_comm _ _

/-- Quotient-level multiplicative-inverse relation. -/
def QInvRel (q r : QBOMA) : Prop := qMul q r = qOne

/-- Every nonzero quotient rational has an explicitly constructed inverse witness.
The proof eliminates the quotient only into a proposition, so it requires no
representative-choice axiom. -/
theorem q_inverse_exists (q : QBOMA) (hq : q ≠ qZero) :
    ∃ r : QBOMA, QInvRel q r := by
  refine Quotient.inductionOn q ?_ hq
  intro x hx
  have hnum : x.num ≠ zzero := by
    intro hzero
    apply hx
    exact qmk_sound ((raw_equiv_zero_iff_num_zero x).2 hzero)
  cases x with
  | mk num den =>
      cases num with
      | zero => exact False.elim (hnum rfl)
      | pos n =>
          refine ⟨qmk (rawRecipPos den n), ?_⟩
          change qmk (rawMul ⟨pos n, den⟩ (rawRecipPos den n)) = qmk rawOne
          exact qmk_sound (rawMul_recip_pos_equiv_one den n)
      | neg n =>
          refine ⟨qmk (rawRecipNeg den n), ?_⟩
          change qmk (rawMul ⟨neg n, den⟩ (rawRecipNeg den n)) = qmk rawOne
          exact qmk_sound (rawMul_recip_neg_equiv_one den n)

/-- Multiplicative inverse witnesses are unique in the commutative monoid. -/
theorem q_inverse_unique {q r s : QBOMA}
    (hr : QInvRel q r) (hs : QInvRel q s) : r = s := by
  unfold QInvRel at hr hs
  calc
    r = qMul qOne r := (qMul_one_left r).symm
    _ = qMul (qMul q s) r := congrArg (fun t => qMul t r) hs.symm
    _ = qMul q (qMul s r) := qMul_assoc q s r
    _ = qMul q (qMul r s) := congrArg (fun t => qMul q t) (qMul_comm s r)
    _ = qMul (qMul q r) s := (qMul_assoc q r s).symm
    _ = qMul qOne s := congrArg (fun t => qMul t s) hr
    _ = s := qMul_one_left s

/-- QA-09 constructive interface: each nonzero rational has one inverse witness,
and every inverse witness is equal to it. This avoids `∃!` notation and any
Choice-based global selector. -/
theorem q_inverse_exists_unique (q : QBOMA) (hq : q ≠ qZero) :
    ∃ r : QBOMA, QInvRel q r ∧ ∀ s : QBOMA, QInvRel q s → s = r := by
  rcases q_inverse_exists q hq with ⟨r, hr⟩
  refine ⟨r, hr, ?_⟩
  intro s hs
  exact q_inverse_unique hs hr

end BOMA.Q.Inverse001

/- Preservation laws for the accepted Z embedding into the rational quotient carrier. -/
namespace BOMA.Q.Embedding001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001

@[simp] theorem qOfZ_zero : qOfZ zzero = qZero := rfl

@[simp] theorem qOfZ_one : qOfZ zone = qOne := rfl

/-- Integer negation is preserved exactly by the quotient embedding. -/
theorem qOfZ_neg (a : ZSigned) : qOfZ (zneg a) = qNeg (qOfZ a) := by
  rfl

/-- Integer addition is preserved by the rational embedding. -/
theorem qOfZ_add (a b : ZSigned) :
    qOfZ (zadd a b) = qAdd (qOfZ a) (qOfZ b) := by
  apply qmk_sound
  change
    zmul (zadd a b) (denZ (denMul oneDen oneDen)) =
    zmul (zadd (zmul a zone) (zmul b zone)) zone
  calc
    zmul (zadd a b) (denZ (denMul oneDen oneDen)) =
        zmul (zadd a b) (zmul zone zone) :=
      congrArg (fun t => zmul (zadd a b) t) (denZ_mul oneDen oneDen)
    _ = zmul (zadd a b) zone := by rw [zmul_one_left]
    _ = zadd a b := zmul_one_right (zadd a b)
    _ = zadd (zmul a zone) (zmul b zone) := by
      rw [zmul_one_right a, zmul_one_right b]
    _ = zmul (zadd (zmul a zone) (zmul b zone)) zone :=
      (zmul_one_right _).symm

/-- Integer multiplication is preserved by the rational embedding. -/
theorem qOfZ_mul (a b : ZSigned) :
    qOfZ (zmul a b) = qMul (qOfZ a) (qOfZ b) := by
  apply qmk_sound
  change
    zmul (zmul a b) (denZ (denMul oneDen oneDen)) =
    zmul (zmul a b) zone
  rw [denZ_mul, denZ_one, zmul_one_left, zmul_one_right]

/-- The only Stage-One natural embedding into Q is the documented composition
N_BOMA -> Z_BOMA -> QBOMA. -/
def qOfN (n : BOMANat) : QBOMA := qOfZ (embedN n)

/-- Coherence with the direct fraction spelling `n/1`. -/
theorem qOfN_fraction (n : BOMANat) :
    qOfN n = qmk (fracOfZ (embedN n)) := rfl

@[simp] theorem qOfN_zero : qOfN z = qZero := rfl

@[simp] theorem qOfN_one : qOfN (s z) = qOne := rfl

/-- The composed natural embedding preserves accepted natural addition. -/
theorem qOfN_add (a b : BOMANat) :
    qOfN (BOMA.NArithmetic.Addition001.add a b) =
    qAdd (qOfN a) (qOfN b) := by
  unfold qOfN
  rw [BOMA.Z.Arithmetic001.embedN_add]
  exact qOfZ_add (embedN a) (embedN b)

/-- The composed natural embedding preserves accepted natural multiplication. -/
theorem qOfN_mul (a b : BOMANat) :
    qOfN (BOMA.NArithmetic.Multiplication001.mul a b) =
    qMul (qOfN a) (qOfN b) := by
  unfold qOfN
  rw [BOMA.Z.Arithmetic001.embedN_mul]
  exact qOfZ_mul (embedN a) (embedN b)

end BOMA.Q.Embedding001

/- Stage-One rational order from positive-denominator cross products. -/
namespace BOMA.Q.Order001

open BOMA.Z.Rep001
open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Gateway001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001

/-- Every selected rational denominator is nonnegative in accepted Z. -/
theorem denZ_nonneg (d : PosDen) : NonNeg (denZ d) := by
  unfold NonNeg denZ denNat
  exact (embedN_order BOMA.NCore.RB001.BOMANat.z
    (BOMA.NCore.RB001.BOMANat.s d.pred)).2
    (BOMA.NArithmetic.Order001.z_le _)

/-- Multiplication by a nonnegative nonzero integer reflects order. This is the
order analogue of the QG-01 cancellation gateway and is derived rather than
assumed. -/
theorem zmul_order_reflect_right_nonneg_nonzero {x y c : BOMA.Z.Rep001.ZSigned}
    (hcN : NonNeg c) (hc0 : c ≠ zzero)
    (h : zLE (zmul x c) (zmul y c)) : zLE x y := by
  rcases zle_total x y with hxy | hyx
  · exact hxy
  · have hback : zLE (zmul y c) (zmul x c) :=
      zmul_mono_right_nonneg hyx hcN
    have heq : zmul x c = zmul y c := zle_antisymm h hback
    have hxyEq : x = y := zmul_right_cancel_nonzero hc0 heq
    rw [hxyEq]
    exact zle_refl y

/-- Raw cross-product order. Positive denominator syntax fixes orientation. -/
def RawLE (x y : RawFrac) : Prop :=
  zLE (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den))

/-- Changing the left fraction representative preserves raw order. -/
theorem rawLE_respects_left {x x' y : RawFrac}
    (hx : FracEquiv x x') (h : RawLE x y) : RawLE x' y := by
  change zmul x.num (denZ x'.den) =
    zmul x'.num (denZ x.den) at hx
  change zLE (zmul x.num (denZ y.den))
    (zmul y.num (denZ x.den)) at h
  change zLE (zmul x'.num (denZ y.den))
    (zmul y.num (denZ x'.den))
  have hm := zmul_mono_right_nonneg h (denZ_nonneg x'.den)
  have hleft :
      zmul (zmul x.num (denZ y.den)) (denZ x'.den) =
      zmul (zmul x'.num (denZ y.den)) (denZ x.den) := by
    calc
      zmul (zmul x.num (denZ y.den)) (denZ x'.den) =
          zmul (zmul x.num (denZ x'.den)) (denZ y.den) :=
        zmul_swap_last x.num (denZ y.den) (denZ x'.den)
      _ = zmul (zmul x'.num (denZ x.den)) (denZ y.den) :=
        congrArg (fun t => zmul t (denZ y.den)) hx
      _ = zmul (zmul x'.num (denZ y.den)) (denZ x.den) :=
        zmul_swap_last x'.num (denZ x.den) (denZ y.den)
  have hright :
      zmul (zmul y.num (denZ x.den)) (denZ x'.den) =
      zmul (zmul y.num (denZ x'.den)) (denZ x.den) :=
    zmul_swap_last y.num (denZ x.den) (denZ x'.den)
  rw [hleft, hright] at hm
  exact zmul_order_reflect_right_nonneg_nonzero
    (denZ_nonneg x.den) (denZ_ne_zero x.den) hm

/-- Changing the right fraction representative preserves raw order. -/
theorem rawLE_respects_right {x y y' : RawFrac}
    (hy : FracEquiv y y') (h : RawLE x y) : RawLE x y' := by
  change zmul y.num (denZ y'.den) =
    zmul y'.num (denZ y.den) at hy
  change zLE (zmul x.num (denZ y.den))
    (zmul y.num (denZ x.den)) at h
  change zLE (zmul x.num (denZ y'.den))
    (zmul y'.num (denZ x.den))
  have hm := zmul_mono_right_nonneg h (denZ_nonneg y'.den)
  have hleft :
      zmul (zmul x.num (denZ y.den)) (denZ y'.den) =
      zmul (zmul x.num (denZ y'.den)) (denZ y.den) :=
    zmul_swap_last x.num (denZ y.den) (denZ y'.den)
  have hright :
      zmul (zmul y.num (denZ x.den)) (denZ y'.den) =
      zmul (zmul y'.num (denZ x.den)) (denZ y.den) := by
    calc
      zmul (zmul y.num (denZ x.den)) (denZ y'.den) =
          zmul (zmul y.num (denZ y'.den)) (denZ x.den) :=
        zmul_swap_last y.num (denZ x.den) (denZ y'.den)
      _ = zmul (zmul y'.num (denZ y.den)) (denZ x.den) :=
        congrArg (fun t => zmul t (denZ x.den)) hy
      _ = zmul (zmul y'.num (denZ x.den)) (denZ y.den) :=
        zmul_swap_last y'.num (denZ y.den) (denZ x.den)
  rw [hleft, hright] at hm
  exact zmul_order_reflect_right_nonneg_nonzero
    (denZ_nonneg y.den) (denZ_ne_zero y.den) hm

theorem rawLE_respects {x x' y y' : RawFrac}
    (hx : FracEquiv x x') (hy : FracEquiv y y') (h : RawLE x y) :
    RawLE x' y' :=
  rawLE_respects_right hy (rawLE_respects_left hx h)

theorem rawLE_refl (x : RawFrac) : RawLE x x := zle_refl _

theorem rawLE_total (x y : RawFrac) : RawLE x y ∨ RawLE y x :=
  zle_total _ _

/-- Opposite raw inequalities force fraction equivalence. -/
theorem rawLE_antisymm_equiv {x y : RawFrac}
    (hxy : RawLE x y) (hyx : RawLE y x) : FracEquiv x y := by
  exact zle_antisymm hxy hyx

/-- Transitivity uses one positive middle denominator as a cancellable common
factor after multiplying the two cross inequalities. -/
theorem rawLE_trans {x y w : RawFrac}
    (hxy : RawLE x y) (hyw : RawLE y w) : RawLE x w := by
  change zLE (zmul x.num (denZ y.den))
    (zmul y.num (denZ x.den)) at hxy
  change zLE (zmul y.num (denZ w.den))
    (zmul w.num (denZ y.den)) at hyw
  change zLE (zmul x.num (denZ w.den))
    (zmul w.num (denZ x.den))
  have h1 := zmul_mono_right_nonneg hxy (denZ_nonneg w.den)
  have h2 := zmul_mono_right_nonneg hyw (denZ_nonneg x.den)
  rw [zmul_swap_last x.num (denZ y.den) (denZ w.den)] at h1
  rw [zmul_swap_last y.num (denZ x.den) (denZ w.den)] at h1
  rw [zmul_swap_last w.num (denZ y.den) (denZ x.den)] at h2
  have hcommon := zle_trans h1 h2
  exact zmul_order_reflect_right_nonneg_nonzero
    (denZ_nonneg y.den) (denZ_ne_zero y.den) hcommon

/-- Quotient order without proposition extensionality: witnesses are raw
representatives tied by formal quotient equality to the two endpoints. -/
def qLE (q r : QBOMA) : Prop :=
  ∃ x : RawFrac, ∃ y : RawFrac,
    q = qmk x ∧ r = qmk y ∧ RawLE x y

/-- On explicit quotient representatives, qLE is exactly the raw cross order. -/
theorem qLE_mk_iff (x y : RawFrac) :
    qLE (qmk x) (qmk y) ↔ RawLE x y := by
  constructor
  · rintro ⟨x', y', hxq, hyq, hle⟩
    have hx : FracEquiv x x' := (qmk_eq_iff).mp hxq
    have hy : FracEquiv y y' := (qmk_eq_iff).mp hyq
    exact rawLE_respects (frac_symm hx) (frac_symm hy) hle
  · intro h
    exact ⟨x, y, rfl, rfl, h⟩

theorem qle_refl (q : QBOMA) : qLE q q := by
  refine Quotient.inductionOn q ?_
  intro x
  exact (qLE_mk_iff x x).2 (rawLE_refl x)

theorem qle_trans {q r s : QBOMA} (hqr : qLE q r) (hrs : qLE r s) : qLE q s := by
  refine Quotient.inductionOn q ?_ hqr hrs
  intro x hxr hrs'
  refine Quotient.inductionOn r ?_ hxr hrs'
  intro y hxy hys
  refine Quotient.inductionOn s ?_ hxy hys
  intro w hxy' hyw'
  apply (qLE_mk_iff x w).2
  exact rawLE_trans ((qLE_mk_iff x y).1 hxy') ((qLE_mk_iff y w).1 hyw')

theorem qle_antisymm {q r : QBOMA} (hqr : qLE q r) (hrq : qLE r q) : q = r := by
  refine Quotient.inductionOn q ?_ hqr hrq
  intro x hxr hrx
  refine Quotient.inductionOn r ?_ hxr hrx
  intro y hxy hyx
  exact qmk_sound (rawLE_antisymm_equiv
    ((qLE_mk_iff x y).1 hxy) ((qLE_mk_iff y x).1 hyx))

theorem qle_total (q r : QBOMA) : qLE q r ∨ qLE r q := by
  refine Quotient.inductionOn q ?_
  intro x
  refine Quotient.inductionOn r ?_
  intro y
  rcases rawLE_total x y with h | h
  · exact Or.inl ((qLE_mk_iff x y).2 h)
  · exact Or.inr ((qLE_mk_iff y x).2 h)

/-- The rational order exactly extends the accepted integer order.
The representative-order Iff is composed explicitly, avoiding proposition-level
rewriting by `qLE_mk_iff`. -/
theorem qOfZ_order (a b : BOMA.Z.Rep001.ZSigned) :
    qLE (qOfZ a) (qOfZ b) ↔ zLE a b := by
  change qLE (qmk (fracOfZ a)) (qmk (fracOfZ b)) ↔ zLE a b
  have hRaw : RawLE (fracOfZ a) (fracOfZ b) ↔ zLE a b := by
    constructor
    · intro h
      change zLE (zmul a zone) (zmul b zone) at h
      rw [zmul_one_right, zmul_one_right] at h
      exact h
    · intro h
      change zLE (zmul a zone) (zmul b zone)
      rw [zmul_one_right, zmul_one_right]
      exact h
  exact (qLE_mk_iff (fracOfZ a) (fracOfZ b)).trans hRaw

end BOMA.Q.Order001

/- Additive compatibility of the Stage-One rational order. -/
namespace BOMA.Q.OrderedField001

open BOMA.Z.Rep001
open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Gateway001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001
open BOMA.Q.Order001

/-- Additive cancellation in QBOMA. -/
theorem qAdd_left_cancel {a b c : QBOMA}
    (h : qAdd a b = qAdd a c) : b = c := by
  have h' := congrArg (fun t => qAdd (qNeg a) t) h
  calc
    b = qAdd qZero b := (qAdd_zero_left b).symm
    _ = qAdd (qAdd (qNeg a) a) b := by rw [qAdd_neg_left]
    _ = qAdd (qNeg a) (qAdd a b) := qAdd_assoc (qNeg a) a b
    _ = qAdd (qNeg a) (qAdd a c) := h'
    _ = qAdd (qAdd (qNeg a) a) c := (qAdd_assoc (qNeg a) a c).symm
    _ = qAdd qZero c := by rw [qAdd_neg_left]
    _ = c := qAdd_zero_left c

/-- Any additive inverse equals the selected qNeg. -/
theorem qAdd_inverse_unique {x y : QBOMA}
    (h : qAdd x y = qZero) : y = qNeg x := by
  apply qAdd_left_cancel (a := x)
  calc
    qAdd x y = qZero := h
    _ = qAdd x (qNeg x) := (qAdd_neg_right x).symm

/-- Exchange the two middle terms of a four-term additive expression. -/
theorem qAdd_exchange (a b c d : QBOMA) :
    qAdd a (qAdd b (qAdd c d)) =
    qAdd a (qAdd c (qAdd b d)) := by
  apply congrArg (fun t => qAdd a t)
  calc
    qAdd b (qAdd c d) = qAdd (qAdd b c) d := (qAdd_assoc b c d).symm
    _ = qAdd (qAdd c b) d := congrArg (fun t => qAdd t d) (qAdd_comm b c)
    _ = qAdd c (qAdd b d) := qAdd_assoc c b d

/-- Negation distributes over addition. -/
theorem qNeg_add (x y : QBOMA) :
    qNeg (qAdd x y) = qAdd (qNeg x) (qNeg y) := by
  symm
  apply qAdd_inverse_unique (x := qAdd x y)
  calc
    qAdd (qAdd x y) (qAdd (qNeg x) (qNeg y)) =
        qAdd x (qAdd y (qAdd (qNeg x) (qNeg y))) :=
      qAdd_assoc x y (qAdd (qNeg x) (qNeg y))
    _ = qAdd x (qAdd (qNeg x) (qAdd y (qNeg y))) :=
      qAdd_exchange x y (qNeg x) (qNeg y)
    _ = qAdd x (qAdd (qNeg x) qZero) := by rw [qAdd_neg_right]
    _ = qAdd x (qNeg x) := by rw [qAdd_zero_right]
    _ = qZero := qAdd_neg_right x

/-- Ordered-additive-group bridge in accepted Z. -/
theorem zle_iff_zero_le_difference (a b : BOMA.Z.Rep001.ZSigned) :
    zLE a b ↔ zLE zzero (zadd b (zneg a)) := by
  constructor
  · intro h
    have ht := zadd_mono_left h (zneg a)
    rw [zadd_neg_left] at ht
    rw [zadd_comm (zneg a) b] at ht
    exact ht
  · intro h
    have ht := zadd_mono_left h a
    rw [zadd_zero_right] at ht
    have hright : zadd a (zadd b (zneg a)) = b := by
      calc
        zadd a (zadd b (zneg a)) = zadd (zadd a b) (zneg a) :=
          (zadd_assoc a b (zneg a)).symm
        _ = zadd (zadd b a) (zneg a) :=
          congrArg (fun t => zadd t (zneg a)) (zadd_comm a b)
        _ = zadd b (zadd a (zneg a)) := zadd_assoc b a (zneg a)
        _ = zadd b zzero := by rw [zadd_neg_right]
        _ = b := zadd_zero_right b
    rw [hright] at ht
    exact ht

/-- On an explicit fraction, nonnegativity is exactly numerator nonnegativity.
The representative-order Iff is composed explicitly rather than used as a
proposition rewrite. -/
theorem qNonNeg_mk_iff (x : RawFrac) :
    qLE qZero (qmk x) ↔ zLE zzero x.num := by
  change qLE (qmk rawZero) (qmk x) ↔ zLE zzero x.num
  have hRaw : RawLE rawZero x ↔ zLE zzero x.num := by
    constructor
    · intro h
      change
        zLE (zmul zzero (denZ x.den)) (zmul x.num zone) at h
      rw [zmul_zero_left, zmul_one_right] at h
      exact h
    · intro h
      change
        zLE (zmul zzero (denZ x.den)) (zmul x.num zone)
      rw [zmul_zero_left, zmul_one_right]
      exact h
  exact (qLE_mk_iff rawZero x).trans hRaw

/-- Rational order is equivalent to nonnegativity of y-x.
The proof composes three Iff interfaces directly, preventing `rw` from turning
those Iffs into proposition equalities through proposition extensionality. -/
theorem qle_iff_nonneg_difference (x y : QBOMA) :
    qLE x y ↔ qLE qZero (qAdd y (qNeg x)) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  change qLE (qmk a) (qmk b) ↔
    qLE qZero (qmk (rawAdd b (rawNeg a)))
  have hRaw :
      RawLE a b ↔ zLE zzero (rawAdd b (rawNeg a)).num := by
    change
      zLE (zmul a.num (denZ b.den)) (zmul b.num (denZ a.den)) ↔
      zLE zzero
        (zadd (zmul b.num (denZ a.den))
          (zmul (zneg a.num) (denZ b.den)))
    rw [BOMA.Q.Gateway001.zmul_neg_left]
    exact zle_iff_zero_le_difference
      (zmul a.num (denZ b.den))
      (zmul b.num (denZ a.den))
  have hNonNeg :
      zLE zzero (rawAdd b (rawNeg a)).num ↔
      qLE qZero (qmk (rawAdd b (rawNeg a))) :=
    (qNonNeg_mk_iff (rawAdd b (rawNeg a))).symm
  exact (qLE_mk_iff a b).trans (hRaw.trans hNonNeg)

/-- Translating both sides by the same rational leaves their difference unchanged. -/
theorem q_difference_translate (x y c : QBOMA) :
    qAdd (qAdd y c) (qNeg (qAdd x c)) = qAdd y (qNeg x) := by
  rw [qNeg_add]
  calc
    qAdd (qAdd y c) (qAdd (qNeg x) (qNeg c)) =
        qAdd y (qAdd c (qAdd (qNeg x) (qNeg c))) :=
      qAdd_assoc y c (qAdd (qNeg x) (qNeg c))
    _ = qAdd y (qAdd (qNeg x) (qAdd c (qNeg c))) :=
      qAdd_exchange y c (qNeg x) (qNeg c)
    _ = qAdd y (qAdd (qNeg x) qZero) := by rw [qAdd_neg_right]
    _ = qAdd y (qNeg x) := by rw [qAdd_zero_right]

/-- Addition monotonicity by a common right translate. -/
theorem qadd_mono_right {x y : QBOMA} (h : qLE x y) (c : QBOMA) :
    qLE (qAdd x c) (qAdd y c) := by
  apply (qle_iff_nonneg_difference (qAdd x c) (qAdd y c)).2
  have hd := (qle_iff_nonneg_difference x y).1 h
  rw [q_difference_translate x y c]
  exact hd

/-- Full addition translation invariance. -/
theorem qadd_translate_iff (x y c : QBOMA) :
    qLE (qAdd x c) (qAdd y c) ↔ qLE x y := by
  constructor
  · intro h
    have hb := qadd_mono_right h (qNeg c)
    have hx : qAdd (qAdd x c) (qNeg c) = x := by
      calc
        qAdd (qAdd x c) (qNeg c) = qAdd x (qAdd c (qNeg c)) :=
          qAdd_assoc x c (qNeg c)
        _ = qAdd x qZero := by rw [qAdd_neg_right]
        _ = x := qAdd_zero_right x
    have hy : qAdd (qAdd y c) (qNeg c) = y := by
      calc
        qAdd (qAdd y c) (qNeg c) = qAdd y (qAdd c (qNeg c)) :=
          qAdd_assoc y c (qNeg c)
        _ = qAdd y qZero := by rw [qAdd_neg_right]
        _ = y := qAdd_zero_right y
    rw [hx, hy] at hb
    exact hb
  · intro h
    exact qadd_mono_right h c

/-- Negation reverses rational order. -/
theorem qneg_reverses {x y : QBOMA} (h : qLE x y) :
    qLE (qNeg y) (qNeg x) := by
  have ht := qadd_mono_right h (qAdd (qNeg x) (qNeg y))
  have hleft : qAdd x (qAdd (qNeg x) (qNeg y)) = qNeg y := by
    calc
      qAdd x (qAdd (qNeg x) (qNeg y)) =
          qAdd (qAdd x (qNeg x)) (qNeg y) :=
        (qAdd_assoc x (qNeg x) (qNeg y)).symm
      _ = qAdd qZero (qNeg y) := by rw [qAdd_neg_right]
      _ = qNeg y := qAdd_zero_left _
  have hright : qAdd y (qAdd (qNeg x) (qNeg y)) = qNeg x := by
    calc
      qAdd y (qAdd (qNeg x) (qNeg y)) =
          qAdd y (qAdd (qNeg y) (qNeg x)) :=
        congrArg (fun t => qAdd y t) (qAdd_comm (qNeg x) (qNeg y))
      _ = qAdd (qAdd y (qNeg y)) (qNeg x) :=
        (qAdd_assoc y (qNeg y) (qNeg x)).symm
      _ = qAdd qZero (qNeg x) := by rw [qAdd_neg_right]
      _ = qNeg x := qAdd_zero_left _
  rw [hleft, hright] at ht
  exact ht

end BOMA.Q.OrderedField001

/- Multiplicative compatibility of the Stage-One rational order. -/
namespace BOMA.Q.OrderedField001

open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.Inverse001

/-- A negated left factor produces the additive inverse of the product. -/
theorem qMul_neg_left (x c : QBOMA) :
    qMul (qNeg x) c = qNeg (qMul x c) := by
  apply qAdd_inverse_unique (x := qMul x c)
  calc
    qAdd (qMul x c) (qMul (qNeg x) c) =
        qMul (qAdd x (qNeg x)) c :=
      (qMul_add_left x (qNeg x) c).symm
    _ = qMul qZero c := congrArg (fun t => qMul t c) (qAdd_neg_right x)
    _ = qZero := qMul_zero_left c

/-- Product of two nonnegative rationals is nonnegative. -/
theorem qmul_nonneg {x y : QBOMA}
    (hx : qLE qZero x) (hy : qLE qZero y) : qLE qZero (qMul x y) := by
  refine Quotient.inductionOn x ?_ hx
  intro a hxa
  refine Quotient.inductionOn y ?_ hy
  intro b hyb
  have ha : zLE zzero a.num := (qNonNeg_mk_iff a).1 hxa
  have hb : zLE zzero b.num := (qNonNeg_mk_iff b).1 hyb
  apply (qNonNeg_mk_iff (rawMul a b)).2
  change zLE zzero (zmul a.num b.num)
  have hm := zmul_mono_right_nonneg ha hb
  rw [zmul_zero_left] at hm
  exact hm

/-- Multiplication by a nonnegative rational preserves order. -/
theorem qmul_mono_right_nonneg {x y c : QBOMA}
    (hxy : qLE x y) (hc : qLE qZero c) :
    qLE (qMul x c) (qMul y c) := by
  apply (qle_iff_nonneg_difference (qMul x c) (qMul y c)).2
  have hd := (qle_iff_nonneg_difference x y).1 hxy
  have hp := qmul_nonneg hd hc
  have hEq :
      qAdd (qMul y c) (qNeg (qMul x c)) =
      qMul (qAdd y (qNeg x)) c := by
    calc
      qAdd (qMul y c) (qNeg (qMul x c)) =
          qAdd (qMul y c) (qMul (qNeg x) c) :=
        congrArg (fun t => qAdd (qMul y c) t) (qMul_neg_left x c).symm
      _ = qMul (qAdd y (qNeg x)) c :=
        (qMul_add_left y (qNeg x) c).symm
  rw [hEq]
  exact hp

/-- Multiplication by a nonnegative rational on the left. -/
theorem qmul_mono_left_nonneg {x y c : QBOMA}
    (hxy : qLE x y) (hc : qLE qZero c) :
    qLE (qMul c x) (qMul c y) := by
  rw [qMul_comm c x, qMul_comm c y]
  exact qmul_mono_right_nonneg hxy hc

/-- Rational one is nonnegative. -/
theorem qzero_le_one : qLE qZero qOne := by
  change qLE (qOfZ zzero) (qOfZ zone)
  apply (qOfZ_order zzero zone).2
  exact (embedN_order BOMA.NCore.RB001.BOMANat.z
    (BOMA.NCore.RB001.BOMANat.s BOMA.NCore.RB001.BOMANat.z)).2
    (BOMA.NArithmetic.Order001.z_le _)

/-- Rational one is distinct from zero by faithful Z embedding. -/
theorem qone_ne_zero : qOne ≠ qZero := by
  intro h
  change qOfZ zone = qOfZ zzero at h
  have hz : zone = zzero := qOfZ_injective h
  cases hz

/-- A positive rational is nonnegative and nonzero; no separate strict-order
primitive is required solely for this acceptance gate. -/
def QPositive (q : QBOMA) : Prop := qLE qZero q ∧ q ≠ qZero

/-- The unique multiplicative inverse witness of a positive rational is positive. -/
theorem inverse_of_positive_is_positive {q r : QBOMA}
    (hq : QPositive q) (hr : QInvRel q r) : QPositive r := by
  constructor
  · rcases qle_total qZero r with h0r | hr0
    · exact h0r
    · have hm := qmul_mono_right_nonneg hr0 hq.1
      have hleft : qMul r q = qOne := by
        calc
          qMul r q = qMul q r := qMul_comm r q
          _ = qOne := hr
      have hright : qMul qZero q = qZero := qMul_zero_left q
      rw [hleft, hright] at hm
      have heq : qOne = qZero := qle_antisymm hm qzero_le_one
      exact False.elim (qone_ne_zero heq)
  · intro hrzero
    unfold QInvRel at hr
    rw [hrzero, qMul_zero_right] at hr
    exact qone_ne_zero hr.symm

end BOMA.Q.OrderedField001

/- Shared pre-real order/positivity interface over accepted QBOMA. -/
namespace BOMA.R.Gateway001

open BOMA.Q.Quotient001
open BOMA.Q.Order001

/-- Strict rational order derived from the accepted total non-strict order. -/
def qLT (x y : QBOMA) : Prop := qLE x y ∧ x ≠ y

/-- Positive rational in the strict-order sense. -/
def qPos (x : QBOMA) : Prop := qLT qZero x

@[simp] theorem qlt_irrefl (x : QBOMA) : ¬ qLT x x := by
  intro h
  exact h.2 rfl

theorem qlt_of_le_of_ne {x y : QBOMA} (hxy : qLE x y) (hne : x ≠ y) : qLT x y :=
  ⟨hxy, hne⟩

theorem qlt_trans {x y z : QBOMA} (hxy : qLT x y) (hyz : qLT y z) : qLT x z := by
  refine ⟨qle_trans hxy.1 hyz.1, ?_⟩
  intro hxz
  have hzx : qLE z x := by
    rw [hxz]
    exact qle_refl z
  have hyx : qLE y x := qle_trans hyz.1 hzx
  have hy_eq_x : y = x := qle_antisymm hyx hxy.1
  apply hxy.2
  exact hy_eq_x.symm

theorem qlt_asymm {x y : QBOMA} (hxy : qLT x y) : ¬ qLT y x := by
  intro hyx
  have heq := qle_antisymm hxy.1 hyx.1
  exact hxy.2 heq

/-- Total-order trichotomy without adding a separate primitive order.
The equality split is an explicit localized classical commitment rather than an
implicit `by_cases` use of the global proposition-decidability instance. -/
theorem qlt_trichotomy (x y : QBOMA) : qLT x y ∨ x = y ∨ qLT y x := by
  rcases qle_total x y with hxy | hyx
  · rcases Classical.em (x = y) with h | h
    · exact Or.inr (Or.inl h)
    · exact Or.inl ⟨hxy, h⟩
  · rcases Classical.em (x = y) with h | h
    · exact Or.inr (Or.inl h)
    · exact Or.inr (Or.inr ⟨hyx, fun hyxEq => h hyxEq.symm⟩)

/-- Symmetric rational epsilon-closeness expressed without a primitive absolute value. -/
def qClose (eps x y : QBOMA) : Prop :=
  qLE (qNeg eps) (qAdd x (qNeg y)) ∧
  qLE (qAdd x (qNeg y)) eps

end BOMA.R.Gateway001

/- Shared Q-density gateway for real completion routes. -/
namespace BOMA.R.Gateway001

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001

/-- Strict order is preserved by a common additive translate. -/
theorem qlt_add_right {x y : QBOMA} (hxy : qLT x y) (c : QBOMA) :
    qLT (qAdd x c) (qAdd y c) := by
  refine ⟨qadd_mono_right hxy.1 c, ?_⟩
  intro heq
  have hleft : qAdd c x = qAdd c y := by
    calc
      qAdd c x = qAdd x c := qAdd_comm c x
      _ = qAdd y c := heq
      _ = qAdd c y := qAdd_comm y c
  exact hxy.2 (qAdd_left_cancel hleft)

/-- Multiplicative cancellation by a nonzero left factor, derived from the
constructive unique-inverse witness interface. -/
theorem qMul_left_cancel_nonzero {a b c : QBOMA}
    (ha : a ≠ qZero) (h : qMul a b = qMul a c) : b = c := by
  rcases q_inverse_exists a ha with ⟨r, hr⟩
  unfold QInvRel at hr
  calc
    b = qMul qOne b := (qMul_one_left b).symm
    _ = qMul (qMul a r) b := congrArg (fun t => qMul t b) hr.symm
    _ = qMul r (qMul a b) := by
      calc
        qMul (qMul a r) b = qMul a (qMul r b) := qMul_assoc a r b
        _ = qMul a (qMul b r) := congrArg (fun t => qMul a t) (qMul_comm r b)
        _ = qMul (qMul a b) r := (qMul_assoc a b r).symm
        _ = qMul r (qMul a b) := qMul_comm _ _
    _ = qMul r (qMul a c) := congrArg (fun t => qMul r t) h
    _ = qMul (qMul a r) c := by
      calc
        qMul r (qMul a c) = qMul (qMul r a) c := (qMul_assoc r a c).symm
        _ = qMul (qMul a r) c := congrArg (fun t => qMul t c) (qMul_comm r a)
    _ = qMul qOne c := congrArg (fun t => qMul t c) hr
    _ = c := qMul_one_left c

/-- Product of two nonzero rationals is nonzero. -/
theorem qMul_ne_zero {a b : QBOMA} (ha : a ≠ qZero) (hb : b ≠ qZero) :
    qMul a b ≠ qZero := by
  intro hab
  have hzero : qMul a b = qMul a qZero := by
    rw [qMul_zero_right]
    exact hab
  exact hb (qMul_left_cancel_nonzero ha hzero)

/-- Strict multiplication monotonicity by a positive left factor. -/
theorem qlt_mul_left_positive {x y c : QBOMA}
    (hxy : qLT x y) (hc : QPositive c) :
    qLT (qMul c x) (qMul c y) := by
  refine ⟨qmul_mono_left_nonneg hxy.1 hc.1, ?_⟩
  intro heq
  exact hxy.2 (qMul_left_cancel_nonzero hc.2 heq)

/-- Rational two. -/
def qTwo : QBOMA := qAdd qOne qOne

/-- Zero is strictly below one. -/
theorem qzero_lt_one : qLT qZero qOne :=
  ⟨qzero_le_one, fun h => qone_ne_zero h.symm⟩

/-- One is strictly below two. -/
theorem qone_lt_two : qLT qOne qTwo := by
  have h := qlt_add_right qzero_lt_one qOne
  change qLT (qAdd qZero qOne) qTwo at h
  rw [qAdd_zero_left] at h
  exact h

/-- Two is positive and nonzero. -/
theorem qtwo_positive : QPositive qTwo := by
  have h02 : qLT qZero qTwo := qlt_trans qzero_lt_one qone_lt_two
  exact ⟨h02.1, fun h => h02.2 h.symm⟩

/-- There exists a positive rational half strictly between zero and one, obtained
from the already-accepted unique inverse witness for two. -/
theorem rational_half_exists :
    ∃ h : QBOMA, QInvRel qTwo h ∧ qLT qZero h ∧ qLT h qOne := by
  rcases q_inverse_exists qTwo qtwo_positive.2 with ⟨h, hh⟩
  have hpos : QPositive h := inverse_of_positive_is_positive qtwo_positive hh
  have h0h : qLT qZero h := ⟨hpos.1, fun hz => hpos.2 hz.symm⟩
  have hsum : qAdd h h = qOne := by
    unfold QInvRel at hh
    calc
      qAdd h h = qAdd (qMul qOne h) h :=
        congrArg (fun t => qAdd t h) (qMul_one_left h).symm
      _ = qAdd (qMul qOne h) (qMul qOne h) :=
        congrArg (fun t => qAdd (qMul qOne h) t) (qMul_one_left h).symm
      _ = qMul (qAdd qOne qOne) h := (qMul_add_left qOne qOne h).symm
      _ = qMul qTwo h := rfl
      _ = qOne := hh
  have hlt1 : qLT h qOne := by
    have ht := qlt_add_right h0h h
    rw [qAdd_zero_left, hsum] at ht
    exact ht
  exact ⟨h, hh, h0h, hlt1⟩

/-- If x<y then the ordered-field difference y-x is positive. -/
theorem positive_difference_of_lt {x y : QBOMA} (hxy : qLT x y) :
    QPositive (qAdd y (qNeg x)) := by
  constructor
  · exact (qle_iff_nonneg_difference x y).1 hxy.1
  · intro hd0
    have hleft : qAdd (qNeg x) y = qZero := by
      calc
        qAdd (qNeg x) y = qAdd y (qNeg x) := qAdd_comm _ _
        _ = qZero := hd0
    have hright : qAdd (qNeg x) x = qZero := qAdd_neg_left x
    have hyx : y = x := qAdd_left_cancel (hleft.trans hright.symm)
    exact hxy.2 hyx.symm

/-- The accepted rational order is internally dense. This theorem is a shared
pre-real gateway and does not depend on either the Dedekind or Cauchy carrier. -/
theorem rational_order_dense {x y : QBOMA} (hxy : qLT x y) :
    ∃ m : QBOMA, qLT x m ∧ qLT m y := by
  rcases rational_half_exists with ⟨half, hhalfInv, h0half, hhalf1⟩
  let d := qAdd y (qNeg x)
  have hdpos : QPositive d := positive_difference_of_lt hxy
  let p := qMul d half
  have hhalfPos : QPositive half :=
    ⟨h0half.1, fun h => h0half.2 h.symm⟩
  have hpNonNeg : qLE qZero p := by
    unfold p
    exact qmul_nonneg hdpos.1 hhalfPos.1
  have hpNe : p ≠ qZero := by
    unfold p
    exact qMul_ne_zero hdpos.2 hhalfPos.2
  have h0p : qLT qZero p := ⟨hpNonNeg, fun h => hpNe h.symm⟩
  have hpd : qLT p d := by
    have hm := qlt_mul_left_positive hhalf1 hdpos
    unfold p
    rw [qMul_one_right] at hm
    exact hm
  let m := qAdd x p
  have hxm : qLT x m := by
    have ht := qlt_add_right h0p x
    change qLT (qAdd qZero x) (qAdd p x) at ht
    rw [qAdd_zero_left, qAdd_comm p x] at ht
    exact ht
  have hmy : qLT m y := by
    have ht := qlt_add_right hpd x
    have hdx : qAdd d x = y := by
      unfold d
      calc
        qAdd (qAdd y (qNeg x)) x = qAdd y (qAdd (qNeg x) x) :=
          qAdd_assoc y (qNeg x) x
        _ = qAdd y qZero := by rw [qAdd_neg_left]
        _ = y := qAdd_zero_right y
    change qLT (qAdd p x) (qAdd d x) at ht
    rw [qAdd_comm p x, hdx] at ht
    exact ht
  exact ⟨m, hxm, hmy⟩

end BOMA.R.Gateway001

/- Representation-only Dedekind route probe. No real carrier identity is selected here. -/
namespace BOMA.R.DedekindProbe001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001

/-- Lower Dedekind-cut syntax over accepted QBOMA.
The no-greatest-element requirement is expressed by strict rational order. -/
structure LowerCut where
  lower : QBOMA → Prop
  nonempty : ∃ q : QBOMA, lower q
  proper : ∃ q : QBOMA, ¬ lower q
  downward : ∀ {a b : QBOMA}, lower b → qLE a b → lower a
  rounded : ∀ {a : QBOMA}, lower a → ∃ b : QBOMA, lower b ∧ qLT a b

/-- Extensional representation relation for cut syntax.
This is deliberately external: the probe does not assume function/proposition
extensionality or select raw structure equality as real identity. -/
def CutEquiv (A B : LowerCut) : Prop :=
  ∀ q : QBOMA, A.lower q ↔ B.lower q

theorem cutEquiv_refl (A : LowerCut) : CutEquiv A A := by
  intro q
  exact Iff.rfl

theorem cutEquiv_symm {A B : LowerCut} (h : CutEquiv A B) : CutEquiv B A := by
  intro q
  exact (h q).symm

theorem cutEquiv_trans {A B C : LowerCut}
    (hAB : CutEquiv A B) (hBC : CutEquiv B C) : CutEquiv A C := by
  intro q
  exact Iff.trans (hAB q) (hBC q)

end BOMA.R.DedekindProbe001

/- Deeper Dedekind-route probe: principal rational lower cuts. -/
namespace BOMA.R.DedekindProbe001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001

/-- A concrete rational predecessor q-1 lies strictly below q. -/
theorem q_minus_one_lt (q : QBOMA) : qLT (qAdd q (qNeg qOne)) q := by
  have ht := qlt_add_right qzero_lt_one (qAdd q (qNeg qOne))
  have hright : qAdd qOne (qAdd q (qNeg qOne)) = q := by
    calc
      qAdd qOne (qAdd q (qNeg qOne)) =
          qAdd qOne (qAdd (qNeg qOne) q) :=
        congrArg (fun t => qAdd qOne t) (qAdd_comm q (qNeg qOne))
      _ = qAdd (qAdd qOne (qNeg qOne)) q :=
        (qAdd_assoc qOne (qNeg qOne) q).symm
      _ = qAdd qZero q := by rw [qAdd_neg_right]
      _ = q := qAdd_zero_left q
  rw [qAdd_zero_left, hright] at ht
  exact ht

/-- Principal lower cut associated with an accepted rational q. -/
def principalCut (q : QBOMA) : LowerCut where
  lower := fun a => qLT a q
  nonempty := ⟨qAdd q (qNeg qOne), q_minus_one_lt q⟩
  proper := ⟨q, qlt_irrefl q⟩
  downward := by
    intro a b hb hab
    refine ⟨qle_trans hab hb.1, ?_⟩
    intro haq
    rw [haq] at hab
    have hbq : b = q := qle_antisymm hb.1 hab
    exact hb.2 hbq
  rounded := by
    intro a ha
    rcases rational_order_dense ha with ⟨b, hab, hbq⟩
    exact ⟨b, hbq, hab⟩

/-- Principal-cut representation preserves rational equality. -/
theorem principalCut_preserves {q r : QBOMA} (h : q = r) :
    CutEquiv (principalCut q) (principalCut r) := by
  cases h
  exact cutEquiv_refl _

/-- Principal-cut representation reflects rational equality at the external
CutEquiv layer. This uses internal Q density, making the dependency explicit. -/
theorem principalCut_reflects {q r : QBOMA}
    (h : CutEquiv (principalCut q) (principalCut r)) : q = r := by
  rcases qlt_trichotomy q r with hqr | heq | hrq
  · rcases rational_order_dense hqr with ⟨m, hqm, hmr⟩
    have hmR : (principalCut r).lower m := hmr
    have hmQ : (principalCut q).lower m := (h m).2 hmR
    exact False.elim ((qlt_asymm hqm) hmQ)
  · exact heq
  · rcases rational_order_dense hrq with ⟨m, hrm, hmq⟩
    have hmQ : (principalCut q).lower m := hmq
    have hmR : (principalCut r).lower m := (h m).1 hmQ
    exact False.elim ((qlt_asymm hrm) hmR)

/-- Inclusion relation restricted to principal rational cuts. -/
def PrincipalLE (q r : QBOMA) : Prop :=
  ∀ a : QBOMA, (principalCut q).lower a → (principalCut r).lower a

/-- Principal-cut inclusion is exactly the accepted rational non-strict order.
The forward proof reuses the single explicit trichotomy gateway instead of
introducing a second implicit proposition-decidability split. -/
theorem principalLE_iff_qLE (q r : QBOMA) : PrincipalLE q r ↔ qLE q r := by
  constructor
  · intro hInc
    rcases qlt_trichotomy q r with hqr | heq | hrq
    · exact hqr.1
    · rw [heq]
      exact qle_refl r
    · rcases rational_order_dense hrq with ⟨m, hrm, hmq⟩
      have hmQ : (principalCut q).lower m := hmq
      have hmR : (principalCut r).lower m := hInc m hmQ
      exact False.elim ((qlt_asymm hrm) hmR)
  · intro hqr a haq
    refine ⟨qle_trans haq.1 hqr, ?_⟩
    intro har
    have hqa : qLE q a := by
      rw [har]
      exact hqr
    have hqaEq : q = a := qle_antisymm hqa haq.1
    exact haq.2 hqaEq.symm

end BOMA.R.DedekindProbe001

/- Dedekind-route completeness probe: supremum by union of lower cuts. -/
namespace BOMA.R.DedekindProbe001

open BOMA.Q.Quotient001

/-- Inclusion order between lower-cut representations. -/
def CutLE (A B : LowerCut) : Prop :=
  ∀ q : QBOMA, A.lower q → B.lower q

@[simp] theorem cutLE_refl (A : LowerCut) : CutLE A A := by
  intro q hq
  exact hq

theorem cutLE_trans {A B C : LowerCut}
    (hAB : CutLE A B) (hBC : CutLE B C) : CutLE A C := by
  intro q hq
  exact hBC q (hAB q hq)

/-- A family of lower cuts is bounded above by U when every member is included in U. -/
def FamilyBoundedAbove (F : LowerCut → Prop) (U : LowerCut) : Prop :=
  ∀ A : LowerCut, F A → CutLE A U

/-- Union cut of a nonempty family with an explicit upper bound. -/
def supCut
    (F : LowerCut → Prop)
    (hne : ∃ A : LowerCut, F A)
    (U : LowerCut)
    (hUB : FamilyBoundedAbove F U) : LowerCut where
  lower := fun q => ∃ A : LowerCut, F A ∧ A.lower q
  nonempty := by
    rcases hne with ⟨A, hFA⟩
    rcases A.nonempty with ⟨q, hq⟩
    exact ⟨q, A, hFA, hq⟩
  proper := by
    rcases U.proper with ⟨q, hqU⟩
    refine ⟨q, ?_⟩
    intro hqSup
    rcases hqSup with ⟨A, hFA, hqA⟩
    exact hqU (hUB A hFA q hqA)
  downward := by
    intro a b hb hab
    rcases hb with ⟨A, hFA, hbA⟩
    exact ⟨A, hFA, A.downward hbA hab⟩
  rounded := by
    intro a ha
    rcases ha with ⟨A, hFA, haA⟩
    rcases A.rounded haA with ⟨b, hbA, hab⟩
    exact ⟨b, ⟨A, hFA, hbA⟩, hab⟩

/-- Every family member lies below the union cut. -/
theorem member_le_supCut
    (F : LowerCut → Prop)
    (hne : ∃ A : LowerCut, F A)
    (U : LowerCut)
    (hUB : FamilyBoundedAbove F U)
    {A : LowerCut} (hFA : F A) :
    CutLE A (supCut F hne U hUB) := by
  intro q hq
  exact ⟨A, hFA, hq⟩

/-- The union cut is below every common upper bound, hence is least. -/
theorem supCut_le_of_upper
    (F : LowerCut → Prop)
    (hne : ∃ A : LowerCut, F A)
    (U : LowerCut)
    (hUB : FamilyBoundedAbove F U)
    (B : LowerCut)
    (hB : FamilyBoundedAbove F B) :
    CutLE (supCut F hne U hUB) B := by
  intro q hq
  rcases hq with ⟨A, hFA, hqA⟩
  exact hB A hFA q hqA

/-- Representation-level least-upper-bound certificate. -/
theorem supCut_is_lub
    (F : LowerCut → Prop)
    (hne : ∃ A : LowerCut, F A)
    (U : LowerCut)
    (hUB : FamilyBoundedAbove F U) :
    (∀ A : LowerCut, F A → CutLE A (supCut F hne U hUB)) ∧
    (∀ B : LowerCut, FamilyBoundedAbove F B → CutLE (supCut F hne U hUB) B) := by
  constructor
  · intro A hFA
    exact member_le_supCut F hne U hUB hFA
  · intro B hB
    exact supCut_le_of_upper F hne U hUB B hB

end BOMA.R.DedekindProbe001

/- Formal identity probe for the selected Dedekind route. -/
namespace BOMA.R.DedekindQuotient001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.DedekindProbe001

/-- Extensional cut identity packaged as a formal Setoid. -/
def cutSetoid : Setoid LowerCut where
  r := CutEquiv
  iseqv := ⟨cutEquiv_refl, @cutEquiv_symm, @cutEquiv_trans⟩

/-- Candidate Stage-One real carrier under identity Candidate A. -/
def RBOMA : Type := Quotient cutSetoid

/-- Injection of a lower-cut representation into the formal carrier. -/
def rmk (A : LowerCut) : RBOMA := Quotient.mk cutSetoid A

/-- Extensional-equivalent cuts become formally equal. -/
theorem rmk_sound {A B : LowerCut} (h : CutEquiv A B) : rmk A = rmk B :=
  Quotient.sound h

/-- Formal equality of explicit representatives is exactly CutEquiv. -/
theorem rmk_eq_iff {A B : LowerCut} : rmk A = rmk B ↔ CutEquiv A B := by
  constructor
  · intro h
    exact Quotient.exact h
  · exact rmk_sound

/-- Candidate rational embedding into the quotient real carrier. -/
def rOfQ (q : QBOMA) : RBOMA := rmk (principalCut q)

/-- The principal-cut rational embedding remains injective after quotienting. -/
theorem rOfQ_injective {q r : QBOMA} (h : rOfQ q = rOfQ r) : q = r := by
  apply principalCut_reflects
  exact Quotient.exact h

/-- Inclusion of cuts respects extensional identity in both endpoints. -/
theorem cutLE_respects {A A' B B' : LowerCut}
    (hA : CutEquiv A A') (hB : CutEquiv B B')
    (hLE : CutLE A B) : CutLE A' B' := by
  intro q hqA'
  have hqA : A.lower q := (hA q).mpr hqA'
  have hqB : B.lower q := hLE q hqA
  exact (hB q).mp hqB

/-- Quotient order without proposition extensionality: endpoints are witnessed
by explicit cut representatives related by inclusion. -/
def rLE (x y : RBOMA) : Prop :=
  ∃ A : LowerCut, ∃ B : LowerCut,
    x = rmk A ∧ y = rmk B ∧ CutLE A B

/-- On explicit representatives, formal real order is exactly cut inclusion. -/
theorem rLE_mk_iff (A B : LowerCut) :
    rLE (rmk A) (rmk B) ↔ CutLE A B := by
  constructor
  · rintro ⟨A', B', hAeq, hBeq, hLE⟩
    have hA : CutEquiv A A' := (rmk_eq_iff).mp hAeq
    have hB : CutEquiv B B' := (rmk_eq_iff).mp hBeq
    exact cutLE_respects (cutEquiv_symm hA) (cutEquiv_symm hB) hLE
  · intro h
    exact ⟨A, B, rfl, rfl, h⟩

/-- The quotient rational embedding preserves and reflects accepted Q order.
The Iff chain is composed directly rather than rewriting one proposition by an
Iff theorem, keeping proposition extensionality out of this proof term. -/
theorem rOfQ_order (q r : QBOMA) :
    rLE (rOfQ q) (rOfQ r) ↔ qLE q r := by
  change rLE (rmk (principalCut q)) (rmk (principalCut r)) ↔ qLE q r
  have hPrincipal :
      CutLE (principalCut q) (principalCut r) ↔ qLE q r := by
    change PrincipalLE q r ↔ qLE q r
    exact principalLE_iff_qLE q r
  exact (rLE_mk_iff (principalCut q) (principalCut r)).trans hPrincipal

end BOMA.R.DedekindQuotient001

/- Constructive core of the selected Dedekind quotient order. -/
namespace BOMA.R.DedekindOrderConstructive001

open BOMA.Q.Quotient001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001

/-- Opposite cut inclusions give extensional cut identity constructively. -/
theorem cutLE_antisymm_equiv {A B : LowerCut}
    (hAB : CutLE A B) (hBA : CutLE B A) : CutEquiv A B := by
  intro q
  constructor
  · intro hq
    exact hAB q hq
  · intro hq
    exact hBA q hq

/-- Reflexivity of quotient cut order. -/
theorem rLE_refl (x : RBOMA) : rLE x x := by
  refine Quotient.inductionOn x ?_
  intro A
  exact (rLE_mk_iff A A).2 (cutLE_refl A)

/-- Transitivity of quotient cut order. -/
theorem rLE_trans {x y z : RBOMA}
    (hxy : rLE x y) (hyz : rLE y z) : rLE x z := by
  refine Quotient.inductionOn x ?_ hxy hyz
  intro A hAy hYz
  refine Quotient.inductionOn y ?_ hAy hYz
  intro B hAB hBz
  refine Quotient.inductionOn z ?_ hAB hBz
  intro C hAB' hBC'
  apply (rLE_mk_iff A C).2
  exact cutLE_trans ((rLE_mk_iff A B).1 hAB') ((rLE_mk_iff B C).1 hBC')

/-- Antisymmetry of quotient cut order. -/
theorem rLE_antisymm {x y : RBOMA}
    (hxy : rLE x y) (hyx : rLE y x) : x = y := by
  refine Quotient.inductionOn x ?_ hxy hyx
  intro A hAy hYA
  refine Quotient.inductionOn y ?_ hAy hYA
  intro B hAB hBA
  exact rmk_sound (cutLE_antisymm_equiv
    ((rLE_mk_iff A B).1 hAB) ((rLE_mk_iff B A).1 hBA))

/-- Exact isolated interface needed for disjunctive totality. -/
def CutComparability : Prop :=
  ∀ A B : LowerCut, CutLE A B ∨ CutLE B A

/-- Totality follows from the isolated comparability interface, without using
Classical inside this theorem. -/
theorem rLE_total_of_cutComparability
    (hComp : CutComparability) (x y : RBOMA) : rLE x y ∨ rLE y x := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  rcases hComp A B with hAB | hBA
  · exact Or.inl ((rLE_mk_iff A B).2 hAB)
  · exact Or.inr ((rLE_mk_iff B A).2 hBA)

end BOMA.R.DedekindOrderConstructive001

/- Isolated classical witness for total comparability of Dedekind lower cuts. -/
namespace BOMA.R.DedekindOrderClassical001

open BOMA.Q.Order001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001

/-- Classical excluded middle supplies the isolated CutComparability interface
for lower sets of the accepted linearly ordered rational carrier. The classical
commitment is explicit in the two calls to `Classical.em`. -/
theorem cutComparability_classical : CutComparability := by
  intro A B
  cases Classical.em (CutLE A B) with
  | inl hAB =>
      exact Or.inl hAB
  | inr hNotAB =>
      apply Or.inr
      intro q hqB
      cases Classical.em (A.lower q) with
      | inl hqA =>
          exact hqA
      | inr hNotAq =>
          exfalso
          apply hNotAB
          intro r hrA
          rcases qle_total r q with hrq | hqr
          · exact B.downward hqB hrq
          · exact False.elim (hNotAq (A.downward hrA hqr))

/-- Stage-One totality candidate obtained from the localized classical witness. -/
theorem rLE_total_classical (x y : RBOMA) : rLE x y ∨ rLE y x :=
  rLE_total_of_cutComparability cutComparability_classical x y

end BOMA.R.DedekindOrderClassical001

/- Addition on selected Dedekind lower cuts and the formal RBOMA quotient. -/
namespace BOMA.R.DedekindAddition001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001

/-- Mixed non-strict/strict transitivity on accepted Q. -/
theorem qle_lt_trans {x y z : QBOMA} (hxy : qLE x y) (hyz : qLT y z) : qLT x z := by
  refine ⟨qle_trans hxy hyz.1, ?_⟩
  intro hxz
  have hzy : qLE z y := by
    have h := hxy
    rw [hxz] at h
    exact h
  have hyzEq : y = z := qle_antisymm hyz.1 hzy
  exact hyz.2 hyzEq

/-- Strict/non-strict transitivity on accepted Q. -/
theorem qlt_le_trans {x y z : QBOMA} (hxy : qLT x y) (hyz : qLE y z) : qLT x z := by
  refine ⟨qle_trans hxy.1 hyz, ?_⟩
  intro hxz
  have hyx : qLE y x := by
    have h := hyz
    rw [← hxz] at h
    exact h
  have hxyEq : x = y := qle_antisymm hxy.1 hyx
  exact hxy.2 hxyEq

/-- Addition is monotone in both accepted rational arguments. -/
theorem qadd_mono {a a' b b' : QBOMA}
    (ha : qLE a a') (hb : qLE b b') :
    qLE (qAdd a b) (qAdd a' b') := by
  have h1 : qLE (qAdd a b) (qAdd a' b) := qadd_mono_right ha b
  have h2raw : qLE (qAdd b a') (qAdd b' a') := qadd_mono_right hb a'
  have h2 : qLE (qAdd a' b) (qAdd a' b') := by
    rw [qAdd_comm a' b, qAdd_comm a' b']
    exact h2raw
  exact qle_trans h1 h2

/-- Raw Dedekind sum: q lies below A+B when it lies strictly below a+b for
some a in A and b in B. -/
def cutAdd (A B : LowerCut) : LowerCut where
  lower := fun q =>
    ∃ a b : QBOMA, A.lower a ∧ B.lower b ∧ qLT q (qAdd a b)
  nonempty := by
    rcases A.nonempty with ⟨a, ha⟩
    rcases B.nonempty with ⟨b, hb⟩
    let s := qAdd a b
    let q := qAdd s (qNeg qOne)
    refine ⟨q, a, b, ha, hb, ?_⟩
    change qLT (qAdd s (qNeg qOne)) s
    exact BOMA.R.DedekindProbe001.q_minus_one_lt s
  proper := by
    rcases A.proper with ⟨uA, huA⟩
    rcases B.proper with ⟨uB, huB⟩
    refine ⟨qAdd uA uB, ?_⟩
    intro hsum
    rcases hsum with ⟨a, b, ha, hb, hstrict⟩
    have haU : qLE a uA := by
      rcases qle_total a uA with h | h
      · exact h
      · exact False.elim (huA (A.downward ha h))
    have hbU : qLE b uB := by
      rcases qle_total b uB with h | h
      · exact h
      · exact False.elim (huB (B.downward hb h))
    have habU : qLE (qAdd a b) (qAdd uA uB) := qadd_mono haU hbU
    have heq : qAdd uA uB = qAdd a b := qle_antisymm hstrict.1 habU
    exact hstrict.2 heq
  downward := by
    intro p q hq hpq
    rcases hq with ⟨a, b, ha, hb, hqsum⟩
    exact ⟨a, b, ha, hb, qle_lt_trans hpq hqsum⟩
  rounded := by
    intro q hq
    rcases hq with ⟨a, b, ha, hb, hqsum⟩
    rcases rational_order_dense hqsum with ⟨m, hqm, hmsum⟩
    exact ⟨m, ⟨a, b, ha, hb, hmsum⟩, hqm⟩

/-- Raw cut addition respects extensional identity in both inputs. -/
theorem cutAdd_respects {A A' B B' : LowerCut}
    (hA : CutEquiv A A') (hB : CutEquiv B B') :
    CutEquiv (cutAdd A B) (cutAdd A' B') := by
  intro q
  constructor
  · intro hq
    rcases hq with ⟨a, b, ha, hb, hlt⟩
    exact ⟨a, b, (hA a).mp ha, (hB b).mp hb, hlt⟩
  · intro hq
    rcases hq with ⟨a, b, ha, hb, hlt⟩
    exact ⟨a, b, (hA a).mpr ha, (hB b).mpr hb, hlt⟩

/-- Formal real addition lifted through the verified CutEquiv respect theorem. -/
def rAdd : RBOMA → RBOMA → RBOMA :=
  Quotient.lift₂
    (fun A B => rmk (cutAdd A B))
    (fun _ _ _ _ hA hB => rmk_sound (cutAdd_respects hA hB))

@[simp] theorem rAdd_mk (A B : LowerCut) :
    rAdd (rmk A) (rmk B) = rmk (cutAdd A B) := rfl

/-- Candidate real zero and one inherited from the faithful rational embedding. -/
def rZero : RBOMA := rOfQ qZero
def rOne : RBOMA := rOfQ qOne

end BOMA.R.DedekindAddition001

/- Rational embedding preservation for selected Dedekind real addition. -/
namespace BOMA.R.DedekindAdditionEmbedding001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001

/-- Translating x < q+r by -r yields x-r < q. -/
theorem qlt_sub_right_of_lt_add {x q r : QBOMA}
    (h : qLT x (qAdd q r)) :
    qLT (qAdd x (qNeg r)) q := by
  have ht := qlt_add_right h (qNeg r)
  have hright : qAdd (qAdd q r) (qNeg r) = q := by
    calc
      qAdd (qAdd q r) (qNeg r) = qAdd q (qAdd r (qNeg r)) :=
        qAdd_assoc q r (qNeg r)
      _ = qAdd q qZero := by rw [qAdd_neg_right]
      _ = q := qAdd_zero_right q
  rw [hright] at ht
  exact ht

/-- Translating x-r < a back by r yields x < a+r. -/
theorem qlt_add_back_right {x a r : QBOMA}
    (h : qLT (qAdd x (qNeg r)) a) :
    qLT x (qAdd a r) := by
  have ht := qlt_add_right h r
  have hleft : qAdd (qAdd x (qNeg r)) r = x := by
    calc
      qAdd (qAdd x (qNeg r)) r = qAdd x (qAdd (qNeg r) r) :=
        qAdd_assoc x (qNeg r) r
      _ = qAdd x qZero := by rw [qAdd_neg_left]
      _ = x := qAdd_zero_right x
  rw [hleft] at ht
  exact ht

/-- Translating x < a+r by -a yields x-a < r. -/
theorem qlt_sub_left_of_lt_add {x a r : QBOMA}
    (h : qLT x (qAdd a r)) :
    qLT (qAdd x (qNeg a)) r := by
  have ht := qlt_add_right h (qNeg a)
  have hright : qAdd (qAdd a r) (qNeg a) = r := by
    calc
      qAdd (qAdd a r) (qNeg a) = qAdd a (qAdd r (qNeg a)) :=
        qAdd_assoc a r (qNeg a)
      _ = qAdd a (qAdd (qNeg a) r) :=
        congrArg (fun t => qAdd a t) (qAdd_comm r (qNeg a))
      _ = qAdd (qAdd a (qNeg a)) r :=
        (qAdd_assoc a (qNeg a) r).symm
      _ = qAdd qZero r := by rw [qAdd_neg_right]
      _ = r := qAdd_zero_left r
  rw [hright] at ht
  exact ht

/-- Translating x-a < b back by a yields x < a+b. -/
theorem qlt_add_back_left {x a b : QBOMA}
    (h : qLT (qAdd x (qNeg a)) b) :
    qLT x (qAdd a b) := by
  have ht := qlt_add_right h a
  have hleft : qAdd (qAdd x (qNeg a)) a = x := by
    calc
      qAdd (qAdd x (qNeg a)) a = qAdd x (qAdd (qNeg a) a) :=
        qAdd_assoc x (qNeg a) a
      _ = qAdd x qZero := by rw [qAdd_neg_left]
      _ = x := qAdd_zero_right x
  have hright : qAdd b a = qAdd a b := qAdd_comm b a
  rw [hleft, hright] at ht
  exact ht

/-- The Dedekind sum of two principal rational cuts is extensionally the
principal cut of the accepted rational sum. -/
theorem cutAdd_principal (q r : QBOMA) :
    CutEquiv
      (cutAdd (principalCut q) (principalCut r))
      (principalCut (qAdd q r)) := by
  intro x
  constructor
  · intro hx
    rcases hx with ⟨a, b, ha, hb, hxab⟩
    have hab : qLE (qAdd a b) (qAdd q r) :=
      qadd_mono ha.1 hb.1
    exact qlt_le_trans hxab hab
  · intro hx
    have hxq : qLT (qAdd x (qNeg r)) q :=
      qlt_sub_right_of_lt_add hx
    rcases rational_order_dense hxq with ⟨a, hxa, haq⟩
    have hxar : qLT x (qAdd a r) := qlt_add_back_right hxa
    have hxr : qLT (qAdd x (qNeg a)) r :=
      qlt_sub_left_of_lt_add hxar
    rcases rational_order_dense hxr with ⟨b, hxb, hbr⟩
    have hxab : qLT x (qAdd a b) := qlt_add_back_left hxb
    exact ⟨a, b, haq, hbr, hxab⟩

/-- The accepted rational embedding into RBOMA preserves addition. -/
theorem rOfQ_add (q r : QBOMA) :
    rAdd (rOfQ q) (rOfQ r) = rOfQ (qAdd q r) := by
  change
    rmk (cutAdd (principalCut q) (principalCut r)) =
    rmk (principalCut (qAdd q r))
  exact rmk_sound (cutAdd_principal q r)

/-- The real zero spelling agrees with the rational embedding of qZero. -/
@[simp] theorem rZero_eq_rOfQ_zero : rZero = rOfQ qZero := rfl

/-- The real one spelling agrees with the rational embedding of qOne. -/
@[simp] theorem rOne_eq_rOfQ_one : rOne = rOfQ qOne := rfl

end BOMA.R.DedekindAdditionEmbedding001

/- Additive laws for the selected Dedekind real operation, before negation. -/
namespace BOMA.R.DedekindAdditionLaws001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionEmbedding001

/-- Raw Dedekind addition is commutative up to extensional cut identity. -/
theorem cutAdd_comm_equiv (A B : LowerCut) :
    CutEquiv (cutAdd A B) (cutAdd B A) := by
  intro x
  constructor
  · rintro ⟨a, b, ha, hb, hxab⟩
    have hxba : qLT x (qAdd b a) := by
      rw [qAdd_comm b a]
      exact hxab
    exact ⟨b, a, hb, ha, hxba⟩
  · rintro ⟨b, a, hb, ha, hxba⟩
    have hxab : qLT x (qAdd a b) := by
      rw [qAdd_comm a b]
      exact hxba
    exact ⟨a, b, ha, hb, hxab⟩

/-- The principal zero cut is a left identity for raw Dedekind addition. -/
theorem cutAdd_zero_left_equiv (A : LowerCut) :
    CutEquiv (cutAdd (principalCut qZero) A) A := by
  intro x
  constructor
  · rintro ⟨a, b, ha0, hb, hxab⟩
    have hab : qLE (qAdd a b) b := by
      have hmono := qadd_mono ha0.1 (qle_refl b)
      rw [qAdd_zero_left] at hmono
      exact hmono
    have hxb : qLT x b := qlt_le_trans hxab hab
    exact A.downward hb hxb.1
  · intro hxA
    rcases A.rounded hxA with ⟨b, hbA, hxb⟩
    have hx0 : qLT (qAdd x (qNeg b)) qZero := by
      have ht : qLT (qAdd x (qNeg b)) qZero := by
        have hz : qAdd qZero b = b := qAdd_zero_left b
        have h0 := qlt_sub_right_of_lt_add (q := qZero) (r := b) (by
          rw [hz]
          exact hxb)
        exact h0
      exact ht
    rcases rational_order_dense hx0 with ⟨a, hxa, ha0⟩
    have hxab : qLT x (qAdd a b) := qlt_add_back_right hxa
    exact ⟨a, b, ha0, hbA, hxab⟩

/-- The principal zero cut is also a right identity. -/
theorem cutAdd_zero_right_equiv (A : LowerCut) :
    CutEquiv (cutAdd A (principalCut qZero)) A := by
  exact cutEquiv_trans
    (cutAdd_comm_equiv A (principalCut qZero))
    (cutAdd_zero_left_equiv A)

/-- Raw Dedekind addition is associative up to extensional cut identity. -/
theorem cutAdd_assoc_equiv (A B C : LowerCut) :
    CutEquiv (cutAdd (cutAdd A B) C) (cutAdd A (cutAdd B C)) := by
  intro x
  constructor
  · rintro ⟨s, c, hsAB, hc, hxsc⟩
    rcases hsAB with ⟨a, b, ha, hb, hsab⟩
    have hscABC : qLT (qAdd s c) (qAdd a (qAdd b c)) := by
      have ht := qlt_add_right hsab c
      rw [qAdd_assoc a b c] at ht
      exact ht
    have hxABC : qLT x (qAdd a (qAdd b c)) := qlt_trans hxsc hscABC
    have hxbc : qLT (qAdd x (qNeg a)) (qAdd b c) :=
      qlt_sub_left_of_lt_add hxABC
    rcases rational_order_dense hxbc with ⟨t, hxt, htbc⟩
    have htBC : (cutAdd B C).lower t := ⟨b, c, hb, hc, htbc⟩
    have hxat : qLT x (qAdd a t) := qlt_add_back_left hxt
    exact ⟨a, t, ha, htBC, hxat⟩
  · rintro ⟨a, t, ha, htBC, hxat⟩
    rcases htBC with ⟨b, c, hb, hc, htbc⟩
    have hatABC : qLT (qAdd a t) (qAdd a (qAdd b c)) := by
      have ht := qlt_add_right htbc a
      have hleft : qAdd t a = qAdd a t := qAdd_comm t a
      have hright : qAdd (qAdd b c) a = qAdd a (qAdd b c) :=
        qAdd_comm (qAdd b c) a
      rw [hleft, hright] at ht
      exact ht
    have hxABC : qLT x (qAdd a (qAdd b c)) := qlt_trans hxat hatABC
    have hxAssoc : qLT x (qAdd (qAdd a b) c) := by
      rw [qAdd_assoc a b c]
      exact hxABC
    have hxab : qLT (qAdd x (qNeg c)) (qAdd a b) :=
      qlt_sub_right_of_lt_add hxAssoc
    rcases rational_order_dense hxab with ⟨s, hxs, hsab⟩
    have hsAB : (cutAdd A B).lower s := ⟨a, b, ha, hb, hsab⟩
    have hxsc : qLT x (qAdd s c) := qlt_add_back_right hxs
    exact ⟨s, c, hsAB, hc, hxsc⟩

/-- Formal real addition is commutative. -/
theorem rAdd_comm (x y : RBOMA) : rAdd x y = rAdd y x := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  change rmk (cutAdd A B) = rmk (cutAdd B A)
  exact rmk_sound (cutAdd_comm_equiv A B)

/-- Formal real addition is associative. -/
theorem rAdd_assoc (x y z : RBOMA) :
    rAdd (rAdd x y) z = rAdd x (rAdd y z) := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  refine Quotient.inductionOn z ?_
  intro C
  change rmk (cutAdd (cutAdd A B) C) = rmk (cutAdd A (cutAdd B C))
  exact rmk_sound (cutAdd_assoc_equiv A B C)

/-- Formal real zero is a left additive identity. -/
@[simp] theorem rAdd_zero_left (x : RBOMA) : rAdd rZero x = x := by
  refine Quotient.inductionOn x ?_
  intro A
  change rmk (cutAdd (principalCut qZero) A) = rmk A
  exact rmk_sound (cutAdd_zero_left_equiv A)

/-- Formal real zero is a right additive identity. -/
@[simp] theorem rAdd_zero_right (x : RBOMA) : rAdd x rZero = x := by
  calc
    rAdd x rZero = rAdd rZero x := rAdd_comm x rZero
    _ = x := rAdd_zero_left x

end BOMA.R.DedekindAdditionLaws001

/- Additive compatibility of the selected Dedekind real order. -/
namespace BOMA.R.DedekindOrderAdditive001

open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001

/-- Cut addition is monotone under cut inclusion in both arguments. -/
theorem cutAdd_mono
    {A A' B B' : LowerCut}
    (hA : CutLE A A')
    (hB : CutLE B B') :
    CutLE (cutAdd A B) (cutAdd A' B') := by
  intro q hq
  rcases hq with ⟨a, b, ha, hb, hqab⟩
  exact ⟨a, b, hA a ha, hB b hb, hqab⟩

/-- Formal real addition is monotone in both arguments. -/
theorem rAdd_mono
    {x x' y y' : RBOMA}
    (hx : rLE x x')
    (hy : rLE y y') :
    rLE (rAdd x y) (rAdd x' y') := by
  rcases hx with ⟨A, A', hxA, hxA', hAA'⟩
  rcases hy with ⟨B, B', hyB, hyB', hBB'⟩
  refine ⟨cutAdd A B, cutAdd A' B', ?_, ?_, cutAdd_mono hAA' hBB'⟩
  · rw [hxA, hyB]
    rfl
  · rw [hxA', hyB']
    rfl

/-- Addition by a common right translate preserves order. -/
theorem rAdd_mono_right {x y : RBOMA}
    (hxy : rLE x y) (c : RBOMA) :
    rLE (rAdd x c) (rAdd y c) :=
  rAdd_mono hxy (rLE_refl c)

/-- Addition by a common left translate preserves order. -/
theorem rAdd_mono_left {x y : RBOMA}
    (hxy : rLE x y) (c : RBOMA) :
    rLE (rAdd c x) (rAdd c y) :=
  rAdd_mono (rLE_refl c) hxy

/-- The sum of two nonnegative reals is nonnegative. -/
theorem rAdd_nonneg
    {x y : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y) :
    rLE rZero (rAdd x y) := by
  have h := rAdd_mono h0x h0y
  rw [rAdd_zero_left] at h
  exact h

/-- The sum of two nonpositive reals is nonpositive. -/
theorem rAdd_nonpos
    {x y : RBOMA}
    (hx0 : rLE x rZero)
    (hy0 : rLE y rZero) :
    rLE (rAdd x y) rZero := by
  have h := rAdd_mono hx0 hy0
  rw [rAdd_zero_left] at h
  exact h

end BOMA.R.DedekindOrderAdditive001

/- Negation candidate on selected Dedekind lower cuts, before additive-inverse certification. -/
namespace BOMA.R.DedekindNegationCandidate001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001

/-- Rational negation is involutive on the accepted quotient carrier. -/
theorem qNeg_involutive (x : QBOMA) : qNeg (qNeg x) = x := by
  symm
  exact qAdd_inverse_unique
    (x := qNeg x)
    (y := x)
    (qAdd_neg_left x)

/-- Rational negation is injective. -/
theorem qNeg_injective {x y : QBOMA} (h : qNeg x = qNeg y) : x = y := by
  calc
    x = qNeg (qNeg x) := (qNeg_involutive x).symm
    _ = qNeg (qNeg y) := congrArg qNeg h
    _ = y := qNeg_involutive y

/-- Strict rational order reverses under negation. -/
theorem qneg_strict_reverses {x y : QBOMA} (h : qLT x y) :
    qLT (qNeg y) (qNeg x) := by
  refine ⟨qneg_reverses h.1, ?_⟩
  intro hneg
  have hyx : y = x := qNeg_injective hneg
  exact h.2 hyx.symm

/-- Dedekind negation candidate.
A rational q lies in -A when it lies strictly below -r for some rational r
outside A. This formulation does not require selecting a boundary point. -/
def cutNeg (A : LowerCut) : LowerCut where
  lower := fun q =>
    ∃ r : QBOMA, ¬ A.lower r ∧ qLT q (qNeg r)
  nonempty := by
    rcases A.proper with ⟨r, hr⟩
    let q := qAdd (qNeg r) (qNeg qOne)
    refine ⟨q, r, hr, ?_⟩
    change qLT (qAdd (qNeg r) (qNeg qOne)) (qNeg r)
    exact BOMA.R.DedekindProbe001.q_minus_one_lt (qNeg r)
  proper := by
    rcases A.nonempty with ⟨a, ha⟩
    refine ⟨qNeg a, ?_⟩
    rintro ⟨r, hrOut, hlt⟩
    have hraNeg : qLT (qNeg (qNeg r)) (qNeg (qNeg a)) :=
      qneg_strict_reverses hlt
    have hra : qLT r a := by
      rw [qNeg_involutive r, qNeg_involutive a] at hraNeg
      exact hraNeg
    exact hrOut (A.downward ha hra.1)
  downward := by
    intro p q hq hpq
    rcases hq with ⟨r, hrOut, hqr⟩
    exact ⟨r, hrOut, qle_lt_trans hpq hqr⟩
  rounded := by
    intro q hq
    rcases hq with ⟨r, hrOut, hqr⟩
    rcases rational_order_dense hqr with ⟨m, hqm, hmr⟩
    exact ⟨m, ⟨r, hrOut, hmr⟩, hqm⟩

/-- The negation candidate respects extensional cut identity. -/
theorem cutNeg_respects {A B : LowerCut} (hAB : CutEquiv A B) :
    CutEquiv (cutNeg A) (cutNeg B) := by
  intro q
  constructor
  · rintro ⟨r, hrA, hqr⟩
    have hrB : ¬ B.lower r := by
      intro hBr
      exact hrA ((hAB r).mpr hBr)
    exact ⟨r, hrB, hqr⟩
  · rintro ⟨r, hrB, hqr⟩
    have hrA : ¬ A.lower r := by
      intro hAr
      exact hrB ((hAB r).mp hAr)
    exact ⟨r, hrA, hqr⟩

/-- Formal negation candidate lifted to RBOMA after the respect theorem. -/
def rNeg : RBOMA → RBOMA :=
  Quotient.lift
    (fun A => rmk (cutNeg A))
    (fun _ _ h => rmk_sound (cutNeg_respects h))

@[simp] theorem rNeg_mk (A : LowerCut) :
    rNeg (rmk A) = rmk (cutNeg A) := rfl

/-- The negation of a principal rational cut is the principal cut of the
accepted rational negation. The order comparison is routed through the shared
trichotomy theorem, avoiding a second implicit `by_cases`/propDecidable site. -/
theorem cutNeg_principal (q : QBOMA) :
    CutEquiv (cutNeg (principalCut q)) (principalCut (qNeg q)) := by
  intro x
  constructor
  · rintro ⟨r, hrNot, hxr⟩
    have hqr : qLE q r := by
      rcases qlt_trichotomy q r with hlt | heq | hgt
      · exact hlt.1
      · rw [heq]
        exact qle_refl r
      · exact False.elim (hrNot hgt)
    have hneg : qLE (qNeg r) (qNeg q) := qneg_reverses hqr
    exact qlt_le_trans hxr hneg
  · intro hx
    exact ⟨q, qlt_irrefl q, hx⟩

/-- The accepted rational embedding preserves the negation candidate. -/
theorem rOfQ_neg (q : QBOMA) :
    rNeg (rOfQ q) = rOfQ (qNeg q) := by
  change rmk (cutNeg (principalCut q)) = rmk (principalCut (qNeg q))
  exact rmk_sound (cutNeg_principal q)

end BOMA.R.DedekindNegationCandidate001

/- First reusable Archimedean probe for accepted QBOMA: every rational has a natural upper bound. -/
namespace BOMA.R.QArchimedeanUpperBound001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001

/-- Every structurally positive rational denominator is at least integer one. -/
theorem denZ_ge_one (d : PosDen) : zLE zone (denZ d) := by
  unfold denZ denNat
  change zLE (embedN (s z)) (embedN (s d.pred))
  exact (embedN_order (s z) (s d.pred)).2
    ((le_s_iff).2 (z_le d.pred))

/-- Every raw fraction lies below a canonically embedded natural.
For a positive numerator, the numerator magnitude itself is enough because
the denominator is at least one. Zero and negative numerators are bounded by 0. -/
theorem rawFrac_le_natural (x : RawFrac) :
    ∃ n : BOMANat, RawLE x (fracOfZ (embedN n)) := by
  cases x with
  | mk num den =>
      cases num with
      | zero =>
          refine ⟨z, ?_⟩
          change zLE (zmul zzero zone) (zmul (embedN z) (denZ den))
          rw [zmul_zero_left, embedN_zero, zmul_zero_left]
          exact zle_refl zzero
      | neg p =>
          refine ⟨z, ?_⟩
          change zLE (zmul (neg p) zone) (zmul (embedN z) (denZ den))
          rw [zmul_one_right, embedN_zero, zmul_zero_left]
          change True
          exact True.intro
      | pos p =>
          refine ⟨s p, ?_⟩
          change zLE (zmul (pos p) zone)
            (zmul (embedN (s p)) (denZ den))
          rw [zmul_one_right]
          have hnum : NonNeg (embedN (s p)) := by
            unfold NonNeg
            exact (embedN_order z (s p)).2 (z_le (s p))
          have hm := zmul_mono_left_nonneg (denZ_ge_one den) hnum
          rw [zmul_one_right] at hm
          exact hm

/-- Reusable Archimedean upper-bound interface on the accepted quotient rational carrier. -/
theorem q_le_natural_upper (q : QBOMA) :
    ∃ n : BOMANat, qLE q (qOfN n) := by
  refine Quotient.inductionOn q ?_
  intro x
  rcases rawFrac_le_natural x with ⟨n, hn⟩
  refine ⟨n, ?_⟩
  change qLE (qmk x) (qmk (fracOfZ (embedN n)))
  exact (qLE_mk_iff x (fracOfZ (embedN n))).2 hn

end BOMA.R.QArchimedeanUpperBound001

/- Reusable Archimedean scaling consequence on accepted QBOMA. -/
namespace BOMA.R.QArchimedeanScaling001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.Q.Inverse001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QArchimedeanUpperBound001

/-- Every rational gap is bounded above by a natural multiple of any positive
rational step. The inverse is consumed as an existential witness; no global
inverse selector or Choice principle is introduced. -/
theorem q_archimedean_scale (gap delta : QBOMA) (hdelta : qLT qZero delta) :
    ∃ n : BOMANat, qLE gap (qMul (qOfN n) delta) := by
  have hdeltaNZ : delta ≠ qZero := hdelta.2.symm
  rcases q_inverse_exists delta hdeltaNZ with ⟨rinv, hrinv⟩
  have hdeltaPos : QPositive delta := ⟨hdelta.1, hdeltaNZ⟩
  have hrinvPos : QPositive rinv :=
    inverse_of_positive_is_positive hdeltaPos hrinv
  rcases q_le_natural_upper (qMul gap rinv) with ⟨n, hn⟩
  have hm := qmul_mono_left_nonneg hn hdelta.1
  have hleft : qMul delta (qMul gap rinv) = gap := by
    calc
      qMul delta (qMul gap rinv) = qMul (qMul delta gap) rinv :=
        (qMul_assoc delta gap rinv).symm
      _ = qMul (qMul gap delta) rinv :=
        congrArg (fun t => qMul t rinv) (qMul_comm delta gap)
      _ = qMul gap (qMul delta rinv) := qMul_assoc gap delta rinv
      _ = qMul gap qOne := congrArg (fun t => qMul gap t) hrinv
      _ = gap := qMul_one_right gap
  have hright : qMul delta (qOfN n) = qMul (qOfN n) delta :=
    qMul_comm delta (qOfN n)
  rw [hleft, hright] at hm
  exact ⟨n, hm⟩

end BOMA.R.QArchimedeanScaling001

/- Constructive rational grid consequences of the accepted Archimedean scaling theorem. -/
namespace BOMA.R.QArchimedeanGrid001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.QArchimedeanScaling001

/-- Successor compatibility of the accepted N -> Q embedding. -/
theorem qOfN_succ (n : BOMANat) :
    qOfN (s n) = qAdd (qOfN n) qOne := by
  have h := qOfN_add n (s z)
  simpa using h

/-- Rational grid based at a with positive step delta. -/
def qGrid (a delta : QBOMA) (n : BOMANat) : QBOMA :=
  qAdd a (qMul (qOfN n) delta)

@[simp] theorem qGrid_zero (a delta : QBOMA) : qGrid a delta z = a := by
  unfold qGrid
  rw [qOfN_zero, qMul_zero_left, qAdd_zero_right]

/-- Advancing the natural index advances the grid by exactly one delta. -/
theorem qGrid_succ (a delta : QBOMA) (n : BOMANat) :
    qGrid a delta (s n) = qAdd (qGrid a delta n) delta := by
  unfold qGrid
  rw [qOfN_succ, qMul_add_left, qMul_one_left]
  exact (qAdd_assoc a (qMul (qOfN n) delta) delta).symm

/-- A bound on the translated gap u-a gives a bound of u by the corresponding grid point. -/
theorem qle_grid_of_gap_bound {a u delta : QBOMA} {n : BOMANat}
    (h : qLE (qAdd u (qNeg a)) (qMul (qOfN n) delta)) :
    qLE u (qGrid a delta n) := by
  have ht := qadd_mono_right h a
  have hleft : qAdd (qAdd u (qNeg a)) a = u := by
    calc
      qAdd (qAdd u (qNeg a)) a = qAdd u (qAdd (qNeg a) a) :=
        qAdd_assoc u (qNeg a) a
      _ = qAdd u qZero := by rw [qAdd_neg_left]
      _ = u := qAdd_zero_right u
  have hright : qAdd (qMul (qOfN n) delta) a = qGrid a delta n := by
    unfold qGrid
    exact qAdd_comm (qMul (qOfN n) delta) a
  rw [hleft, hright] at ht
  exact ht

/-- From any base point a and any known outside point u of a proper lower cut,
a positive rational step eventually reaches a grid point outside the cut.
The base point need not itself be known inside for this purely crossing/bounding statement.
No membership decision or Classical.em is used here. -/
theorem qGrid_eventually_outside
    (A : LowerCut) (a u delta : QBOMA)
    (hu : ¬ A.lower u)
    (hdelta : qLT qZero delta) :
    ∃ n : BOMANat, ¬ A.lower (qGrid a delta n) := by
  rcases q_archimedean_scale (qAdd u (qNeg a)) delta hdelta with ⟨n, hn⟩
  refine ⟨n, ?_⟩
  intro hgrid
  apply hu
  exact A.downward hgrid (qle_grid_of_gap_bound hn)

end BOMA.R.QArchimedeanGrid001

/- Isolated logical search over a finite rational grid.
The arithmetic grid and eventual crossing are proved constructively elsewhere. -/
namespace BOMA.R.DedekindFiniteExit001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Q.Quotient001
open BOMA.R.DedekindProbe001
open BOMA.R.QArchimedeanGrid001

/-- Given an inside base point and a finite grid endpoint known outside,
there is an adjacent inside/outside pair along the grid.

The only nonconstructive ingredient is the explicit proposition-level
`Classical.em` used to decide membership of the predecessor grid point. -/
theorem qGrid_first_exit
    (A : LowerCut) (a delta : QBOMA)
    (ha : A.lower a) :
    ∀ n : BOMANat,
      ¬ A.lower (qGrid a delta n) →
      ∃ b r : QBOMA,
        A.lower b ∧
        ¬ A.lower r ∧
        r = qAdd b delta := by
  intro n
  induction n with
  | z =>
      intro hout
      have hbase : A.lower (qGrid a delta z) := by
        simpa using ha
      exact False.elim (hout hbase)
  | s n ih =>
      intro hout
      rcases Classical.em (A.lower (qGrid a delta n)) with hprev | hprev
      · refine ⟨qGrid a delta n, qGrid a delta (s n), hprev, hout, ?_⟩
        exact qGrid_succ a delta n
      · exact ih hprev

end BOMA.R.DedekindFiniteExit001

/- Arbitrarily fine inside/outside rational bracketing for selected Dedekind cuts.
Arithmetic Archimedean scaling and finite predicate search remain separate dependencies. -/
namespace BOMA.R.DedekindCutBracket001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.QArchimedeanGrid001
open BOMA.R.DedekindFiniteExit001

/-- Every positive rational epsilon admits an inside/outside bracket around an
arbitrary Dedekind lower cut whose rational width is positive and strictly
smaller than epsilon.

The arithmetic growth is inherited from the constructive Q Archimedean route.
The only predicate-membership search is inherited from the isolated finite-exit theorem. -/
theorem cut_bracket_approx
    (A : LowerCut) (eps : QBOMA)
    (heps : qLT qZero eps) :
    ∃ b r : QBOMA,
      A.lower b ∧
      ¬ A.lower r ∧
      qLT qZero (qAdd r (qNeg b)) ∧
      qLT (qAdd r (qNeg b)) eps := by
  rcases rational_order_dense heps with ⟨delta, h0delta, hdeltaeps⟩
  rcases A.nonempty with ⟨a, ha⟩
  rcases A.proper with ⟨u, hu⟩
  rcases qGrid_eventually_outside A a u delta hu h0delta with ⟨n, hout⟩
  rcases qGrid_first_exit A a delta ha n hout with ⟨b, r, hb, hr, hstep⟩
  have hwidth : qAdd r (qNeg b) = delta := by
    calc
      qAdd r (qNeg b) = qAdd (qAdd b delta) (qNeg b) :=
        congrArg (fun t => qAdd t (qNeg b)) hstep
      _ = qAdd b (qAdd delta (qNeg b)) :=
        qAdd_assoc b delta (qNeg b)
      _ = qAdd b (qAdd (qNeg b) delta) :=
        congrArg (fun t => qAdd b t) (qAdd_comm delta (qNeg b))
      _ = qAdd (qAdd b (qNeg b)) delta :=
        (qAdd_assoc b (qNeg b) delta).symm
      _ = qAdd qZero delta := by rw [qAdd_neg_right]
      _ = delta := qAdd_zero_left delta
  refine ⟨b, r, hb, hr, ?_, ?_⟩
  · rw [hwidth]
    exact h0delta
  · rw [hwidth]
    exact hdeltaeps

end BOMA.R.DedekindCutBracket001

/- Additive-inverse certification for the verified Dedekind negation candidate. -/
namespace BOMA.R.DedekindAdditiveInverse001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionEmbedding001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindCutBracket001

/-- Rational negation fixes zero. -/
theorem qNeg_zero : qNeg qZero = qZero := by
  have h : qZero = qNeg qZero :=
    qAdd_inverse_unique (x := qZero) (y := qZero) (qAdd_zero_left qZero)
  exact h.symm

/-- Any member of A + (-A) is strictly below rational zero. This direction
uses no Archimedean bracketing theorem. -/
theorem cutAdd_neg_to_zero (A : LowerCut) {x : QBOMA}
    (hx : (cutAdd A (cutNeg A)).lower x) :
    (principalCut qZero).lower x := by
  rcases hx with ⟨a, b, ha, hbNeg, hxab⟩
  rcases hbNeg with ⟨r, hrOut, hbr⟩
  have har : qLE a r := by
    rcases qle_total a r with har | hra
    · exact har
    · exact False.elim (hrOut (A.downward ha hra))
  have habar : qLT (qAdd a b) (qAdd a (qNeg r)) := by
    have ht := qlt_add_right hbr a
    rw [qAdd_comm b a, qAdd_comm (qNeg r) a] at ht
    exact ht
  have har0 : qLE (qAdd a (qNeg r)) qZero := by
    have ht := qadd_mono_right har (qNeg r)
    rw [qAdd_neg_right] at ht
    exact ht
  exact qlt_le_trans (qlt_trans hxab habar) har0

/-- If x is strictly below zero, the fine cut-bracketing theorem supplies
witnesses showing x belongs to A + (-A). This is the direction that consumes
R-QARCH-BLOCK-001 through cut_bracket_approx. -/
theorem zero_to_cutAdd_neg (A : LowerCut) {x : QBOMA}
    (hx : (principalCut qZero).lower x) :
    (cutAdd A (cutNeg A)).lower x := by
  have hposNegX : qLT qZero (qNeg x) := by
    have ht := qneg_strict_reverses hx
    rw [qNeg_zero] at ht
    exact ht
  rcases cut_bracket_approx A (qNeg x) hposNegX with
    ⟨b, r, hb, hrOut, _hwidthPos, hwidthLt⟩
  have hx_bminusr : qLT x (qAdd b (qNeg r)) := by
    have ht := qneg_strict_reverses hwidthLt
    have hleft : qNeg (qNeg x) = x := qNeg_involutive x
    have hright : qNeg (qAdd r (qNeg b)) = qAdd b (qNeg r) := by
      rw [qNeg_add, qNeg_involutive]
      exact qAdd_comm (qNeg r) b
    rw [hleft, hright] at ht
    exact ht
  have hxb_negr : qLT (qAdd x (qNeg b)) (qNeg r) := by
    have ht := qlt_add_right hx_bminusr (qNeg b)
    have hright : qAdd (qAdd b (qNeg r)) (qNeg b) = qNeg r := by
      calc
        qAdd (qAdd b (qNeg r)) (qNeg b) =
            qAdd b (qAdd (qNeg r) (qNeg b)) :=
          qAdd_assoc b (qNeg r) (qNeg b)
        _ = qAdd b (qAdd (qNeg b) (qNeg r)) :=
          congrArg (fun t => qAdd b t) (qAdd_comm (qNeg r) (qNeg b))
        _ = qAdd (qAdd b (qNeg b)) (qNeg r) :=
          (qAdd_assoc b (qNeg b) (qNeg r)).symm
        _ = qAdd qZero (qNeg r) := by rw [qAdd_neg_right]
        _ = qNeg r := qAdd_zero_left _
    rw [hright] at ht
    exact ht
  rcases rational_order_dense hxb_negr with ⟨c, hxc, hcr⟩
  have hcNeg : (cutNeg A).lower c := ⟨r, hrOut, hcr⟩
  have hxsum : qLT x (qAdd b c) := qlt_add_back_left hxc
  exact ⟨b, c, hb, hcNeg, hxsum⟩

/-- Raw Dedekind addition with the verified negation candidate is extensionally
exactly the principal zero cut. -/
theorem cutAdd_neg_equiv_zero (A : LowerCut) :
    CutEquiv (cutAdd A (cutNeg A)) (principalCut qZero) := by
  intro x
  constructor
  · exact cutAdd_neg_to_zero A
  · exact zero_to_cutAdd_neg A

/-- The verified negation candidate is a right additive inverse on formal RBOMA. -/
theorem rAdd_neg_right (x : RBOMA) :
    rAdd x (rNeg x) = rZero := by
  refine Quotient.inductionOn x ?_
  intro A
  change rmk (cutAdd A (cutNeg A)) = rmk (principalCut qZero)
  exact rmk_sound (cutAdd_neg_equiv_zero A)

/-- By commutativity, it is also a left additive inverse. -/
theorem rAdd_neg_left (x : RBOMA) :
    rAdd (rNeg x) x = rZero := by
  calc
    rAdd (rNeg x) x = rAdd x (rNeg x) := rAdd_comm (rNeg x) x
    _ = rZero := rAdd_neg_right x

/-- Additive cancellation is now available on RBOMA. -/
theorem rAdd_left_cancel {a b c : RBOMA}
    (h : rAdd a b = rAdd a c) : b = c := by
  have h' := congrArg (fun t => rAdd (rNeg a) t) h
  calc
    b = rAdd rZero b := (rAdd_zero_left b).symm
    _ = rAdd (rAdd (rNeg a) a) b := by rw [rAdd_neg_left]
    _ = rAdd (rNeg a) (rAdd a b) := rAdd_assoc (rNeg a) a b
    _ = rAdd (rNeg a) (rAdd a c) := h'
    _ = rAdd (rAdd (rNeg a) a) c := (rAdd_assoc (rNeg a) a c).symm
    _ = rAdd rZero c := by rw [rAdd_neg_left]
    _ = c := rAdd_zero_left c

/-- Additive inverses are unique on the accepted real additive group. -/
theorem rAdd_inverse_unique {x y : RBOMA}
    (h : rAdd x y = rZero) : y = rNeg x := by
  apply rAdd_left_cancel (a := x)
  calc
    rAdd x y = rZero := h
    _ = rAdd x (rNeg x) := (rAdd_neg_right x).symm

/-- Real negation is involutive after inverse certification. -/
theorem rNeg_involutive (x : RBOMA) : rNeg (rNeg x) = x := by
  symm
  exact rAdd_inverse_unique
    (x := rNeg x)
    (y := x)
    (rAdd_neg_left x)

end BOMA.R.DedekindAdditiveInverse001

/- Reusable identities derived from the certified additive group on RBOMA. -/
namespace BOMA.R.DedekindAdditiveDerived001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001

/-- Exchange the middle two terms in a four-term additive expression. -/
theorem rAdd_exchange (a b c d : RBOMA) :
    rAdd a (rAdd b (rAdd c d)) =
    rAdd a (rAdd c (rAdd b d)) := by
  apply congrArg (fun t => rAdd a t)
  calc
    rAdd b (rAdd c d) = rAdd (rAdd b c) d := (rAdd_assoc b c d).symm
    _ = rAdd (rAdd c b) d :=
      congrArg (fun t => rAdd t d) (rAdd_comm b c)
    _ = rAdd c (rAdd b d) := rAdd_assoc c b d

/-- Negation distributes over formal real addition. -/
theorem rNeg_add (x y : RBOMA) :
    rNeg (rAdd x y) = rAdd (rNeg x) (rNeg y) := by
  symm
  apply rAdd_inverse_unique (x := rAdd x y)
  calc
    rAdd (rAdd x y) (rAdd (rNeg x) (rNeg y)) =
        rAdd x (rAdd y (rAdd (rNeg x) (rNeg y))) :=
      rAdd_assoc x y (rAdd (rNeg x) (rNeg y))
    _ = rAdd x (rAdd (rNeg x) (rAdd y (rNeg y))) :=
      rAdd_exchange x y (rNeg x) (rNeg y)
    _ = rAdd x (rAdd (rNeg x) rZero) := by rw [rAdd_neg_right]
    _ = rAdd x (rNeg x) := by rw [rAdd_zero_right]
    _ = rZero := rAdd_neg_right x

/-- Cancel a right summand by adding its inverse. -/
theorem rAdd_sub_right (x y : RBOMA) :
    rAdd (rAdd x y) (rNeg y) = x := by
  calc
    rAdd (rAdd x y) (rNeg y) = rAdd x (rAdd y (rNeg y)) :=
      rAdd_assoc x y (rNeg y)
    _ = rAdd x rZero := by rw [rAdd_neg_right]
    _ = x := rAdd_zero_right x

/-- Cancel a left negative translation. -/
theorem rAdd_sub_left (x y : RBOMA) :
    rAdd (rAdd x (rNeg y)) y = x := by
  calc
    rAdd (rAdd x (rNeg y)) y = rAdd x (rAdd (rNeg y) y) :=
      rAdd_assoc x (rNeg y) y
    _ = rAdd x rZero := by rw [rAdd_neg_left]
    _ = x := rAdd_zero_right x

/-- Subtracting a sum from its first summand gives the inverse of the second. -/
theorem rAdd_neg_sum_cancel_left (x y : RBOMA) :
    rAdd x (rNeg (rAdd x y)) = rNeg y := by
  rw [rNeg_add]
  calc
    rAdd x (rAdd (rNeg x) (rNeg y)) =
        rAdd (rAdd x (rNeg x)) (rNeg y) :=
      (rAdd_assoc x (rNeg x) (rNeg y)).symm
    _ = rAdd rZero (rNeg y) := by rw [rAdd_neg_right]
    _ = rNeg y := rAdd_zero_left _

/-- Subtracting a sum from its second summand gives the inverse of the first. -/
theorem rAdd_neg_sum_cancel_right (x y : RBOMA) :
    rAdd y (rNeg (rAdd x y)) = rNeg x := by
  rw [rAdd_comm x y]
  exact rAdd_neg_sum_cancel_left y x

end BOMA.R.DedekindAdditiveDerived001

/- Nonnegative envelope for Dedekind reals, built without sign case-splitting. -/
namespace BOMA.R.DedekindPositivePart001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001

/-- Positive/nonnegative envelope of a cut: union with the principal zero cut.
This is the cut-level max(A,0), defined without deciding the sign of A. -/
def cutPosPart (A : LowerCut) : LowerCut where
  lower := fun q => A.lower q ∨ qLT q qZero
  nonempty := by
    rcases A.nonempty with ⟨a, ha⟩
    exact ⟨a, Or.inl ha⟩
  proper := by
    rcases A.proper with ⟨u, hu⟩
    rcases qle_total qZero u with h0u | hu0
    · refine ⟨u, ?_⟩
      intro h
      rcases h with huA | huNeg
      · exact hu huA
      · have heq : qZero = u := qle_antisymm h0u huNeg.1
        exact huNeg.2 heq.symm
    · refine ⟨qZero, ?_⟩
      intro h
      rcases h with h0A | h00
      · exact hu (A.downward h0A hu0)
      · exact qlt_irrefl qZero h00
  downward := by
    intro p q hq hpq
    rcases hq with hqA | hq0
    · exact Or.inl (A.downward hqA hpq)
    · exact Or.inr (BOMA.R.DedekindAddition001.qle_lt_trans hpq hq0)
  rounded := by
    intro q hq
    rcases hq with hqA | hq0
    · rcases A.rounded hqA with ⟨r, hrA, hqr⟩
      exact ⟨r, Or.inl hrA, hqr⟩
    · rcases rational_order_dense hq0 with ⟨r, hqr, hr0⟩
      exact ⟨r, Or.inr hr0, hqr⟩

/-- The positive-part construction respects extensional cut identity. -/
theorem cutPosPart_respects {A B : LowerCut} (hAB : CutEquiv A B) :
    CutEquiv (cutPosPart A) (cutPosPart B) := by
  intro q
  constructor
  · intro h
    rcases h with hA | h0
    · exact Or.inl ((hAB q).mp hA)
    · exact Or.inr h0
  · intro h
    rcases h with hB | h0
    · exact Or.inl ((hAB q).mpr hB)
    · exact Or.inr h0

/-- Formal nonnegative envelope lifted to RBOMA. -/
def rPosPart : RBOMA → RBOMA :=
  Quotient.lift
    (fun A => rmk (cutPosPart A))
    (fun _ _ h => rmk_sound (cutPosPart_respects h))

@[simp] theorem rPosPart_mk (A : LowerCut) :
    rPosPart (rmk A) = rmk (cutPosPart A) := rfl

/-- The zero cut is included in every positive-part envelope. -/
theorem cutZero_le_posPart (A : LowerCut) :
    CutLE (principalCut qZero) (cutPosPart A) := by
  intro q hq
  exact Or.inr hq

/-- Every cut is included in its positive-part envelope. -/
theorem cut_le_posPart (A : LowerCut) : CutLE A (cutPosPart A) := by
  intro q hq
  exact Or.inl hq

/-- If a cut is already nonnegative, taking the positive part changes nothing
up to extensional identity. -/
theorem cutPosPart_of_nonneg {A : LowerCut}
    (h0A : CutLE (principalCut qZero) A) :
    CutEquiv (cutPosPart A) A := by
  intro q
  constructor
  · intro h
    rcases h with hA | h0
    · exact hA
    · exact h0A q h0
  · intro hA
    exact Or.inl hA

/-- Formal positive part lies above zero. -/
theorem rZero_le_rPosPart (x : RBOMA) : rLE rZero (rPosPart x) := by
  refine Quotient.inductionOn x ?_
  intro A
  change rLE (rmk (principalCut qZero)) (rmk (cutPosPart A))
  exact (rLE_mk_iff (principalCut qZero) (cutPosPart A)).2
    (cutZero_le_posPart A)

/-- Formal positive part lies above the original real. -/
theorem rLE_rPosPart (x : RBOMA) : rLE x (rPosPart x) := by
  refine Quotient.inductionOn x ?_
  intro A
  change rLE (rmk A) (rmk (cutPosPart A))
  exact (rLE_mk_iff A (cutPosPart A)).2 (cut_le_posPart A)

/-- Negative magnitude candidate, still defined without a sign case split. -/
def rNegPart (x : RBOMA) : RBOMA := rPosPart (rNeg x)

end BOMA.R.DedekindPositivePart001

/- Positive/negative-envelope decomposition on selected Dedekind reals.
The envelope definitions are sign-case-free; the final decomposition theorem
uses the already-isolated classical total-comparability witness explicitly. -/
namespace BOMA.R.DedekindPositiveDecomposition001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositivePart001

/-- If A is below zero, its positive envelope is exactly zero. -/
theorem cutPosPart_of_nonpos {A : LowerCut}
    (hA0 : CutLE A (principalCut qZero)) :
    CutEquiv (cutPosPart A) (principalCut qZero) := by
  intro q
  constructor
  · intro hq
    rcases hq with hA | h0
    · exact hA0 q hA
    · exact h0
  · intro h0
    exact Or.inr h0

/-- Any rational outside a cut known to contain the zero cut is nonnegative. -/
theorem outside_of_nonnegative_cut_is_nonneg
    {A : LowerCut} {r : QBOMA}
    (h0A : CutLE (principalCut qZero) A)
    (hrOut : ¬ A.lower r) :
    qLE qZero r := by
  rcases qlt_trichotomy r qZero with hr0 | heq | h0r
  · exact False.elim (hrOut (h0A r hr0))
  · rw [heq]
    exact qle_refl qZero
  · exact h0r.1

/-- Negation of a nonnegative cut is below zero. -/
theorem cutNeg_le_zero_of_zero_le
    {A : LowerCut}
    (h0A : CutLE (principalCut qZero) A) :
    CutLE (cutNeg A) (principalCut qZero) := by
  intro q hq
  rcases hq with ⟨r, hrOut, hqnegr⟩
  have h0r : qLE qZero r :=
    outside_of_nonnegative_cut_is_nonneg h0A hrOut
  have hneg : qLE (qNeg r) (qNeg qZero) := qneg_reverses h0r
  rw [qNeg_zero] at hneg
  exact qlt_le_trans hqnegr hneg

/-- Negation of a nonpositive cut contains the zero cut. -/
theorem cutZero_le_neg_of_le_zero
    {A : LowerCut}
    (hA0 : CutLE A (principalCut qZero)) :
    CutLE (principalCut qZero) (cutNeg A) := by
  intro q hq0
  have h0negq : qLT qZero (qNeg q) := by
    have ht := qneg_strict_reverses hq0
    rw [qNeg_zero] at ht
    exact ht
  rcases rational_order_dense h0negq with ⟨r, h0r, hrnegq⟩
  have hrOut : ¬ A.lower r := by
    intro hrA
    have hr0 : qLT r qZero := hA0 r hrA
    exact (qlt_asymm h0r) hr0
  have hqnegr : qLT q (qNeg r) := by
    have ht := qneg_strict_reverses hrnegq
    rw [qNeg_involutive q] at ht
    exact ht
  exact ⟨r, hrOut, hqnegr⟩

/-- Formal positive part is fixed on nonnegative reals. -/
theorem rPosPart_of_nonneg {x : RBOMA}
    (h0x : rLE rZero x) :
    rPosPart x = x := by
  refine Quotient.inductionOn x ?_ h0x
  intro A h0A
  change rmk (cutPosPart A) = rmk A
  apply rmk_sound
  apply cutPosPart_of_nonneg
  change rLE (rmk (principalCut qZero)) (rmk A) at h0A
  exact (rLE_mk_iff (principalCut qZero) A).1 h0A

/-- Formal positive part collapses to zero on nonpositive reals. -/
theorem rPosPart_of_nonpos {x : RBOMA}
    (hx0 : rLE x rZero) :
    rPosPart x = rZero := by
  refine Quotient.inductionOn x ?_ hx0
  intro A hA0
  change rmk (cutPosPart A) = rmk (principalCut qZero)
  apply rmk_sound
  apply cutPosPart_of_nonpos
  change rLE (rmk A) (rmk (principalCut qZero)) at hA0
  exact (rLE_mk_iff A (principalCut qZero)).1 hA0

/-- Real negation sends a nonnegative real to a nonpositive real. -/
theorem rNeg_nonpos_of_nonneg {x : RBOMA}
    (h0x : rLE rZero x) :
    rLE (rNeg x) rZero := by
  refine Quotient.inductionOn x ?_ h0x
  intro A h0A
  change rLE (rmk (cutNeg A)) (rmk (principalCut qZero))
  apply (rLE_mk_iff (cutNeg A) (principalCut qZero)).2
  apply cutNeg_le_zero_of_zero_le
  change rLE (rmk (principalCut qZero)) (rmk A) at h0A
  exact (rLE_mk_iff (principalCut qZero) A).1 h0A

/-- Real negation sends a nonpositive real to a nonnegative real. -/
theorem rNeg_nonneg_of_nonpos {x : RBOMA}
    (hx0 : rLE x rZero) :
    rLE rZero (rNeg x) := by
  refine Quotient.inductionOn x ?_ hx0
  intro A hA0
  change rLE (rmk (principalCut qZero)) (rmk (cutNeg A))
  apply (rLE_mk_iff (principalCut qZero) (cutNeg A)).2
  apply cutZero_le_neg_of_le_zero
  change rLE (rmk A) (rmk (principalCut qZero)) at hA0
  exact (rLE_mk_iff A (principalCut qZero)).1 hA0

/-- Formal real negation fixes zero. -/
@[simp] theorem rNeg_zero : rNeg rZero = rZero := by
  symm
  exact rAdd_inverse_unique
    (x := rZero)
    (y := rZero)
    (rAdd_zero_left rZero)

/-- For a nonnegative real, the negative envelope is zero. -/
theorem rNegPart_of_nonneg {x : RBOMA}
    (h0x : rLE rZero x) :
    rNegPart x = rZero := by
  unfold rNegPart
  exact rPosPart_of_nonpos (rNeg_nonpos_of_nonneg h0x)

/-- For a nonpositive real, the negative envelope is exactly -x. -/
theorem rNegPart_of_nonpos {x : RBOMA}
    (hx0 : rLE x rZero) :
    rNegPart x = rNeg x := by
  unfold rNegPart
  exact rPosPart_of_nonneg (rNeg_nonneg_of_nonpos hx0)

/-- Signed decomposition of every selected Dedekind real.
The only sign split occurs here through the isolated classical total-order witness. -/
theorem rPosNeg_decomposition (x : RBOMA) :
    rAdd (rPosPart x) (rNeg (rNegPart x)) = x := by
  rcases rLE_total_classical rZero x with h0x | hx0
  · rw [rPosPart_of_nonneg h0x, rNegPart_of_nonneg h0x,
      rNeg_zero, rAdd_zero_right]
  · rw [rPosPart_of_nonpos hx0, rNegPart_of_nonpos hx0,
      rNeg_involutive, rAdd_zero_left]

end BOMA.R.DedekindPositiveDecomposition001

/- Multiplication kernel for nonnegative Dedekind envelopes.
This is not yet the final signed real multiplication. -/
namespace BOMA.R.DedekindNonnegativeMul001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositivePart001

/-- Any point outside max(A,0) is rationally nonnegative. -/
theorem outside_posPart_nonneg (A : LowerCut) {u : QBOMA}
    (hu : ¬ (cutPosPart A).lower u) : qLE qZero u := by
  rcases qlt_trichotomy u qZero with hneg | heq | hpos
  · exact False.elim (hu (Or.inr hneg))
  · rw [heq]
    exact qle_refl qZero
  · exact hpos.1

/-- Every member of a lower cut lies below every point known outside it. -/
theorem member_le_outside {P : LowerCut} {a u : QBOMA}
    (ha : P.lower a) (hu : ¬ P.lower u) : qLE a u := by
  rcases qle_total a u with hau | hua
  · exact hau
  · exact False.elim (hu (P.downward ha hua))

/-- Positive-envelope product.
Negative rationals are included automatically; nonnegative content is generated
strictly below products of positive witnesses from the two positive envelopes. -/
def cutMulNonnegEnvelope (A B : LowerCut) : LowerCut where
  lower := fun q =>
    qLT q qZero ∨
    ∃ a b : QBOMA,
      (cutPosPart A).lower a ∧
      (cutPosPart B).lower b ∧
      qLT qZero a ∧
      qLT qZero b ∧
      qLT q (qMul a b)
  nonempty := by
    let m := qAdd qZero (qNeg qOne)
    refine ⟨m, Or.inl ?_⟩
    exact BOMA.R.DedekindProbe001.q_minus_one_lt qZero
  proper := by
    rcases (cutPosPart A).proper with ⟨uA, huA⟩
    rcases (cutPosPart B).proper with ⟨uB, huB⟩
    let U := qAdd uA qOne
    let V := qAdd uB qOne
    let M := qAdd (qMul U V) qOne
    have h0uA : qLE qZero uA := outside_posPart_nonneg A huA
    have h0uB : qLE qZero uB := outside_posPart_nonneg B huB
    have huA_U : qLE uA U := by
      have h := qadd_mono_right qzero_le_one uA
      change qLE (qAdd qZero uA) (qAdd qOne uA) at h
      rw [qAdd_zero_left, qAdd_comm qOne uA] at h
      exact h
    have huB_V : qLE uB V := by
      have h := qadd_mono_right qzero_le_one uB
      change qLE (qAdd qZero uB) (qAdd qOne uB) at h
      rw [qAdd_zero_left, qAdd_comm qOne uB] at h
      exact h
    have h0U : qLE qZero U := qle_trans h0uA huA_U
    have h0V : qLE qZero V := qle_trans h0uB huB_V
    have h0UV : qLE qZero (qMul U V) := qmul_nonneg h0U h0V
    have hUV_M : qLT (qMul U V) M := by
      have h := qlt_add_right qzero_lt_one (qMul U V)
      change qLT (qAdd qZero (qMul U V)) (qAdd qOne (qMul U V)) at h
      rw [qAdd_zero_left, qAdd_comm qOne (qMul U V)] at h
      exact h
    have h0M : qLT qZero M :=
      BOMA.R.DedekindAddition001.qle_lt_trans h0UV hUV_M
    refine ⟨M, ?_⟩
    intro hM
    rcases hM with hMneg | hMprod
    · exact qlt_asymm h0M hMneg
    · rcases hMprod with ⟨a, b, ha, hb, h0a, h0b, hMab⟩
      have ha_uA : qLE a uA := member_le_outside ha huA
      have hb_uB : qLE b uB := member_le_outside hb huB
      have haU : qLE a U := qle_trans ha_uA huA_U
      have hbV : qLE b V := qle_trans hb_uB huB_V
      have hab_Ub : qLE (qMul a b) (qMul U b) := by
        have h := qmul_mono_left_nonneg haU h0b.1
        rw [qMul_comm b a, qMul_comm b U] at h
        exact h
      have hUb_UV : qLE (qMul U b) (qMul U V) :=
        qmul_mono_left_nonneg hbV h0U
      have hab_UV : qLE (qMul a b) (qMul U V) :=
        qle_trans hab_Ub hUb_UV
      have hMUV : qLT M (qMul U V) :=
        BOMA.R.DedekindAddition001.qlt_le_trans hMab hab_UV
      exact qlt_asymm hUV_M hMUV
  downward := by
    intro p q hq hpq
    rcases hq with hqNeg | hqProd
    · exact Or.inl (BOMA.R.DedekindAddition001.qle_lt_trans hpq hqNeg)
    · rcases hqProd with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      exact Or.inr ⟨a, b, ha, hb, h0a, h0b,
        BOMA.R.DedekindAddition001.qle_lt_trans hpq hq⟩
  rounded := by
    intro q hq
    rcases hq with hqNeg | hqProd
    · rcases rational_order_dense hqNeg with ⟨r, hqr, hr0⟩
      exact ⟨r, Or.inl hr0, hqr⟩
    · rcases hqProd with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      rcases rational_order_dense hq with ⟨r, hqr, hrab⟩
      exact ⟨r, Or.inr ⟨a, b, ha, hb, h0a, h0b, hrab⟩, hqr⟩

/-- The nonnegative-envelope product respects extensional identity. -/
theorem cutMulNonnegEnvelope_respects
    {A A' B B' : LowerCut}
    (hA : CutEquiv A A') (hB : CutEquiv B B') :
    CutEquiv
      (cutMulNonnegEnvelope A B)
      (cutMulNonnegEnvelope A' B') := by
  intro q
  constructor
  · intro hq
    rcases hq with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      have hPA := cutPosPart_respects hA
      have hPB := cutPosPart_respects hB
      exact Or.inr ⟨a, b, (hPA a).mp ha, (hPB b).mp hb, h0a, h0b, hq⟩
  · intro hq
    rcases hq with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      have hPA := cutPosPart_respects hA
      have hPB := cutPosPart_respects hB
      exact Or.inr ⟨a, b, (hPA a).mpr ha, (hPB b).mpr hb, h0a, h0b, hq⟩

/-- Symmetry of the nonnegative multiplication kernel. -/
theorem cutMulNonnegEnvelope_comm (A B : LowerCut) :
    CutEquiv (cutMulNonnegEnvelope A B) (cutMulNonnegEnvelope B A) := by
  intro q
  constructor
  · intro hq
    rcases hq with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      have hq' : qLT q (qMul b a) := by
        rw [qMul_comm b a]
        exact hq
      exact Or.inr ⟨b, a, hb, ha, h0b, h0a, hq'⟩
  · intro hq
    rcases hq with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨b, a, hb, ha, h0b, h0a, hq⟩
      have hq' : qLT q (qMul a b) := by
        rw [qMul_comm a b]
        exact hq
      exact Or.inr ⟨a, b, ha, hb, h0a, h0b, hq'⟩

/-- Quotient lift of the nonnegative-envelope kernel. This is an intermediate
operation, not yet the final signed real multiplication. -/
def rMulNonnegEnvelope : RBOMA → RBOMA → RBOMA :=
  Quotient.lift₂
    (fun A B => rmk (cutMulNonnegEnvelope A B))
    (fun _ _ _ _ hA hB => rmk_sound (cutMulNonnegEnvelope_respects hA hB))

@[simp] theorem rMulNonnegEnvelope_mk (A B : LowerCut) :
    rMulNonnegEnvelope (rmk A) (rmk B) = rmk (cutMulNonnegEnvelope A B) := rfl

/-- The intermediate kernel is commutative. -/
theorem rMulNonnegEnvelope_comm (x y : RBOMA) :
    rMulNonnegEnvelope x y = rMulNonnegEnvelope y x := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  change rmk (cutMulNonnegEnvelope A B) = rmk (cutMulNonnegEnvelope B A)
  exact rmk_sound (cutMulNonnegEnvelope_comm A B)

end BOMA.R.DedekindNonnegativeMul001

/- Strict positive multiplication and inner approximation on accepted QBOMA.
This is a Q-level contribution used by the selected Dedekind multiplication route. -/
namespace BOMA.R.QPositiveMultiplicativeApprox001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.Inverse001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001

/-- Right cancellation by a nonzero rational, derived from the existential
inverse interface rather than a global inverse selector. -/
theorem qmul_right_cancel_nonzero {x y c : QBOMA}
    (hc : c ≠ qZero)
    (h : qMul x c = qMul y c) : x = y := by
  rcases q_inverse_exists c hc with ⟨cinv, hcinv⟩
  have h' := congrArg (fun t => qMul t cinv) h
  calc
    x = qMul x qOne := (qMul_one_right x).symm
    _ = qMul x (qMul c cinv) :=
      congrArg (fun t => qMul x t) hcinv.symm
    _ = qMul (qMul x c) cinv := (qMul_assoc x c cinv).symm
    _ = qMul (qMul y c) cinv := h'
    _ = qMul y (qMul c cinv) := qMul_assoc y c cinv
    _ = qMul y qOne := congrArg (fun t => qMul y t) hcinv
    _ = y := qMul_one_right y

/-- Left cancellation by a nonzero rational. -/
theorem qmul_left_cancel_nonzero {x y c : QBOMA}
    (hc : c ≠ qZero)
    (h : qMul c x = qMul c y) : x = y := by
  apply qmul_right_cancel_nonzero hc
  rw [qMul_comm x c, qMul_comm y c]
  exact h

/-- Multiplication on the right by a strictly positive rational preserves strict order. -/
theorem qmul_lt_right_positive {x y c : QBOMA}
    (hxy : qLT x y) (hc : qLT qZero c) :
    qLT (qMul x c) (qMul y c) := by
  refine ⟨qmul_mono_right_nonneg hxy.1 hc.1, ?_⟩
  intro heq
  have hcNZ : c ≠ qZero := by
    intro hc0
    exact hc.2 hc0.symm
  exact hxy.2 (qmul_right_cancel_nonzero hcNZ heq)

/-- Multiplication on the left by a strictly positive rational preserves strict order. -/
theorem qmul_lt_left_positive {x y c : QBOMA}
    (hxy : qLT x y) (hc : qLT qZero c) :
    qLT (qMul c x) (qMul c y) := by
  rw [qMul_comm c x, qMul_comm c y]
  exact qmul_lt_right_positive hxy hc

/-- If 0 ≤ u < v, then v is strictly positive. -/
theorem qlt_zero_of_nonneg_lt {u v : QBOMA}
    (h0u : qLE qZero u) (huv : qLT u v) : qLT qZero v := by
  refine ⟨qle_trans h0u huv.1, ?_⟩
  intro h0v
  have hu0 : qLE u qZero := by
    rw [h0v]
    exact huv.1
  have hueq0 : u = qZero := qle_antisymm hu0 h0u
  apply huv.2
  calc
    u = qZero := hueq0
    _ = v := h0v

/-- The existential inverse witness of a strictly positive rational is strictly positive. -/
theorem qlt_zero_inverse {q r : QBOMA}
    (hq : qLT qZero q) (hr : QInvRel q r) : qLT qZero r := by
  have hp : QPositive r :=
    inverse_of_positive_is_positive ⟨hq.1, fun hq0 => hq.2 hq0.symm⟩ hr
  exact ⟨hp.1, fun h0r => hp.2 h0r.symm⟩

/-- Dividing a strict inequality x < q*r by positive r on the right. -/
theorem qlt_mul_div_right {x q r rinv : QBOMA}
    (h : qLT x (qMul q r))
    (hr : qLT qZero r)
    (hrinv : QInvRel r rinv) :
    qLT (qMul x rinv) q := by
  have hrinvPos : qLT qZero rinv := qlt_zero_inverse hr hrinv
  have ht := qmul_lt_right_positive h hrinvPos
  have hright : qMul (qMul q r) rinv = q := by
    calc
      qMul (qMul q r) rinv = qMul q (qMul r rinv) := qMul_assoc q r rinv
      _ = qMul q qOne := congrArg (fun t => qMul q t) hrinv
      _ = q := qMul_one_right q
  rw [hright] at ht
  exact ht

/-- Recompose after dividing on the right. -/
theorem qlt_mul_recompose_right {x a r rinv : QBOMA}
    (h : qLT (qMul x rinv) a)
    (hr : qLT qZero r)
    (hrinv : QInvRel r rinv) :
    qLT x (qMul a r) := by
  have ht := qmul_lt_right_positive h hr
  have hleft : qMul (qMul x rinv) r = x := by
    have hri : qMul rinv r = qOne := by
      calc
        qMul rinv r = qMul r rinv := qMul_comm rinv r
        _ = qOne := hrinv
    calc
      qMul (qMul x rinv) r = qMul x (qMul rinv r) := qMul_assoc x rinv r
      _ = qMul x qOne := congrArg (fun t => qMul x t) hri
      _ = x := qMul_one_right x
  rw [hleft] at ht
  exact ht

/-- Divide x < a*r by positive a on the left. -/
theorem qlt_mul_div_left {x a r ainv : QBOMA}
    (h : qLT x (qMul a r))
    (ha : qLT qZero a)
    (hainv : QInvRel a ainv) :
    qLT (qMul ainv x) r := by
  have hainvPos : qLT qZero ainv := qlt_zero_inverse ha hainv
  have ht := qmul_lt_left_positive h hainvPos
  have hright : qMul ainv (qMul a r) = r := by
    have hia : qMul ainv a = qOne := by
      calc
        qMul ainv a = qMul a ainv := qMul_comm ainv a
        _ = qOne := hainv
    calc
      qMul ainv (qMul a r) = qMul (qMul ainv a) r := (qMul_assoc ainv a r).symm
      _ = qMul qOne r := congrArg (fun t => qMul t r) hia
      _ = r := qMul_one_left r
  rw [hright] at ht
  exact ht

/-- Recompose after dividing on the left. -/
theorem qlt_mul_recompose_left {x a b ainv : QBOMA}
    (h : qLT (qMul ainv x) b)
    (ha : qLT qZero a)
    (hainv : QInvRel a ainv) :
    qLT x (qMul a b) := by
  have ht := qmul_lt_left_positive h ha
  have hleft : qMul a (qMul ainv x) = x := by
    calc
      qMul a (qMul ainv x) = qMul (qMul a ainv) x := (qMul_assoc a ainv x).symm
      _ = qMul qOne x := congrArg (fun t => qMul t x) hainv
      _ = x := qMul_one_left x
  rw [hleft] at ht
  exact ht

/-- Inner-product approximation below positive r.
If x is nonnegative and x < q*r while r is positive, then positivity of q is
forced by the inequality itself; no separate q>0 assumption is required. -/
theorem q_positive_product_inner_approx
    {x q r : QBOMA}
    (hx : qLE qZero x)
    (hr : qLT qZero r)
    (hprod : qLT x (qMul q r)) :
    ∃ a b : QBOMA,
      qLT qZero a ∧
      qLT a q ∧
      qLT qZero b ∧
      qLT b r ∧
      qLT x (qMul a b) := by
  have hrNZ : r ≠ qZero := by
    intro hr0
    exact hr.2 hr0.symm
  rcases q_inverse_exists r hrNZ with ⟨rinv, hrinv⟩
  have hrinvPos : qLT qZero rinv := qlt_zero_inverse hr hrinv
  have hxdivq : qLT (qMul x rinv) q :=
    qlt_mul_div_right hprod hr hrinv
  have h0xrinv : qLE qZero (qMul x rinv) :=
    qmul_nonneg hx hrinvPos.1
  rcases rational_order_dense hxdivq with ⟨a, hxa, haq⟩
  have haPos : qLT qZero a := qlt_zero_of_nonneg_lt h0xrinv hxa
  have hxar : qLT x (qMul a r) :=
    qlt_mul_recompose_right hxa hr hrinv
  have haNZ : a ≠ qZero := by
    intro ha0
    exact haPos.2 ha0.symm
  rcases q_inverse_exists a haNZ with ⟨ainv, hainv⟩
  have hainvPos : qLT qZero ainv := qlt_zero_inverse haPos hainv
  have hxdivr : qLT (qMul ainv x) r :=
    qlt_mul_div_left hxar haPos hainv
  have h0ainvx : qLE qZero (qMul ainv x) :=
    qmul_nonneg hainvPos.1 hx
  rcases rational_order_dense hxdivr with ⟨b, hxb, hbr⟩
  have hbPos : qLT qZero b := qlt_zero_of_nonneg_lt h0ainvx hxb
  have hxab : qLT x (qMul a b) :=
    qlt_mul_recompose_left hxb haPos hainv
  exact ⟨a, b, haPos, haq, hbPos, hbr, hxab⟩

end BOMA.R.QPositiveMultiplicativeApprox001

/- Rational preservation for the nonnegative-envelope Dedekind multiplication kernel. -/
namespace BOMA.R.DedekindNonnegativeMulEmbedding001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- Principal zero inclusion into a nonnegative principal rational cut. -/
theorem principal_zero_le_principal {q : QBOMA} (hq : qLE qZero q) :
    CutLE (principalCut qZero) (principalCut q) := by
  intro x hx
  exact (principalLE_iff_qLE qZero q).2 hq x hx

/-- For a nonnegative rational q, max(principal(q),0) is just principal(q). -/
theorem cutPosPart_principal_nonneg {q : QBOMA} (hq : qLE qZero q) :
    CutEquiv (cutPosPart (principalCut q)) (principalCut q) :=
  cutPosPart_of_nonneg (principal_zero_le_principal hq)

/-- The positive-envelope multiplication kernel agrees extensionally with
ordinary rational multiplication on nonnegative principal cuts. -/
theorem cutMulNonnegEnvelope_principal
    (q r : QBOMA)
    (hq : qLE qZero q)
    (hr : qLE qZero r) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut q) (principalCut r))
      (principalCut (qMul q r)) := by
  intro x
  constructor
  · intro hx
    rcases hx with hxNeg | hxProd
    · have hqrNonNeg : qLE qZero (qMul q r) := qmul_nonneg hq hr
      exact qlt_le_trans hxNeg hqrNonNeg
    · rcases hxProd with ⟨a, b, haPosCut, hbPosCut, h0a, h0b, hxab⟩
      have haQ : qLT a q :=
        ((cutPosPart_principal_nonneg hq) a).mp haPosCut
      have hbR : qLT b r :=
        ((cutPosPart_principal_nonneg hr) b).mp hbPosCut
      have hab_qb : qLE (qMul a b) (qMul q b) :=
        qmul_mono_right_nonneg haQ.1 h0b.1
      have hqb_qr : qLE (qMul q b) (qMul q r) :=
        qmul_mono_left_nonneg hbR.1 hq
      have hab_qr : qLE (qMul a b) (qMul q r) :=
        qle_trans hab_qb hqb_qr
      exact qlt_le_trans hxab hab_qr
  · intro hx
    rcases qlt_trichotomy x qZero with hxNeg | hxEq | hxPos
    · exact Or.inl hxNeg
    · have hx0 : qLE qZero x := by
        rw [hxEq]
        exact qle_refl qZero
      have hrNZ : qZero ≠ r := by
        intro h0r
        have hprod0 : qMul q r = qZero := by
          rw [← h0r, qMul_zero_right]
        have hxlt0 : qLT x qZero := by
          rw [← hprod0]
          exact hx
        have hxeq0 : x = qZero := qle_antisymm hxlt0.1 hx0
        exact hxlt0.2 hxeq0
      have hrPos : qLT qZero r := ⟨hr, hrNZ⟩
      rcases q_positive_product_inner_approx hx0 hrPos hx with
        ⟨a, b, h0a, haq, h0b, hbr, hxab⟩
      exact Or.inr ⟨a, b, Or.inl haq, Or.inl hbr, h0a, h0b, hxab⟩
    · have hx0 : qLE qZero x := hxPos.1
      have hrNZ : qZero ≠ r := by
        intro h0r
        have hprod0 : qMul q r = qZero := by
          rw [← h0r, qMul_zero_right]
        have hxlt0 : qLT x qZero := by
          rw [← hprod0]
          exact hx
        exact (qlt_asymm hxPos) hxlt0
      have hrPos : qLT qZero r := ⟨hr, hrNZ⟩
      rcases q_positive_product_inner_approx hx0 hrPos hx with
        ⟨a, b, h0a, haq, h0b, hbr, hxab⟩
      exact Or.inr ⟨a, b, Or.inl haq, Or.inl hbr, h0a, h0b, hxab⟩

/-- The formal nonnegative-envelope multiplication kernel preserves accepted
rational multiplication on nonnegative rational inputs. -/
theorem rMulNonnegEnvelope_rOfQ
    (q r : QBOMA)
    (hq : qLE qZero q)
    (hr : qLE qZero r) :
    rMulNonnegEnvelope (rOfQ q) (rOfQ r) = rOfQ (qMul q r) := by
  change
    rmk (cutMulNonnegEnvelope (principalCut q) (principalCut r)) =
    rmk (principalCut (qMul q r))
  exact rmk_sound (cutMulNonnegEnvelope_principal q r hq hr)

end BOMA.R.DedekindNonnegativeMulEmbedding001

/- Rational inverse-order interface used by the real reciprocal route. -/
namespace BOMA.R.QInverseOrder001

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- Existential inverse witnesses reverse strict order on positive rationals. -/
theorem q_inverse_strict_antitone
    {a b ainv binv : QBOMA}
    (h0a : qLT qZero a)
    (hab : qLT a b)
    (hainv : QInvRel a ainv)
    (hbinv : QInvRel b binv) :
    qLT binv ainv := by
  have h0b : qLT qZero b := qlt_trans h0a hab
  have h0ainv : qLT qZero ainv := qlt_zero_inverse h0a hainv
  have h0binv : qLT qZero binv := qlt_zero_inverse h0b hbinv
  have h1raw := qmul_lt_right_positive hab h0ainv
  have h1 : qLT qOne (qMul b ainv) := by
    unfold QInvRel at hainv
    rw [hainv] at h1raw
    exact h1raw
  have h2 := qmul_lt_left_positive h1 h0binv
  have hright : qMul binv (qMul b ainv) = ainv := by
    unfold QInvRel at hbinv
    calc
      qMul binv (qMul b ainv) = qMul (qMul binv b) ainv :=
        (qMul_assoc binv b ainv).symm
      _ = qMul (qMul b binv) ainv := by rw [qMul_comm binv b]
      _ = qMul qOne ainv := by rw [hbinv]
      _ = ainv := qMul_one_left ainv
  rw [qMul_one_right, hright] at h2
  exact h2

end BOMA.R.QInverseOrder001

/- Direct positive reciprocal candidate for the selected Dedekind route.
The lower predicate uses positive rational outside witnesses and their accepted
Q inverse witnesses. The source-positivity proof is consumed only by validity. -/
namespace BOMA.R.DedekindPositiveReciprocal001

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.QPositiveMultiplicativeApprox001
open BOMA.R.QInverseOrder001

/-- Local non-strict/strict transitivity used to keep this reciprocal gate
independent of later R-stage helper files. -/
theorem qle_lt_trans_recip {x y z : QBOMA}
    (hxy : qLE x y) (hyz : qLT y z) : qLT x z := by
  refine ⟨qle_trans hxy hyz.1, ?_⟩
  intro hxz
  have hzy : qLE z y := by
    rw [← hxz]
    exact hxy
  have hyzEq : y = z := qle_antisymm hyz.1 hzy
  exact hyz.2 hyzEq

/-- Representation-level witness that a lower cut contains a strictly positive rational. -/
def CutHasPositive (A : LowerCut) : Prop :=
  ∃ a : QBOMA, A.lower a ∧ qLT qZero a

/-- Any inside point of a lower cut lies strictly below any outside point. -/
theorem cut_inside_lt_outside
    {A : LowerCut} {a r : QBOMA}
    (ha : A.lower a)
    (hr : ¬ A.lower r) :
    qLT a r := by
  rcases qle_total a r with har | hra
  · refine ⟨har, ?_⟩
    intro harEq
    apply hr
    rw [← harEq]
    exact ha
  · exact False.elim (hr (A.downward ha hra))

/-- Direct reciprocal lower cut for a source cut with an explicit positive-inside witness.
The `hApos` proof does not occur in the lower predicate itself. -/
def cutRecipPos (A : LowerCut) (hApos : CutHasPositive A) : LowerCut where
  lower := fun q =>
    qLT q qZero ∨
    ∃ r rinv : QBOMA,
      ¬ A.lower r ∧
      qLT qZero r ∧
      QInvRel r rinv ∧
      qLT q rinv
  nonempty := by
    have hneg : qLT (qNeg qOne) qZero := by
      have ht := qlt_add_right qzero_lt_one (qNeg qOne)
      rw [qAdd_zero_left, qAdd_neg_right] at ht
      exact ht
    exact ⟨qNeg qOne, Or.inl hneg⟩
  proper := by
    rcases hApos with ⟨a, haA, h0a⟩
    have haNZ : a ≠ qZero := by
      intro ha0
      exact h0a.2 ha0.symm
    rcases q_inverse_exists a haNZ with ⟨ainv, hainv⟩
    refine ⟨ainv, ?_⟩
    intro hain
    rcases hain with hainNeg | ⟨r, rinv, hrOut, h0r, hrinv, hain_lt_rinv⟩
    · have h0ainv : qLT qZero ainv := qlt_zero_inverse h0a hainv
      exact (qlt_asymm h0ainv) hainNeg
    · have har : qLT a r := cut_inside_lt_outside haA hrOut
      have hrev : qLT rinv ainv :=
        q_inverse_strict_antitone h0a har hainv hrinv
      exact (qlt_asymm hain_lt_rinv) hrev
  downward := by
    intro p q hq hpq
    rcases hq with hqNeg | ⟨r, rinv, hrOut, h0r, hrinv, hqInv⟩
    · exact Or.inl (qle_lt_trans_recip hpq hqNeg)
    · exact Or.inr ⟨r, rinv, hrOut, h0r, hrinv, qle_lt_trans_recip hpq hqInv⟩
  rounded := by
    intro q hq
    rcases hq with hqNeg | ⟨r, rinv, hrOut, h0r, hrinv, hqInv⟩
    · rcases rational_order_dense hqNeg with ⟨m, hqm, hm0⟩
      exact ⟨m, Or.inl hm0, hqm⟩
    · rcases rational_order_dense hqInv with ⟨m, hqm, hmInv⟩
      exact ⟨m, Or.inr ⟨r, rinv, hrOut, h0r, hrinv, hmInv⟩, hqm⟩

/-- The reciprocal candidate is independent of which proof of source positivity is supplied. -/
theorem cutRecipPos_proof_independent
    (A : LowerCut)
    (h1 h2 : CutHasPositive A) :
    CutEquiv (cutRecipPos A h1) (cutRecipPos A h2) := by
  intro q
  rfl

/-- Extensional source identity transports the positive reciprocal candidate. -/
theorem cutRecipPos_respects
    {A B : LowerCut}
    (hAB : CutEquiv A B)
    (hApos : CutHasPositive A)
    (hBpos : CutHasPositive B) :
    CutEquiv (cutRecipPos A hApos) (cutRecipPos B hBpos) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | ⟨r, rinv, hrA, h0r, hrinv, hqinv⟩
    · exact Or.inl hqNeg
    · have hrB : ¬ B.lower r := by
        intro hBr
        exact hrA ((hAB r).mpr hBr)
      exact Or.inr ⟨r, rinv, hrB, h0r, hrinv, hqinv⟩
  · intro hq
    rcases hq with hqNeg | ⟨r, rinv, hrB, h0r, hrinv, hqinv⟩
    · exact Or.inl hqNeg
    · have hrA : ¬ A.lower r := by
        intro hAr
        exact hrB ((hAB r).mp hAr)
      exact Or.inr ⟨r, rinv, hrA, h0r, hrinv, hqinv⟩

end BOMA.R.DedekindPositiveReciprocal001

/- Rational preservation for the direct positive Dedekind reciprocal candidate. -/
namespace BOMA.R.DedekindPositiveReciprocalEmbedding001

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.QPositiveMultiplicativeApprox001
open BOMA.R.QInverseOrder001
open BOMA.R.DedekindPositiveReciprocal001

/-- A positive principal rational cut contains a strictly positive rational witness. -/
theorem principalCut_has_positive
    {q : QBOMA} (h0q : qLT qZero q) :
    CutHasPositive (principalCut q) := by
  rcases rational_order_dense h0q with ⟨a, h0a, haq⟩
  exact ⟨a, haq, h0a⟩

/-- An outside point of principalCut(q) lies at or above q. -/
theorem principal_outside_ge
    {q r : QBOMA}
    (hrOut : ¬ (principalCut q).lower r) :
    qLE q r := by
  rcases qle_total q r with hqr | hrq
  · exact hqr
  · by_cases heq : r = q
    · rw [heq]
      exact qle_refl q
    · have hrltq : qLT r q := ⟨hrq, heq⟩
      exact False.elim (hrOut hrltq)

/-- Two inverse witnesses for the same nonzero rational coincide. -/
theorem q_inverse_witness_unique
    {q a b : QBOMA}
    (hq0 : q ≠ qZero)
    (ha : QInvRel q a)
    (hb : QInvRel q b) : a = b := by
  unfold QInvRel at ha hb
  apply qMul_left_cancel_nonzero hq0
  exact ha.trans hb.symm

/-- On a positive principal rational cut, the direct reciprocal candidate is
exactly the principal cut of any accepted Q inverse witness. -/
theorem cutRecipPos_principal
    {q qinv : QBOMA}
    (h0q : qLT qZero q)
    (hqinv : QInvRel q qinv) :
    CutEquiv
      (cutRecipPos (principalCut q) (principalCut_has_positive h0q))
      (principalCut qinv) := by
  have h0qinv : qLT qZero qinv := qlt_zero_inverse h0q hqinv
  have hqNZ : q ≠ qZero := by
    intro hq0
    exact h0q.2 hq0.symm
  intro p
  constructor
  · intro hp
    rcases hp with hpNeg | ⟨r, rinv, hrOut, h0r, hrinv, hpRinv⟩
    · exact qlt_trans hpNeg h0qinv
    · have hqr : qLE q r := principal_outside_ge hrOut
      rcases qlt_trichotomy q r with hqrStrict | hEq | hrqStrict
      · have hrev : qLT rinv qinv :=
          q_inverse_strict_antitone h0q hqrStrict hqinv hrinv
        exact qlt_trans hpRinv hrev
      · have hsame : rinv = qinv := by
          have hrAsQ : QInvRel q rinv := by
            rw [hEq]
            exact hrinv
          exact q_inverse_witness_unique hqNZ hrAsQ hqinv
        rw [hsame] at hpRinv
        exact hpRinv
      · exact False.elim (hrOut hrqStrict)
  · intro hp
    rcases qlt_trichotomy p qZero with hpNeg | hpEq | h0p
    · exact Or.inl hpNeg
    · have hp0 : qLE qZero p := by
        rw [hpEq]
        exact qle_refl qZero
      rcases rational_order_dense hp with ⟨t, hpt, htqinv⟩
      have h0t : qLT qZero t := qlt_zero_of_nonneg_lt hp0 hpt
      have htNZ : t ≠ qZero := by
        intro ht0
        exact h0t.2 ht0.symm
      rcases q_inverse_exists t htNZ with ⟨r, htr⟩
      have hrt : QInvRel r t := by
        unfold QInvRel at htr ⊢
        calc
          qMul r t = qMul t r := qMul_comm r t
          _ = qOne := htr
      have hqinvq : QInvRel qinv q := by
        unfold QInvRel at hqinv ⊢
        calc
          qMul qinv q = qMul q qinv := qMul_comm qinv q
          _ = qOne := hqinv
      have hqr : qLT q r :=
        q_inverse_strict_antitone h0t htqinv htr hqinvq
      have hrOut : ¬ (principalCut q).lower r := by
        intro hrq
        exact (qlt_asymm hqr) hrq
      exact Or.inr ⟨r, t, hrOut,
        qlt_trans h0q hqr, hrt, hpt⟩
    · have hp0 : qLE qZero p := h0p.1
      rcases rational_order_dense hp with ⟨t, hpt, htqinv⟩
      have h0t : qLT qZero t := qlt_zero_of_nonneg_lt hp0 hpt
      have htNZ : t ≠ qZero := by
        intro ht0
        exact h0t.2 ht0.symm
      rcases q_inverse_exists t htNZ with ⟨r, htr⟩
      have hrt : QInvRel r t := by
        unfold QInvRel at htr ⊢
        calc
          qMul r t = qMul t r := qMul_comm r t
          _ = qOne := htr
      have hqinvq : QInvRel qinv q := by
        unfold QInvRel at hqinv ⊢
        calc
          qMul qinv q = qMul q qinv := qMul_comm qinv q
          _ = qOne := hqinv
      have hqr : qLT q r :=
        q_inverse_strict_antitone h0t htqinv htr hqinvq
      have hrOut : ¬ (principalCut q).lower r := by
        intro hrq
        exact (qlt_asymm hqr) hrq
      exact Or.inr ⟨r, t, hrOut,
        qlt_trans h0q hqr, hrt, hpt⟩

end BOMA.R.DedekindPositiveReciprocalEmbedding001

/- Anchored fine bracketing for positive Dedekind lower cuts.
This strengthens the accepted CutBracketApprox by preserving a chosen positive
inside anchor as a lower bound on the returned inside endpoint. -/
namespace BOMA.R.DedekindAnchoredBracket001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindCutBracket001
open BOMA.R.DedekindPositiveReciprocal001

/-- If a0 is inside A and a0≤b, keep b; otherwise use a0.
The resulting inside endpoint remains below the same outside r and its gap
is no larger than the original bracket gap. -/
theorem cut_bracket_approx_anchored
    (A : LowerCut)
    (a0 eps : QBOMA)
    (ha0 : A.lower a0)
    (heps : qLT qZero eps) :
    ∃ a r : QBOMA,
      A.lower a ∧
      ¬ A.lower r ∧
      qLE a0 a ∧
      qLT qZero (qAdd r (qNeg a)) ∧
      qLT (qAdd r (qNeg a)) eps := by
  rcases cut_bracket_approx A eps heps with
    ⟨b, r, hbA, hrOut, hgapPos, hgapSmall⟩
  rcases qle_total a0 b with h0b | hb0
  · exact ⟨b, r, hbA, hrOut, h0b, hgapPos, hgapSmall⟩
  · have ha0r : qLT a0 r := by
      rcases qle_total a0 r with h0r | hr0
      · refine ⟨h0r, ?_⟩
        intro heq
        apply hrOut
        rw [← heq]
        exact ha0
      · exact False.elim (hrOut (A.downward ha0 hr0))
    have hnewPosRaw : QPositive (qAdd r (qNeg a0)) :=
      positive_difference_of_lt ha0r
    have hnewPos : qLT qZero (qAdd r (qNeg a0)) :=
      ⟨hnewPosRaw.1, fun h => hnewPosRaw.2 h.symm⟩
    have hgapLE :
        qLE (qAdd r (qNeg a0)) (qAdd r (qNeg b)) := by
      have hneg : qLE (qNeg a0) (qNeg b) := qneg_reverses hb0
      have ht := qadd_mono_right hneg r
      rw [qAdd_comm (qNeg a0) r, qAdd_comm (qNeg b) r] at ht
      exact ht
    have hnewSmall : qLT (qAdd r (qNeg a0)) eps :=
      qle_lt_trans_recip hgapLE hgapSmall
    exact ⟨a0, r, ha0, hrOut, qle_refl a0, hnewPos, hnewSmall⟩

end BOMA.R.DedekindAnchoredBracket001

/- Rational reciprocal-gap estimate revision 004.
Preserves 001-003 as PDSA proof-engineering history. -/
namespace BOMA.R.QReciprocalGap004

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QPositiveMultiplicativeApprox001

 theorem qlt_le_trans_gap {x y z : QBOMA}
    (hxy : qLT x y) (hyz : qLE y z) : qLT x z := by
  refine ⟨qle_trans hxy.1 hyz, ?_⟩
  intro hxz
  have hzy : qLE z y := by
    rw [← hxz]
    exact hxy.1
  have hyzEq : y = z := qle_antisymm hyz hzy
  have hxyEq : x = y := hxz.trans hyzEq.symm
  exact hxy.2 hxyEq

 theorem q_add_one_minus (q : QBOMA) :
    qAdd q (qAdd qOne (qNeg q)) = qOne := by
  calc
    qAdd q (qAdd qOne (qNeg q)) = qAdd qOne (qAdd q (qNeg q)) := by
      calc
        qAdd q (qAdd qOne (qNeg q)) = qAdd (qAdd q qOne) (qNeg q) :=
          (qAdd_assoc q qOne (qNeg q)).symm
        _ = qAdd (qAdd qOne q) (qNeg q) :=
          congrArg (fun t => qAdd t (qNeg q)) (qAdd_comm q qOne)
        _ = qAdd qOne (qAdd q (qNeg q)) := qAdd_assoc qOne q (qNeg q)
    _ = qAdd qOne qZero := by rw [qAdd_neg_right]
    _ = qOne := qAdd_zero_right qOne

 theorem q_add_gap (a r : QBOMA) :
    qAdd a (qAdd r (qNeg a)) = r := by
  calc
    qAdd a (qAdd r (qNeg a)) = qAdd r (qAdd a (qNeg a)) := by
      calc
        qAdd a (qAdd r (qNeg a)) = qAdd (qAdd a r) (qNeg a) :=
          (qAdd_assoc a r (qNeg a)).symm
        _ = qAdd (qAdd r a) (qNeg a) :=
          congrArg (fun t => qAdd t (qNeg a)) (qAdd_comm a r)
        _ = qAdd r (qAdd a (qNeg a)) := qAdd_assoc r a (qNeg a)
    _ = qAdd r qZero := by rw [qAdd_neg_right]
    _ = r := qAdd_zero_right r

 theorem q_lt_mul_inverse_of_small_gap
    {q a0 a r rinv : QBOMA}
    (h0q : qLE qZero q)
    (hq1 : qLT q qOne)
    (h0a0 : qLT qZero a0)
    (ha0a : qLE a0 a)
    (h0r : qLT qZero r)
    (hgapPos : qLT qZero (qAdd r (qNeg a)))
    (hgapSmall : qLT (qAdd r (qNeg a)) (qMul (qAdd qOne (qNeg q)) a0))
    (hrinv : QInvRel r rinv) :
    qLT q (qMul a rinv) := by
  let g := qAdd r (qNeg a)
  let omq := qAdd qOne (qNeg q)
  have homqPos : QPositive omq := by
    unfold omq
    exact positive_difference_of_lt hq1
  have hgapPos' : qLT qZero g := hgapPos
  have hgapSmall' : qLT g (qMul omq a0) := hgapSmall
  have hbound : qLE (qMul omq a0) (qMul omq a) :=
    qmul_mono_left_nonneg ha0a homqPos.1
  have hgapToA : qLT g (qMul omq a) :=
    qlt_le_trans_gap hgapSmall' hbound
  have hqg : qLT (qMul q g) g := by
    have ht := qmul_lt_right_positive hq1 hgapPos'
    rw [qMul_one_left] at ht
    exact ht
  have hqa_qag :
      qLT (qAdd (qMul q a) (qMul q g)) (qAdd (qMul q a) g) := by
    have ht := qlt_add_right hqg (qMul q a)
    rw [qAdd_comm (qMul q g) (qMul q a), qAdd_comm g (qMul q a)] at ht
    exact ht
  have hqag_final :
      qLT (qAdd (qMul q a) g) (qAdd (qMul q a) (qMul omq a)) := by
    have ht := qlt_add_right hgapToA (qMul q a)
    rw [qAdd_comm g (qMul q a), qAdd_comm (qMul omq a) (qMul q a)] at ht
    exact ht
  have hsumA : qAdd (qMul q a) (qMul omq a) = a := by
    calc
      qAdd (qMul q a) (qMul omq a) = qMul (qAdd q omq) a :=
        (qMul_add_left q omq a).symm
      _ = qMul qOne a := by rw [q_add_one_minus]
      _ = a := qMul_one_left a
  have hqexpand : qMul q r = qAdd (qMul q a) (qMul q g) := by
    have hrag : qAdd a g = r := by
      unfold g
      exact q_add_gap a r
    calc
      qMul q r = qMul q (qAdd a g) := by rw [hrag]
      _ = qAdd (qMul q a) (qMul q g) := qMul_add_right q a g
  have hmid :
      qLT (qAdd (qMul q a) (qMul q g))
          (qAdd (qMul q a) (qMul omq a)) :=
    qlt_trans hqa_qag hqag_final
  have hqr : qLT (qMul q r) a := by
    have ht := hmid
    rw [← hqexpand, hsumA] at ht
    exact ht
  have h0rinv : qLT qZero rinv := qlt_zero_inverse h0r hrinv
  have ht := qmul_lt_right_positive hqr h0rinv
  have hleft : qMul (qMul q r) rinv = q := by
    calc
      qMul (qMul q r) rinv = qMul q (qMul r rinv) := qMul_assoc q r rinv
      _ = qMul q qOne := by rw [hrinv]
      _ = q := qMul_one_right q
  rw [hleft] at ht
  exact ht

end BOMA.R.QReciprocalGap004

/- Positive inverse-product revision 004.
Preserves earlier revisions; fixes only proof-witness scope after destructuring. -/
namespace BOMA.R.DedekindPositiveInverseProduct004

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.QPositiveMultiplicativeApprox001
open BOMA.R.DedekindPositiveReciprocal001
open BOMA.R.DedekindAnchoredBracket001
open BOMA.R.QReciprocalGap004

 theorem principal_one_mem_mul_recip_of_nonneg
    (A : LowerCut)
    (hApos : CutHasPositive A)
    {q : QBOMA}
    (h0q : qLE qZero q)
    (hq1 : qLT q qOne) :
    (cutMulNonnegEnvelope A (cutRecipPos A hApos)).lower q := by
  have hAposOrig : CutHasPositive A := hApos
  rcases hApos with ⟨a0, ha0A, h0a0⟩
  let omq := qAdd qOne (qNeg q)
  have homqRaw : QPositive omq := by
    unfold omq
    exact positive_difference_of_lt hq1
  have homq : qLT qZero omq :=
    ⟨homqRaw.1, fun hz => homqRaw.2 hz.symm⟩
  let eps := qMul omq a0
  have heps : qLT qZero eps := by
    have ht := qmul_lt_right_positive homq h0a0
    unfold eps
    rw [qMul_zero_left] at ht
    exact ht
  rcases cut_bracket_approx_anchored A a0 eps ha0A heps with
    ⟨a, r, haA, hrOut, ha0a, hgapPos, hgapSmall⟩
  have h0a : qLT qZero a := qlt_le_trans_gap h0a0 ha0a
  have har : qLT a r := cut_inside_lt_outside haA hrOut
  have h0r : qLT qZero r := qlt_trans h0a har
  have hrNZ : r ≠ qZero := by
    intro hr0
    exact h0r.2 hr0.symm
  rcases q_inverse_exists r hrNZ with ⟨rinv, hrinv⟩
  have hratio : qLT q (qMul a rinv) := by
    apply q_lt_mul_inverse_of_small_gap h0q hq1 h0a0 ha0a h0r hgapPos
    · unfold eps omq at hgapSmall
      exact hgapSmall
    · exact hrinv
  have h0rinv : qLT qZero rinv := qlt_zero_inverse h0r hrinv
  rcases q_positive_product_inner_approx h0q h0rinv hratio with
    ⟨a', b, h0a', ha'a, h0b, hbInv, hqab⟩
  have ha'A : A.lower a' := A.downward haA ha'a.1
  have hLocalPos : CutHasPositive A := ⟨a0, ha0A, h0a0⟩
  have hbLocal : (cutRecipPos A hLocalPos).lower b :=
    Or.inr ⟨r, rinv, hrOut, h0r, hrinv, hbInv⟩
  have hProofEq : CutEquiv (cutRecipPos A hLocalPos) (cutRecipPos A hAposOrig) :=
    cutRecipPos_proof_independent A hLocalPos hAposOrig
  have hbRecip : (cutRecipPos A hAposOrig).lower b := (hProofEq b).mp hbLocal
  exact Or.inr ⟨a', b, Or.inl ha'A, Or.inl hbRecip, h0a', h0b, hqab⟩

 theorem cutMul_recipPos_equiv_one
    (A : LowerCut)
    (hApos : CutHasPositive A) :
    CutEquiv (cutMulNonnegEnvelope A (cutRecipPos A hApos)) (principalCut qOne) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact qlt_trans hqNeg qzero_lt_one
    · rcases hqProd with ⟨a, b, haPos, hbPos, h0a, h0b, hqab⟩
      have haA : A.lower a := by
        rcases haPos with haA | haNeg
        · exact haA
        · exact False.elim ((qlt_asymm h0a) haNeg)
      have hbRecip : (cutRecipPos A hApos).lower b := by
        rcases hbPos with hbRecip | hbNeg
        · exact hbRecip
        · exact False.elim ((qlt_asymm h0b) hbNeg)
      rcases hbRecip with hbNeg | ⟨r, rinv, hrOut, h0r, hrinv, hbInv⟩
      · exact False.elim ((qlt_asymm h0b) hbNeg)
      · have har : qLT a r := cut_inside_lt_outside haA hrOut
        have h0rinv : qLT qZero rinv := qlt_zero_inverse h0r hrinv
        have hab_arinv : qLT (qMul a b) (qMul a rinv) := qmul_lt_left_positive hbInv h0a
        have har_rinv : qLT (qMul a rinv) (qMul r rinv) := qmul_lt_right_positive har h0rinv
        have hab1 : qLT (qMul a b) qOne := by
          have ht := qlt_trans hab_arinv har_rinv
          unfold QInvRel at hrinv
          rw [hrinv] at ht
          exact ht
        exact qlt_trans hqab hab1
  · intro hq1
    rcases qlt_trichotomy q qZero with hqNeg | hqEq | h0qStrict
    · exact Or.inl hqNeg
    · have h0q : qLE qZero q := by
        rw [hqEq]
        exact qle_refl qZero
      exact principal_one_mem_mul_recip_of_nonneg A hApos h0q hq1
    · exact principal_one_mem_mul_recip_of_nonneg A hApos h0qStrict.1 hq1

end BOMA.R.DedekindPositiveInverseProduct004

/- Corrected positive representative witnesses for nonzero nonnegative selected reals.
Revision 002 preserves revision 001 as a proof-engineering learning artifact. -/
namespace BOMA.R.DedekindPositiveRepresentative002

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositiveReciprocal001

/-- A cut containing one positive rational contains the entire principal zero cut. -/
theorem cut_zero_le_of_has_positive
    {A : LowerCut}
    (hApos : CutHasPositive A) :
    CutLE (principalCut qZero) A := by
  rcases hApos with ⟨a, haA, h0a⟩
  intro q hq0
  exact A.downward haA (qlt_trans hq0 h0a).1

/-- A nonnegative cut that is not extensionally zero must contain a positive rational.
The witness extraction uses Classical.byContradiction explicitly. -/
theorem cut_has_positive_of_nonneg_ne_zero
    {A : LowerCut}
    (h0A : CutLE (principalCut qZero) A)
    (hne : ¬ CutEquiv A (principalCut qZero)) :
    CutHasPositive A := by
  apply Classical.byContradiction
  intro hNoPos
  apply hne
  intro q
  constructor
  · intro hqA
    rcases qlt_trichotomy q qZero with hq0 | heq | h0q
    · exact hq0
    · rcases A.rounded hqA with ⟨b, hbA, hqb⟩
      have h0b : qLT qZero b := by
        rw [heq] at hqb
        exact hqb
      exact False.elim (hNoPos ⟨b, hbA, h0b⟩)
    · exact False.elim (hNoPos ⟨q, hqA, h0q⟩)
  · intro hq0
    exact h0A q hq0

/-- Every nonzero nonnegative formal real has a representative with an explicit
positive rational inside witness. -/
theorem r_nonneg_nonzero_positive_rep
    {x : RBOMA}
    (h0x : rLE rZero x)
    (hx0 : x ≠ rZero) :
    ∃ A : LowerCut, ∃ hApos : CutHasPositive A,
      x = rmk A := by
  refine Quotient.inductionOn x ?_ h0x hx0
  intro A h0A hAne
  have h0Acut : CutLE (principalCut qZero) A := by
    change rLE (rmk (principalCut qZero)) (rmk A) at h0A
    exact (rLE_mk_iff (principalCut qZero) A).1 h0A
  have hneCut : ¬ CutEquiv A (principalCut qZero) := by
    intro hEq
    apply hAne
    change rmk A = rmk (principalCut qZero)
    exact rmk_sound hEq
  have hApos : CutHasPositive A :=
    cut_has_positive_of_nonneg_ne_zero h0Acut hneCut
  exact ⟨A, hApos, rfl⟩

end BOMA.R.DedekindPositiveRepresentative002

/- Signed Dedekind multiplication candidate built compositionally from positive envelopes.
The operation definition contains no sign-case `if`; sign analysis appears only in proofs. -/
namespace BOMA.R.DedekindSignedMulCandidate001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulEmbedding001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- If a principal rational cut is nonpositive, its positive envelope is the zero cut. -/
theorem cutPosPart_principal_nonpos {q : QBOMA} (hq : qLE q qZero) :
    CutEquiv (cutPosPart (principalCut q)) (principalCut qZero) := by
  intro x
  constructor
  · intro hx
    rcases hx with hxq | hx0
    · exact qlt_le_trans hxq hq
    · exact hx0
  · intro hx0
    exact Or.inr hx0

/-- If the left rational input is nonpositive, the nonnegative-envelope kernel is zero. -/
theorem cutMulNonnegEnvelope_principal_left_nonpos
    (q r : QBOMA) (hq : qLE q qZero) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut q) (principalCut r))
      (principalCut qZero) := by
  intro x
  constructor
  · intro hx
    rcases hx with hxNeg | hxProd
    · exact hxNeg
    · rcases hxProd with ⟨a, b, ha, _hb, h0a, _h0b, _hxab⟩
      have ha0 : qLT a qZero :=
        ((cutPosPart_principal_nonpos hq) a).mp ha
      exact False.elim ((qlt_asymm h0a) ha0)
  · intro hx0
    exact Or.inl hx0

/-- If the right rational input is nonpositive, the kernel is zero. -/
theorem cutMulNonnegEnvelope_principal_right_nonpos
    (q r : QBOMA) (hr : qLE r qZero) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut q) (principalCut r))
      (principalCut qZero) := by
  exact cutEquiv_trans
    (cutMulNonnegEnvelope_comm (principalCut q) (principalCut r))
    (cutMulNonnegEnvelope_principal_left_nonpos r q hr)

/-- Quotient form of left nonpositive annihilation on rational inputs. -/
theorem rMulNonnegEnvelope_rOfQ_left_nonpos
    (q r : QBOMA) (hq : qLE q qZero) :
    rMulNonnegEnvelope (rOfQ q) (rOfQ r) = rZero := by
  change
    rmk (cutMulNonnegEnvelope (principalCut q) (principalCut r)) =
    rmk (principalCut qZero)
  exact rmk_sound (cutMulNonnegEnvelope_principal_left_nonpos q r hq)

/-- Quotient form of right nonpositive annihilation on rational inputs. -/
theorem rMulNonnegEnvelope_rOfQ_right_nonpos
    (q r : QBOMA) (hr : qLE r qZero) :
    rMulNonnegEnvelope (rOfQ q) (rOfQ r) = rZero := by
  change
    rmk (cutMulNonnegEnvelope (principalCut q) (principalCut r)) =
    rmk (principalCut qZero)
  exact rmk_sound (cutMulNonnegEnvelope_principal_right_nonpos q r hr)

/-- Negation sends nonnegative rationals to nonpositive rationals. -/
theorem qneg_nonpos_of_nonneg {q : QBOMA} (hq : qLE qZero q) :
    qLE (qNeg q) qZero := by
  have h := qneg_reverses hq
  rw [qNeg_zero] at h
  exact h

/-- Negation sends nonpositive rationals to nonnegative rationals. -/
theorem qneg_nonneg_of_nonpos {q : QBOMA} (hq : qLE q qZero) :
    qLE qZero (qNeg q) := by
  have h := qneg_reverses hq
  rw [qNeg_zero] at h
  exact h

/-- Multiplying a negated left factor negates the rational product. -/
theorem qMul_neg_left (q r : QBOMA) :
    qMul (qNeg q) r = qNeg (qMul q r) := by
  apply qAdd_inverse_unique
  calc
    qAdd (qMul q r) (qMul (qNeg q) r) =
        qMul (qAdd q (qNeg q)) r := (qMul_add_left q (qNeg q) r).symm
    _ = qMul qZero r := by rw [qAdd_neg_right]
    _ = qZero := qMul_zero_left r

/-- Multiplying a negated right factor negates the rational product. -/
theorem qMul_neg_right (q r : QBOMA) :
    qMul q (qNeg r) = qNeg (qMul q r) := by
  calc
    qMul q (qNeg r) = qMul (qNeg r) q := qMul_comm q (qNeg r)
    _ = qNeg (qMul r q) := qMul_neg_left r q
    _ = qNeg (qMul q r) := congrArg qNeg (qMul_comm r q)

/-- Product of two rational negatives is the original product. -/
theorem qMul_neg_neg (q r : QBOMA) :
    qMul (qNeg q) (qNeg r) = qMul q r := by
  calc
    qMul (qNeg q) (qNeg r) = qNeg (qMul q (qNeg r)) :=
      qMul_neg_left q (qNeg r)
    _ = qNeg (qNeg (qMul q r)) := congrArg qNeg (qMul_neg_right q r)
    _ = qMul q r := qNeg_involutive (qMul q r)

/-- Zero is fixed by formal real negation. -/
@[simp] theorem rNeg_zero : rNeg rZero = rZero := by
  symm
  exact rAdd_inverse_unique
    (x := rZero)
    (y := rZero)
    (rAdd_zero_left rZero)

/-- Candidate A: signed multiplication obtained by bilinear positive/negative-part expansion.
`rMulNonnegEnvelope` internally applies positive envelopes to its inputs.
No proposition-valued sign decision occurs in this definition. -/
def rMulCandidate (x y : RBOMA) : RBOMA :=
  rAdd
    (rAdd
      (rMulNonnegEnvelope x y)
      (rMulNonnegEnvelope (rNeg x) (rNeg y)))
    (rNeg
      (rAdd
        (rMulNonnegEnvelope x (rNeg y))
        (rMulNonnegEnvelope (rNeg x) y)))

/-- Candidate A preserves accepted rational multiplication for all rational signs.
Sign splitting is confined to this proof; the operation definition itself is sign-case-free. -/
theorem rMulCandidate_rOfQ (q r : QBOMA) :
    rMulCandidate (rOfQ q) (rOfQ r) = rOfQ (qMul q r) := by
  rcases qle_total qZero q with hqNonNeg | hqNonPos
  · rcases qle_total qZero r with hrNonNeg | hrNonPos
    · have hnq : qLE (qNeg q) qZero := qneg_nonpos_of_nonneg hqNonNeg
      have hnr : qLE (qNeg r) qZero := qneg_nonpos_of_nonneg hrNonNeg
      have hPP := rMulNonnegEnvelope_rOfQ q r hqNonNeg hrNonNeg
      have hNN := rMulNonnegEnvelope_rOfQ_left_nonpos (qNeg q) (qNeg r) hnq
      have hPN := rMulNonnegEnvelope_rOfQ_right_nonpos q (qNeg r) hnr
      have hNP := rMulNonnegEnvelope_rOfQ_left_nonpos (qNeg q) r hnq
      unfold rMulCandidate
      rw [rOfQ_neg q, rOfQ_neg r, hPP, hNN, hPN, hNP]
      rw [rAdd_zero_right, rAdd_zero_left, rNeg_zero, rAdd_zero_right]
    · have hnq : qLE (qNeg q) qZero := qneg_nonpos_of_nonneg hqNonNeg
      have hnr : qLE qZero (qNeg r) := qneg_nonneg_of_nonpos hrNonPos
      have hPP := rMulNonnegEnvelope_rOfQ_right_nonpos q r hrNonPos
      have hNN := rMulNonnegEnvelope_rOfQ_left_nonpos (qNeg q) (qNeg r) hnq
      have hPN := rMulNonnegEnvelope_rOfQ q (qNeg r) hqNonNeg hnr
      have hNP := rMulNonnegEnvelope_rOfQ_left_nonpos (qNeg q) r hnq
      unfold rMulCandidate
      rw [rOfQ_neg q, rOfQ_neg r, hPP, hNN, hPN, hNP]
      rw [rAdd_zero_left, rAdd_zero_right]
      rw [rOfQ_neg]
      rw [rAdd_zero_left]
      apply congrArg rOfQ
      calc
        qNeg (qMul q (qNeg r)) = qNeg (qNeg (qMul q r)) :=
          congrArg qNeg (qMul_neg_right q r)
        _ = qMul q r := qNeg_involutive _
  · rcases qle_total qZero r with hrNonNeg | hrNonPos
    · have hnq : qLE qZero (qNeg q) := qneg_nonneg_of_nonpos hqNonPos
      have hnr : qLE (qNeg r) qZero := qneg_nonpos_of_nonneg hrNonNeg
      have hPP := rMulNonnegEnvelope_rOfQ_left_nonpos q r hqNonPos
      have hNN := rMulNonnegEnvelope_rOfQ_right_nonpos (qNeg q) (qNeg r) hnr
      have hPN := rMulNonnegEnvelope_rOfQ_left_nonpos q (qNeg r) hqNonPos
      have hNP := rMulNonnegEnvelope_rOfQ (qNeg q) r hnq hrNonNeg
      unfold rMulCandidate
      rw [rOfQ_neg q, rOfQ_neg r, hPP, hNN, hPN, hNP]
      rw [rAdd_zero_left, rAdd_zero_left]
      rw [rAdd_zero_left]
      rw [rOfQ_neg]
      apply congrArg rOfQ
      calc
        qNeg (qMul (qNeg q) r) = qNeg (qNeg (qMul q r)) :=
          congrArg qNeg (qMul_neg_left q r)
        _ = qMul q r := qNeg_involutive _
    · have hnq : qLE qZero (qNeg q) := qneg_nonneg_of_nonpos hqNonPos
      have hnr : qLE qZero (qNeg r) := qneg_nonneg_of_nonpos hrNonPos
      have hPP := rMulNonnegEnvelope_rOfQ_left_nonpos q r hqNonPos
      have hNN := rMulNonnegEnvelope_rOfQ (qNeg q) (qNeg r) hnq hnr
      have hPN := rMulNonnegEnvelope_rOfQ_left_nonpos q (qNeg r) hqNonPos
      have hNP := rMulNonnegEnvelope_rOfQ_right_nonpos (qNeg q) r hrNonPos
      unfold rMulCandidate
      rw [rOfQ_neg q, rOfQ_neg r, hPP, hNN, hPN, hNP]
      rw [rAdd_zero_left, rAdd_zero_right, rNeg_zero, rAdd_zero_right]
      apply congrArg rOfQ
      exact qMul_neg_neg q r

end BOMA.R.DedekindSignedMulCandidate001

/- Algebraic laws for the nonnegative-envelope Dedekind multiplication kernel.
These laws are proved before lifting the selected signed multiplication candidate. -/
namespace BOMA.R.DedekindNonnegativeMulLaws001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- The principal zero cut is included in every nonnegative multiplication kernel. -/
theorem cutZero_le_mulNonneg (A B : LowerCut) :
    CutLE (principalCut qZero) (cutMulNonnegEnvelope A B) := by
  intro q hq
  exact Or.inl hq

/-- A nonnegative multiplication kernel is already fixed by positive-envelope closure. -/
theorem cutPosPart_mulNonneg (A B : LowerCut) :
    CutEquiv
      (cutPosPart (cutMulNonnegEnvelope A B))
      (cutMulNonnegEnvelope A B) :=
  cutPosPart_of_nonneg (cutZero_le_mulNonneg A B)

/-- Zero annihilates the nonnegative kernel on the left. -/
theorem cutMulNonnegEnvelope_zero_left (A : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut qZero) A)
      (principalCut qZero) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact hqNeg
    · rcases hqProd with ⟨a, _b, ha, _hb, h0a, _h0b, _hq⟩
      have haNeg : qLT a qZero := by
        rcases ha with ha0 | ha0
        · exact ha0
        · exact ha0
      exact False.elim ((qlt_asymm h0a) haNeg)
  · intro hq
    exact Or.inl hq

/-- Zero annihilates the nonnegative kernel on the right. -/
theorem cutMulNonnegEnvelope_zero_right (A : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope A (principalCut qZero))
      (principalCut qZero) :=
  cutEquiv_trans
    (cutMulNonnegEnvelope_comm A (principalCut qZero))
    (cutMulNonnegEnvelope_zero_left A)

@[simp] theorem rMulNonnegEnvelope_zero_left (x : RBOMA) :
    rMulNonnegEnvelope rZero x = rZero := by
  refine Quotient.inductionOn x ?_
  intro A
  change
    rmk (cutMulNonnegEnvelope (principalCut qZero) A) =
    rmk (principalCut qZero)
  exact rmk_sound (cutMulNonnegEnvelope_zero_left A)

@[simp] theorem rMulNonnegEnvelope_zero_right (x : RBOMA) :
    rMulNonnegEnvelope x rZero = rZero := by
  rw [rMulNonnegEnvelope_comm]
  exact rMulNonnegEnvelope_zero_left x

/-- A rational is either strictly negative or nonnegative. This packages the
sign split needed only inside proof logic, not in the multiplication definition. -/
theorem qlt_zero_or_nonneg (q : QBOMA) :
    qLT q qZero ∨ qLE qZero q := by
  rcases qlt_trichotomy q qZero with hneg | heq | hpos
  · exact Or.inl hneg
  · right
    rw [heq]
    exact qle_refl qZero
  · exact Or.inr hpos.1

/-- Multiplying the principal one cut by an arbitrary input returns the
positive envelope of that input. This is the correct unit law for the
nonnegative kernel before the signed decomposition is reassembled. -/
theorem cutMulNonnegEnvelope_one_left (A : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut qOne) A)
      (cutPosPart A) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact Or.inr hqNeg
    · rcases hqProd with ⟨a, b, ha, hb, h0a, h0b, hqab⟩
      have ha1 : qLT a qOne := by
        rcases ha with ha1 | ha0
        · exact ha1
        · exact qlt_trans ha0 qzero_lt_one
      have hab_b : qLT (qMul a b) b := by
        have ht := qmul_lt_right_positive ha1 h0b
        rw [qMul_one_left] at ht
        exact ht
      have hqb : qLT q b := qlt_trans hqab hab_b
      exact (cutPosPart A).downward hb hqb.1
  · intro hq
    rcases qlt_zero_or_nonneg q with hqNeg | h0q
    · exact Or.inl hqNeg
    · rcases (cutPosPart A).rounded hq with ⟨b, hb, hqb⟩
      have h0b : qLT qZero b := qlt_zero_of_nonneg_lt h0q hqb
      have hq1b : qLT q (qMul qOne b) := by
        rw [qMul_one_left]
        exact hqb
      rcases q_positive_product_inner_approx h0q h0b hq1b with
        ⟨a, b', h0a, ha1, h0b', hb'b, hqab'⟩
      have ha : (cutPosPart (principalCut qOne)).lower a :=
        Or.inl ha1
      have hb' : (cutPosPart A).lower b' :=
        (cutPosPart A).downward hb hb'b.1
      exact Or.inr ⟨a, b', ha, hb', h0a, h0b', hqab'⟩

/-- Right one law for the nonnegative kernel. -/
theorem cutMulNonnegEnvelope_one_right (A : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope A (principalCut qOne))
      (cutPosPart A) :=
  cutEquiv_trans
    (cutMulNonnegEnvelope_comm A (principalCut qOne))
    (cutMulNonnegEnvelope_one_left A)

theorem rMulNonnegEnvelope_one_left (x : RBOMA) :
    rMulNonnegEnvelope rOne x = rPosPart x := by
  refine Quotient.inductionOn x ?_
  intro A
  change
    rmk (cutMulNonnegEnvelope (principalCut qOne) A) =
    rmk (cutPosPart A)
  exact rmk_sound (cutMulNonnegEnvelope_one_left A)

theorem rMulNonnegEnvelope_one_right (x : RBOMA) :
    rMulNonnegEnvelope x rOne = rPosPart x := by
  rw [rMulNonnegEnvelope_comm]
  exact rMulNonnegEnvelope_one_left x

/-- Associativity of the nonnegative-envelope kernel.
The strict witness semantics requires a fresh interior witness when reassociating;
that witness is supplied by the previously certified Q multiplicative-approximation interface. -/
theorem cutMulNonnegEnvelope_assoc (A B C : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope (cutMulNonnegEnvelope A B) C)
      (cutMulNonnegEnvelope A (cutMulNonnegEnvelope B C)) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact Or.inl hqNeg
    · rcases hqProd with ⟨u, c, huPosPart, hc, h0u, h0c, hquc⟩
      have huK : (cutMulNonnegEnvelope A B).lower u :=
        ((cutPosPart_mulNonneg A B) u).mp huPosPart
      rcases huK with huNeg | huProd
      · exact False.elim ((qlt_asymm h0u) huNeg)
      · rcases huProd with ⟨a, b, ha, hb, h0a, h0b, huab⟩
        have huc_abc : qLT (qMul u c) (qMul (qMul a b) c) :=
          qmul_lt_right_positive huab h0c
        have hq_abc0 : qLT q (qMul (qMul a b) c) :=
          qlt_trans hquc huc_abc
        have hq_abc : qLT q (qMul a (qMul b c)) := by
          rw [← qMul_assoc a b c]
          exact hq_abc0
        rcases qlt_zero_or_nonneg q with hq0 | h0q
        · exact Or.inl hq0
        · have hbcPos : qLT qZero (qMul b c) := by
            have ht := qmul_lt_right_positive h0b h0c
            rw [qMul_zero_left] at ht
            exact ht
          rcases q_positive_product_inner_approx h0q hbcPos hq_abc with
            ⟨a', w, h0a', ha'a, h0w, hwbc, hqaw⟩
          have ha' : (cutPosPart A).lower a' :=
            (cutPosPart A).downward ha ha'a.1
          have hwK : (cutMulNonnegEnvelope B C).lower w :=
            Or.inr ⟨b, c, hb, hc, h0b, h0c, hwbc⟩
          have hwPosPart :
              (cutPosPart (cutMulNonnegEnvelope B C)).lower w :=
            Or.inl hwK
          exact Or.inr ⟨a', w, ha', hwPosPart, h0a', h0w, hqaw⟩
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact Or.inl hqNeg
    · rcases hqProd with ⟨a, v, ha, hvPosPart, h0a, h0v, hqav⟩
      have hvK : (cutMulNonnegEnvelope B C).lower v :=
        ((cutPosPart_mulNonneg B C) v).mp hvPosPart
      rcases hvK with hvNeg | hvProd
      · exact False.elim ((qlt_asymm h0v) hvNeg)
      · rcases hvProd with ⟨b, c, hb, hc, h0b, h0c, hvbc⟩
        have hav_abc : qLT (qMul a v) (qMul a (qMul b c)) :=
          qmul_lt_left_positive hvbc h0a
        have hq_abc0 : qLT q (qMul a (qMul b c)) :=
          qlt_trans hqav hav_abc
        have hq_abc : qLT q (qMul (qMul a b) c) := by
          rw [qMul_assoc a b c]
          exact hq_abc0
        rcases qlt_zero_or_nonneg q with hq0 | h0q
        · exact Or.inl hq0
        · rcases q_positive_product_inner_approx h0q h0c hq_abc with
            ⟨u, c', h0u, huab, h0c', hc'c, hquc'⟩
          have huK : (cutMulNonnegEnvelope A B).lower u :=
            Or.inr ⟨a, b, ha, hb, h0a, h0b, huab⟩
          have huPosPart :
              (cutPosPart (cutMulNonnegEnvelope A B)).lower u :=
            Or.inl huK
          have hc' : (cutPosPart C).lower c' :=
            (cutPosPart C).downward hc hc'c.1
          exact Or.inr ⟨u, c', huPosPart, hc', h0u, h0c', hquc'⟩

/-- Quotient associativity of the nonnegative multiplication kernel. -/
theorem rMulNonnegEnvelope_assoc (x y z : RBOMA) :
    rMulNonnegEnvelope (rMulNonnegEnvelope x y) z =
    rMulNonnegEnvelope x (rMulNonnegEnvelope y z) := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  refine Quotient.inductionOn z ?_
  intro C
  change
    rmk (cutMulNonnegEnvelope (cutMulNonnegEnvelope A B) C) =
    rmk (cutMulNonnegEnvelope A (cutMulNonnegEnvelope B C))
  exact rmk_sound (cutMulNonnegEnvelope_assoc A B C)

end BOMA.R.DedekindNonnegativeMulLaws001

/- Distributivity of the nonnegative-envelope multiplication kernel over
addition on nonnegative right inputs. -/
namespace BOMA.R.DedekindNonnegativeMulDistributivity001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionEmbedding001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulLaws001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- Strict addition monotonicity in both arguments. -/
theorem qadd_lt_mono {a a' b b' : QBOMA}
    (ha : qLT a a') (hb : qLT b b') :
    qLT (qAdd a b) (qAdd a' b') := by
  have h1 : qLT (qAdd a b) (qAdd a' b) := qlt_add_right ha b
  have h2raw : qLT (qAdd b a') (qAdd b' a') := qlt_add_right hb a'
  have h2 : qLT (qAdd a' b) (qAdd a' b') := by
    rw [qAdd_comm a' b, qAdd_comm a' b']
    exact h2raw
  exact qlt_trans h1 h2

/-- Any strict inequality below a sum admits two strictly interior summands. -/
theorem q_sum_inner_approx {q u v : QBOMA}
    (h : qLT q (qAdd u v)) :
    ∃ u' v' : QBOMA,
      qLT u' u ∧ qLT v' v ∧ qLT q (qAdd u' v') := by
  have hqu : qLT (qAdd q (qNeg v)) u := qlt_sub_right_of_lt_add h
  rcases rational_order_dense hqu with ⟨u', hqvu, hu'u⟩
  have hquv : qLT q (qAdd u' v) := qlt_add_back_right hqvu
  have hqv : qLT (qAdd q (qNeg u')) v := qlt_sub_left_of_lt_add hquv
  rcases rational_order_dense hqv with ⟨v', hqu'v, hv'v⟩
  have hsum : qLT q (qAdd u' v') := qlt_add_back_left hqu'v
  exact ⟨u', v', hu'u, hv'v, hsum⟩

/-- If the left summand cut contains zero, adding it contains the right cut. -/
theorem cut_le_add_of_zero_le_left
    (B C : LowerCut)
    (h0B : CutLE (principalCut qZero) B) :
    CutLE C (cutAdd B C) := by
  intro q hqC
  rcases C.rounded hqC with ⟨c, hcC, hqc⟩
  have hdiff0 : qLT (qAdd q (qNeg c)) qZero := by
    have ht := qlt_add_right hqc (qNeg c)
    rw [qAdd_neg_right] at ht
    exact ht
  rcases rational_order_dense hdiff0 with ⟨b, hdiffb, hb0⟩
  have hbB : B.lower b := h0B b hb0
  have hqbc : qLT q (qAdd b c) := qlt_add_back_right hdiffb
  exact ⟨b, c, hbB, hcC, hqbc⟩

/-- If the right summand cut contains zero, adding it contains the left cut. -/
theorem cut_le_add_of_zero_le_right
    (B C : LowerCut)
    (h0C : CutLE (principalCut qZero) C) :
    CutLE B (cutAdd B C) := by
  intro q hqB
  have hqCB : (cutAdd C B).lower q :=
    cut_le_add_of_zero_le_left C B h0C q hqB
  exact (cutAdd_comm_equiv C B q).mp hqCB

/-- Sum of two nonnegative cuts is nonnegative. -/
theorem cutAdd_nonneg
    (B C : LowerCut)
    (h0B : CutLE (principalCut qZero) B)
    (h0C : CutLE (principalCut qZero) C) :
    CutLE (principalCut qZero) (cutAdd B C) :=
  cutLE_trans h0B (cut_le_add_of_zero_le_right B C h0C)

/-- Any rational strictly below a positive-factor product belongs to the kernel;
if the second factor is nonpositive the rational is automatically negative,
and if it is positive the explicit product witness is used. -/
theorem below_product_mem_kernel
    {A B : LowerCut} {a b t : QBOMA}
    (ha : (cutPosPart A).lower a)
    (hb : (cutPosPart B).lower b)
    (h0a : qLT qZero a)
    (ht : qLT t (qMul a b)) :
    (cutMulNonnegEnvelope A B).lower t := by
  rcases qlt_trichotomy b qZero with hb0 | hbeq | h0b
  · have hp0 : qLE (qMul a b) qZero := by
      have hm := qmul_mono_left_nonneg hb0.1 h0a.1
      rw [qMul_zero_right] at hm
      exact hm
    exact Or.inl (qlt_le_trans ht hp0)
  · have ht0 : qLT t qZero := by
      rw [hbeq, qMul_zero_right] at ht
      exact ht
    exact Or.inl ht0
  · exact Or.inr ⟨a, b, ha, hb, h0a, h0b, ht⟩

/-- A sum of two strict negatives is strict negative. -/
theorem qadd_lt_zero_of_neg {u v : QBOMA}
    (hu : qLT u qZero) (hv : qLT v qZero) :
    qLT (qAdd u v) qZero := by
  have h := qadd_lt_mono hu hv
  rw [qAdd_zero_left] at h
  exact h

/-- A sum of two positive rationals is positive. -/
theorem qzero_lt_add_of_pos {u v : QBOMA}
    (hu : qLT qZero u) (hv : qLT qZero v) :
    qLT qZero (qAdd u v) := by
  have h := qadd_lt_mono hu hv
  rw [qAdd_zero_left] at h
  exact h

/-- A positive sum witness b+c actually belongs to B+C when b∈B and c∈C,
using roundedness to create the strict witness required by cutAdd. -/
theorem sum_member_cutAdd
    {B C : LowerCut} {b c : QBOMA}
    (hb : B.lower b) (hc : C.lower c) :
    (cutAdd B C).lower (qAdd b c) := by
  rcases B.rounded hb with ⟨b', hb'B, hbb'⟩
  rcases C.rounded hc with ⟨c', hc'C, hcc'⟩
  have hsum : qLT (qAdd b c) (qAdd b' c') := qadd_lt_mono hbb' hcc'
  exact ⟨b', c', hb'B, hc'C, hsum⟩

/-- Distributivity of the nonnegative-envelope kernel in the right input,
provided both summand cuts are nonnegative. -/
theorem cutMulNonnegEnvelope_add_right_of_nonneg
    (A B C : LowerCut)
    (h0B : CutLE (principalCut qZero) B)
    (h0C : CutLE (principalCut qZero) C) :
    CutEquiv
      (cutMulNonnegEnvelope A (cutAdd B C))
      (cutAdd (cutMulNonnegEnvelope A B) (cutMulNonnegEnvelope A C)) := by
  have hBC0 : CutLE (principalCut qZero) (cutAdd B C) :=
    cutAdd_nonneg B C h0B h0C
  have hBpos : CutEquiv (cutPosPart B) B := cutPosPart_of_nonneg h0B
  have hCpos : CutEquiv (cutPosPart C) C := cutPosPart_of_nonneg h0C
  have hBCpos : CutEquiv (cutPosPart (cutAdd B C)) (cutAdd B C) :=
    cutPosPart_of_nonneg hBC0
  have hRHS0 :
      CutLE (principalCut qZero)
        (cutAdd (cutMulNonnegEnvelope A B) (cutMulNonnegEnvelope A C)) :=
    cutAdd_nonneg
      (cutMulNonnegEnvelope A B)
      (cutMulNonnegEnvelope A C)
      (cutZero_le_mulNonneg A B)
      (cutZero_le_mulNonneg A C)
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact hRHS0 q hqNeg
    · rcases hqProd with ⟨a, d, ha, hdPos, h0a, h0d, hqad⟩
      have hd : (cutAdd B C).lower d := (hBCpos d).mp hdPos
      rcases hd with ⟨b, c, hb, hc, hdbc⟩
      have hadsum : qLT (qMul a d) (qAdd (qMul a b) (qMul a c)) := by
        have hm := qmul_lt_left_positive hdbc h0a
        rw [qMul_add_right] at hm
        exact hm
      have hqsum : qLT q (qAdd (qMul a b) (qMul a c)) :=
        qlt_trans hqad hadsum
      rcases q_sum_inner_approx hqsum with ⟨u, v, hu, hv, hquv⟩
      have huK : (cutMulNonnegEnvelope A B).lower u :=
        below_product_mem_kernel ha (Or.inl hb) h0a hu
      have hvK : (cutMulNonnegEnvelope A C).lower v :=
        below_product_mem_kernel ha (Or.inl hc) h0a hv
      exact ⟨u, v, huK, hvK, hquv⟩
  · intro hq
    rcases hq with ⟨u, v, huK, hvK, hquv⟩
    rcases huK with huNeg | huProd
    · rcases hvK with hvNeg | hvProd
      · have huv0 : qLT (qAdd u v) qZero := qadd_lt_zero_of_neg huNeg hvNeg
        exact Or.inl (qlt_trans hquv huv0)
      · rcases hvProd with ⟨a, c, ha, hcPos, h0a, h0c, hvac⟩
        have hcC : C.lower c := (hCpos c).mp hcPos
        have hcBC : (cutAdd B C).lower c :=
          cut_le_add_of_zero_le_left B C h0B c hcC
        have huv_v : qLT (qAdd u v) v := by
          have ht := qlt_add_right huNeg v
          rw [qAdd_zero_left] at ht
          exact ht
        have hqac : qLT q (qMul a c) :=
          qlt_trans hquv (qlt_trans huv_v hvac)
        exact Or.inr ⟨a, c, ha, Or.inl hcBC, h0a, h0c, hqac⟩
    · rcases huProd with ⟨a1, b, ha1, hbPos, h0a1, h0b, huab⟩
      rcases hvK with hvNeg | hvProd
      · have hbB : B.lower b := (hBpos b).mp hbPos
        have hbBC : (cutAdd B C).lower b :=
          cut_le_add_of_zero_le_right B C h0C b hbB
        have huv_u : qLT (qAdd u v) u := by
          have ht := qlt_add_right hvNeg u
          rw [qAdd_zero_left, qAdd_comm v u] at ht
          exact ht
        have hqab : qLT q (qMul a1 b) :=
          qlt_trans hquv (qlt_trans huv_u huab)
        exact Or.inr ⟨a1, b, ha1, Or.inl hbBC, h0a1, h0b, hqab⟩
      · rcases hvProd with ⟨a2, c, ha2, hcPos, h0a2, h0c, hvac⟩
        have hbB : B.lower b := (hBpos b).mp hbPos
        have hcC : C.lower c := (hCpos c).mp hcPos
        rcases qle_total a1 a2 with h12 | h21
        · rcases (cutPosPart A).rounded ha2 with ⟨a, ha, ha2a⟩
          have ha1a : qLT a1 a := qle_lt_trans h12 ha2a
          have h0a : qLT qZero a := qlt_trans h0a1 ha1a
          have huab' : qLT u (qMul a b) :=
            qlt_trans huab (qmul_lt_right_positive ha1a h0b)
          have hvac' : qLT v (qMul a c) :=
            qlt_trans hvac (qmul_lt_right_positive ha2a h0c)
          have hquv' : qLT q (qAdd (qMul a b) (qMul a c)) :=
            qlt_trans hquv (qadd_lt_mono huab' hvac')
          have hqprod : qLT q (qMul a (qAdd b c)) := by
            rw [qMul_add_right]
            exact hquv'
          have hbc : (cutAdd B C).lower (qAdd b c) :=
            sum_member_cutAdd hbB hcC
          have h0bc : qLT qZero (qAdd b c) := qzero_lt_add_of_pos h0b h0c
          exact Or.inr ⟨a, qAdd b c, ha, Or.inl hbc, h0a, h0bc, hqprod⟩
        · rcases (cutPosPart A).rounded ha1 with ⟨a, ha, ha1a⟩
          have ha2a : qLT a2 a := qle_lt_trans h21 ha1a
          have h0a : qLT qZero a := qlt_trans h0a2 ha2a
          have huab' : qLT u (qMul a b) :=
            qlt_trans huab (qmul_lt_right_positive ha1a h0b)
          have hvac' : qLT v (qMul a c) :=
            qlt_trans hvac (qmul_lt_right_positive ha2a h0c)
          have hquv' : qLT q (qAdd (qMul a b) (qMul a c)) :=
            qlt_trans hquv (qadd_lt_mono huab' hvac')
          have hqprod : qLT q (qMul a (qAdd b c)) := by
            rw [qMul_add_right]
            exact hquv'
          have hbc : (cutAdd B C).lower (qAdd b c) :=
            sum_member_cutAdd hbB hcC
          have h0bc : qLT qZero (qAdd b c) := qzero_lt_add_of_pos h0b h0c
          exact Or.inr ⟨a, qAdd b c, ha, Or.inl hbc, h0a, h0bc, hqprod⟩

/-- Quotient distributive interface on nonnegative right inputs. -/
theorem rMulNonnegEnvelope_add_right_of_nonneg
    (x y z : RBOMA)
    (h0y : rLE rZero y)
    (h0z : rLE rZero z) :
    rMulNonnegEnvelope x (rAdd y z) =
    rAdd (rMulNonnegEnvelope x y) (rMulNonnegEnvelope x z) := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_ h0y
  intro B h0B
  refine Quotient.inductionOn z ?_ h0z
  intro C h0C
  have hBcut : CutLE (principalCut qZero) B := by
    change rLE (rmk (principalCut qZero)) (rmk B) at h0B
    exact (rLE_mk_iff (principalCut qZero) B).1 h0B
  have hCcut : CutLE (principalCut qZero) C := by
    change rLE (rmk (principalCut qZero)) (rmk C) at h0C
    exact (rLE_mk_iff (principalCut qZero) C).1 h0C
  change
    rmk (cutMulNonnegEnvelope A (cutAdd B C)) =
    rmk (cutAdd (cutMulNonnegEnvelope A B) (cutMulNonnegEnvelope A C))
  exact rmk_sound (cutMulNonnegEnvelope_add_right_of_nonneg A B C hBcut hCcut)

end BOMA.R.DedekindNonnegativeMulDistributivity001

/- Basic laws for the selected sign-case-free signed Dedekind multiplication. -/
namespace BOMA.R.DedekindSignedMulBasicLaws001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulLaws001
open BOMA.R.DedekindSignedMulCandidate001

/-- The selected signed multiplication is commutative before any distributive law is used. -/
theorem rMulCandidate_comm (x y : RBOMA) :
    rMulCandidate x y = rMulCandidate y x := by
  unfold rMulCandidate
  have hPP : rMulNonnegEnvelope x y = rMulNonnegEnvelope y x :=
    rMulNonnegEnvelope_comm x y
  have hNN :
      rMulNonnegEnvelope (rNeg x) (rNeg y) =
      rMulNonnegEnvelope (rNeg y) (rNeg x) :=
    rMulNonnegEnvelope_comm (rNeg x) (rNeg y)
  have hPN :
      rMulNonnegEnvelope x (rNeg y) =
      rMulNonnegEnvelope (rNeg y) x :=
    rMulNonnegEnvelope_comm x (rNeg y)
  have hNP :
      rMulNonnegEnvelope (rNeg x) y =
      rMulNonnegEnvelope y (rNeg x) :=
    rMulNonnegEnvelope_comm (rNeg x) y
  rw [hPP, hNN, hPN, hNP]
  apply congrArg (fun t => rAdd (rAdd
    (rMulNonnegEnvelope y x)
    (rMulNonnegEnvelope (rNeg y) (rNeg x))) (rNeg t))
  exact rAdd_comm
    (rMulNonnegEnvelope (rNeg y) x)
    (rMulNonnegEnvelope y (rNeg x))

/-- Zero annihilates the selected signed multiplication on the left. -/
@[simp] theorem rMulCandidate_zero_left (x : RBOMA) :
    rMulCandidate rZero x = rZero := by
  unfold rMulCandidate
  rw [BOMA.R.DedekindSignedMulCandidate001.rNeg_zero]
  simp only [rMulNonnegEnvelope_zero_left, rAdd_zero_left,
    BOMA.R.DedekindSignedMulCandidate001.rNeg_zero]

/-- Zero annihilates the selected signed multiplication on the right. -/
@[simp] theorem rMulCandidate_zero_right (x : RBOMA) :
    rMulCandidate x rZero = rZero := by
  rw [rMulCandidate_comm]
  exact rMulCandidate_zero_left x

/-- A nonpositive principal rational factor annihilates the nonnegative kernel,
even when the second input is an arbitrary real representative. -/
theorem cutMulNonnegEnvelope_principal_nonpos_left
    (q : QBOMA) (A : LowerCut) (hq : qLE q qZero) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut q) A)
      (principalCut qZero) := by
  intro t
  constructor
  · intro ht
    rcases ht with htNeg | htProd
    · exact htNeg
    · rcases htProd with ⟨a, _b, ha, _hb, h0a, _h0b, _ht⟩
      have ha0 : qLT a qZero :=
        ((cutPosPart_principal_nonpos hq) a).mp ha
      exact False.elim ((qlt_asymm h0a) ha0)
  · intro ht0
    exact Or.inl ht0

/-- Quotient form of arbitrary-right annihilation by a nonpositive rational factor. -/
theorem rMulNonnegEnvelope_rOfQ_nonpos_left
    (q : QBOMA) (x : RBOMA) (hq : qLE q qZero) :
    rMulNonnegEnvelope (rOfQ q) x = rZero := by
  refine Quotient.inductionOn x ?_
  intro A
  change
    rmk (cutMulNonnegEnvelope (principalCut q) A) =
    rmk (principalCut qZero)
  exact rmk_sound (cutMulNonnegEnvelope_principal_nonpos_left q A hq)

/-- The nonnegative kernel sees the formal real -1 as zero on its left input. -/
theorem rMulNonnegEnvelope_negOne_left (x : RBOMA) :
    rMulNonnegEnvelope (rNeg rOne) x = rZero := by
  change rMulNonnegEnvelope (rNeg (rOfQ qOne)) x = rZero
  rw [rOfQ_neg qOne]
  apply rMulNonnegEnvelope_rOfQ_nonpos_left
  exact qneg_nonpos_of_nonneg qzero_le_one

/-- One is a left identity for the selected signed multiplication.
The kernel one law reduces the expression to x⁺-x⁻, then the separately
verified positive/negative decomposition theorem closes the proof. -/
theorem rMulCandidate_one_left (x : RBOMA) :
    rMulCandidate rOne x = x := by
  unfold rMulCandidate
  rw [rMulNonnegEnvelope_one_left x]
  rw [rMulNonnegEnvelope_negOne_left (rNeg x)]
  rw [rMulNonnegEnvelope_one_left (rNeg x)]
  rw [rMulNonnegEnvelope_negOne_left x]
  rw [rAdd_zero_right, rAdd_zero_right]
  change rAdd (rPosPart x) (rNeg (rNegPart x)) = x
  exact rPosNeg_decomposition x

/-- One is also a right identity by commutativity. -/
theorem rMulCandidate_one_right (x : RBOMA) :
    rMulCandidate x rOne = x := by
  rw [rMulCandidate_comm]
  exact rMulCandidate_one_left x

end BOMA.R.DedekindSignedMulBasicLaws001

/- Sign-quadrant simplifications for the selected signed Dedekind multiplication.
Sign comparison is proof-level; the operation definition remains sign-case-free. -/
namespace BOMA.R.DedekindSignedMulSignLaws001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulLaws001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001

/-- Any nonpositive real factor is annihilated by the nonnegative-envelope kernel. -/
theorem cutMulNonnegEnvelope_left_nonpos
    {A : LowerCut} (B : LowerCut)
    (hA0 : CutLE A (principalCut qZero)) :
    CutEquiv
      (cutMulNonnegEnvelope A B)
      (principalCut qZero) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact hqNeg
    · rcases hqProd with ⟨a, _b, ha, _hb, h0a, _h0b, _hqab⟩
      have ha0 : qLT a qZero :=
        ((cutPosPart_of_nonpos hA0) a).mp ha
      exact False.elim ((qlt_asymm h0a) ha0)
  · intro hq0
    exact Or.inl hq0

/-- Quotient-level left annihilation for an arbitrary nonpositive real. -/
theorem rMulNonnegEnvelope_left_nonpos
    {x : RBOMA} (y : RBOMA)
    (hx0 : rLE x rZero) :
    rMulNonnegEnvelope x y = rZero := by
  refine Quotient.inductionOn x ?_ hx0
  intro A hA0
  refine Quotient.inductionOn y ?_
  intro B
  change
    rmk (cutMulNonnegEnvelope A B) =
    rmk (principalCut qZero)
  apply rmk_sound
  apply cutMulNonnegEnvelope_left_nonpos B
  change rLE (rmk A) (rmk (principalCut qZero)) at hA0
  exact (rLE_mk_iff A (principalCut qZero)).1 hA0

/-- Right annihilation follows from kernel commutativity. -/
theorem rMulNonnegEnvelope_right_nonpos
    (x : RBOMA) {y : RBOMA}
    (hy0 : rLE y rZero) :
    rMulNonnegEnvelope x y = rZero := by
  rw [rMulNonnegEnvelope_comm]
  exact rMulNonnegEnvelope_left_nonpos x hy0

/-- If x is nonnegative, -x is kernel-nonpositive. -/
theorem rMulNonnegEnvelope_neg_left_of_nonneg
    {x : RBOMA} (y : RBOMA)
    (h0x : rLE rZero x) :
    rMulNonnegEnvelope (rNeg x) y = rZero :=
  rMulNonnegEnvelope_left_nonpos y (rNeg_nonpos_of_nonneg h0x)

/-- If y is nonnegative, -y is kernel-nonpositive on the right. -/
theorem rMulNonnegEnvelope_neg_right_of_nonneg
    (x : RBOMA) {y : RBOMA}
    (h0y : rLE rZero y) :
    rMulNonnegEnvelope x (rNeg y) = rZero :=
  rMulNonnegEnvelope_right_nonpos x (rNeg_nonpos_of_nonneg h0y)

/-- Positive-positive quadrant: signed multiplication is the nonnegative kernel. -/
theorem rMulCandidate_of_nonneg_nonneg
    {x y : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y) :
    rMulCandidate x y = rMulNonnegEnvelope x y := by
  unfold rMulCandidate
  rw [rMulNonnegEnvelope_neg_left_of_nonneg (rNeg y) h0x]
  rw [rMulNonnegEnvelope_neg_right_of_nonneg x h0y]
  rw [rMulNonnegEnvelope_neg_left_of_nonneg y h0x]
  rw [rAdd_zero_right, rAdd_zero_left,
      BOMA.R.DedekindSignedMulCandidate001.rNeg_zero, rAdd_zero_right]

/-- Positive-negative quadrant: signed multiplication is minus the kernel of x and -y. -/
theorem rMulCandidate_of_nonneg_nonpos
    {x y : RBOMA}
    (h0x : rLE rZero x)
    (hy0 : rLE y rZero) :
    rMulCandidate x y = rNeg (rMulNonnegEnvelope x (rNeg y)) := by
  unfold rMulCandidate
  rw [rMulNonnegEnvelope_right_nonpos x hy0]
  rw [rMulNonnegEnvelope_neg_left_of_nonneg (rNeg y) h0x]
  rw [rMulNonnegEnvelope_neg_left_of_nonneg y h0x]
  simp only [rAdd_zero_left, rAdd_zero_right]

/-- Negative-positive quadrant. -/
theorem rMulCandidate_of_nonpos_nonneg
    {x y : RBOMA}
    (hx0 : rLE x rZero)
    (h0y : rLE rZero y) :
    rMulCandidate x y = rNeg (rMulNonnegEnvelope (rNeg x) y) := by
  calc
    rMulCandidate x y = rMulCandidate y x := rMulCandidate_comm x y
    _ = rNeg (rMulNonnegEnvelope y (rNeg x)) :=
      rMulCandidate_of_nonneg_nonpos h0y hx0
    _ = rNeg (rMulNonnegEnvelope (rNeg x) y) := by
      rw [rMulNonnegEnvelope_comm]

/-- Negative-negative quadrant: signed multiplication is the kernel of the negated inputs. -/
theorem rMulCandidate_of_nonpos_nonpos
    {x y : RBOMA}
    (hx0 : rLE x rZero)
    (hy0 : rLE y rZero) :
    rMulCandidate x y = rMulNonnegEnvelope (rNeg x) (rNeg y) := by
  unfold rMulCandidate
  rw [rMulNonnegEnvelope_left_nonpos y hx0]
  rw [rMulNonnegEnvelope_left_nonpos (rNeg y) hx0]
  rw [rMulNonnegEnvelope_right_nonpos (rNeg x) hy0]
  rw [rAdd_zero_left, rAdd_zero_left,
      BOMA.R.DedekindSignedMulCandidate001.rNeg_zero, rAdd_zero_right]

end BOMA.R.DedekindSignedMulSignLaws001

/- Associativity of the selected signed Dedekind multiplication.
The proof classifies signs with the isolated classical total-order witness and
reduces all eight quadrants to the certified nonnegative-kernel associativity. -/
namespace BOMA.R.DedekindSignedMulAssociativity001

open BOMA.Q.Quotient001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulLaws001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulSignLaws001

/-- Every nonnegative-envelope kernel value is nonnegative. -/
theorem rMulNonnegEnvelope_nonneg (x y : RBOMA) :
    rLE rZero (rMulNonnegEnvelope x y) := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  change
    rLE (rmk (principalCut qZero))
      (rmk (cutMulNonnegEnvelope A B))
  exact (rLE_mk_iff (principalCut qZero) (cutMulNonnegEnvelope A B)).2
    (cutZero_le_mulNonneg A B)

/-- Associativity of the selected signed multiplication. -/
theorem rMulCandidate_assoc (x y z : RBOMA) :
    rMulCandidate (rMulCandidate x y) z =
    rMulCandidate x (rMulCandidate y z) := by
  rcases rLE_total_classical rZero x with h0x | hx0
  · rcases rLE_total_classical rZero y with h0y | hy0
    · rcases rLE_total_classical rZero z with h0z | hz0
      · -- + + +
        have hxy := rMulCandidate_of_nonneg_nonneg h0x h0y
        have hyz := rMulCandidate_of_nonneg_nonneg h0y h0z
        have h0xy : rLE rZero (rMulCandidate x y) := by
          rw [hxy]
          exact rMulNonnegEnvelope_nonneg x y
        have h0yz : rLE rZero (rMulCandidate y z) := by
          rw [hyz]
          exact rMulNonnegEnvelope_nonneg y z
        calc
          rMulCandidate (rMulCandidate x y) z =
              rMulNonnegEnvelope (rMulCandidate x y) z :=
            rMulCandidate_of_nonneg_nonneg h0xy h0z
          _ = rMulNonnegEnvelope (rMulNonnegEnvelope x y) z := by rw [hxy]
          _ = rMulNonnegEnvelope x (rMulNonnegEnvelope y z) :=
            rMulNonnegEnvelope_assoc x y z
          _ = rMulNonnegEnvelope x (rMulCandidate y z) := by rw [hyz]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonneg_nonneg h0x h0yz).symm
      · -- + + -
        have hxy := rMulCandidate_of_nonneg_nonneg h0x h0y
        have hyz := rMulCandidate_of_nonneg_nonpos h0y hz0
        have h0xy : rLE rZero (rMulCandidate x y) := by
          rw [hxy]
          exact rMulNonnegEnvelope_nonneg x y
        have hyz0 : rLE (rMulCandidate y z) rZero := by
          rw [hyz]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg y (rNeg z))
        calc
          rMulCandidate (rMulCandidate x y) z =
              rNeg (rMulNonnegEnvelope (rMulCandidate x y) (rNeg z)) :=
            rMulCandidate_of_nonneg_nonpos h0xy hz0
          _ = rNeg (rMulNonnegEnvelope (rMulNonnegEnvelope x y) (rNeg z)) := by
            rw [hxy]
          _ = rNeg (rMulNonnegEnvelope x
                (rMulNonnegEnvelope y (rNeg z))) := by
            rw [rMulNonnegEnvelope_assoc]
          _ = rNeg (rMulNonnegEnvelope x (rNeg (rMulCandidate y z))) := by
            rw [hyz, rNeg_involutive]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonneg_nonpos h0x hyz0).symm
    · rcases rLE_total_classical rZero z with h0z | hz0
      · -- + - +
        have hxy := rMulCandidate_of_nonneg_nonpos h0x hy0
        have hyz := rMulCandidate_of_nonpos_nonneg hy0 h0z
        have hxy0 : rLE (rMulCandidate x y) rZero := by
          rw [hxy]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg x (rNeg y))
        have hyz0 : rLE (rMulCandidate y z) rZero := by
          rw [hyz]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg (rNeg y) z)
        calc
          rMulCandidate (rMulCandidate x y) z =
              rNeg (rMulNonnegEnvelope (rNeg (rMulCandidate x y)) z) :=
            rMulCandidate_of_nonpos_nonneg hxy0 h0z
          _ = rNeg (rMulNonnegEnvelope
                (rMulNonnegEnvelope x (rNeg y)) z) := by
            rw [hxy, rNeg_involutive]
          _ = rNeg (rMulNonnegEnvelope x
                (rMulNonnegEnvelope (rNeg y) z)) := by
            rw [rMulNonnegEnvelope_assoc]
          _ = rNeg (rMulNonnegEnvelope x (rNeg (rMulCandidate y z))) := by
            rw [hyz, rNeg_involutive]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonneg_nonpos h0x hyz0).symm
      · -- + - -
        have hxy := rMulCandidate_of_nonneg_nonpos h0x hy0
        have hyz := rMulCandidate_of_nonpos_nonpos hy0 hz0
        have hxy0 : rLE (rMulCandidate x y) rZero := by
          rw [hxy]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg x (rNeg y))
        have h0yz : rLE rZero (rMulCandidate y z) := by
          rw [hyz]
          exact rMulNonnegEnvelope_nonneg (rNeg y) (rNeg z)
        calc
          rMulCandidate (rMulCandidate x y) z =
              rMulNonnegEnvelope (rNeg (rMulCandidate x y)) (rNeg z) :=
            rMulCandidate_of_nonpos_nonpos hxy0 hz0
          _ = rMulNonnegEnvelope (rMulNonnegEnvelope x (rNeg y)) (rNeg z) := by
            rw [hxy, rNeg_involutive]
          _ = rMulNonnegEnvelope x
                (rMulNonnegEnvelope (rNeg y) (rNeg z)) :=
            rMulNonnegEnvelope_assoc x (rNeg y) (rNeg z)
          _ = rMulNonnegEnvelope x (rMulCandidate y z) := by rw [hyz]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonneg_nonneg h0x h0yz).symm
  · rcases rLE_total_classical rZero y with h0y | hy0
    · rcases rLE_total_classical rZero z with h0z | hz0
      · -- - + +
        have hxy := rMulCandidate_of_nonpos_nonneg hx0 h0y
        have hyz := rMulCandidate_of_nonneg_nonneg h0y h0z
        have hxy0 : rLE (rMulCandidate x y) rZero := by
          rw [hxy]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg (rNeg x) y)
        have h0yz : rLE rZero (rMulCandidate y z) := by
          rw [hyz]
          exact rMulNonnegEnvelope_nonneg y z
        calc
          rMulCandidate (rMulCandidate x y) z =
              rNeg (rMulNonnegEnvelope (rNeg (rMulCandidate x y)) z) :=
            rMulCandidate_of_nonpos_nonneg hxy0 h0z
          _ = rNeg (rMulNonnegEnvelope
                (rMulNonnegEnvelope (rNeg x) y) z) := by
            rw [hxy, rNeg_involutive]
          _ = rNeg (rMulNonnegEnvelope (rNeg x)
                (rMulNonnegEnvelope y z)) := by
            rw [rMulNonnegEnvelope_assoc]
          _ = rNeg (rMulNonnegEnvelope (rNeg x) (rMulCandidate y z)) := by
            rw [hyz]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonpos_nonneg hx0 h0yz).symm
      · -- - + -
        have hxy := rMulCandidate_of_nonpos_nonneg hx0 h0y
        have hyz := rMulCandidate_of_nonneg_nonpos h0y hz0
        have hxy0 : rLE (rMulCandidate x y) rZero := by
          rw [hxy]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg (rNeg x) y)
        have hyz0 : rLE (rMulCandidate y z) rZero := by
          rw [hyz]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg y (rNeg z))
        calc
          rMulCandidate (rMulCandidate x y) z =
              rMulNonnegEnvelope (rNeg (rMulCandidate x y)) (rNeg z) :=
            rMulCandidate_of_nonpos_nonpos hxy0 hz0
          _ = rMulNonnegEnvelope (rMulNonnegEnvelope (rNeg x) y) (rNeg z) := by
            rw [hxy, rNeg_involutive]
          _ = rMulNonnegEnvelope (rNeg x)
                (rMulNonnegEnvelope y (rNeg z)) :=
            rMulNonnegEnvelope_assoc (rNeg x) y (rNeg z)
          _ = rMulNonnegEnvelope (rNeg x) (rNeg (rMulCandidate y z)) := by
            rw [hyz, rNeg_involutive]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonpos_nonpos hx0 hyz0).symm
    · rcases rLE_total_classical rZero z with h0z | hz0
      · -- - - +
        have hxy := rMulCandidate_of_nonpos_nonpos hx0 hy0
        have hyz := rMulCandidate_of_nonpos_nonneg hy0 h0z
        have h0xy : rLE rZero (rMulCandidate x y) := by
          rw [hxy]
          exact rMulNonnegEnvelope_nonneg (rNeg x) (rNeg y)
        have hyz0 : rLE (rMulCandidate y z) rZero := by
          rw [hyz]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg (rNeg y) z)
        calc
          rMulCandidate (rMulCandidate x y) z =
              rMulNonnegEnvelope (rMulCandidate x y) z :=
            rMulCandidate_of_nonneg_nonneg h0xy h0z
          _ = rMulNonnegEnvelope
                (rMulNonnegEnvelope (rNeg x) (rNeg y)) z := by rw [hxy]
          _ = rMulNonnegEnvelope (rNeg x)
                (rMulNonnegEnvelope (rNeg y) z) :=
            rMulNonnegEnvelope_assoc (rNeg x) (rNeg y) z
          _ = rMulNonnegEnvelope (rNeg x) (rNeg (rMulCandidate y z)) := by
            rw [hyz, rNeg_involutive]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonpos_nonpos hx0 hyz0).symm
      · -- - - -
        have hxy := rMulCandidate_of_nonpos_nonpos hx0 hy0
        have hyz := rMulCandidate_of_nonpos_nonpos hy0 hz0
        have h0xy : rLE rZero (rMulCandidate x y) := by
          rw [hxy]
          exact rMulNonnegEnvelope_nonneg (rNeg x) (rNeg y)
        have h0yz : rLE rZero (rMulCandidate y z) := by
          rw [hyz]
          exact rMulNonnegEnvelope_nonneg (rNeg y) (rNeg z)
        calc
          rMulCandidate (rMulCandidate x y) z =
              rNeg (rMulNonnegEnvelope (rMulCandidate x y) (rNeg z)) :=
            rMulCandidate_of_nonneg_nonpos h0xy hz0
          _ = rNeg (rMulNonnegEnvelope
                (rMulNonnegEnvelope (rNeg x) (rNeg y)) (rNeg z)) := by rw [hxy]
          _ = rNeg (rMulNonnegEnvelope (rNeg x)
                (rMulNonnegEnvelope (rNeg y) (rNeg z))) := by
            rw [rMulNonnegEnvelope_assoc]
          _ = rNeg (rMulNonnegEnvelope (rNeg x) (rMulCandidate y z)) := by rw [hyz]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonpos_nonneg hx0 h0yz).symm

end BOMA.R.DedekindSignedMulAssociativity001

/- Distributivity of the selected signed Dedekind multiplication.
The proof reduces to the certified nonnegative-kernel distributivity plus
additive-group identities and localized sign classification. -/
namespace BOMA.R.DedekindSignedMulDistributivity001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindOrderAdditive001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindAdditiveDerived001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulDistributivity001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindSignedMulSignLaws001

/-- Distributivity for a nonnegative left factor and two nonnegative summands. -/
theorem rMulCandidate_add_right_nonneg_nonneg
    {x y z : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y)
    (h0z : rLE rZero z) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  have h0sum : rLE rZero (rAdd y z) := rAdd_nonneg h0y h0z
  calc
    rMulCandidate x (rAdd y z) =
        rMulNonnegEnvelope x (rAdd y z) :=
      rMulCandidate_of_nonneg_nonneg h0x h0sum
    _ = rAdd (rMulNonnegEnvelope x y) (rMulNonnegEnvelope x z) :=
      rMulNonnegEnvelope_add_right_of_nonneg x y z h0y h0z
    _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
      rw [rMulCandidate_of_nonneg_nonneg h0x h0y,
          rMulCandidate_of_nonneg_nonneg h0x h0z]

/-- Distributivity for a nonnegative left factor and two nonpositive summands. -/
theorem rMulCandidate_add_right_nonpos_nonpos
    {x y z : RBOMA}
    (h0x : rLE rZero x)
    (hy0 : rLE y rZero)
    (hz0 : rLE z rZero) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  have hsum0 : rLE (rAdd y z) rZero := rAdd_nonpos hy0 hz0
  have h0ny : rLE rZero (rNeg y) := rNeg_nonneg_of_nonpos hy0
  have h0nz : rLE rZero (rNeg z) := rNeg_nonneg_of_nonpos hz0
  calc
    rMulCandidate x (rAdd y z) =
        rNeg (rMulNonnegEnvelope x (rNeg (rAdd y z))) :=
      rMulCandidate_of_nonneg_nonpos h0x hsum0
    _ = rNeg (rMulNonnegEnvelope x (rAdd (rNeg y) (rNeg z))) := by
      rw [rNeg_add]
    _ = rNeg (rAdd
          (rMulNonnegEnvelope x (rNeg y))
          (rMulNonnegEnvelope x (rNeg z))) := by
      rw [rMulNonnegEnvelope_add_right_of_nonneg x (rNeg y) (rNeg z) h0ny h0nz]
    _ = rAdd
          (rNeg (rMulNonnegEnvelope x (rNeg y)))
          (rNeg (rMulNonnegEnvelope x (rNeg z))) :=
      rNeg_add _ _
    _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
      rw [rMulCandidate_of_nonneg_nonpos h0x hy0,
          rMulCandidate_of_nonneg_nonpos h0x hz0]

/-- Mixed-sign distributivity for nonnegative x, nonnegative y, nonpositive z. -/
theorem rMulCandidate_add_right_nonneg_nonpos
    {x y z : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y)
    (hz0 : rLE z rZero) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  have h0nz : rLE rZero (rNeg z) := rNeg_nonneg_of_nonpos hz0
  rcases rLE_total_classical rZero (rAdd y z) with h0sum | hsum0
  · -- y+z remains nonnegative: y=(y+z)+(-z)
    have hK := rMulNonnegEnvelope_add_right_of_nonneg
      x (rAdd y z) (rNeg z) h0sum h0nz
    rw [rAdd_sub_right y z] at hK
    have hsolve :
        rMulNonnegEnvelope x (rAdd y z) =
        rAdd (rMulNonnegEnvelope x y)
          (rNeg (rMulNonnegEnvelope x (rNeg z))) := by
      calc
        rMulNonnegEnvelope x (rAdd y z) =
            rAdd (rMulNonnegEnvelope x (rAdd y z)) rZero :=
          (rAdd_zero_right _).symm
        _ = rAdd (rMulNonnegEnvelope x (rAdd y z))
              (rAdd (rMulNonnegEnvelope x (rNeg z))
                (rNeg (rMulNonnegEnvelope x (rNeg z)))) := by
          exact congrArg
            (fun t => rAdd (rMulNonnegEnvelope x (rAdd y z)) t)
            (rAdd_neg_right (rMulNonnegEnvelope x (rNeg z))).symm
        _ = rAdd
              (rAdd (rMulNonnegEnvelope x (rAdd y z))
                (rMulNonnegEnvelope x (rNeg z)))
              (rNeg (rMulNonnegEnvelope x (rNeg z))) :=
          (rAdd_assoc _ _ _).symm
        _ = rAdd (rMulNonnegEnvelope x y)
              (rNeg (rMulNonnegEnvelope x (rNeg z))) := by
          rw [← hK]
    calc
      rMulCandidate x (rAdd y z) =
          rMulNonnegEnvelope x (rAdd y z) :=
        rMulCandidate_of_nonneg_nonneg h0x h0sum
      _ = rAdd (rMulNonnegEnvelope x y)
            (rNeg (rMulNonnegEnvelope x (rNeg z))) := hsolve
      _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
        rw [rMulCandidate_of_nonneg_nonneg h0x h0y,
            rMulCandidate_of_nonneg_nonpos h0x hz0]
  · -- y+z is nonpositive: -z = y + (-(y+z))
    have h0nsum : rLE rZero (rNeg (rAdd y z)) :=
      rNeg_nonneg_of_nonpos hsum0
    have hK := rMulNonnegEnvelope_add_right_of_nonneg
      x y (rNeg (rAdd y z)) h0y h0nsum
    rw [rAdd_neg_sum_cancel_left y z] at hK
    have hsolve :
        rNeg (rMulNonnegEnvelope x (rNeg (rAdd y z))) =
        rAdd (rMulNonnegEnvelope x y)
          (rNeg (rMulNonnegEnvelope x (rNeg z))) := by
      calc
        rNeg (rMulNonnegEnvelope x (rNeg (rAdd y z))) =
            rAdd (rMulNonnegEnvelope x y)
              (rNeg (rAdd
                (rMulNonnegEnvelope x y)
                (rMulNonnegEnvelope x (rNeg (rAdd y z))))) :=
          (rAdd_neg_sum_cancel_left
            (rMulNonnegEnvelope x y)
            (rMulNonnegEnvelope x (rNeg (rAdd y z)))).symm
        _ = rAdd (rMulNonnegEnvelope x y)
              (rNeg (rMulNonnegEnvelope x (rNeg z))) := by
          rw [← hK]
    calc
      rMulCandidate x (rAdd y z) =
          rNeg (rMulNonnegEnvelope x (rNeg (rAdd y z))) :=
        rMulCandidate_of_nonneg_nonpos h0x hsum0
      _ = rAdd (rMulNonnegEnvelope x y)
            (rNeg (rMulNonnegEnvelope x (rNeg z))) := hsolve
      _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
        rw [rMulCandidate_of_nonneg_nonneg h0x h0y,
            rMulCandidate_of_nonneg_nonpos h0x hz0]

/-- Full right distributivity for any nonnegative left factor. -/
theorem rMulCandidate_add_right_of_nonneg_left
    {x : RBOMA}
    (h0x : rLE rZero x)
    (y z : RBOMA) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  rcases rLE_total_classical rZero y with h0y | hy0
  · rcases rLE_total_classical rZero z with h0z | hz0
    · exact rMulCandidate_add_right_nonneg_nonneg h0x h0y h0z
    · exact rMulCandidate_add_right_nonneg_nonpos h0x h0y hz0
  · rcases rLE_total_classical rZero z with h0z | hz0
    · calc
        rMulCandidate x (rAdd y z) = rMulCandidate x (rAdd z y) := by
          rw [rAdd_comm y z]
        _ = rAdd (rMulCandidate x z) (rMulCandidate x y) :=
          rMulCandidate_add_right_nonneg_nonpos h0x h0z hy0
        _ = rAdd (rMulCandidate x y) (rMulCandidate x z) :=
          rAdd_comm _ _
    · exact rMulCandidate_add_right_nonpos_nonpos h0x hy0 hz0

/-- For a nonpositive left factor, multiplication equals the negative of
multiplication by its nonnegative opposite. -/
theorem rMulCandidate_nonpos_left_as_neg
    {x : RBOMA}
    (hx0 : rLE x rZero)
    (y : RBOMA) :
    rMulCandidate x y = rNeg (rMulCandidate (rNeg x) y) := by
  have h0nx : rLE rZero (rNeg x) := rNeg_nonneg_of_nonpos hx0
  rcases rLE_total_classical rZero y with h0y | hy0
  · calc
      rMulCandidate x y = rNeg (rMulNonnegEnvelope (rNeg x) y) :=
        rMulCandidate_of_nonpos_nonneg hx0 h0y
      _ = rNeg (rMulCandidate (rNeg x) y) := by
        rw [rMulCandidate_of_nonneg_nonneg h0nx h0y]
  · calc
      rMulCandidate x y = rMulNonnegEnvelope (rNeg x) (rNeg y) :=
        rMulCandidate_of_nonpos_nonpos hx0 hy0
      _ = rNeg (rNeg (rMulNonnegEnvelope (rNeg x) (rNeg y))) := by
        rw [rNeg_involutive]
      _ = rNeg (rMulCandidate (rNeg x) y) := by
        rw [rMulCandidate_of_nonneg_nonpos h0nx hy0]

/-- Full right distributivity for the selected signed multiplication. -/
theorem rMulCandidate_add_right (x y z : RBOMA) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  rcases rLE_total_classical rZero x with h0x | hx0
  · exact rMulCandidate_add_right_of_nonneg_left h0x y z
  · have h0nx : rLE rZero (rNeg x) := rNeg_nonneg_of_nonpos hx0
    have hd := rMulCandidate_add_right_of_nonneg_left h0nx y z
    have hsum := rMulCandidate_nonpos_left_as_neg hx0 (rAdd y z)
    have hy := rMulCandidate_nonpos_left_as_neg hx0 y
    have hz := rMulCandidate_nonpos_left_as_neg hx0 z
    calc
      rMulCandidate x (rAdd y z) =
          rNeg (rMulCandidate (rNeg x) (rAdd y z)) := hsum
      _ = rNeg (rAdd
            (rMulCandidate (rNeg x) y)
            (rMulCandidate (rNeg x) z)) := by rw [hd]
      _ = rAdd
            (rNeg (rMulCandidate (rNeg x) y))
            (rNeg (rMulCandidate (rNeg x) z)) :=
        rNeg_add _ _
      _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
        rw [← hy, ← hz]

/-- Left distributivity follows from multiplication commutativity. -/
theorem rMulCandidate_add_left (x y z : RBOMA) :
    rMulCandidate (rAdd x y) z =
    rAdd (rMulCandidate x z) (rMulCandidate y z) := by
  calc
    rMulCandidate (rAdd x y) z = rMulCandidate z (rAdd x y) :=
      rMulCandidate_comm _ _
    _ = rAdd (rMulCandidate z x) (rMulCandidate z y) :=
      rMulCandidate_add_right z x y
    _ = rAdd (rMulCandidate x z) (rMulCandidate y z) := by
      rw [rMulCandidate_comm z x, rMulCandidate_comm z y]

end BOMA.R.DedekindSignedMulDistributivity001

/- Ordered-ring compatibility for the selected Dedekind real operations.
This layer derives multiplication monotonicity from the additive difference
interface and the already-certified signed distributivity. -/
namespace BOMA.R.DedekindOrderedRing001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderAdditive001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindAdditiveDerived001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindSignedMulSignLaws001
open BOMA.R.DedekindSignedMulAssociativity001
open BOMA.R.DedekindSignedMulDistributivity001

/-- Real order is equivalent to nonnegativity of the additive difference y-x. -/
theorem rle_iff_nonneg_difference (x y : RBOMA) :
    rLE x y ↔ rLE rZero (rAdd y (rNeg x)) := by
  constructor
  · intro hxy
    have ht := rAdd_mono_right hxy (rNeg x)
    have hx0 : rAdd x (rNeg x) = rZero := rAdd_neg_right x
    rw [hx0] at ht
    exact ht
  · intro hdiff
    have ht := rAdd_mono_right hdiff x
    have hleft : rAdd rZero x = x := rAdd_zero_left x
    have hright : rAdd (rAdd y (rNeg x)) x = y := by
      calc
        rAdd (rAdd y (rNeg x)) x = rAdd y (rAdd (rNeg x) x) :=
          rAdd_assoc y (rNeg x) x
        _ = rAdd y rZero := by rw [rAdd_neg_left]
        _ = y := rAdd_zero_right y
    rw [hleft, hright] at ht
    exact ht

/-- The product of two nonnegative selected reals is nonnegative. -/
theorem rMulCandidate_nonneg
    {x y : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y) :
    rLE rZero (rMulCandidate x y) := by
  rw [rMulCandidate_of_nonneg_nonneg h0x h0y]
  exact rMulNonnegEnvelope_nonneg x y

/-- Multiplication of the additive inverse on the right is the additive inverse
of the product. This is derived from distributivity and inverse uniqueness. -/
theorem rMulCandidate_neg_right (x y : RBOMA) :
    rMulCandidate x (rNeg y) = rNeg (rMulCandidate x y) := by
  apply rAdd_inverse_unique (x := rMulCandidate x y)
  calc
    rAdd (rMulCandidate x y) (rMulCandidate x (rNeg y)) =
        rMulCandidate x (rAdd y (rNeg y)) :=
      (rMulCandidate_add_right x y (rNeg y)).symm
    _ = rMulCandidate x rZero := by rw [rAdd_neg_right]
    _ = rZero := rMulCandidate_zero_right x

/-- Left negation compatibility follows from multiplication commutativity. -/
theorem rMulCandidate_neg_left (x y : RBOMA) :
    rMulCandidate (rNeg x) y = rNeg (rMulCandidate x y) := by
  calc
    rMulCandidate (rNeg x) y = rMulCandidate y (rNeg x) :=
      rMulCandidate_comm _ _
    _ = rNeg (rMulCandidate y x) := rMulCandidate_neg_right y x
    _ = rNeg (rMulCandidate x y) :=
      congrArg rNeg (rMulCandidate_comm y x)

/-- A nonnegative left factor preserves formal real order. -/
theorem rMulCandidate_mono_left_nonneg
    {x y c : RBOMA}
    (hxy : rLE x y)
    (h0c : rLE rZero c) :
    rLE (rMulCandidate c x) (rMulCandidate c y) := by
  have hdiff : rLE rZero (rAdd y (rNeg x)) :=
    (rle_iff_nonneg_difference x y).1 hxy
  have hprod :
      rLE rZero (rMulCandidate c (rAdd y (rNeg x))) :=
    rMulCandidate_nonneg h0c hdiff
  have hrepr :
      rMulCandidate c (rAdd y (rNeg x)) =
      rAdd (rMulCandidate c y) (rNeg (rMulCandidate c x)) := by
    calc
      rMulCandidate c (rAdd y (rNeg x)) =
          rAdd (rMulCandidate c y) (rMulCandidate c (rNeg x)) :=
        rMulCandidate_add_right c y (rNeg x)
      _ = rAdd (rMulCandidate c y) (rNeg (rMulCandidate c x)) := by
        rw [rMulCandidate_neg_right]
  rw [hrepr] at hprod
  exact (rle_iff_nonneg_difference
    (rMulCandidate c x) (rMulCandidate c y)).2 hprod

/-- A nonnegative right factor preserves formal real order. -/
theorem rMulCandidate_mono_right_nonneg
    {x y c : RBOMA}
    (hxy : rLE x y)
    (h0c : rLE rZero c) :
    rLE (rMulCandidate x c) (rMulCandidate y c) := by
  rw [rMulCandidate_comm x c, rMulCandidate_comm y c]
  exact rMulCandidate_mono_left_nonneg hxy h0c

/-- Ordered-ring translation form: if a≤b and 0≤c then a*c≤b*c. -/
theorem rMulCandidate_order_compatible
    {a b c : RBOMA}
    (hab : rLE a b)
    (h0c : rLE rZero c) :
    rLE (rMulCandidate a c) (rMulCandidate b c) :=
  rMulCandidate_mono_right_nonneg hab h0c

end BOMA.R.DedekindOrderedRing001

/- Representative-independent positive inverse relation revision 003.
Consumes positive representative extraction 002 and the V5-passing inverse-product 004. -/
namespace BOMA.R.DedekindPositiveInverseRelation003

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulSignLaws001
open BOMA.R.DedekindPositiveReciprocal001
open BOMA.R.DedekindPositiveReciprocalEmbedding001
open BOMA.R.DedekindPositiveRepresentative002
open BOMA.R.DedekindPositiveInverseProduct004

/-- Positive inverse relation with no global representative selector. -/
def RPositiveInvRel (x y : RBOMA) : Prop :=
  ∃ A : LowerCut, ∃ hApos : CutHasPositive A,
    x = rmk A ∧ y = rmk (cutRecipPos A hApos)

 theorem cut_zero_le_recipPos
    (A : LowerCut) (hApos : CutHasPositive A) :
    CutLE (principalCut qZero) (cutRecipPos A hApos) := by
  intro q hq0
  exact Or.inl hq0

 theorem rPositiveInvRel_exists
    {x : RBOMA}
    (h0x : rLE rZero x)
    (hx0 : x ≠ rZero) :
    ∃ y : RBOMA, RPositiveInvRel x y := by
  rcases r_nonneg_nonzero_positive_rep h0x hx0 with ⟨A, hApos, hxA⟩
  exact ⟨rmk (cutRecipPos A hApos), A, hApos, hxA, rfl⟩

 theorem rPositiveInvRel_unique
    {x y z : RBOMA}
    (hy : RPositiveInvRel x y)
    (hz : RPositiveInvRel x z) :
    y = z := by
  rcases hy with ⟨A, hApos, hxA, hyA⟩
  rcases hz with ⟨B, hBpos, hxB, hzB⟩
  have hmk : rmk A = rmk B := hxA.symm.trans hxB
  have hAB : CutEquiv A B := (rmk_eq_iff).1 hmk
  have hRec : CutEquiv (cutRecipPos A hApos) (cutRecipPos B hBpos) :=
    cutRecipPos_respects hAB hApos hBpos
  calc
    y = rmk (cutRecipPos A hApos) := hyA
    _ = rmk (cutRecipPos B hBpos) := rmk_sound hRec
    _ = z := hzB.symm

 theorem rPositiveInvRel_product_one
    {x y : RBOMA}
    (hxy : RPositiveInvRel x y) :
    rMulCandidate x y = rOne := by
  rcases hxy with ⟨A, hApos, hxA, hyA⟩
  rw [hxA, hyA]
  have h0A : rLE rZero (rmk A) := by
    change rLE (rmk (principalCut qZero)) (rmk A)
    exact (rLE_mk_iff (principalCut qZero) A).2
      (cut_zero_le_of_has_positive hApos)
  have h0Rec : rLE rZero (rmk (cutRecipPos A hApos)) := by
    change rLE (rmk (principalCut qZero)) (rmk (cutRecipPos A hApos))
    exact (rLE_mk_iff (principalCut qZero) (cutRecipPos A hApos)).2
      (cut_zero_le_recipPos A hApos)
  rw [rMulCandidate_of_nonneg_nonneg h0A h0Rec]
  change rmk (cutMulNonnegEnvelope A (cutRecipPos A hApos)) = rmk (principalCut qOne)
  exact rmk_sound (cutMul_recipPos_equiv_one A hApos)

 theorem rPositiveInvRel_rOfQ
    {q qinv : QBOMA}
    (h0q : qLT qZero q)
    (hqinv : QInvRel q qinv) :
    RPositiveInvRel (rOfQ q) (rOfQ qinv) := by
  let hpos : CutHasPositive (principalCut q) := principalCut_has_positive h0q
  refine ⟨principalCut q, hpos, rfl, ?_⟩
  change rmk (principalCut qinv) = rmk (cutRecipPos (principalCut q) hpos)
  exact (rmk_sound (cutRecipPos_principal h0q hqinv)).symm

end BOMA.R.DedekindPositiveInverseRelation003

/- Nonzero multiplicative inverse existence revision 004.
Revision 003 is preserved; this revision resolves only the ambiguous rNeg_zero provenance. -/
namespace BOMA.R.DedekindNonzeroInverse004

open BOMA.Q.Quotient001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindSignedMulAssociativity001
open BOMA.R.DedekindOrderedRing001
open BOMA.R.DedekindPositiveInverseRelation003

 theorem rNeg_ne_zero {x : RBOMA}
    (hx0 : x ≠ rZero) :
    rNeg x ≠ rZero := by
  intro hneg0
  apply hx0
  have h := congrArg rNeg hneg0
  rw [rNeg_involutive,
      BOMA.R.DedekindSignedMulCandidate001.rNeg_zero] at h
  exact h

 theorem r_inverse_exists_nonzero
    (x : RBOMA)
    (hx0 : x ≠ rZero) :
    ∃ y : RBOMA, rMulCandidate x y = rOne := by
  rcases rLE_total_classical rZero x with h0x | hxle0
  · rcases rPositiveInvRel_exists h0x hx0 with ⟨y, hyRel⟩
    exact ⟨y, rPositiveInvRel_product_one hyRel⟩
  · have h0nx : rLE rZero (rNeg x) := rNeg_nonneg_of_nonpos hxle0
    have hnx0 : rNeg x ≠ rZero := rNeg_ne_zero hx0
    rcases rPositiveInvRel_exists h0nx hnx0 with ⟨y, hyRel⟩
    have hprod : rMulCandidate (rNeg x) y = rOne :=
      rPositiveInvRel_product_one hyRel
    refine ⟨rNeg y, ?_⟩
    calc
      rMulCandidate x (rNeg y) = rNeg (rMulCandidate x y) :=
        rMulCandidate_neg_right x y
      _ = rMulCandidate (rNeg x) y :=
        (rMulCandidate_neg_left x y).symm
      _ = rOne := hprod

 theorem r_inverse_exists_nonzero_left
    (x : RBOMA)
    (hx0 : x ≠ rZero) :
    ∃ y : RBOMA, rMulCandidate y x = rOne := by
  rcases r_inverse_exists_nonzero x hx0 with ⟨y, hy⟩
  refine ⟨y, ?_⟩
  rw [rMulCandidate_comm]
  exact hy

 theorem r_inverse_witness_unique
    {x y z : RBOMA}
    (hy : rMulCandidate x y = rOne)
    (hz : rMulCandidate x z = rOne) :
    y = z := by
  calc
    y = rMulCandidate y rOne := (rMulCandidate_one_right y).symm
    _ = rMulCandidate y (rMulCandidate x z) :=
      congrArg (fun t => rMulCandidate y t) hz.symm
    _ = rMulCandidate (rMulCandidate y x) z :=
      (rMulCandidate_assoc y x z).symm
    _ = rMulCandidate (rMulCandidate x y) z := by
      rw [rMulCandidate_comm y x]
    _ = rMulCandidate rOne z := by rw [hy]
    _ = z := rMulCandidate_one_left z

end BOMA.R.DedekindNonzeroInverse004

/- Derived strict order on the selected Dedekind quotient carrier.
No new primitive order is introduced: strictness is non-strict order plus inequality. -/
namespace BOMA.R.DedekindStrictOrder001

open BOMA.Q.Quotient001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001

/-- Strict real order derived from the accepted quotient non-strict order. -/
def rLT (x y : RBOMA) : Prop := rLE x y ∧ x ≠ y

@[simp] theorem rlt_irrefl (x : RBOMA) : ¬ rLT x x := by
  intro h
  exact h.2 rfl

/-- On explicit cut representatives, strict real order is strict cut inclusion:
inclusion together with failure of extensional cut identity. -/
theorem rlt_mk_iff (A B : LowerCut) :
    rLT (rmk A) (rmk B) ↔ CutLE A B ∧ ¬ CutEquiv A B := by
  constructor
  · intro h
    refine ⟨(rLE_mk_iff A B).1 h.1, ?_⟩
    intro hEq
    exact h.2 (rmk_sound hEq)
  · intro h
    refine ⟨(rLE_mk_iff A B).2 h.1, ?_⟩
    intro hmk
    exact h.2 ((rmk_eq_iff).1 hmk)

/-- The rational embedding preserves and reflects strict order. -/
theorem rOfQ_strict_order (q r : QBOMA) :
    rLT (rOfQ q) (rOfQ r) ↔ qLT q r := by
  constructor
  · intro h
    refine ⟨(rOfQ_order q r).1 h.1, ?_⟩
    intro hqr
    apply h.2
    exact congrArg rOfQ hqr
  · intro h
    refine ⟨(rOfQ_order q r).2 h.1, ?_⟩
    intro hEq
    exact h.2 (rOfQ_injective hEq)

end BOMA.R.DedekindStrictOrder001

/- Explicit ordered-field closure laws required by the Stage-One R acceptance contract.
These are derived from already-certified RBOMA additive/order/multiplicative/inverse interfaces. -/
namespace BOMA.R.DedekindOrderedFieldClosure001

open BOMA.Q.Quotient001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindStrictOrder001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindOrderAdditive001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindAdditiveDerived001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindPositiveReciprocal001
open BOMA.R.DedekindPositiveInverseRelation003
open BOMA.R.DedekindNonzeroInverse004

/-- Nontriviality of the selected real zero and one is inherited from the
accepted rational strict order through the faithful principal-cut embedding. -/
theorem rZero_ne_rOne_field : rZero ≠ rOne := by
  have hlt : rLT rZero rOne := by
    change rLT (rOfQ qZero) (rOfQ qOne)
    exact (rOfQ_strict_order qZero qOne).2 qzero_lt_one
  exact hlt.2

/-- Addition by a common right translate is an order equivalence, not merely
one-way monotonicity. -/
theorem rLE_add_right_iff (x y c : RBOMA) :
    rLE (rAdd x c) (rAdd y c) ↔ rLE x y := by
  constructor
  · intro h
    have h' := rAdd_mono_right h (rNeg c)
    rw [rAdd_sub_right x c, rAdd_sub_right y c] at h'
    exact h'
  · intro h
    exact rAdd_mono_right h c

/-- Addition by a common left translate is likewise an order equivalence. -/
theorem rLE_add_left_iff (x y c : RBOMA) :
    rLE (rAdd c x) (rAdd c y) ↔ rLE x y := by
  rw [rAdd_comm c x, rAdd_comm c y]
  exact rLE_add_right_iff x y c

/-- Negation reverses the selected real order. -/
theorem rNeg_order_reversing {x y : RBOMA}
    (hxy : rLE x y) :
    rLE (rNeg y) (rNeg x) := by
  let c : RBOMA := rAdd (rNeg x) (rNeg y)
  have h := rAdd_mono_right hxy c
  have hx : rAdd x c = rNeg y := by
    unfold c
    calc
      rAdd x (rAdd (rNeg x) (rNeg y)) =
          rAdd (rAdd x (rNeg x)) (rNeg y) :=
        (rAdd_assoc x (rNeg x) (rNeg y)).symm
      _ = rAdd rZero (rNeg y) := by rw [rAdd_neg_right]
      _ = rNeg y := rAdd_zero_left _
  have hy : rAdd y c = rNeg x := by
    unfold c
    calc
      rAdd y (rAdd (rNeg x) (rNeg y)) =
          rAdd y (rAdd (rNeg y) (rNeg x)) := by
        rw [rAdd_comm (rNeg x) (rNeg y)]
      _ = rAdd (rAdd y (rNeg y)) (rNeg x) :=
        (rAdd_assoc y (rNeg y) (rNeg x)).symm
      _ = rAdd rZero (rNeg x) := by rw [rAdd_neg_right]
      _ = rNeg x := rAdd_zero_left _
  rw [hx, hy] at h
  exact h

/-- The selected positive reciprocal relation yields a strictly positive inverse,
not merely a nonnegative one. -/
theorem rPositiveInvRel_strict_positive
    {x y : RBOMA}
    (hxy : RPositiveInvRel x y) :
    rLT rZero y := by
  have hprod : rMulCandidate x y = rOne :=
    rPositiveInvRel_product_one hxy
  have hy0 : y ≠ rZero := by
    intro hy0
    rw [hy0, rMulCandidate_zero_right] at hprod
    exact rZero_ne_rOne_field hprod
  rcases hxy with ⟨A, hApos, hxA, hyA⟩
  have h0y : rLE rZero y := by
    rw [hyA]
    change rLE (rmk (principalCut qZero)) (rmk (cutRecipPos A hApos))
    exact (rLE_mk_iff (principalCut qZero) (cutRecipPos A hApos)).2
      (cut_zero_le_recipPos A hApos)
  exact ⟨h0y, fun h0yEq => hy0 h0yEq.symm⟩

/-- Any multiplicative inverse witness of a strictly positive real is strictly
positive. Uniqueness transports positivity from the direct positive reciprocal
witness to an arbitrary accepted inverse witness. -/
theorem rInverse_positive_of_positive
    {x y : RBOMA}
    (h0x : rLT rZero x)
    (hxy : rMulCandidate x y = rOne) :
    rLT rZero y := by
  have hx0 : x ≠ rZero := by
    intro hx0
    exact h0x.2 hx0.symm
  rcases rPositiveInvRel_exists h0x.1 hx0 with ⟨z, hz⟩
  have hzprod : rMulCandidate x z = rOne :=
    rPositiveInvRel_product_one hz
  have hyz : y = z := r_inverse_witness_unique hxy hzprod
  rw [hyz]
  exact rPositiveInvRel_strict_positive hz

end BOMA.R.DedekindOrderedFieldClosure001

/- Formal-carrier Dedekind completeness for the selected RBOMA quotient. -/
namespace BOMA.R.DedekindCompleteness001

open BOMA.Q.Quotient001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001

/-- U is an upper bound of a formal real family F. -/
def RUpperBound (F : RBOMA → Prop) (U : RBOMA) : Prop :=
  ∀ x : RBOMA, F x → rLE x U

/-- Raw lower cut formed from all rational members occurring in representatives
of a nonempty formal-real family. An explicit representative of one upper bound
is used only to prove properness; no representative selector for family elements
is introduced. -/
def supCutFromFamily
    (F : RBOMA → Prop)
    (hne : ∃ x : RBOMA, F x)
    (U : LowerCut)
    (hUB : RUpperBound F (rmk U)) : LowerCut where
  lower := fun q =>
    ∃ x : RBOMA, F x ∧ ∃ A : LowerCut, x = rmk A ∧ A.lower q
  nonempty := by
    rcases hne with ⟨x, hxF⟩
    refine Quotient.inductionOn x ?_ hxF
    intro A hAF
    rcases A.nonempty with ⟨q, hqA⟩
    exact ⟨q, rmk A, hAF, A, rfl, hqA⟩
  proper := by
    rcases U.proper with ⟨q, hqU⟩
    refine ⟨q, ?_⟩
    intro hqSup
    rcases hqSup with ⟨x, hxF, A, hxA, hqA⟩
    have hxU : rLE x (rmk U) := hUB x hxF
    rw [hxA] at hxU
    have hAU : CutLE A U := (rLE_mk_iff A U).1 hxU
    exact hqU (hAU q hqA)
  downward := by
    intro a b hb hab
    rcases hb with ⟨x, hxF, A, hxA, hbA⟩
    exact ⟨x, hxF, A, hxA, A.downward hbA hab⟩
  rounded := by
    intro a ha
    rcases ha with ⟨x, hxF, A, hxA, haA⟩
    rcases A.rounded haA with ⟨b, hbA, hab⟩
    exact ⟨b, ⟨x, hxF, A, hxA, hbA⟩, hab⟩

/-- Every member of F lies below the formal class of the union cut. -/
theorem member_le_supFamily
    (F : RBOMA → Prop)
    (hne : ∃ x : RBOMA, F x)
    (U : LowerCut)
    (hUB : RUpperBound F (rmk U))
    (x : RBOMA) (hxF : F x) :
    rLE x (rmk (supCutFromFamily F hne U hUB)) := by
  refine Quotient.inductionOn x ?_ hxF
  intro A hAF
  apply (rLE_mk_iff A (supCutFromFamily F hne U hUB)).2
  intro q hqA
  exact ⟨rmk A, hAF, A, rfl, hqA⟩

/-- The formal union cut lies below every common upper bound. -/
theorem supFamily_le_of_upper
    (F : RBOMA → Prop)
    (hne : ∃ x : RBOMA, F x)
    (U : LowerCut)
    (hUB : RUpperBound F (rmk U))
    (B : RBOMA) (hB : RUpperBound F B) :
    rLE (rmk (supCutFromFamily F hne U hUB)) B := by
  refine Quotient.inductionOn B ?_ hB
  intro C hC
  apply (rLE_mk_iff (supCutFromFamily F hne U hUB) C).2
  intro q hqSup
  rcases hqSup with ⟨x, hxF, A, hxA, hqA⟩
  have hxC : rLE x (rmk C) := hC x hxF
  rw [hxA] at hxC
  have hAC : CutLE A C := (rLE_mk_iff A C).1 hxC
  exact hAC q hqA

/-- Formal-carrier Dedekind least-upper-bound theorem.
Every nonempty family having an explicit upper bound has a least upper bound in
RBOMA. The theorem is proved without choosing representatives for the family. -/
theorem rDedekind_lub_exists
    (F : RBOMA → Prop)
    (hne : ∃ x : RBOMA, F x)
    (U : RBOMA)
    (hUB : RUpperBound F U) :
    ∃ s : RBOMA,
      (∀ x : RBOMA, F x → rLE x s) ∧
      (∀ B : RBOMA, RUpperBound F B → rLE s B) := by
  refine Quotient.inductionOn U ?_ hUB
  intro Ucut hU
  let S : RBOMA := rmk (supCutFromFamily F hne Ucut hU)
  refine ⟨S, ?_, ?_⟩
  · intro x hxF
    exact member_le_supFamily F hne Ucut hU x hxF
  · intro B hB
    exact supFamily_le_of_upper F hne Ucut hU B hB

end BOMA.R.DedekindCompleteness001

/- Rational-image density in the selected Dedekind quotient carrier.
The only new classical step is witness extraction from strict extensional cut inclusion. -/
namespace BOMA.R.DedekindRationalDensity001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindStrictOrder001

/-- Strict cut inclusion has an explicit rational point lying in the larger cut
and outside the smaller cut. The witness extraction from failure of extensional
identity is the localized classical step in this file. -/
theorem strict_cut_inclusion_witness
    {A B : LowerCut}
    (hAB : CutLE A B)
    (hne : ¬ CutEquiv A B) :
    ∃ b : QBOMA, B.lower b ∧ ¬ A.lower b := by
  apply Classical.byContradiction
  intro hNoWitness
  apply hne
  intro q
  constructor
  · intro hqA
    exact hAB q hqA
  · intro hqB
    cases Classical.em (A.lower q) with
    | inl hqA => exact hqA
    | inr hNotA =>
        exact False.elim (hNoWitness ⟨q, hqB, hNotA⟩)

/-- Between two strictly nested lower cuts lies a principal rational cut that is
strictly above the smaller cut and strictly below the larger cut. -/
theorem principal_cut_between_strict_cuts
    {A B : LowerCut}
    (hAB : CutLE A B)
    (hne : ¬ CutEquiv A B) :
    ∃ m : QBOMA,
      CutLE A (principalCut m) ∧
      ¬ CutEquiv A (principalCut m) ∧
      CutLE (principalCut m) B ∧
      ¬ CutEquiv (principalCut m) B := by
  rcases strict_cut_inclusion_witness hAB hne with ⟨b, hbB, hbNotA⟩
  rcases B.rounded hbB with ⟨c, hcB, hbc⟩
  rcases rational_order_dense hbc with ⟨m, hbm, hmc⟩

  have hApm : CutLE A (principalCut m) := by
    intro a haA
    change qLT a m
    have hab : qLT a b := by
      rcases qle_total a b with hab | hba
      · refine ⟨hab, ?_⟩
        intro heq
        apply hbNotA
        rw [← heq]
        exact haA
      · exact False.elim (hbNotA (A.downward haA hba))
    exact qlt_trans hab hbm

  have hmB : B.lower m := B.downward hcB hmc.1

  have hpmB : CutLE (principalCut m) B := by
    intro a haM
    exact B.downward hmB haM.1

  have hAne : ¬ CutEquiv A (principalCut m) := by
    intro hEq
    exact hbNotA ((hEq b).2 hbm)

  have hBne : ¬ CutEquiv (principalCut m) B := by
    intro hEq
    have hmm : (principalCut m).lower m := (hEq m).2 hmB
    exact (qlt_irrefl m) hmm

  exact ⟨m, hApm, hAne, hpmB, hBne⟩

/-- RA-12: the embedded accepted rationals are strictly order-dense in RBOMA. -/
theorem r_rational_image_dense
    {x y : RBOMA}
    (hxy : rLT x y) :
    ∃ q : QBOMA,
      rLT x (rOfQ q) ∧ rLT (rOfQ q) y := by
  rcases hxy.1 with ⟨A, B, hxA, hyB, hAB⟩
  have hneAB : ¬ CutEquiv A B := by
    intro hEq
    apply hxy.2
    calc
      x = rmk A := hxA
      _ = rmk B := rmk_sound hEq
      _ = y := hyB.symm
  rcases principal_cut_between_strict_cuts hAB hneAB with
    ⟨m, hApm, hAne, hpmB, hBne⟩
  refine ⟨m, ?_, ?_⟩
  · constructor
    · exact ⟨A, principalCut m, hxA, rfl, hApm⟩
    · intro hxq
      apply hAne
      have hmk : rmk A = rmk (principalCut m) := by
        calc
          rmk A = x := hxA.symm
          _ = rOfQ m := hxq
          _ = rmk (principalCut m) := rfl
      exact (rmk_eq_iff).1 hmk
  · constructor
    · exact ⟨principalCut m, B, rfl, hyB, hpmB⟩
    · intro hqy
      apply hBne
      have hmk : rmk (principalCut m) = rmk B := by
        calc
          rmk (principalCut m) = rOfQ m := rfl
          _ = y := hqy
          _ = rmk B := hyB
      exact (rmk_eq_iff).1 hmk

end BOMA.R.DedekindRationalDensity001

/- Archimedean characterization of the selected Dedekind quotient carrier.
The proof reuses only the certified rational natural-upper-bound contribution;
it does not consume finite cut-membership search or cut-bracketing. -/
namespace BOMA.R.DedekindArchimedean001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.QArchimedeanUpperBound001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindStrictOrder001

/-- Constructive mixed strict/non-strict transitivity used locally so the
Archimedean theorem does not inherit the real-addition payload merely for a Q helper. -/
theorem qlt_le_trans_arch {x y z : QBOMA}
    (hxy : qLT x y) (hyz : qLE y z) : qLT x z := by
  refine ⟨qle_trans hxy.1 hyz, ?_⟩
  intro hxz
  have hyx : qLE y x := by
    have h := hyz
    rw [← hxz] at h
    exact h
  have hxyEq : x = y := qle_antisymm hxy.1 hyx
  exact hxy.2 hxyEq

/-- Every selected lower cut lies strictly below some principal cut generated by
an embedded BOMA natural. -/
theorem cut_strict_below_natural_principal
    (A : LowerCut) :
    ∃ n : BOMANat,
      CutLE A (principalCut (qOfN n)) ∧
      ¬ CutEquiv A (principalCut (qOfN n)) := by
  rcases A.proper with ⟨u, huNotA⟩
  let u1 := qAdd u qOne
  have huu1 : qLT u u1 := by
    have h := qlt_add_right qzero_lt_one u
    change qLT (qAdd qZero u) (qAdd qOne u) at h
    rw [qAdd_zero_left, qAdd_comm qOne u] at h
    exact h
  rcases q_le_natural_upper u1 with ⟨n, hu1n⟩
  have hun : qLT u (qOfN n) := qlt_le_trans_arch huu1 hu1n

  have hLE : CutLE A (principalCut (qOfN n)) := by
    intro a haA
    change qLT a (qOfN n)
    have hau : qLT a u := by
      rcases qle_total a u with hau | hua
      · refine ⟨hau, ?_⟩
        intro heq
        apply huNotA
        rw [← heq]
        exact haA
      · exact False.elim (huNotA (A.downward haA hua))
    exact qlt_trans hau hun

  have hne : ¬ CutEquiv A (principalCut (qOfN n)) := by
    intro hEq
    exact huNotA ((hEq u).2 hun)

  exact ⟨n, hLE, hne⟩

/-- RA-13: every selected real lies strictly below an embedded BOMA natural. -/
theorem r_archimedean_strict_upper (x : RBOMA) :
    ∃ n : BOMANat, rLT x (rOfQ (qOfN n)) := by
  refine Quotient.inductionOn x ?_
  intro A
  rcases cut_strict_below_natural_principal A with ⟨n, hLE, hne⟩
  refine ⟨n, ?_⟩
  change rLT (rmk A) (rmk (principalCut (qOfN n)))
  exact (rlt_mk_iff A (principalCut (qOfN n))).2 ⟨hLE, hne⟩

end BOMA.R.DedekindArchimedean001

/- Stage-One real integration certificate.
This file introduces no new carrier, operation, axiom, or completeness notion.
It packages already-certified interfaces to verify that they coexist on one RBOMA. -/
namespace BOMA.R.StageIntegration002

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindStrictOrder001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindSignedMulAssociativity001
open BOMA.R.DedekindSignedMulDistributivity001
open BOMA.R.DedekindOrderedRing001
open BOMA.R.DedekindNonzeroInverse004
open BOMA.R.DedekindOrderedFieldClosure001
open BOMA.R.DedekindCompleteness001
open BOMA.R.DedekindRationalDensity001
open BOMA.R.DedekindArchimedean001

/-- RA-21 machine-checkable integration surface.

The certificate deliberately keeps multiplicative inversion witness-based:
no global inverse selector is introduced. Completeness is exactly the selected
Dedekind least-upper-bound contract. -/
structure RStageIntegrationCertificate where
  qEmbeddingInjective :
    ∀ {q r : QBOMA}, rOfQ q = rOfQ r → q = r
  qOrderExact :
    ∀ q r : QBOMA, rLE (rOfQ q) (rOfQ r) ↔ qLE q r
  orderRefl :
    ∀ x : RBOMA, rLE x x
  orderTrans :
    ∀ {x y z : RBOMA}, rLE x y → rLE y z → rLE x z
  orderAntisymm :
    ∀ {x y : RBOMA}, rLE x y → rLE y x → x = y
  orderTotal :
    ∀ x y : RBOMA, rLE x y ∨ rLE y x
  strictIrrefl :
    ∀ x : RBOMA, ¬ rLT x x
  nontrivial :
    rZero ≠ rOne
  addComm :
    ∀ x y : RBOMA, rAdd x y = rAdd y x
  addAssoc :
    ∀ x y z : RBOMA, rAdd (rAdd x y) z = rAdd x (rAdd y z)
  addZeroLeft :
    ∀ x : RBOMA, rAdd rZero x = x
  addInverseRight :
    ∀ x : RBOMA, rAdd x (rNeg x) = rZero
  addTranslateOrderIff :
    ∀ x y c : RBOMA, rLE (rAdd x c) (rAdd y c) ↔ rLE x y
  negOrderReversing :
    ∀ {x y : RBOMA}, rLE x y → rLE (rNeg y) (rNeg x)
  mulComm :
    ∀ x y : RBOMA, rMulCandidate x y = rMulCandidate y x
  mulAssoc :
    ∀ x y z : RBOMA,
      rMulCandidate (rMulCandidate x y) z =
      rMulCandidate x (rMulCandidate y z)
  mulOneLeft :
    ∀ x : RBOMA, rMulCandidate rOne x = x
  distribRight :
    ∀ x y z : RBOMA,
      rMulCandidate x (rAdd y z) =
      rAdd (rMulCandidate x y) (rMulCandidate x z)
  orderMulNonneg :
    ∀ {a b c : RBOMA},
      rLE a b → rLE rZero c →
      rLE (rMulCandidate a c) (rMulCandidate b c)
  inverseExists :
    ∀ x : RBOMA, x ≠ rZero →
      ∃ y : RBOMA, rMulCandidate x y = rOne
  inverseUnique :
    ∀ {x y z : RBOMA},
      rMulCandidate x y = rOne →
      rMulCandidate x z = rOne → y = z
  positiveInverse :
    ∀ {x y : RBOMA},
      rLT rZero x → rMulCandidate x y = rOne → rLT rZero y
  dedekindLUB :
    ∀ (F : RBOMA → Prop),
      (∃ x : RBOMA, F x) →
      ∀ U : RBOMA, RUpperBound F U →
      ∃ s : RBOMA,
        (∀ x : RBOMA, F x → rLE x s) ∧
        (∀ B : RBOMA, RUpperBound F B → rLE s B)
  rationalDensity :
    ∀ {x y : RBOMA}, rLT x y →
      ∃ q : QBOMA, rLT x (rOfQ q) ∧ rLT (rOfQ q) y
  archimedeanUpper :
    ∀ x : RBOMA,
      ∃ n : BOMANat, rLT x (rOfQ (BOMA.Q.Embedding001.qOfN n))

/-- The single certificate used by R-J-002. Each field is an already-proved
Stage-One theorem instantiated on the same formal carrier and operations. -/
theorem rStageIntegrationCertificate : RStageIntegrationCertificate where
  qEmbeddingInjective := @rOfQ_injective
  qOrderExact := rOfQ_order
  orderRefl := rLE_refl
  orderTrans := @rLE_trans
  orderAntisymm := @rLE_antisymm
  orderTotal := rLE_total_classical
  strictIrrefl := rlt_irrefl
  nontrivial := rZero_ne_rOne_field
  addComm := rAdd_comm
  addAssoc := rAdd_assoc
  addZeroLeft := rAdd_zero_left
  addInverseRight := rAdd_neg_right
  addTranslateOrderIff := rLE_add_right_iff
  negOrderReversing := @rNeg_order_reversing
  mulComm := rMulCandidate_comm
  mulAssoc := rMulCandidate_assoc
  mulOneLeft := rMulCandidate_one_left
  distribRight := rMulCandidate_add_right
  orderMulNonneg := @rMulCandidate_order_compatible
  inverseExists := r_inverse_exists_nonzero
  inverseUnique := @r_inverse_witness_unique
  positiveInverse := @rInverse_positive_of_positive
  dedekindLUB := rDedekind_lub_exists
  rationalDensity := @r_rational_image_dense
  archimedeanUpper := r_archimedean_strict_upper

end BOMA.R.StageIntegration002

/- C-stage accepted-R interface sufficiency probe.

Purpose:
  derive the order facts needed by likely C constructions from an abstract
  RStageIntegrationCertificate first, then instantiate the result with the
  accepted R certificate. The abstract proof does not unfold LowerCut,
  CutEquiv, quotient representatives, or the selected Dedekind
  multiplication/inverse implementations.

This file does not construct a complex carrier and does not select C-DP-001.
-/
namespace BOMA.C.RInterfaceNoSquareProbe001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002

/-- Zero is fixed by negation, derived only from the accepted additive interface. -/
theorem neg_zero_from_interface
    (C : RStageIntegrationCertificate) :
    rNeg rZero = rZero := by
  calc
    rNeg rZero = rAdd rZero (rNeg rZero) :=
      (C.addZeroLeft (rNeg rZero)).symm
    _ = rZero := C.addInverseRight rZero

/-- Additive inverse witnesses are unique, derived from the accepted additive laws. -/
theorem add_inverse_unique_from_interface
    (C : RStageIntegrationCertificate)
    {x y : RBOMA}
    (hxy : rAdd x y = rZero) :
    y = rNeg x := by
  calc
    y = rAdd rZero y := (C.addZeroLeft y).symm
    _ = rAdd (rAdd x (rNeg x)) y := by
      rw [C.addInverseRight x]
    _ = rAdd x (rAdd (rNeg x) y) :=
      C.addAssoc x (rNeg x) y
    _ = rAdd x (rAdd y (rNeg x)) := by
      rw [C.addComm (rNeg x) y]
    _ = rAdd (rAdd x y) (rNeg x) :=
      (C.addAssoc x y (rNeg x)).symm
    _ = rAdd rZero (rNeg x) := by rw [hxy]
    _ = rNeg x := C.addZeroLeft (rNeg x)

/-- Negation is involutive, derived from accepted additive commutativity and inverse uniqueness. -/
theorem neg_involutive_from_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rNeg (rNeg x) = x := by
  have hleft : rAdd (rNeg x) x = rZero := by
    calc
      rAdd (rNeg x) x = rAdd x (rNeg x) := C.addComm (rNeg x) x
      _ = rZero := C.addInverseRight x
  exact (add_inverse_unique_from_interface C hleft).symm

/-- Right zero-annihilation follows from distributivity and the accepted additive group laws. -/
theorem mul_zero_right_from_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rMulCandidate x rZero = rZero := by
  let p : RBOMA := rMulCandidate x rZero
  have hdist := C.distribRight x rZero rZero
  have h00 : rAdd rZero rZero = rZero := C.addZeroLeft rZero
  have hp : p = rAdd p p := by
    unfold p
    rw [h00] at hdist
    exact hdist
  have hnegleft : rAdd (rNeg p) p = rZero := by
    calc
      rAdd (rNeg p) p = rAdd p (rNeg p) := C.addComm (rNeg p) p
      _ = rZero := C.addInverseRight p
  have hcancel := congrArg (fun t => rAdd (rNeg p) t) hp
  have hz_eq_p : rZero = p := by
    calc
      rZero = rAdd (rNeg p) p := hnegleft.symm
      _ = rAdd (rNeg p) (rAdd p p) := hcancel
      _ = rAdd (rAdd (rNeg p) p) p :=
        (C.addAssoc (rNeg p) p p).symm
      _ = rAdd rZero p := by rw [hnegleft]
      _ = p := C.addZeroLeft p
  exact hz_eq_p.symm

/-- Left zero-annihilation follows from accepted multiplication commutativity. -/
theorem mul_zero_left_from_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rMulCandidate rZero x = rZero := by
  calc
    rMulCandidate rZero x = rMulCandidate x rZero := C.mulComm rZero x
    _ = rZero := mul_zero_right_from_interface C x

/-- Multiplication by an additive inverse on the right negates the product. -/
theorem mul_neg_right_from_interface
    (C : RStageIntegrationCertificate)
    (x y : RBOMA) :
    rMulCandidate x (rNeg y) = rNeg (rMulCandidate x y) := by
  have hd := C.distribRight x y (rNeg y)
  have hy0 : rAdd y (rNeg y) = rZero := C.addInverseRight y
  have hsum :
      rAdd (rMulCandidate x y) (rMulCandidate x (rNeg y)) = rZero := by
    calc
      rAdd (rMulCandidate x y) (rMulCandidate x (rNeg y)) =
          rMulCandidate x (rAdd y (rNeg y)) := hd.symm
      _ = rMulCandidate x rZero := by rw [hy0]
      _ = rZero := mul_zero_right_from_interface C x
  exact add_inverse_unique_from_interface C hsum

/-- Multiplication by an additive inverse on the left negates the product. -/
theorem mul_neg_left_from_interface
    (C : RStageIntegrationCertificate)
    (x y : RBOMA) :
    rMulCandidate (rNeg x) y = rNeg (rMulCandidate x y) := by
  calc
    rMulCandidate (rNeg x) y = rMulCandidate y (rNeg x) :=
      C.mulComm (rNeg x) y
    _ = rNeg (rMulCandidate y x) := mul_neg_right_from_interface C y x
    _ = rNeg (rMulCandidate x y) := by rw [C.mulComm y x]

/-- Squaring a negated value gives the same square, using only accepted field laws. -/
theorem mul_neg_neg_same_from_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rMulCandidate (rNeg x) (rNeg x) = rMulCandidate x x := by
  calc
    rMulCandidate (rNeg x) (rNeg x) =
        rNeg (rMulCandidate x (rNeg x)) :=
      mul_neg_left_from_interface C x (rNeg x)
    _ = rNeg (rNeg (rMulCandidate x x)) := by
      rw [mul_neg_right_from_interface C x x]
    _ = rMulCandidate x x := neg_involutive_from_interface C _

/-- C-RL-001 at the abstract accepted-R interface level: every square is nonnegative.

The proof branches only on total order supplied by the certificate. The
negative branch replaces x by -x and uses identities proved above from the
same abstract interface. -/
theorem square_nonnegative_of_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rLE rZero (rMulCandidate x x) := by
  rcases C.orderTotal rZero x with h0x | hx0
  · have h := C.orderMulNonneg (a := rZero) (b := x) (c := x) h0x h0x
    rw [mul_zero_left_from_interface C x] at h
    exact h
  · have h0nx0 := C.negOrderReversing hx0
    have h0nx : rLE rZero (rNeg x) := by
      rw [neg_zero_from_interface C] at h0nx0
      exact h0nx0
    have h := C.orderMulNonneg
      (a := rZero) (b := rNeg x) (c := rNeg x) h0nx h0nx
    rw [mul_zero_left_from_interface C (rNeg x),
        mul_neg_neg_same_from_interface C x] at h
    exact h

/-- One is nonnegative as the square of one, at the abstract interface level. -/
theorem zero_le_one_of_interface
    (C : RStageIntegrationCertificate) :
    rLE rZero rOne := by
  have h := square_nonnegative_of_interface C rOne
  rw [C.mulOneLeft rOne] at h
  exact h

/-- C-RL-002 at the abstract accepted-R interface level: -1 is not a square. -/
theorem minus_one_not_square_of_interface
    (C : RStageIntegrationCertificate) :
    ¬ ∃ x : RBOMA, rMulCandidate x x = rNeg rOne := by
  rintro ⟨x, hx⟩
  have hsq : rLE rZero (rNeg rOne) := by
    have h := square_nonnegative_of_interface C x
    rw [hx] at h
    exact h
  have h10raw := C.negOrderReversing hsq
  have h10 : rLE rOne rZero := by
    rw [neg_involutive_from_interface C rOne,
        neg_zero_from_interface C] at h10raw
    exact h10raw
  have h01 : rLE rZero rOne := zero_le_one_of_interface C
  have hEq : rZero = rOne := C.orderAntisymm h01 h10
  exact C.nontrivial hEq

/-- C-RL-001 instantiated on the accepted Stage-One R integration certificate. -/
theorem square_nonnegative_from_accepted_R (x : RBOMA) :
    rLE rZero (rMulCandidate x x) :=
  square_nonnegative_of_interface rStageIntegrationCertificate x

/-- C-RL-002 instantiated on the accepted Stage-One R integration certificate.

This is the route-neutral C boundary fact needed to prevent a future
imaginary generator from collapsing into the embedded real line. -/
theorem minus_one_not_square_from_accepted_R :
    ¬ ∃ x : RBOMA, rMulCandidate x x = rNeg rOne :=
  minus_one_not_square_of_interface rStageIntegrationCertificate

end BOMA.C.RInterfaceNoSquareProbe001

/- PDSA-C-003 Route P: noncanonical rank-two coordinate probe.

This file is an exploratory producer candidate. It does not select C-DP-001,
create an accepted C Claim, construct a full field inverse, or use the Route Q
candidate.
-/
namespace BOMA.C.RoutePairProbe001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001

/-- Route-local coordinate carrier; not the canonical BOMA complex carrier. -/
structure PairCandidate where
  re : RBOMA
  im : RBOMA

/-- Core Lean does not generate a structure extensionality theorem automatically. -/
theorem pair_ext {z w : PairCandidate}
    (hre : z.re = w.re) (him : z.im = w.im) :
    z = w := by
  cases z
  cases w
  cases hre
  cases him
  rfl

def zero : PairCandidate := ⟨rZero, rZero⟩
def one : PairCandidate := ⟨rOne, rZero⟩
def ofR (a : RBOMA) : PairCandidate := ⟨a, rZero⟩
def imag : PairCandidate := ⟨rZero, rOne⟩

def neg (z : PairCandidate) : PairCandidate :=
  ⟨rNeg z.re, rNeg z.im⟩

def add (z w : PairCandidate) : PairCandidate :=
  ⟨rAdd z.re w.re, rAdd z.im w.im⟩

def mul (z w : PairCandidate) : PairCandidate :=
  ⟨rAdd (rMulCandidate z.re w.re) (rNeg (rMulCandidate z.im w.im)),
   rAdd (rMulCandidate z.re w.im) (rMulCandidate z.im w.re)⟩

theorem add_zero_right_from_interface
    (C : RStageIntegrationCertificate) (x : RBOMA) :
    rAdd x rZero = x := by
  calc
    rAdd x rZero = rAdd rZero x := C.addComm x rZero
    _ = x := C.addZeroLeft x

theorem mul_one_right_from_interface
    (C : RStageIntegrationCertificate) (x : RBOMA) :
    rMulCandidate x rOne = x := by
  calc
    rMulCandidate x rOne = rMulCandidate rOne x := C.mulComm x rOne
    _ = x := C.mulOneLeft x

/-- P/Q-03: route-local real embedding is faithful. -/
theorem ofR_injective {a b : RBOMA}
    (h : ofR a = ofR b) : a = b :=
  congrArg PairCandidate.re h

/-- Multiplication by the route-local generator extracts an imaginary coefficient. -/
theorem embed_mul_imag
    (C : RStageIntegrationCertificate) (b : RBOMA) :
    mul (ofR b) imag = ⟨rZero, b⟩ := by
  apply pair_ext
  · change
      rAdd (rMulCandidate b rZero)
        (rNeg (rMulCandidate rZero rOne)) = rZero
    rw [mul_zero_right_from_interface C b,
        mul_zero_left_from_interface C rOne,
        neg_zero_from_interface C,
        C.addZeroLeft rZero]
  · change
      rAdd (rMulCandidate b rOne)
        (rMulCandidate rZero rZero) = b
    rw [mul_one_right_from_interface C b,
        mul_zero_left_from_interface C rZero,
        add_zero_right_from_interface C b]

/-- Normal form of a real-plus-imaginary route-local expression. -/
theorem coordinate_expression
    (C : RStageIntegrationCertificate) (a b : RBOMA) :
    add (ofR a) (mul (ofR b) imag) = ⟨a, b⟩ := by
  rw [embed_mul_imag C b]
  apply pair_ext
  · exact add_zero_right_from_interface C a
  · exact C.addZeroLeft b

/-- P/Q-06: the distinguished generator squares to negative one. -/
theorem imag_squared
    (C : RStageIntegrationCertificate) :
    mul imag imag = neg one := by
  apply pair_ext
  · change
      rAdd (rMulCandidate rZero rZero)
        (rNeg (rMulCandidate rOne rOne)) = rNeg rOne
    rw [mul_zero_left_from_interface C rZero,
        C.mulOneLeft rOne,
        C.addZeroLeft (rNeg rOne)]
  · change
      rAdd (rMulCandidate rZero rOne)
        (rMulCandidate rOne rZero) = rNeg rZero
    rw [mul_zero_left_from_interface C rOne,
        C.mulOneLeft rZero,
        C.addZeroLeft rZero,
        neg_zero_from_interface C]

/-- P/Q-07: every route-local candidate has a real/imaginary decomposition. -/
theorem decomposition
    (C : RStageIntegrationCertificate) (z : PairCandidate) :
    ∃ a b : RBOMA, z = add (ofR a) (mul (ofR b) imag) := by
  refine ⟨z.re, z.im, ?_⟩
  rw [coordinate_expression C z.re z.im]

/-- P/Q-08: real/imaginary coordinates are unique at Route P equality. -/
theorem decomposition_unique
    (C : RStageIntegrationCertificate)
    {a b a' b' : RBOMA}
    (h : add (ofR a) (mul (ofR b) imag) =
      add (ofR a') (mul (ofR b') imag)) :
    a = a' ∧ b = b' := by
  rw [coordinate_expression C a b,
      coordinate_expression C a' b'] at h
  exact ⟨congrArg PairCandidate.re h,
         congrArg PairCandidate.im h⟩

/-- P/Q-09: the imaginary generator is not in the embedded real line. -/
theorem imag_not_real
    (C : RStageIntegrationCertificate) :
    ¬ ∃ a : RBOMA, imag = ofR a := by
  rintro ⟨a, ha⟩
  have h : rOne = rZero := congrArg PairCandidate.im ha
  exact C.nontrivial h.symm

end BOMA.C.RoutePairProbe001

/- PDSA-C-004: user-selected Route P canonical complex carrier and ring core.

The canonical carrier transparently reuses the already verified Route P record.
Every non-definitional scalar law is derived from the abstract accepted real
integration certificate. This file proves a commutative-ring core only; the
nonzero multiplicative inverse belongs to a later frozen PDSA cycle.
-/
namespace BOMA.C.PairCore001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001

/-- The selected canonical carrier is exactly the verified Route P record. -/
abbrev CBOMA : Type := BOMA.C.RoutePairProbe001.PairCandidate

/-- The selected identity is Lean record equality, equivalent to coordinate equality. -/
theorem c_ext {z w : CBOMA}
    (hre : z.re = w.re) (him : z.im = w.im) : z = w :=
  BOMA.C.RoutePairProbe001.pair_ext hre him

def cZero : CBOMA := BOMA.C.RoutePairProbe001.zero
def cOne : CBOMA := BOMA.C.RoutePairProbe001.one
def cOfR (a : RBOMA) : CBOMA := BOMA.C.RoutePairProbe001.ofR a
def cI : CBOMA := BOMA.C.RoutePairProbe001.imag
def cNeg (z : CBOMA) : CBOMA := BOMA.C.RoutePairProbe001.neg z
def cAdd (z w : CBOMA) : CBOMA := BOMA.C.RoutePairProbe001.add z w
def cMul (z w : CBOMA) : CBOMA := BOMA.C.RoutePairProbe001.mul z w

/-- Scalar additive reassociation needed by the explicit equational normalizer. -/
theorem r_add_left_comm_from_interface
    (C : RStageIntegrationCertificate) (a b c : RBOMA) :
    rAdd a (rAdd b c) = rAdd b (rAdd a c) := by
  calc
    rAdd a (rAdd b c) = rAdd (rAdd a b) c := (C.addAssoc a b c).symm
    _ = rAdd (rAdd b a) c := by rw [C.addComm a b]
    _ = rAdd b (rAdd a c) := C.addAssoc b a c

/-- Scalar multiplicative reassociation needed by the explicit normalizer. -/
theorem r_mul_left_comm_from_interface
    (C : RStageIntegrationCertificate) (a b c : RBOMA) :
    rMulCandidate a (rMulCandidate b c) =
      rMulCandidate b (rMulCandidate a c) := by
  calc
    rMulCandidate a (rMulCandidate b c) =
        rMulCandidate (rMulCandidate a b) c := (C.mulAssoc a b c).symm
    _ = rMulCandidate (rMulCandidate b a) c := by rw [C.mulComm a b]
    _ = rMulCandidate b (rMulCandidate a c) := C.mulAssoc b a c

/-- Distribution in the first scalar argument is derived, not assumed. -/
theorem r_mul_add_left_from_interface
    (C : RStageIntegrationCertificate) (a b c : RBOMA) :
    rMulCandidate (rAdd a b) c =
      rAdd (rMulCandidate a c) (rMulCandidate b c) := by
  calc
    rMulCandidate (rAdd a b) c = rMulCandidate c (rAdd a b) :=
      C.mulComm (rAdd a b) c
    _ = rAdd (rMulCandidate c a) (rMulCandidate c b) :=
      C.distribRight c a b
    _ = rAdd (rMulCandidate a c) (rMulCandidate b c) := by
      rw [C.mulComm c a, C.mulComm c b]

/-- Additive inverse distributes over scalar addition using inverse uniqueness. -/
theorem r_neg_add_from_interface
    (C : RStageIntegrationCertificate) (a b : RBOMA) :
    rNeg (rAdd a b) = rAdd (rNeg a) (rNeg b) := by
  have h : rAdd (rAdd a b) (rAdd (rNeg a) (rNeg b)) = rZero := by
    calc
      rAdd (rAdd a b) (rAdd (rNeg a) (rNeg b)) =
          rAdd a (rAdd b (rAdd (rNeg a) (rNeg b))) :=
        C.addAssoc a b (rAdd (rNeg a) (rNeg b))
      _ = rAdd a (rAdd (rNeg a) (rAdd b (rNeg b))) := by
        rw [r_add_left_comm_from_interface C b (rNeg a) (rNeg b)]
      _ = rAdd (rAdd a (rNeg a)) (rAdd b (rNeg b)) :=
        (C.addAssoc a (rNeg a) (rAdd b (rNeg b))).symm
      _ = rZero := by
        rw [C.addInverseRight a, C.addInverseRight b, C.addZeroLeft rZero]
  exact (add_inverse_unique_from_interface C h).symm

/-- The canonical complex zero and unit remain distinct. -/
theorem c_zero_ne_one (C : RStageIntegrationCertificate) :
    cZero ≠ cOne := by
  intro h
  exact C.nontrivial (congrArg BOMA.C.RoutePairProbe001.PairCandidate.re h)

/-- The selected real embedding is faithful. -/
theorem c_ofR_injective {a b : RBOMA} (h : cOfR a = cOfR b) : a = b :=
  BOMA.C.RoutePairProbe001.ofR_injective h

theorem c_add_comm (C : RStageIntegrationCertificate) (z w : CBOMA) :
    cAdd z w = cAdd w z := by
  apply c_ext
  · exact C.addComm z.re w.re
  · exact C.addComm z.im w.im

theorem c_add_assoc
    (C : RStageIntegrationCertificate) (z w v : CBOMA) :
    cAdd (cAdd z w) v = cAdd z (cAdd w v) := by
  apply c_ext
  · exact C.addAssoc z.re w.re v.re
  · exact C.addAssoc z.im w.im v.im

theorem c_add_zero_left (C : RStageIntegrationCertificate) (z : CBOMA) :
    cAdd cZero z = z := by
  apply c_ext
  · exact C.addZeroLeft z.re
  · exact C.addZeroLeft z.im

theorem c_add_zero_right (C : RStageIntegrationCertificate) (z : CBOMA) :
    cAdd z cZero = z := by
  rw [c_add_comm C z cZero, c_add_zero_left C z]

theorem c_add_neg_right (C : RStageIntegrationCertificate) (z : CBOMA) :
    cAdd z (cNeg z) = cZero := by
  apply c_ext
  · exact C.addInverseRight z.re
  · exact C.addInverseRight z.im

theorem c_add_neg_left (C : RStageIntegrationCertificate) (z : CBOMA) :
    cAdd (cNeg z) z = cZero := by
  rw [c_add_comm C (cNeg z) z, c_add_neg_right C z]

theorem c_neg_involutive (C : RStageIntegrationCertificate) (z : CBOMA) :
    cNeg (cNeg z) = z := by
  apply c_ext
  · exact neg_involutive_from_interface C z.re
  · exact neg_involutive_from_interface C z.im

theorem c_mul_comm (C : RStageIntegrationCertificate) (z w : CBOMA) :
    cMul z w = cMul w z := by
  cases z <;> cases w <;>
    simp [cMul, BOMA.C.RoutePairProbe001.mul, C.mulComm, C.addComm]

/-- Associativity is an explicit consequence of the accepted real ring laws. -/
theorem c_mul_assoc
    (C : RStageIntegrationCertificate) (z w v : CBOMA) :
    cMul (cMul z w) v = cMul z (cMul w v) := by
  cases z <;> cases w <;> cases v <;>
    simp [cMul, BOMA.C.RoutePairProbe001.mul,
      r_mul_add_left_from_interface C, C.distribRight,
      mul_neg_left_from_interface C, mul_neg_right_from_interface C,
      r_neg_add_from_interface C, neg_involutive_from_interface C,
      C.mulAssoc, C.mulComm, r_mul_left_comm_from_interface C,
      C.addAssoc, C.addComm, r_add_left_comm_from_interface C]

theorem c_mul_one_left (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul cOne z = z := by
  apply c_ext
  · change
      rAdd (rMulCandidate rOne z.re)
        (rNeg (rMulCandidate rZero z.im)) = z.re
    rw [C.mulOneLeft z.re, mul_zero_left_from_interface C z.im,
      neg_zero_from_interface C,
      BOMA.C.RoutePairProbe001.add_zero_right_from_interface C z.re]
  · change
      rAdd (rMulCandidate rOne z.im)
        (rMulCandidate rZero z.re) = z.im
    rw [C.mulOneLeft z.im, mul_zero_left_from_interface C z.re,
      BOMA.C.RoutePairProbe001.add_zero_right_from_interface C z.im]

theorem c_mul_one_right (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul z cOne = z := by
  rw [c_mul_comm C z cOne, c_mul_one_left C z]

/-- Right distribution is proved independently from the abstract real interface. -/
theorem c_mul_add_right
    (C : RStageIntegrationCertificate) (z w v : CBOMA) :
    cMul z (cAdd w v) = cAdd (cMul z w) (cMul z v) := by
  cases z <;> cases w <;> cases v <;>
    simp [cMul, cAdd, BOMA.C.RoutePairProbe001.mul,
      BOMA.C.RoutePairProbe001.add,
      r_mul_add_left_from_interface C, C.distribRight,
      mul_neg_left_from_interface C, mul_neg_right_from_interface C,
      r_neg_add_from_interface C, neg_involutive_from_interface C,
      C.mulAssoc, C.mulComm, r_mul_left_comm_from_interface C,
      C.addAssoc, C.addComm, r_add_left_comm_from_interface C]

theorem c_mul_add_left
    (C : RStageIntegrationCertificate) (z w v : CBOMA) :
    cMul (cAdd z w) v = cAdd (cMul z v) (cMul w v) := by
  calc
    cMul (cAdd z w) v = cMul v (cAdd z w) :=
      c_mul_comm C (cAdd z w) v
    _ = cAdd (cMul v z) (cMul v w) := c_mul_add_right C v z w
    _ = cAdd (cMul z v) (cMul w v) := by
      rw [c_mul_comm C v z, c_mul_comm C v w]

theorem c_mul_zero_left (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul cZero z = cZero := by
  apply c_ext
  · change
      rAdd (rMulCandidate rZero z.re)
        (rNeg (rMulCandidate rZero z.im)) = rZero
    rw [mul_zero_left_from_interface C z.re,
      mul_zero_left_from_interface C z.im,
      neg_zero_from_interface C, C.addZeroLeft rZero]
  · change
      rAdd (rMulCandidate rZero z.im)
        (rMulCandidate rZero z.re) = rZero
    rw [mul_zero_left_from_interface C z.im,
      mul_zero_left_from_interface C z.re, C.addZeroLeft rZero]

theorem c_mul_zero_right (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul z cZero = cZero := by
  rw [c_mul_comm C z cZero, c_mul_zero_left C z]

theorem c_ofR_zero : cOfR rZero = cZero := rfl

theorem c_ofR_one : cOfR rOne = cOne := rfl

theorem c_ofR_neg (C : RStageIntegrationCertificate) (a : RBOMA) :
    cOfR (rNeg a) = cNeg (cOfR a) := by
  apply c_ext
  · rfl
  · exact (neg_zero_from_interface C).symm

theorem c_ofR_add (C : RStageIntegrationCertificate) (a b : RBOMA) :
    cOfR (rAdd a b) = cAdd (cOfR a) (cOfR b) := by
  apply c_ext
  · rfl
  · exact (C.addZeroLeft rZero).symm

theorem c_ofR_mul (C : RStageIntegrationCertificate) (a b : RBOMA) :
    cOfR (rMulCandidate a b) = cMul (cOfR a) (cOfR b) := by
  apply c_ext
  · change
      rMulCandidate a b =
        rAdd (rMulCandidate a b) (rNeg (rMulCandidate rZero rZero))
    rw [mul_zero_left_from_interface C rZero,
      neg_zero_from_interface C,
      BOMA.C.RoutePairProbe001.add_zero_right_from_interface C
        (rMulCandidate a b)]
  · change
      rZero = rAdd (rMulCandidate a rZero) (rMulCandidate rZero b)
    rw [mul_zero_right_from_interface C a,
      mul_zero_left_from_interface C b, C.addZeroLeft rZero]

theorem c_i_squared (C : RStageIntegrationCertificate) :
    cMul cI cI = cNeg cOne :=
  BOMA.C.RoutePairProbe001.imag_squared C

theorem c_generation (C : RStageIntegrationCertificate) (z : CBOMA) :
    ∃ a b : RBOMA, z = cAdd (cOfR a) (cMul (cOfR b) cI) :=
  BOMA.C.RoutePairProbe001.decomposition C z

theorem c_coordinate_unique
    (C : RStageIntegrationCertificate) {a b a' b' : RBOMA}
    (h : cAdd (cOfR a) (cMul (cOfR b) cI) =
      cAdd (cOfR a') (cMul (cOfR b') cI)) :
    a = a' ∧ b = b' :=
  BOMA.C.RoutePairProbe001.decomposition_unique C h

theorem c_i_not_real (C : RStageIntegrationCertificate) :
    ¬ ∃ a : RBOMA, cI = cOfR a :=
  BOMA.C.RoutePairProbe001.imag_not_real C

/-- Precisely scoped selected-route integration surface: ring, not field. -/
structure CPairRingCoreCertificate where
  nontrivial : cZero ≠ cOne
  embeddingInjective : ∀ {a b : RBOMA}, cOfR a = cOfR b → a = b
  addComm : ∀ z w : CBOMA, cAdd z w = cAdd w z
  addAssoc : ∀ z w v : CBOMA, cAdd (cAdd z w) v = cAdd z (cAdd w v)
  addZeroLeft : ∀ z : CBOMA, cAdd cZero z = z
  addInverseRight : ∀ z : CBOMA, cAdd z (cNeg z) = cZero
  mulComm : ∀ z w : CBOMA, cMul z w = cMul w z
  mulAssoc : ∀ z w v : CBOMA, cMul (cMul z w) v = cMul z (cMul w v)
  mulOneLeft : ∀ z : CBOMA, cMul cOne z = z
  distribRight : ∀ z w v : CBOMA,
    cMul z (cAdd w v) = cAdd (cMul z w) (cMul z v)
  mulZeroRight : ∀ z : CBOMA, cMul z cZero = cZero
  embeddingZero : cOfR rZero = cZero
  embeddingOne : cOfR rOne = cOne
  embeddingNeg : ∀ a : RBOMA, cOfR (rNeg a) = cNeg (cOfR a)
  embeddingAdd : ∀ a b : RBOMA,
    cOfR (rAdd a b) = cAdd (cOfR a) (cOfR b)
  embeddingMul : ∀ a b : RBOMA,
    cOfR (rMulCandidate a b) = cMul (cOfR a) (cOfR b)
  imagSquared : cMul cI cI = cNeg cOne
  generation : ∀ z : CBOMA,
    ∃ a b : RBOMA, z = cAdd (cOfR a) (cMul (cOfR b) cI)
  coordinateUnique : ∀ {a b a' b' : RBOMA},
    cAdd (cOfR a) (cMul (cOfR b) cI) =
      cAdd (cOfR a') (cMul (cOfR b') cI) → a = a' ∧ b = b'
  imagNotReal : ¬ ∃ a : RBOMA, cI = cOfR a

/-- Abstract real-interface construction; no real representation is unfolded. -/
theorem cPairRingCoreCertificate
    (C : RStageIntegrationCertificate) : CPairRingCoreCertificate where
  nontrivial := c_zero_ne_one C
  embeddingInjective := @c_ofR_injective
  addComm := c_add_comm C
  addAssoc := c_add_assoc C
  addZeroLeft := c_add_zero_left C
  addInverseRight := c_add_neg_right C
  mulComm := c_mul_comm C
  mulAssoc := c_mul_assoc C
  mulOneLeft := c_mul_one_left C
  distribRight := c_mul_add_right C
  mulZeroRight := c_mul_zero_right C
  embeddingZero := c_ofR_zero
  embeddingOne := c_ofR_one
  embeddingNeg := c_ofR_neg C
  embeddingAdd := c_ofR_add C
  embeddingMul := c_ofR_mul C
  imagSquared := c_i_squared C
  generation := c_generation C
  coordinateUnique := @c_coordinate_unique C
  imagNotReal := c_i_not_real C

/-- Instantiate the ring-core certificate on the accepted Stage-One real export. -/
theorem cPairRingCoreCertificateFromAcceptedR : CPairRingCoreCertificate :=
  cPairRingCoreCertificate rStageIntegrationCertificate

end BOMA.C.PairCore001

/- PDSA-C-005: selected Route P conjugate, norm, and inverse witnesses.

Zero norm yields only double-negated zero coordinates at the abstract real
interface. That weaker constructive result suffices to contradict a supplied
nonzero complex hypothesis; no equality decision or inverse selector is needed.
-/
namespace BOMA.C.PairNormInverse001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001
open BOMA.C.PairCore001

/-- Conjugation reverses the selected imaginary coordinate. -/
def cConj (z : CBOMA) : CBOMA := ⟨z.re, rNeg z.im⟩

/-- The real-valued selected-coordinate norm is the sum of two squares. -/
def cNorm (z : CBOMA) : RBOMA :=
  rAdd (rMulCandidate z.re z.re) (rMulCandidate z.im z.im)

theorem c_conj_involutive
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    cConj (cConj z) = z := by
  apply c_ext
  · rfl
  · exact neg_involutive_from_interface C z.im

theorem c_conj_ofR
    (C : RStageIntegrationCertificate) (a : RBOMA) :
    cConj (cOfR a) = cOfR a := by
  apply c_ext
  · rfl
  · exact neg_zero_from_interface C

theorem c_conj_add
    (C : RStageIntegrationCertificate) (z w : CBOMA) :
    cConj (cAdd z w) = cAdd (cConj z) (cConj w) := by
  apply c_ext
  · rfl
  · exact r_neg_add_from_interface C z.im w.im

theorem c_norm_conj
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    cNorm (cConj z) = cNorm z := by
  change
    rAdd (rMulCandidate z.re z.re)
      (rMulCandidate (rNeg z.im) (rNeg z.im)) =
    rAdd (rMulCandidate z.re z.re)
      (rMulCandidate z.im z.im)
  rw [mul_neg_neg_same_from_interface C z.im]

/-- The norm product has exactly the embedded real norm and zero imaginary part. -/
theorem c_mul_conj
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul z (cConj z) = cOfR (cNorm z) := by
  apply c_ext
  · change
      rAdd (rMulCandidate z.re z.re)
        (rNeg (rMulCandidate z.im (rNeg z.im))) =
      rAdd (rMulCandidate z.re z.re) (rMulCandidate z.im z.im)
    rw [mul_neg_right_from_interface C z.im z.im,
      neg_involutive_from_interface C (rMulCandidate z.im z.im)]
  · change
      rAdd (rMulCandidate z.re (rNeg z.im))
        (rMulCandidate z.im z.re) = rZero
    rw [mul_neg_right_from_interface C z.re z.im,
      C.mulComm z.im z.re,
      C.addComm (rNeg (rMulCandidate z.re z.im))
        (rMulCandidate z.re z.im),
      C.addInverseRight (rMulCandidate z.re z.im)]

theorem c_conj_mul
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul (cConj z) z = cOfR (cNorm z) := by
  rw [c_mul_comm C (cConj z) z, c_mul_conj C z]

/-- A nonnegative sum equal to zero has zero first summand. -/
theorem r_nonnegative_sum_zero_left
    (C : RStageIntegrationCertificate) {a b : RBOMA}
    (h0a : rLE rZero a) (h0b : rLE rZero b)
    (hsum : rAdd a b = rZero) : a = rZero := by
  have ha0 : rLE a rZero := by
    have h := (C.addTranslateOrderIff rZero b a).2 h0b
    rw [C.addZeroLeft a, C.addComm b a, hsum] at h
    exact h
  exact C.orderAntisymm ha0 h0a

/-- A nonnegative sum equal to zero has zero second summand. -/
theorem r_nonnegative_sum_zero_right
    (C : RStageIntegrationCertificate) {a b : RBOMA}
    (h0a : rLE rZero a) (h0b : rLE rZero b)
    (hsum : rAdd a b = rZero) : b = rZero := by
  apply r_nonnegative_sum_zero_left C h0b h0a
  rw [C.addComm b a, hsum]

theorem c_norm_nonnegative
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    rLE rZero (cNorm z) := by
  have h0re := square_nonnegative_of_interface C z.re
  have h0im := square_nonnegative_of_interface C z.im
  have h :=
    (C.addTranslateOrderIff rZero
      (rMulCandidate z.im z.im) (rMulCandidate z.re z.re)).2 h0im
  rw [C.addZeroLeft (rMulCandidate z.re z.re),
    C.addComm (rMulCandidate z.im z.im)
      (rMulCandidate z.re z.re)] at h
  exact C.orderTrans h0re h

theorem c_norm_zero_real_square
    (C : RStageIntegrationCertificate) (z : CBOMA)
    (hnorm : cNorm z = rZero) :
    rMulCandidate z.re z.re = rZero := by
  exact r_nonnegative_sum_zero_left C
    (square_nonnegative_of_interface C z.re)
    (square_nonnegative_of_interface C z.im) hnorm

theorem c_norm_zero_imaginary_square
    (C : RStageIntegrationCertificate) (z : CBOMA)
    (hnorm : cNorm z = rZero) :
    rMulCandidate z.im z.im = rZero := by
  exact r_nonnegative_sum_zero_right C
    (square_nonnegative_of_interface C z.re)
    (square_nonnegative_of_interface C z.im) hnorm

/-- A zero real square contradicts any proposed nonzero real witness.

The conclusion is deliberately double-negated equality, not equality; the
abstract real interface does not provide stable or decidable equality. -/
theorem r_square_zero_not_nonzero
    (C : RStageIntegrationCertificate) {a : RBOMA}
    (hsquare : rMulCandidate a a = rZero) : ¬ a ≠ rZero := by
  intro hnonzero
  rcases C.inverseExists a hnonzero with ⟨t, ht⟩
  have hzero : a = rZero := by
    calc
      a = rMulCandidate a rOne :=
        (BOMA.C.RoutePairProbe001.mul_one_right_from_interface C a).symm
      _ = rMulCandidate a (rMulCandidate a t) := by rw [ht]
      _ = rMulCandidate (rMulCandidate a a) t :=
        (C.mulAssoc a a t).symm
      _ = rMulCandidate rZero t := by rw [hsquare]
      _ = rZero := mul_zero_left_from_interface C t
  exact hnonzero hzero

/-- Zero norm entails only double-negated zero coordinates and zero complex value. -/
theorem c_norm_zero_not_nonzero
    (C : RStageIntegrationCertificate) (z : CBOMA)
    (hnorm : cNorm z = rZero) : ¬ z ≠ cZero := by
  intro hnonzero
  have hre := r_square_zero_not_nonzero C
    (c_norm_zero_real_square C z hnorm)
  have him := r_square_zero_not_nonzero C
    (c_norm_zero_imaginary_square C z hnorm)
  apply hre
  intro hzre
  apply him
  intro hzim
  apply hnonzero
  apply c_ext
  · exact hzre
  · exact hzim

/-- A supplied nonzero complex hypothesis constructively makes its norm nonzero. -/
theorem c_norm_nonzero
    (C : RStageIntegrationCertificate) {z : CBOMA}
    (hnonzero : z ≠ cZero) : cNorm z ≠ rZero := by
  intro hnorm
  exact c_norm_zero_not_nonzero C z hnorm hnonzero

/-- A real inverse witness for the norm determines a complex inverse witness. -/
theorem c_inverse_from_real_witness
    (C : RStageIntegrationCertificate) (z : CBOMA) (t : RBOMA)
    (ht : rMulCandidate (cNorm z) t = rOne) :
    cMul z (cMul (cOfR t) (cConj z)) = cOne := by
  calc
    cMul z (cMul (cOfR t) (cConj z)) =
        cMul z (cMul (cConj z) (cOfR t)) := by
      rw [c_mul_comm C (cOfR t) (cConj z)]
    _ = cMul (cMul z (cConj z)) (cOfR t) :=
      (c_mul_assoc C z (cConj z) (cOfR t)).symm
    _ = cMul (cOfR (cNorm z)) (cOfR t) := by rw [c_mul_conj C z]
    _ = cOfR (rMulCandidate (cNorm z) t) :=
      (c_ofR_mul C (cNorm z) t).symm
    _ = cOfR rOne := by rw [ht]
    _ = cOne := c_ofR_one

/-- The field interface supplies existential witnesses, never a global selector. -/
theorem c_inverse_exists
    (C : RStageIntegrationCertificate) (z : CBOMA)
    (hnonzero : z ≠ cZero) :
    ∃ w : CBOMA, cMul z w = cOne := by
  rcases C.inverseExists (cNorm z) (c_norm_nonzero C hnonzero) with ⟨t, ht⟩
  exact ⟨cMul (cOfR t) (cConj z), c_inverse_from_real_witness C z t ht⟩

theorem c_inverse_left_of_right
    (C : RStageIntegrationCertificate) {z w : CBOMA}
    (hzw : cMul z w = cOne) :
    cMul w z = cOne := by
  rw [c_mul_comm C w z, hzw]

/-- Inverse witnesses are unique by the already verified ring laws. -/
theorem c_inverse_unique
    (C : RStageIntegrationCertificate) {z w v : CBOMA}
    (hw : cMul z w = cOne)
    (hv : cMul z v = cOne) : w = v := by
  calc
    w = cMul w cOne := (c_mul_one_right C w).symm
    _ = cMul w (cMul z v) := by rw [hv]
    _ = cMul (cMul w z) v := (c_mul_assoc C w z v).symm
    _ = cMul cOne v := by rw [c_mul_comm C w z, hw]
    _ = v := c_mul_one_left C v

/-- Complete selected-route field-strength certificate with witness-only inversion. -/
structure CPairFieldCertificate where
  ring : CPairRingCoreCertificate
  normNonnegative : ∀ z : CBOMA, rLE rZero (cNorm z)
  normNonzero : ∀ z : CBOMA, z ≠ cZero → cNorm z ≠ rZero
  conjugateProduct : ∀ z : CBOMA, cMul z (cConj z) = cOfR (cNorm z)
  inverseExists : ∀ z : CBOMA, z ≠ cZero → ∃ w : CBOMA, cMul z w = cOne
  inverseUnique : ∀ {z w v : CBOMA},
    cMul z w = cOne → cMul z v = cOne → w = v

/-- Field closure is derived from the abstract accepted real certificate alone. -/
theorem cPairFieldCertificate
    (C : RStageIntegrationCertificate) : CPairFieldCertificate where
  ring := cPairRingCoreCertificate C
  normNonnegative := c_norm_nonnegative C
  normNonzero := fun _ h => c_norm_nonzero C h
  conjugateProduct := c_mul_conj C
  inverseExists := c_inverse_exists C
  inverseUnique := @c_inverse_unique C

/-- Instantiate the witness-field certificate on the accepted real export. -/
theorem cPairFieldCertificateFromAcceptedR : CPairFieldCertificate :=
  cPairFieldCertificate rStageIntegrationCertificate

end BOMA.C.PairNormInverse001

/- PDSA-C-006: representation-neutral quadratic-field comparison.

Every accepted quadratic presentation has a canonical, total, single-valued,
invertible algebra-equivalence graph. Genuine inverse functions are obtained
only when both candidates provide constructive coordinate extractors as data.
-/
namespace BOMA.C.QuadraticComparison001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.PairCore001
open BOMA.C.PairNormInverse001

/-- Common mathematical quadratic-field interface, independent of carrier identity. -/
structure QuadraticFieldPresentation (R : RStageIntegrationCertificate) where
  carrier : Type
  zero : carrier
  one : carrier
  neg : carrier → carrier
  add : carrier → carrier → carrier
  mul : carrier → carrier → carrier
  ofR : RBOMA → carrier
  imag : carrier
  coord : RBOMA → RBOMA → carrier
  nontrivial : zero ≠ one
  addComm : ∀ x y : carrier, add x y = add y x
  addAssoc : ∀ x y z : carrier, add (add x y) z = add x (add y z)
  addZeroLeft : ∀ x : carrier, add zero x = x
  addInverseRight : ∀ x : carrier, add x (neg x) = zero
  mulComm : ∀ x y : carrier, mul x y = mul y x
  mulAssoc : ∀ x y z : carrier, mul (mul x y) z = mul x (mul y z)
  mulOneLeft : ∀ x : carrier, mul one x = x
  distribRight : ∀ x y z : carrier, mul x (add y z) = add (mul x y) (mul x z)
  inverseExists : ∀ x : carrier, x ≠ zero → ∃ y : carrier, mul x y = one
  inverseUnique : ∀ {x y z : carrier}, mul x y = one → mul x z = one → y = z
  embeddingInjective : ∀ {a b : RBOMA}, ofR a = ofR b → a = b
  embeddingZero : ofR rZero = zero
  embeddingOne : ofR rOne = one
  embeddingNeg : ∀ a : RBOMA, ofR (rNeg a) = neg (ofR a)
  embeddingAdd : ∀ a b : RBOMA, ofR (rAdd a b) = add (ofR a) (ofR b)
  embeddingMul : ∀ a b : RBOMA,
    ofR (rMulCandidate a b) = mul (ofR a) (ofR b)
  imagSquared : mul imag imag = neg one
  coordinateExpression : ∀ a b : RBOMA,
    coord a b = add (ofR a) (mul (ofR b) imag)
  coordinateGeneration : ∀ x : carrier, ∃ a b : RBOMA, x = coord a b
  coordinateUnique : ∀ {a b c d : RBOMA},
    coord a b = coord c d → a = c ∧ b = d
  coordinateZero : coord rZero rZero = zero
  coordinateOne : coord rOne rZero = one
  coordinateReal : ∀ a : RBOMA, coord a rZero = ofR a
  coordinateImag : coord rZero rOne = imag
  coordinateNeg : ∀ a b : RBOMA,
    neg (coord a b) = coord (rNeg a) (rNeg b)
  coordinateAdd : ∀ a b c d : RBOMA,
    add (coord a b) (coord c d) = coord (rAdd a c) (rAdd b d)
  coordinateMul : ∀ a b c d : RBOMA,
    mul (coord a b) (coord c d) =
      coord
        (rAdd (rMulCandidate a c) (rNeg (rMulCandidate b d)))
        (rAdd (rMulCandidate a d) (rMulCandidate b c))

/-- The selected Route P field instantiates the carrier-neutral common contract. -/
def selectedPresentation
    (R : RStageIntegrationCertificate) : QuadraticFieldPresentation R where
  carrier := CBOMA
  zero := cZero
  one := cOne
  neg := cNeg
  add := cAdd
  mul := cMul
  ofR := cOfR
  imag := cI
  coord := fun a b => ⟨a, b⟩
  nontrivial := c_zero_ne_one R
  addComm := c_add_comm R
  addAssoc := c_add_assoc R
  addZeroLeft := c_add_zero_left R
  addInverseRight := c_add_neg_right R
  mulComm := c_mul_comm R
  mulAssoc := c_mul_assoc R
  mulOneLeft := c_mul_one_left R
  distribRight := c_mul_add_right R
  inverseExists := c_inverse_exists R
  inverseUnique := @c_inverse_unique R
  embeddingInjective := @c_ofR_injective
  embeddingZero := c_ofR_zero
  embeddingOne := c_ofR_one
  embeddingNeg := c_ofR_neg R
  embeddingAdd := c_ofR_add R
  embeddingMul := c_ofR_mul R
  imagSquared := c_i_squared R
  coordinateExpression := by
    intro a b
    exact (BOMA.C.RoutePairProbe001.coordinate_expression R a b).symm
  coordinateGeneration := by
    intro z
    exact ⟨z.re, z.im, by cases z; rfl⟩
  coordinateUnique := by
    intro a b c d h
    exact ⟨congrArg BOMA.C.RoutePairProbe001.PairCandidate.re h,
      congrArg BOMA.C.RoutePairProbe001.PairCandidate.im h⟩
  coordinateZero := rfl
  coordinateOne := rfl
  coordinateReal := by intro a; rfl
  coordinateImag := rfl
  coordinateNeg := by intro a b; rfl
  coordinateAdd := by intro a b c d; rfl
  coordinateMul := by intro a b c d; rfl

/-- Same accepted-real coefficients define the canonical comparison graph. -/
def Related {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (x : A.carrier) (y : B.carrier) : Prop :=
  ∃ a b : RBOMA, x = A.coord a b ∧ y = B.coord a b

theorem related_total_left {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (x : A.carrier) :
    ∃ y : B.carrier, Related A B x y := by
  rcases A.coordinateGeneration x with ⟨a, b, hx⟩
  exact ⟨B.coord a b, a, b, hx, rfl⟩

theorem related_total_right {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (y : B.carrier) :
    ∃ x : A.carrier, Related A B x y := by
  rcases B.coordinateGeneration y with ⟨a, b, hy⟩
  exact ⟨A.coord a b, a, b, rfl, hy⟩

theorem related_right_unique {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x : A.carrier} {y z : B.carrier}
    (hy : Related A B x y) (hz : Related A B x z) : y = z := by
  rcases hy with ⟨a, b, hxa, hya⟩
  rcases hz with ⟨c, d, hxc, hzc⟩
  rcases A.coordinateUnique (hxa.symm.trans hxc) with ⟨hac, hbd⟩
  cases hac
  cases hbd
  exact hya.trans hzc.symm

theorem related_left_unique {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x z : A.carrier} {y : B.carrier}
    (hx : Related A B x y) (hz : Related A B z y) : x = z := by
  rcases hx with ⟨a, b, hxa, hya⟩
  rcases hz with ⟨c, d, hzc, hyc⟩
  rcases B.coordinateUnique (hya.symm.trans hyc) with ⟨hac, hbd⟩
  cases hac
  cases hbd
  exact hxa.trans hzc.symm

theorem related_symm {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x : A.carrier} {y : B.carrier}
    (h : Related A B x y) : Related B A y x := by
  rcases h with ⟨a, b, hx, hy⟩
  exact ⟨a, b, hy, hx⟩

theorem related_zero {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) :
    Related A B A.zero B.zero :=
  ⟨rZero, rZero, A.coordinateZero.symm, B.coordinateZero.symm⟩

theorem related_one {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) :
    Related A B A.one B.one :=
  ⟨rOne, rZero, A.coordinateOne.symm, B.coordinateOne.symm⟩

theorem related_real {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (a : RBOMA) :
    Related A B (A.ofR a) (B.ofR a) :=
  ⟨a, rZero, (A.coordinateReal a).symm, (B.coordinateReal a).symm⟩

theorem related_imag {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) :
    Related A B A.imag B.imag :=
  ⟨rZero, rOne, A.coordinateImag.symm, B.coordinateImag.symm⟩

theorem related_neg {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x : A.carrier} {y : B.carrier}
    (h : Related A B x y) : Related A B (A.neg x) (B.neg y) := by
  rcases h with ⟨a, b, hx, hy⟩
  refine ⟨rNeg a, rNeg b, ?_, ?_⟩
  · rw [hx, A.coordinateNeg a b]
  · rw [hy, B.coordinateNeg a b]

theorem related_add {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w) :
    Related A B (A.add x z) (B.add y w) := by
  rcases hxy with ⟨a, b, hx, hy⟩
  rcases hzw with ⟨c, d, hz, hw⟩
  refine ⟨rAdd a c, rAdd b d, ?_, ?_⟩
  · rw [hx, hz, A.coordinateAdd a b c d]
  · rw [hy, hw, B.coordinateAdd a b c d]

theorem related_mul {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w) :
    Related A B (A.mul x z) (B.mul y w) := by
  rcases hxy with ⟨a, b, hx, hy⟩
  rcases hzw with ⟨c, d, hz, hw⟩
  refine ⟨rAdd (rMulCandidate a c) (rNeg (rMulCandidate b d)),
    rAdd (rMulCandidate a d) (rMulCandidate b c), ?_, ?_⟩
  · rw [hx, hz, A.coordinateMul a b c d]
  · rw [hy, hw, B.coordinateMul a b c d]

theorem related_inverse_witness {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w)
    (hxz : A.mul x z = A.one) : B.mul y w = B.one := by
  have h := related_mul A B hxy hzw
  rw [hxz] at h
  exact related_right_unique A B h (related_one A B)

/-- Universal comparison package: an invertible field/algebra graph relation. -/
structure QuadraticComparisonCertificate {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) where
  totalLeft : ∀ x : A.carrier, ∃ y : B.carrier, Related A B x y
  totalRight : ∀ y : B.carrier, ∃ x : A.carrier, Related A B x y
  uniqueRight : ∀ {x : A.carrier} {y z : B.carrier},
    Related A B x y → Related A B x z → y = z
  uniqueLeft : ∀ {x z : A.carrier} {y : B.carrier},
    Related A B x y → Related A B z y → x = z
  preserveZero : Related A B A.zero B.zero
  preserveOne : Related A B A.one B.one
  preserveReal : ∀ a : RBOMA, Related A B (A.ofR a) (B.ofR a)
  preserveImag : Related A B A.imag B.imag
  preserveNeg : ∀ {x : A.carrier} {y : B.carrier},
    Related A B x y → Related A B (A.neg x) (B.neg y)
  preserveAdd : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      Related A B (A.add x z) (B.add y w)
  preserveMul : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      Related A B (A.mul x z) (B.mul y w)
  preserveInverse : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      A.mul x z = A.one → B.mul y w = B.one

/-- Any two accepted common presentations admit a canonical algebra-equivalence graph. -/
theorem quadraticComparison
    {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) :
    QuadraticComparisonCertificate A B where
  totalLeft := related_total_left A B
  totalRight := related_total_right A B
  uniqueRight := @related_right_unique R A B
  uniqueLeft := @related_left_unique R A B
  preserveZero := related_zero A B
  preserveOne := related_one A B
  preserveReal := related_real A B
  preserveImag := related_imag A B
  preserveNeg := @related_neg R A B
  preserveAdd := @related_add R A B
  preserveMul := @related_mul R A B
  preserveInverse := @related_inverse_witness R A B

/-- Explicit constructive coordinate data; not inferred from propositional existence. -/
structure CoordinateExtractor {R : RStageIntegrationCertificate}
    (A : QuadraticFieldPresentation R) where
  re : A.carrier → RBOMA
  im : A.carrier → RBOMA
  sound : ∀ x : A.carrier, x = A.coord (re x) (im x)

/-- Route P supplies projections directly; no global selection principle is used. -/
def selectedExtractor
    (R : RStageIntegrationCertificate) :
    CoordinateExtractor (selectedPresentation R) where
  re := fun z => z.re
  im := fun z => z.im
  sound := by intro z; cases z; rfl

/-- A genuine comparison function exists when its source supplies extraction data. -/
def coordinateMap {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (E : CoordinateExtractor A) (x : A.carrier) : B.carrier :=
  B.coord (E.re x) (E.im x)

theorem coordinate_map_related {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (E : CoordinateExtractor A) (x : A.carrier) :
    Related A B x (coordinateMap A B E x) :=
  ⟨E.re x, E.im x, E.sound x, rfl⟩

theorem coordinate_map_zero {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A) :
    coordinateMap A B E A.zero = B.zero :=
  related_right_unique A B
    (coordinate_map_related A B E A.zero) (related_zero A B)

theorem coordinate_map_one {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A) :
    coordinateMap A B E A.one = B.one :=
  related_right_unique A B
    (coordinate_map_related A B E A.one) (related_one A B)

theorem coordinate_map_real {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A)
    (a : RBOMA) :
    coordinateMap A B E (A.ofR a) = B.ofR a :=
  related_right_unique A B
    (coordinate_map_related A B E (A.ofR a)) (related_real A B a)

theorem coordinate_map_imag {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A) :
    coordinateMap A B E A.imag = B.imag :=
  related_right_unique A B
    (coordinate_map_related A B E A.imag) (related_imag A B)

theorem coordinate_map_neg {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A)
    (x : A.carrier) :
    coordinateMap A B E (A.neg x) = B.neg (coordinateMap A B E x) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.neg x))
    (related_neg A B (coordinate_map_related A B E x))

theorem coordinate_map_add {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A)
    (x y : A.carrier) :
    coordinateMap A B E (A.add x y) =
      B.add (coordinateMap A B E x) (coordinateMap A B E y) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.add x y))
    (related_add A B
      (coordinate_map_related A B E x)
      (coordinate_map_related A B E y))

theorem coordinate_map_mul {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A)
    (x y : A.carrier) :
    coordinateMap A B E (A.mul x y) =
      B.mul (coordinateMap A B E x) (coordinateMap A B E y) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.mul x y))
    (related_mul A B
      (coordinate_map_related A B E x)
      (coordinate_map_related A B E y))

theorem coordinate_maps_inverse_left {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B)
    (x : A.carrier) :
    coordinateMap B A EB (coordinateMap A B EA x) = x := by
  have hforward := coordinate_map_related A B EA x
  have hbackward :=
    related_symm B A
      (coordinate_map_related B A EB (coordinateMap A B EA x))
  exact related_left_unique A B hbackward hforward

theorem coordinate_maps_inverse_right {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B)
    (y : B.carrier) :
    coordinateMap A B EA (coordinateMap B A EB y) = y :=
  coordinate_maps_inverse_left B A EB EA y

/-- Genuine inverse algebra maps, conditional on explicit constructive extractors. -/
structure ConstructiveQuadraticIsomorphism {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) where
  forward : A.carrier → B.carrier
  backward : B.carrier → A.carrier
  leftInverse : ∀ x : A.carrier, backward (forward x) = x
  rightInverse : ∀ y : B.carrier, forward (backward y) = y
  preserveZero : forward A.zero = B.zero
  preserveOne : forward A.one = B.one
  preserveReal : ∀ a : RBOMA, forward (A.ofR a) = B.ofR a
  preserveImag : forward A.imag = B.imag
  preserveNeg : ∀ x : A.carrier, forward (A.neg x) = B.neg (forward x)
  preserveAdd : ∀ x y : A.carrier,
    forward (A.add x y) = B.add (forward x) (forward y)
  preserveMul : ∀ x y : A.carrier,
    forward (A.mul x y) = B.mul (forward x) (forward y)

/-- Actual functional R-field isomorphism requires extractor data on both sides. -/
def constructiveQuadraticIsomorphism
    {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B) :
    ConstructiveQuadraticIsomorphism A B where
  forward := coordinateMap A B EA
  backward := coordinateMap B A EB
  leftInverse := coordinate_maps_inverse_left A B EA EB
  rightInverse := coordinate_maps_inverse_right A B EA EB
  preserveZero := coordinate_map_zero A B EA
  preserveOne := coordinate_map_one A B EA
  preserveReal := coordinate_map_real A B EA
  preserveImag := coordinate_map_imag A B EA
  preserveNeg := coordinate_map_neg A B EA
  preserveAdd := coordinate_map_add A B EA
  preserveMul := coordinate_map_mul A B EA

/-- The selected presentation satisfies the universal comparison obligation. -/
theorem selectedQuadraticComparison
    (R : RStageIntegrationCertificate)
    (B : QuadraticFieldPresentation R) :
    QuadraticComparisonCertificate (selectedPresentation R) B :=
  quadraticComparison (selectedPresentation R) B

/-- Selected Route P compares functionally with every constructively coordinatized peer. -/
def selectedConstructiveQuadraticIsomorphism
    (R : RStageIntegrationCertificate)
    (B : QuadraticFieldPresentation R)
    (EB : CoordinateExtractor B) :
    ConstructiveQuadraticIsomorphism (selectedPresentation R) B :=
  constructiveQuadraticIsomorphism
    (selectedPresentation R) B (selectedExtractor R) EB

/-- The accepted-real selected presentation has a verified self-comparison. -/
theorem acceptedSelectedSelfComparison :
    QuadraticComparisonCertificate
      (selectedPresentation rStageIntegrationCertificate)
      (selectedPresentation rStageIntegrationCertificate) :=
  quadraticComparison
    (selectedPresentation rStageIntegrationCertificate)
    (selectedPresentation rStageIntegrationCertificate)

end BOMA.C.QuadraticComparison001

/- PDSA-C-007: same-carrier complex integration and quadratic comparison. -/
namespace BOMA.C.StageIntegration001

open BOMA.R.DedekindQuotient001
open BOMA.R.StageIntegration002
open BOMA.C.PairCore001
open BOMA.C.PairNormInverse001
open BOMA.C.QuadraticComparison001

/-- CA-19 packages every required component on the one selected complex carrier. -/
structure CStageIntegrationCertificate where
  field : CPairFieldCertificate
  generatorSquared : cMul cI cI = cNeg cOne
  realGeneration : ∀ z : CBOMA,
    ∃ a b : RBOMA, z = cAdd (cOfR a) (cMul (cOfR b) cI)
  coordinateUnique : ∀ {a b c d : RBOMA},
    cAdd (cOfR a) (cMul (cOfR b) cI) =
      cAdd (cOfR c) (cMul (cOfR d) cI) → a = c ∧ b = d
  imaginaryNotReal : ¬ ∃ a : RBOMA, cI = cOfR a
  comparison : ∀ (B : QuadraticFieldPresentation rStageIntegrationCertificate),
    QuadraticComparisonCertificate
      (selectedPresentation rStageIntegrationCertificate) B
  functionalComparison : ∀ (B : QuadraticFieldPresentation rStageIntegrationCertificate),
    CoordinateExtractor B →
      ConstructiveQuadraticIsomorphism
        (selectedPresentation rStageIntegrationCertificate) B

/-- Final certificate adds no carrier, operation, inverse selector, or logical commitment. -/
def cStageIntegrationCertificate : CStageIntegrationCertificate where
  field := cPairFieldCertificateFromAcceptedR
  generatorSquared := c_i_squared rStageIntegrationCertificate
  realGeneration := c_generation rStageIntegrationCertificate
  coordinateUnique := @c_coordinate_unique rStageIntegrationCertificate
  imaginaryNotReal := c_i_not_real rStageIntegrationCertificate
  comparison := selectedQuadraticComparison rStageIntegrationCertificate
  functionalComparison :=
    selectedConstructiveQuadraticIsomorphism rStageIntegrationCertificate

end BOMA.C.StageIntegration001

/- PDSA-C-003 Route Q: noncanonical quadratic-expression quotient probe.

This is a formal-expression / normalization / quotient-style adjunction
candidate. It is not a claim that a full polynomial ring R[X] has already
been constructed. All coefficient-normal-form declarations are local to this
namespace; the source does not import the Route P probe.
-/
namespace BOMA.C.RouteQuadraticQuotientProbe001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001

/-- Route-Q-local quadratic normal form; independent of Route P declarations. -/
structure NormalForm where
  re : RBOMA
  im : RBOMA

/-- Core Lean does not supply a generated structure-extensionality lemma. -/
theorem normal_ext {u v : NormalForm}
    (hre : u.re = v.re) (him : u.im = v.im) :
    u = v := by
  cases u
  cases v
  cases hre
  cases him
  rfl

def nfReal (a : RBOMA) : NormalForm := ⟨a, rZero⟩
def nfImag : NormalForm := ⟨rZero, rOne⟩

def nfNeg (u : NormalForm) : NormalForm :=
  ⟨rNeg u.re, rNeg u.im⟩

def nfAdd (u v : NormalForm) : NormalForm :=
  ⟨rAdd u.re v.re, rAdd u.im v.im⟩

def nfMul (u v : NormalForm) : NormalForm :=
  ⟨rAdd (rMulCandidate u.re v.re)
      (rNeg (rMulCandidate u.im v.im)),
   rAdd (rMulCandidate u.re v.im)
      (rMulCandidate u.im v.re)⟩

/-- Freely written finite quadratic-adjunction expressions. -/
inductive Expr where
  | coeff : RBOMA → Expr
  | generator : Expr
  | neg : Expr → Expr
  | add : Expr → Expr → Expr
  | mul : Expr → Expr → Expr

/-- Evaluation modulo the declared generator relation X² = -1. -/
def normalize : Expr → NormalForm
  | .coeff a => nfReal a
  | .generator => nfImag
  | .neg e => nfNeg (normalize e)
  | .add e f => nfAdd (normalize e) (normalize f)
  | .mul e f => nfMul (normalize e) (normalize f)

def exprEquiv (e f : Expr) : Prop := normalize e = normalize f

def exprSetoid : Setoid Expr where
  r := exprEquiv
  iseqv :=
    ⟨(fun _ => rfl),
      (fun h => h.symm),
      (fun h₁ h₂ => h₁.trans h₂)⟩

/-- Route-Q carrier: syntax modulo equal quadratic normal forms. -/
def QuotientCandidate : Type := Quotient exprSetoid

def qmk (e : Expr) : QuotientCandidate :=
  Quotient.mk exprSetoid e

theorem qmk_eq_iff {e f : Expr} :
    qmk e = qmk f ↔ normalize e = normalize f := by
  constructor
  · intro h
    exact Quotient.exact h
  · intro h
    exact Quotient.sound h

theorem neg_respects {e e' : Expr}
    (h : exprEquiv e e') :
    exprEquiv (.neg e) (.neg e') := by
  change nfNeg (normalize e) = nfNeg (normalize e')
  rw [h]

theorem add_respects {e e' f f' : Expr}
    (he : exprEquiv e e')
    (hf : exprEquiv f f') :
    exprEquiv (.add e f) (.add e' f') := by
  change nfAdd (normalize e) (normalize f) =
    nfAdd (normalize e') (normalize f')
  rw [he, hf]

theorem mul_respects {e e' f f' : Expr}
    (he : exprEquiv e e')
    (hf : exprEquiv f f') :
    exprEquiv (.mul e f) (.mul e' f') := by
  change nfMul (normalize e) (normalize f) =
    nfMul (normalize e') (normalize f')
  rw [he, hf]

def neg : QuotientCandidate → QuotientCandidate :=
  Quotient.lift
    (fun e => qmk (.neg e))
    (fun _ _ h => Quotient.sound (neg_respects h))

def add : QuotientCandidate → QuotientCandidate → QuotientCandidate :=
  Quotient.lift₂
    (fun e f => qmk (.add e f))
    (fun _ _ _ _ he hf => Quotient.sound (add_respects he hf))

def mul : QuotientCandidate → QuotientCandidate → QuotientCandidate :=
  Quotient.lift₂
    (fun e f => qmk (.mul e f))
    (fun _ _ _ _ he hf => Quotient.sound (mul_respects he hf))

def ofR (a : RBOMA) : QuotientCandidate := qmk (.coeff a)
def zero : QuotientCandidate := ofR rZero
def one : QuotientCandidate := ofR rOne
def imag : QuotientCandidate := qmk .generator

theorem add_zero_right_from_interface
    (C : RStageIntegrationCertificate) (x : RBOMA) :
    rAdd x rZero = x := by
  calc
    rAdd x rZero = rAdd rZero x := C.addComm x rZero
    _ = x := C.addZeroLeft x

theorem mul_one_right_from_interface
    (C : RStageIntegrationCertificate) (x : RBOMA) :
    rMulCandidate x rOne = x := by
  calc
    rMulCandidate x rOne = rMulCandidate rOne x := C.mulComm x rOne
    _ = x := C.mulOneLeft x

/-- P/Q-03: quotient identity preserves faithful real coefficients. -/
theorem ofR_injective {a b : RBOMA}
    (h : ofR a = ofR b) : a = b := by
  have hn : normalize (.coeff a) = normalize (.coeff b) :=
    (qmk_eq_iff.mp h)
  exact congrArg NormalForm.re hn

/-- Route-local normal form of a formal real-plus-imaginary expression. -/
theorem normalized_coordinate_expression
    (C : RStageIntegrationCertificate) (a b : RBOMA) :
    normalize (.add (.coeff a) (.mul (.coeff b) .generator)) =
      ⟨a, b⟩ := by
  apply normal_ext
  · change
      rAdd a
        (rAdd (rMulCandidate b rZero)
          (rNeg (rMulCandidate rZero rOne))) = a
    rw [mul_zero_right_from_interface C b,
        mul_zero_left_from_interface C rOne,
        neg_zero_from_interface C,
        C.addZeroLeft rZero,
        add_zero_right_from_interface C a]
  · change
      rAdd rZero
        (rAdd (rMulCandidate b rOne)
          (rMulCandidate rZero rZero)) = b
    rw [mul_one_right_from_interface C b,
        mul_zero_left_from_interface C rZero,
        add_zero_right_from_interface C b,
        C.addZeroLeft b]

/-- P/Q-06: quotient identity enforces the declared quadratic relation. -/
theorem imag_squared
    (C : RStageIntegrationCertificate) :
    mul imag imag = neg one := by
  apply Quotient.sound
  change nfMul nfImag nfImag = nfNeg (nfReal rOne)
  apply normal_ext
  · change
      rAdd (rMulCandidate rZero rZero)
        (rNeg (rMulCandidate rOne rOne)) = rNeg rOne
    rw [mul_zero_left_from_interface C rZero,
        C.mulOneLeft rOne,
        C.addZeroLeft (rNeg rOne)]
  · change
      rAdd (rMulCandidate rZero rOne)
        (rMulCandidate rOne rZero) = rNeg rZero
    rw [mul_zero_left_from_interface C rOne,
        C.mulOneLeft rZero,
        C.addZeroLeft rZero,
        neg_zero_from_interface C]

/-- Every raw expression is equivalent to its declared quadratic normal form. -/
theorem representative_decomposition
    (C : RStageIntegrationCertificate) (e : Expr) :
    qmk e =
      add (ofR (normalize e).re)
        (mul (ofR (normalize e).im) imag) := by
  apply Quotient.sound
  change
    normalize e =
      normalize
        (.add (.coeff (normalize e).re)
          (.mul (.coeff (normalize e).im) .generator))
  rw [normalized_coordinate_expression C
      (normalize e).re (normalize e).im]

/-- P/Q-07: every quotient value has a real/imaginary decomposition. -/
theorem decomposition
    (C : RStageIntegrationCertificate) (z : QuotientCandidate) :
    ∃ a b : RBOMA, z = add (ofR a) (mul (ofR b) imag) := by
  refine Quotient.inductionOn z ?_
  intro e
  exact ⟨(normalize e).re, (normalize e).im,
    representative_decomposition C e⟩

/-- P/Q-08: quotient equality retains unique real/imaginary coordinates. -/
theorem decomposition_unique
    (C : RStageIntegrationCertificate)
    {a b a' b' : RBOMA}
    (h : add (ofR a) (mul (ofR b) imag) =
      add (ofR a') (mul (ofR b') imag)) :
    a = a' ∧ b = b' := by
  have hn :
      normalize (.add (.coeff a) (.mul (.coeff b) .generator)) =
      normalize (.add (.coeff a') (.mul (.coeff b') .generator)) :=
    Quotient.exact h
  rw [normalized_coordinate_expression C a b,
      normalized_coordinate_expression C a' b'] at hn
  exact ⟨congrArg NormalForm.re hn,
         congrArg NormalForm.im hn⟩

/-- P/Q-09: the quotient generator cannot equal an embedded real. -/
theorem imag_not_real
    (C : RStageIntegrationCertificate) :
    ¬ ∃ a : RBOMA, imag = ofR a := by
  rintro ⟨a, ha⟩
  have hn : normalize .generator = normalize (.coeff a) :=
    Quotient.exact ha
  have h : rOne = rZero := congrArg NormalForm.im hn
  exact C.nontrivial h.symm

end BOMA.C.RouteQuadraticQuotientProbe001

/- ST2-EXP-002: independent Route-Q-local quadratic normal-form operations.
This source reuses only Route Q's own NormalForm and accepted real interface. -/
namespace BOMA.C.StageTwo.QNormalRoute002

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001

/-- Q-local normalization carrier: never the selected Route P carrier. -/
abbrev NormalForm : Type := BOMA.C.RouteQuadraticQuotientProbe001.NormalForm

theorem normal_ext {u v : NormalForm}
    (hre : u.re = v.re) (him : u.im = v.im) :
    u = v :=
  BOMA.C.RouteQuadraticQuotientProbe001.normal_ext hre him

def zero : NormalForm := BOMA.C.RouteQuadraticQuotientProbe001.nfReal rZero
def one : NormalForm := BOMA.C.RouteQuadraticQuotientProbe001.nfReal rOne
def ofR (a : RBOMA) : NormalForm := BOMA.C.RouteQuadraticQuotientProbe001.nfReal a
def imag : NormalForm := BOMA.C.RouteQuadraticQuotientProbe001.nfImag
def neg (u : NormalForm) : NormalForm := BOMA.C.RouteQuadraticQuotientProbe001.nfNeg u
def add (u v : NormalForm) : NormalForm := BOMA.C.RouteQuadraticQuotientProbe001.nfAdd u v
def mul (u v : NormalForm) : NormalForm := BOMA.C.RouteQuadraticQuotientProbe001.nfMul u v

theorem add_zero_right_from_interface
    (C : RStageIntegrationCertificate) (x : RBOMA) :
    rAdd x rZero = x := by
  calc
    rAdd x rZero = rAdd rZero x := C.addComm x rZero
    _ = x := C.addZeroLeft x

theorem mul_one_right_from_interface
    (C : RStageIntegrationCertificate) (x : RBOMA) :
    rMulCandidate x rOne = x := by
  calc
    rMulCandidate x rOne = rMulCandidate rOne x := C.mulComm x rOne
    _ = x := C.mulOneLeft x

/-- P/Q-03: route-local real embedding is faithful. -/
theorem ofR_injective {a b : RBOMA}
    (h : ofR a = ofR b) : a = b :=
  congrArg BOMA.C.RouteQuadraticQuotientProbe001.NormalForm.re h

/-- Multiplication by the route-local generator extracts an imaginary coefficient. -/
theorem embed_mul_imag
    (C : RStageIntegrationCertificate) (b : RBOMA) :
    mul (ofR b) imag = ⟨rZero, b⟩ := by
  apply normal_ext
  · change
      rAdd (rMulCandidate b rZero)
        (rNeg (rMulCandidate rZero rOne)) = rZero
    rw [mul_zero_right_from_interface C b,
        mul_zero_left_from_interface C rOne,
        neg_zero_from_interface C,
        C.addZeroLeft rZero]
  · change
      rAdd (rMulCandidate b rOne)
        (rMulCandidate rZero rZero) = b
    rw [mul_one_right_from_interface C b,
        mul_zero_left_from_interface C rZero,
        add_zero_right_from_interface C b]

/-- Normal form of a real-plus-imaginary route-local expression. -/
theorem coordinate_expression
    (C : RStageIntegrationCertificate) (a b : RBOMA) :
    add (ofR a) (mul (ofR b) imag) = ⟨a, b⟩ := by
  rw [embed_mul_imag C b]
  apply normal_ext
  · exact add_zero_right_from_interface C a
  · exact C.addZeroLeft b

/-- P/Q-06: the distinguished generator squares to negative one. -/
theorem imag_squared
    (C : RStageIntegrationCertificate) :
    mul imag imag = neg one := by
  apply normal_ext
  · change
      rAdd (rMulCandidate rZero rZero)
        (rNeg (rMulCandidate rOne rOne)) = rNeg rOne
    rw [mul_zero_left_from_interface C rZero,
        C.mulOneLeft rOne,
        C.addZeroLeft (rNeg rOne)]
  · change
      rAdd (rMulCandidate rZero rOne)
        (rMulCandidate rOne rZero) = rNeg rZero
    rw [mul_zero_left_from_interface C rOne,
        C.mulOneLeft rZero,
        C.addZeroLeft rZero,
        neg_zero_from_interface C]

/-- P/Q-07: every route-local candidate has a real/imaginary decomposition. -/
theorem decomposition
    (C : RStageIntegrationCertificate) (z : NormalForm) :
    ∃ a b : RBOMA, z = add (ofR a) (mul (ofR b) imag) := by
  refine ⟨z.re, z.im, ?_⟩
  rw [coordinate_expression C z.re z.im]

/-- P/Q-08: real/imaginary coordinates are unique at Route Q normal-form equality. -/
theorem decomposition_unique
    (C : RStageIntegrationCertificate)
    {a b a' b' : RBOMA}
    (h : add (ofR a) (mul (ofR b) imag) =
      add (ofR a') (mul (ofR b') imag)) :
    a = a' ∧ b = b' := by
  rw [coordinate_expression C a b,
      coordinate_expression C a' b'] at h
  exact ⟨congrArg BOMA.C.RouteQuadraticQuotientProbe001.NormalForm.re h,
         congrArg BOMA.C.RouteQuadraticQuotientProbe001.NormalForm.im h⟩

/-- P/Q-09: the imaginary generator is not in the embedded real line. -/
theorem imag_not_real
    (C : RStageIntegrationCertificate) :
    ¬ ∃ a : RBOMA, imag = ofR a := by
  rintro ⟨a, ha⟩
  have h : rOne = rZero := congrArg BOMA.C.RouteQuadraticQuotientProbe001.NormalForm.im ha
  exact C.nontrivial h.symm

end BOMA.C.StageTwo.QNormalRoute002

/- ST2-EXP-002: independent commutative ring on Route Q's own NormalForm.
No selected pair-route declaration or field producer is referenced. -/
namespace BOMA.C.StageTwo.QNormalCore002

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001

/-- The Q-local carrier is Route Q's own canonical normalization record. -/
abbrev QNormal : Type := BOMA.C.StageTwo.QNormalRoute002.NormalForm

/-- The Q-normal identity is record equality, equivalent to coordinate equality. -/
theorem n_ext {z w : QNormal}
    (hre : z.re = w.re) (him : z.im = w.im) : z = w :=
  BOMA.C.StageTwo.QNormalRoute002.normal_ext hre him

def nZero : QNormal := BOMA.C.StageTwo.QNormalRoute002.zero
def nOne : QNormal := BOMA.C.StageTwo.QNormalRoute002.one
def nOfR (a : RBOMA) : QNormal := BOMA.C.StageTwo.QNormalRoute002.ofR a
def nI : QNormal := BOMA.C.StageTwo.QNormalRoute002.imag
def nNeg (z : QNormal) : QNormal := BOMA.C.StageTwo.QNormalRoute002.neg z
def nAdd (z w : QNormal) : QNormal := BOMA.C.StageTwo.QNormalRoute002.add z w
def nMul (z w : QNormal) : QNormal := BOMA.C.StageTwo.QNormalRoute002.mul z w

/-- Scalar additive reassociation needed by the explicit equational normalizer. -/
theorem r_add_left_comm_from_interface
    (C : RStageIntegrationCertificate) (a b c : RBOMA) :
    rAdd a (rAdd b c) = rAdd b (rAdd a c) := by
  calc
    rAdd a (rAdd b c) = rAdd (rAdd a b) c := (C.addAssoc a b c).symm
    _ = rAdd (rAdd b a) c := by rw [C.addComm a b]
    _ = rAdd b (rAdd a c) := C.addAssoc b a c

/-- Scalar multiplicative reassociation needed by the explicit normalizer. -/
theorem r_mul_left_comm_from_interface
    (C : RStageIntegrationCertificate) (a b c : RBOMA) :
    rMulCandidate a (rMulCandidate b c) =
      rMulCandidate b (rMulCandidate a c) := by
  calc
    rMulCandidate a (rMulCandidate b c) =
        rMulCandidate (rMulCandidate a b) c := (C.mulAssoc a b c).symm
    _ = rMulCandidate (rMulCandidate b a) c := by rw [C.mulComm a b]
    _ = rMulCandidate b (rMulCandidate a c) := C.mulAssoc b a c

/-- Distribution in the first scalar argument is derived, not assumed. -/
theorem r_mul_add_left_from_interface
    (C : RStageIntegrationCertificate) (a b c : RBOMA) :
    rMulCandidate (rAdd a b) c =
      rAdd (rMulCandidate a c) (rMulCandidate b c) := by
  calc
    rMulCandidate (rAdd a b) c = rMulCandidate c (rAdd a b) :=
      C.mulComm (rAdd a b) c
    _ = rAdd (rMulCandidate c a) (rMulCandidate c b) :=
      C.distribRight c a b
    _ = rAdd (rMulCandidate a c) (rMulCandidate b c) := by
      rw [C.mulComm c a, C.mulComm c b]

/-- Additive inverse distributes over scalar addition using inverse uniqueness. -/
theorem r_neg_add_from_interface
    (C : RStageIntegrationCertificate) (a b : RBOMA) :
    rNeg (rAdd a b) = rAdd (rNeg a) (rNeg b) := by
  have h : rAdd (rAdd a b) (rAdd (rNeg a) (rNeg b)) = rZero := by
    calc
      rAdd (rAdd a b) (rAdd (rNeg a) (rNeg b)) =
          rAdd a (rAdd b (rAdd (rNeg a) (rNeg b))) :=
        C.addAssoc a b (rAdd (rNeg a) (rNeg b))
      _ = rAdd a (rAdd (rNeg a) (rAdd b (rNeg b))) := by
        rw [r_add_left_comm_from_interface C b (rNeg a) (rNeg b)]
      _ = rAdd (rAdd a (rNeg a)) (rAdd b (rNeg b)) :=
        (C.addAssoc a (rNeg a) (rAdd b (rNeg b))).symm
      _ = rZero := by
        rw [C.addInverseRight a, C.addInverseRight b, C.addZeroLeft rZero]
  exact (add_inverse_unique_from_interface C h).symm

/-- The canonical complex zero and unit remain distinct. -/
theorem n_zero_ne_one (C : RStageIntegrationCertificate) :
    nZero ≠ nOne := by
  intro h
  exact C.nontrivial (congrArg BOMA.C.RouteQuadraticQuotientProbe001.NormalForm.re h)

/-- The Q-normal real embedding is faithful. -/
theorem n_ofR_injective {a b : RBOMA} (h : nOfR a = nOfR b) : a = b :=
  BOMA.C.StageTwo.QNormalRoute002.ofR_injective h

theorem n_add_comm (C : RStageIntegrationCertificate) (z w : QNormal) :
    nAdd z w = nAdd w z := by
  apply n_ext
  · exact C.addComm z.re w.re
  · exact C.addComm z.im w.im

theorem n_add_assoc
    (C : RStageIntegrationCertificate) (z w v : QNormal) :
    nAdd (nAdd z w) v = nAdd z (nAdd w v) := by
  apply n_ext
  · exact C.addAssoc z.re w.re v.re
  · exact C.addAssoc z.im w.im v.im

theorem n_add_zero_left (C : RStageIntegrationCertificate) (z : QNormal) :
    nAdd nZero z = z := by
  apply n_ext
  · exact C.addZeroLeft z.re
  · exact C.addZeroLeft z.im

theorem n_add_zero_right (C : RStageIntegrationCertificate) (z : QNormal) :
    nAdd z nZero = z := by
  rw [n_add_comm C z nZero, n_add_zero_left C z]

theorem n_add_neg_right (C : RStageIntegrationCertificate) (z : QNormal) :
    nAdd z (nNeg z) = nZero := by
  apply n_ext
  · exact C.addInverseRight z.re
  · exact C.addInverseRight z.im

theorem n_add_neg_left (C : RStageIntegrationCertificate) (z : QNormal) :
    nAdd (nNeg z) z = nZero := by
  rw [n_add_comm C (nNeg z) z, n_add_neg_right C z]

theorem n_neg_involutive (C : RStageIntegrationCertificate) (z : QNormal) :
    nNeg (nNeg z) = z := by
  apply n_ext
  · exact neg_involutive_from_interface C z.re
  · exact neg_involutive_from_interface C z.im

theorem n_mul_comm (C : RStageIntegrationCertificate) (z w : QNormal) :
    nMul z w = nMul w z := by
  cases z <;> cases w <;>
    simp [nMul, BOMA.C.StageTwo.QNormalRoute002.mul, BOMA.C.RouteQuadraticQuotientProbe001.nfMul, C.mulComm, C.addComm]

/-- Associativity is an explicit consequence of the accepted real ring laws. -/
theorem n_mul_assoc
    (C : RStageIntegrationCertificate) (z w v : QNormal) :
    nMul (nMul z w) v = nMul z (nMul w v) := by
  cases z <;> cases w <;> cases v <;>
    simp [nMul, BOMA.C.StageTwo.QNormalRoute002.mul, BOMA.C.RouteQuadraticQuotientProbe001.nfMul,
      r_mul_add_left_from_interface C, C.distribRight,
      mul_neg_left_from_interface C, mul_neg_right_from_interface C,
      r_neg_add_from_interface C, neg_involutive_from_interface C,
      C.mulAssoc, C.mulComm, r_mul_left_comm_from_interface C,
      C.addAssoc, C.addComm, r_add_left_comm_from_interface C]

theorem n_mul_one_left (C : RStageIntegrationCertificate) (z : QNormal) :
    nMul nOne z = z := by
  apply n_ext
  · change
      rAdd (rMulCandidate rOne z.re)
        (rNeg (rMulCandidate rZero z.im)) = z.re
    rw [C.mulOneLeft z.re, mul_zero_left_from_interface C z.im,
      neg_zero_from_interface C,
      BOMA.C.StageTwo.QNormalRoute002.add_zero_right_from_interface C z.re]
  · change
      rAdd (rMulCandidate rOne z.im)
        (rMulCandidate rZero z.re) = z.im
    rw [C.mulOneLeft z.im, mul_zero_left_from_interface C z.re,
      BOMA.C.StageTwo.QNormalRoute002.add_zero_right_from_interface C z.im]

theorem n_mul_one_right (C : RStageIntegrationCertificate) (z : QNormal) :
    nMul z nOne = z := by
  rw [n_mul_comm C z nOne, n_mul_one_left C z]

/-- Right distribution is proved independently from the abstract real interface. -/
theorem n_mul_add_right
    (C : RStageIntegrationCertificate) (z w v : QNormal) :
    nMul z (nAdd w v) = nAdd (nMul z w) (nMul z v) := by
  cases z <;> cases w <;> cases v <;>
    simp [nMul, nAdd, BOMA.C.StageTwo.QNormalRoute002.mul, BOMA.C.RouteQuadraticQuotientProbe001.nfMul,
      BOMA.C.StageTwo.QNormalRoute002.add, BOMA.C.RouteQuadraticQuotientProbe001.nfAdd,
      r_mul_add_left_from_interface C, C.distribRight,
      mul_neg_left_from_interface C, mul_neg_right_from_interface C,
      r_neg_add_from_interface C, neg_involutive_from_interface C,
      C.mulAssoc, C.mulComm, r_mul_left_comm_from_interface C,
      C.addAssoc, C.addComm, r_add_left_comm_from_interface C]

theorem n_mul_add_left
    (C : RStageIntegrationCertificate) (z w v : QNormal) :
    nMul (nAdd z w) v = nAdd (nMul z v) (nMul w v) := by
  calc
    nMul (nAdd z w) v = nMul v (nAdd z w) :=
      n_mul_comm C (nAdd z w) v
    _ = nAdd (nMul v z) (nMul v w) := n_mul_add_right C v z w
    _ = nAdd (nMul z v) (nMul w v) := by
      rw [n_mul_comm C v z, n_mul_comm C v w]

theorem n_mul_zero_left (C : RStageIntegrationCertificate) (z : QNormal) :
    nMul nZero z = nZero := by
  apply n_ext
  · change
      rAdd (rMulCandidate rZero z.re)
        (rNeg (rMulCandidate rZero z.im)) = rZero
    rw [mul_zero_left_from_interface C z.re,
      mul_zero_left_from_interface C z.im,
      neg_zero_from_interface C, C.addZeroLeft rZero]
  · change
      rAdd (rMulCandidate rZero z.im)
        (rMulCandidate rZero z.re) = rZero
    rw [mul_zero_left_from_interface C z.im,
      mul_zero_left_from_interface C z.re, C.addZeroLeft rZero]

theorem n_mul_zero_right (C : RStageIntegrationCertificate) (z : QNormal) :
    nMul z nZero = nZero := by
  rw [n_mul_comm C z nZero, n_mul_zero_left C z]

theorem n_ofR_zero : nOfR rZero = nZero := rfl

theorem n_ofR_one : nOfR rOne = nOne := rfl

theorem n_ofR_neg (C : RStageIntegrationCertificate) (a : RBOMA) :
    nOfR (rNeg a) = nNeg (nOfR a) := by
  apply n_ext
  · rfl
  · exact (neg_zero_from_interface C).symm

theorem n_ofR_add (C : RStageIntegrationCertificate) (a b : RBOMA) :
    nOfR (rAdd a b) = nAdd (nOfR a) (nOfR b) := by
  apply n_ext
  · rfl
  · exact (C.addZeroLeft rZero).symm

theorem n_ofR_mul (C : RStageIntegrationCertificate) (a b : RBOMA) :
    nOfR (rMulCandidate a b) = nMul (nOfR a) (nOfR b) := by
  apply n_ext
  · change
      rMulCandidate a b =
        rAdd (rMulCandidate a b) (rNeg (rMulCandidate rZero rZero))
    rw [mul_zero_left_from_interface C rZero,
      neg_zero_from_interface C,
      BOMA.C.StageTwo.QNormalRoute002.add_zero_right_from_interface C
        (rMulCandidate a b)]
  · change
      rZero = rAdd (rMulCandidate a rZero) (rMulCandidate rZero b)
    rw [mul_zero_right_from_interface C a,
      mul_zero_left_from_interface C b, C.addZeroLeft rZero]

theorem n_i_squared (C : RStageIntegrationCertificate) :
    nMul nI nI = nNeg nOne :=
  BOMA.C.StageTwo.QNormalRoute002.imag_squared C

theorem n_generation (C : RStageIntegrationCertificate) (z : QNormal) :
    ∃ a b : RBOMA, z = nAdd (nOfR a) (nMul (nOfR b) nI) :=
  BOMA.C.StageTwo.QNormalRoute002.decomposition C z

theorem n_coordinate_unique
    (C : RStageIntegrationCertificate) {a b a' b' : RBOMA}
    (h : nAdd (nOfR a) (nMul (nOfR b) nI) =
      nAdd (nOfR a') (nMul (nOfR b') nI)) :
    a = a' ∧ b = b' :=
  BOMA.C.StageTwo.QNormalRoute002.decomposition_unique C h

theorem n_i_not_real (C : RStageIntegrationCertificate) :
    ¬ ∃ a : RBOMA, nI = nOfR a :=
  BOMA.C.StageTwo.QNormalRoute002.imag_not_real C

/-- Precisely scoped Q-normal integration surface: ring, not field. -/
structure QNormalRingCertificate where
  nontrivial : nZero ≠ nOne
  embeddingInjective : ∀ {a b : RBOMA}, nOfR a = nOfR b → a = b
  addComm : ∀ z w : QNormal, nAdd z w = nAdd w z
  addAssoc : ∀ z w v : QNormal, nAdd (nAdd z w) v = nAdd z (nAdd w v)
  addZeroLeft : ∀ z : QNormal, nAdd nZero z = z
  addInverseRight : ∀ z : QNormal, nAdd z (nNeg z) = nZero
  mulComm : ∀ z w : QNormal, nMul z w = nMul w z
  mulAssoc : ∀ z w v : QNormal, nMul (nMul z w) v = nMul z (nMul w v)
  mulOneLeft : ∀ z : QNormal, nMul nOne z = z
  distribRight : ∀ z w v : QNormal,
    nMul z (nAdd w v) = nAdd (nMul z w) (nMul z v)
  mulZeroRight : ∀ z : QNormal, nMul z nZero = nZero
  embeddingZero : nOfR rZero = nZero
  embeddingOne : nOfR rOne = nOne
  embeddingNeg : ∀ a : RBOMA, nOfR (rNeg a) = nNeg (nOfR a)
  embeddingAdd : ∀ a b : RBOMA,
    nOfR (rAdd a b) = nAdd (nOfR a) (nOfR b)
  embeddingMul : ∀ a b : RBOMA,
    nOfR (rMulCandidate a b) = nMul (nOfR a) (nOfR b)
  imagSquared : nMul nI nI = nNeg nOne
  generation : ∀ z : QNormal,
    ∃ a b : RBOMA, z = nAdd (nOfR a) (nMul (nOfR b) nI)
  coordinateUnique : ∀ {a b a' b' : RBOMA},
    nAdd (nOfR a) (nMul (nOfR b) nI) =
      nAdd (nOfR a') (nMul (nOfR b') nI) → a = a' ∧ b = b'
  imagNotReal : ¬ ∃ a : RBOMA, nI = nOfR a

/-- Abstract real-interface construction; no real representation is unfolded. -/
theorem qNormalRingCertificate
    (C : RStageIntegrationCertificate) : QNormalRingCertificate where
  nontrivial := n_zero_ne_one C
  embeddingInjective := @n_ofR_injective
  addComm := n_add_comm C
  addAssoc := n_add_assoc C
  addZeroLeft := n_add_zero_left C
  addInverseRight := n_add_neg_right C
  mulComm := n_mul_comm C
  mulAssoc := n_mul_assoc C
  mulOneLeft := n_mul_one_left C
  distribRight := n_mul_add_right C
  mulZeroRight := n_mul_zero_right C
  embeddingZero := n_ofR_zero
  embeddingOne := n_ofR_one
  embeddingNeg := n_ofR_neg C
  embeddingAdd := n_ofR_add C
  embeddingMul := n_ofR_mul C
  imagSquared := n_i_squared C
  generation := n_generation C
  coordinateUnique := @n_coordinate_unique C
  imagNotReal := n_i_not_real C

/-- Instantiate the ring-core certificate on the accepted Stage-One real export. -/
theorem qNormalRingCertificateFromAcceptedR : QNormalRingCertificate :=
  qNormalRingCertificate rStageIntegrationCertificate

end BOMA.C.StageTwo.QNormalCore002

/- ST2-EXP-002: independent Route-Q-normal-form norm and inverse witnesses.
The proof uses only accepted R and Route Q's own normal-form ring. -/
namespace BOMA.C.StageTwo.QNormalNormInverse002

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001
open BOMA.C.StageTwo.QNormalCore002

/-- Conjugation reverses the Q-normal imaginary coordinate. -/
def nConj (z : QNormal) : QNormal := ⟨z.re, rNeg z.im⟩

/-- The real-valued Q-normal coordinate norm is the sum of two squares. -/
def nNorm (z : QNormal) : RBOMA :=
  rAdd (rMulCandidate z.re z.re) (rMulCandidate z.im z.im)

theorem n_conj_involutive
    (C : RStageIntegrationCertificate) (z : QNormal) :
    nConj (nConj z) = z := by
  apply n_ext
  · rfl
  · exact neg_involutive_from_interface C z.im

theorem n_conj_ofR
    (C : RStageIntegrationCertificate) (a : RBOMA) :
    nConj (nOfR a) = nOfR a := by
  apply n_ext
  · rfl
  · exact neg_zero_from_interface C

theorem n_conj_add
    (C : RStageIntegrationCertificate) (z w : QNormal) :
    nConj (nAdd z w) = nAdd (nConj z) (nConj w) := by
  apply n_ext
  · rfl
  · exact r_neg_add_from_interface C z.im w.im

theorem n_norm_conj
    (C : RStageIntegrationCertificate) (z : QNormal) :
    nNorm (nConj z) = nNorm z := by
  change
    rAdd (rMulCandidate z.re z.re)
      (rMulCandidate (rNeg z.im) (rNeg z.im)) =
    rAdd (rMulCandidate z.re z.re)
      (rMulCandidate z.im z.im)
  rw [mul_neg_neg_same_from_interface C z.im]

/-- The norm product has exactly the embedded real norm and zero imaginary part. -/
theorem n_mul_conj
    (C : RStageIntegrationCertificate) (z : QNormal) :
    nMul z (nConj z) = nOfR (nNorm z) := by
  apply n_ext
  · change
      rAdd (rMulCandidate z.re z.re)
        (rNeg (rMulCandidate z.im (rNeg z.im))) =
      rAdd (rMulCandidate z.re z.re) (rMulCandidate z.im z.im)
    rw [mul_neg_right_from_interface C z.im z.im,
      neg_involutive_from_interface C (rMulCandidate z.im z.im)]
  · change
      rAdd (rMulCandidate z.re (rNeg z.im))
        (rMulCandidate z.im z.re) = rZero
    rw [mul_neg_right_from_interface C z.re z.im,
      C.mulComm z.im z.re,
      C.addComm (rNeg (rMulCandidate z.re z.im))
        (rMulCandidate z.re z.im),
      C.addInverseRight (rMulCandidate z.re z.im)]

theorem n_conj_mul
    (C : RStageIntegrationCertificate) (z : QNormal) :
    nMul (nConj z) z = nOfR (nNorm z) := by
  rw [n_mul_comm C (nConj z) z, n_mul_conj C z]

/-- A nonnegative sum equal to zero has zero first summand. -/
theorem r_nonnegative_sum_zero_left
    (C : RStageIntegrationCertificate) {a b : RBOMA}
    (h0a : rLE rZero a) (h0b : rLE rZero b)
    (hsum : rAdd a b = rZero) : a = rZero := by
  have ha0 : rLE a rZero := by
    have h := (C.addTranslateOrderIff rZero b a).2 h0b
    rw [C.addZeroLeft a, C.addComm b a, hsum] at h
    exact h
  exact C.orderAntisymm ha0 h0a

/-- A nonnegative sum equal to zero has zero second summand. -/
theorem r_nonnegative_sum_zero_right
    (C : RStageIntegrationCertificate) {a b : RBOMA}
    (h0a : rLE rZero a) (h0b : rLE rZero b)
    (hsum : rAdd a b = rZero) : b = rZero := by
  apply r_nonnegative_sum_zero_left C h0b h0a
  rw [C.addComm b a, hsum]

theorem n_norm_nonnegative
    (C : RStageIntegrationCertificate) (z : QNormal) :
    rLE rZero (nNorm z) := by
  have h0re := square_nonnegative_of_interface C z.re
  have h0im := square_nonnegative_of_interface C z.im
  have h :=
    (C.addTranslateOrderIff rZero
      (rMulCandidate z.im z.im) (rMulCandidate z.re z.re)).2 h0im
  rw [C.addZeroLeft (rMulCandidate z.re z.re),
    C.addComm (rMulCandidate z.im z.im)
      (rMulCandidate z.re z.re)] at h
  exact C.orderTrans h0re h

theorem n_norm_zero_real_square
    (C : RStageIntegrationCertificate) (z : QNormal)
    (hnorm : nNorm z = rZero) :
    rMulCandidate z.re z.re = rZero := by
  exact r_nonnegative_sum_zero_left C
    (square_nonnegative_of_interface C z.re)
    (square_nonnegative_of_interface C z.im) hnorm

theorem n_norm_zero_imaginary_square
    (C : RStageIntegrationCertificate) (z : QNormal)
    (hnorm : nNorm z = rZero) :
    rMulCandidate z.im z.im = rZero := by
  exact r_nonnegative_sum_zero_right C
    (square_nonnegative_of_interface C z.re)
    (square_nonnegative_of_interface C z.im) hnorm

/-- A zero real square contradicts any proposed nonzero real witness.

The conclusion is deliberately double-negated equality, not equality; the
abstract real interface does not provide stable or decidable equality. -/
theorem r_square_zero_not_nonzero
    (C : RStageIntegrationCertificate) {a : RBOMA}
    (hsquare : rMulCandidate a a = rZero) : ¬ a ≠ rZero := by
  intro hnonzero
  rcases C.inverseExists a hnonzero with ⟨t, ht⟩
  have hzero : a = rZero := by
    calc
      a = rMulCandidate a rOne :=
        (BOMA.C.StageTwo.QNormalRoute002.mul_one_right_from_interface C a).symm
      _ = rMulCandidate a (rMulCandidate a t) := by rw [ht]
      _ = rMulCandidate (rMulCandidate a a) t :=
        (C.mulAssoc a a t).symm
      _ = rMulCandidate rZero t := by rw [hsquare]
      _ = rZero := mul_zero_left_from_interface C t
  exact hnonzero hzero

/-- Zero norm entails only double-negated zero coordinates and zero complex value. -/
theorem n_norm_zero_not_nonzero
    (C : RStageIntegrationCertificate) (z : QNormal)
    (hnorm : nNorm z = rZero) : ¬ z ≠ nZero := by
  intro hnonzero
  have hre := r_square_zero_not_nonzero C
    (n_norm_zero_real_square C z hnorm)
  have him := r_square_zero_not_nonzero C
    (n_norm_zero_imaginary_square C z hnorm)
  apply hre
  intro hzre
  apply him
  intro hzim
  apply hnonzero
  apply n_ext
  · exact hzre
  · exact hzim

/-- A supplied nonzero complex hypothesis constructively makes its norm nonzero. -/
theorem n_norm_nonzero
    (C : RStageIntegrationCertificate) {z : QNormal}
    (hnonzero : z ≠ nZero) : nNorm z ≠ rZero := by
  intro hnorm
  exact n_norm_zero_not_nonzero C z hnorm hnonzero

/-- A real inverse witness for the norm determines a complex inverse witness. -/
theorem n_inverse_from_real_witness
    (C : RStageIntegrationCertificate) (z : QNormal) (t : RBOMA)
    (ht : rMulCandidate (nNorm z) t = rOne) :
    nMul z (nMul (nOfR t) (nConj z)) = nOne := by
  calc
    nMul z (nMul (nOfR t) (nConj z)) =
        nMul z (nMul (nConj z) (nOfR t)) := by
      rw [n_mul_comm C (nOfR t) (nConj z)]
    _ = nMul (nMul z (nConj z)) (nOfR t) :=
      (n_mul_assoc C z (nConj z) (nOfR t)).symm
    _ = nMul (nOfR (nNorm z)) (nOfR t) := by rw [n_mul_conj C z]
    _ = nOfR (rMulCandidate (nNorm z) t) :=
      (n_ofR_mul C (nNorm z) t).symm
    _ = nOfR rOne := by rw [ht]
    _ = nOne := n_ofR_one

/-- The field interface supplies existential witnesses, never a global selector. -/
theorem n_inverse_exists
    (C : RStageIntegrationCertificate) (z : QNormal)
    (hnonzero : z ≠ nZero) :
    ∃ w : QNormal, nMul z w = nOne := by
  rcases C.inverseExists (nNorm z) (n_norm_nonzero C hnonzero) with ⟨t, ht⟩
  exact ⟨nMul (nOfR t) (nConj z), n_inverse_from_real_witness C z t ht⟩

theorem n_inverse_left_of_right
    (C : RStageIntegrationCertificate) {z w : QNormal}
    (hzw : nMul z w = nOne) :
    nMul w z = nOne := by
  rw [n_mul_comm C w z, hzw]

/-- Inverse witnesses are unique by the already verified ring laws. -/
theorem n_inverse_unique
    (C : RStageIntegrationCertificate) {z w v : QNormal}
    (hw : nMul z w = nOne)
    (hv : nMul z v = nOne) : w = v := by
  calc
    w = nMul w nOne := (n_mul_one_right C w).symm
    _ = nMul w (nMul z v) := by rw [hv]
    _ = nMul (nMul w z) v := (n_mul_assoc C w z v).symm
    _ = nMul nOne v := by rw [n_mul_comm C w z, hw]
    _ = v := n_mul_one_left C v

/-- Complete Q-normal field-strength certificate with witness-only inversion. -/
structure QNormalFieldCertificate where
  ring : QNormalRingCertificate
  normNonnegative : ∀ z : QNormal, rLE rZero (nNorm z)
  normNonzero : ∀ z : QNormal, z ≠ nZero → nNorm z ≠ rZero
  conjugateProduct : ∀ z : QNormal, nMul z (nConj z) = nOfR (nNorm z)
  inverseExists : ∀ z : QNormal, z ≠ nZero → ∃ w : QNormal, nMul z w = nOne
  inverseUnique : ∀ {z w v : QNormal},
    nMul z w = nOne → nMul z v = nOne → w = v

/-- Field closure is derived from the abstract accepted real certificate alone. -/
theorem qNormalFieldCertificate
    (C : RStageIntegrationCertificate) : QNormalFieldCertificate where
  ring := qNormalRingCertificate C
  normNonnegative := n_norm_nonnegative C
  normNonzero := fun _ h => n_norm_nonzero C h
  conjugateProduct := n_mul_conj C
  inverseExists := n_inverse_exists C
  inverseUnique := @n_inverse_unique C

/-- Instantiate the witness-field certificate on the accepted real export. -/
theorem qNormalFieldCertificateFromAcceptedR : QNormalFieldCertificate :=
  qNormalFieldCertificate rStageIntegrationCertificate

end BOMA.C.StageTwo.QNormalNormInverse002

/- ST2-EXP-002: independent field on the retained quadratic-expression quotient.
Every result is proved from accepted R and Route Q's own normalized witness field. -/
namespace BOMA.C.StageTwo.QQuotientField002

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.StageTwo.QNormalCore002
open BOMA.C.StageTwo.QNormalNormInverse002

abbrev QBOMA : Type := BOMA.C.RouteQuadraticQuotientProbe001.QuotientCandidate
abbrev qZero : QBOMA := BOMA.C.RouteQuadraticQuotientProbe001.zero
abbrev qOne : QBOMA := BOMA.C.RouteQuadraticQuotientProbe001.one
abbrev qOfR (a : RBOMA) : QBOMA := BOMA.C.RouteQuadraticQuotientProbe001.ofR a
abbrev qI : QBOMA := BOMA.C.RouteQuadraticQuotientProbe001.imag
abbrev qNeg (z : QBOMA) : QBOMA := BOMA.C.RouteQuadraticQuotientProbe001.neg z
abbrev qAdd (z w : QBOMA) : QBOMA := BOMA.C.RouteQuadraticQuotientProbe001.add z w
abbrev qMul (z w : QBOMA) : QBOMA := BOMA.C.RouteQuadraticQuotientProbe001.mul z w

/-- Constructive canonical normal form; no representative choice is involved. -/
def qNormal : QBOMA → QNormal :=
  Quotient.lift BOMA.C.RouteQuadraticQuotientProbe001.normalize
    (fun _ _ h => h)

/-- Quotient identity is exactly equality of canonical normal forms. -/
theorem q_ext {z w : QBOMA}
    (h : qNormal z = qNormal w) : z = w := by
  revert h
  refine Quotient.inductionOn₂ z w ?_
  intro e f h
  exact Quotient.sound h

theorem q_normal_zero : qNormal qZero = nZero := rfl

theorem q_normal_one : qNormal qOne = nOne := rfl

theorem q_normal_ofR (a : RBOMA) : qNormal (qOfR a) = nOfR a := rfl

theorem q_normal_imag : qNormal qI = nI := rfl

theorem q_normal_neg (z : QBOMA) :
    qNormal (qNeg z) = nNeg (qNormal z) := by
  refine Quotient.inductionOn z ?_
  intro e
  rfl

theorem q_normal_add (z w : QBOMA) :
    qNormal (qAdd z w) = nAdd (qNormal z) (qNormal w) := by
  refine Quotient.inductionOn₂ z w ?_
  intro e f
  rfl

theorem q_normal_mul (z w : QBOMA) :
    qNormal (qMul z w) = nMul (qNormal z) (qNormal w) := by
  refine Quotient.inductionOn₂ z w ?_
  intro e f
  rfl

theorem q_zero_ne_one (R : RStageIntegrationCertificate) :
    qZero ≠ qOne := by
  intro h
  exact R.nontrivial (BOMA.C.RouteQuadraticQuotientProbe001.ofR_injective h)

theorem q_ofR_injective {a b : RBOMA} (h : qOfR a = qOfR b) :
    a = b :=
  BOMA.C.RouteQuadraticQuotientProbe001.ofR_injective h

theorem q_add_comm (R : RStageIntegrationCertificate) (z w : QBOMA) :
    qAdd z w = qAdd w z := by
  apply q_ext
  rw [q_normal_add, q_normal_add]
  exact n_add_comm R (qNormal z) (qNormal w)

theorem q_add_assoc (R : RStageIntegrationCertificate) (z w v : QBOMA) :
    qAdd (qAdd z w) v = qAdd z (qAdd w v) := by
  apply q_ext
  rw [q_normal_add, q_normal_add, q_normal_add, q_normal_add]
  exact n_add_assoc R (qNormal z) (qNormal w) (qNormal v)

theorem q_add_zero_left (R : RStageIntegrationCertificate) (z : QBOMA) :
    qAdd qZero z = z := by
  apply q_ext
  rw [q_normal_add, q_normal_zero]
  exact n_add_zero_left R (qNormal z)

theorem q_add_neg_right (R : RStageIntegrationCertificate) (z : QBOMA) :
    qAdd z (qNeg z) = qZero := by
  apply q_ext
  rw [q_normal_add, q_normal_neg, q_normal_zero]
  exact n_add_neg_right R (qNormal z)

theorem q_mul_comm (R : RStageIntegrationCertificate) (z w : QBOMA) :
    qMul z w = qMul w z := by
  apply q_ext
  rw [q_normal_mul, q_normal_mul]
  exact n_mul_comm R (qNormal z) (qNormal w)

theorem q_mul_assoc (R : RStageIntegrationCertificate) (z w v : QBOMA) :
    qMul (qMul z w) v = qMul z (qMul w v) := by
  apply q_ext
  rw [q_normal_mul, q_normal_mul, q_normal_mul, q_normal_mul]
  exact n_mul_assoc R (qNormal z) (qNormal w) (qNormal v)

theorem q_mul_one_left (R : RStageIntegrationCertificate) (z : QBOMA) :
    qMul qOne z = z := by
  apply q_ext
  rw [q_normal_mul, q_normal_one]
  exact n_mul_one_left R (qNormal z)

theorem q_mul_one_right (R : RStageIntegrationCertificate) (z : QBOMA) :
    qMul z qOne = z := by
  rw [q_mul_comm R z qOne, q_mul_one_left R z]

theorem q_mul_add_right
    (R : RStageIntegrationCertificate) (z w v : QBOMA) :
    qMul z (qAdd w v) = qAdd (qMul z w) (qMul z v) := by
  apply q_ext
  rw [q_normal_mul, q_normal_add, q_normal_add, q_normal_mul, q_normal_mul]
  exact n_mul_add_right R (qNormal z) (qNormal w) (qNormal v)

theorem q_mul_zero_right (R : RStageIntegrationCertificate) (z : QBOMA) :
    qMul z qZero = qZero := by
  apply q_ext
  rw [q_normal_mul, q_normal_zero]
  exact n_mul_zero_right R (qNormal z)

theorem q_ofR_zero : qOfR rZero = qZero := rfl

theorem q_ofR_one : qOfR rOne = qOne := rfl

theorem q_ofR_neg (R : RStageIntegrationCertificate) (a : RBOMA) :
    qOfR (rNeg a) = qNeg (qOfR a) := by
  apply q_ext
  rw [q_normal_ofR, q_normal_neg, q_normal_ofR]
  exact n_ofR_neg R a

theorem q_ofR_add (R : RStageIntegrationCertificate) (a b : RBOMA) :
    qOfR (rAdd a b) = qAdd (qOfR a) (qOfR b) := by
  apply q_ext
  rw [q_normal_ofR, q_normal_add, q_normal_ofR, q_normal_ofR]
  exact n_ofR_add R a b

theorem q_ofR_mul (R : RStageIntegrationCertificate) (a b : RBOMA) :
    qOfR (rMulCandidate a b) = qMul (qOfR a) (qOfR b) := by
  apply q_ext
  rw [q_normal_ofR, q_normal_mul, q_normal_ofR, q_normal_ofR]
  exact n_ofR_mul R a b

theorem q_i_squared (R : RStageIntegrationCertificate) :
    qMul qI qI = qNeg qOne :=
  BOMA.C.RouteQuadraticQuotientProbe001.imag_squared R

def qCoord (a b : RBOMA) : QBOMA :=
  qAdd (qOfR a) (qMul (qOfR b) qI)

theorem q_normal_coord (R : RStageIntegrationCertificate) (a b : RBOMA) :
    qNormal (qCoord a b) = ⟨a, b⟩ := by
  exact BOMA.C.RouteQuadraticQuotientProbe001.normalized_coordinate_expression R a b

theorem q_generation (R : RStageIntegrationCertificate) (z : QBOMA) :
    ∃ a b : RBOMA, z = qCoord a b :=
  BOMA.C.RouteQuadraticQuotientProbe001.decomposition R z

theorem q_coordinate_unique
    (R : RStageIntegrationCertificate) {a b c d : RBOMA}
    (h : qCoord a b = qCoord c d) : a = c ∧ b = d :=
  BOMA.C.RouteQuadraticQuotientProbe001.decomposition_unique R h

theorem q_i_not_real (R : RStageIntegrationCertificate) :
    ¬ ∃ a : RBOMA, qI = qOfR a :=
  BOMA.C.RouteQuadraticQuotientProbe001.imag_not_real R

def qRe (z : QBOMA) : RBOMA := (qNormal z).re
def qIm (z : QBOMA) : RBOMA := (qNormal z).im

theorem q_extract_sound (R : RStageIntegrationCertificate) (z : QBOMA) :
    z = qCoord (qRe z) (qIm z) := by
  apply q_ext
  rw [q_normal_coord R]
  change qNormal z = ⟨(qNormal z).re, (qNormal z).im⟩
  cases qNormal z
  rfl

theorem q_coordinate_zero (R : RStageIntegrationCertificate) :
    qCoord rZero rZero = qZero := by
  apply q_ext
  rw [q_normal_coord R, q_normal_zero]
  rfl

theorem q_coordinate_one (R : RStageIntegrationCertificate) :
    qCoord rOne rZero = qOne := by
  apply q_ext
  rw [q_normal_coord R, q_normal_one]
  rfl

theorem q_coordinate_real (R : RStageIntegrationCertificate) (a : RBOMA) :
    qCoord a rZero = qOfR a := by
  apply q_ext
  rw [q_normal_coord R, q_normal_ofR]
  rfl

theorem q_coordinate_imag (R : RStageIntegrationCertificate) :
    qCoord rZero rOne = qI := by
  apply q_ext
  rw [q_normal_coord R, q_normal_imag]
  rfl

theorem q_coordinate_neg (R : RStageIntegrationCertificate) (a b : RBOMA) :
    qNeg (qCoord a b) = qCoord (rNeg a) (rNeg b) := by
  apply q_ext
  rw [q_normal_neg, q_normal_coord R, q_normal_coord R]
  rfl

theorem q_coordinate_add
    (R : RStageIntegrationCertificate) (a b c d : RBOMA) :
    qAdd (qCoord a b) (qCoord c d) =
      qCoord (rAdd a c) (rAdd b d) := by
  apply q_ext
  rw [q_normal_add, q_normal_coord R, q_normal_coord R, q_normal_coord R]
  rfl

theorem q_coordinate_mul
    (R : RStageIntegrationCertificate) (a b c d : RBOMA) :
    qMul (qCoord a b) (qCoord c d) =
      qCoord
        (rAdd (rMulCandidate a c) (rNeg (rMulCandidate b d)))
        (rAdd (rMulCandidate a d) (rMulCandidate b c)) := by
  apply q_ext
  rw [q_normal_mul, q_normal_coord R, q_normal_coord R, q_normal_coord R]
  rfl

/-- Encode a Q-local normal form by the quotient's declared expression syntax. -/
def qOfNormal (u : QNormal) : QBOMA := qCoord u.re u.im

theorem q_normal_of_normal
    (R : RStageIntegrationCertificate) (u : QNormal) :
    qNormal (qOfNormal u) = u := by
  change qNormal (qCoord u.re u.im) = u
  rw [q_normal_coord R]

theorem q_inverse_exists
    (R : RStageIntegrationCertificate) (z : QBOMA)
    (hnonzero : z ≠ qZero) :
    ∃ w : QBOMA, qMul z w = qOne := by
  have hn : qNormal z ≠ nZero := by
    intro hz
    apply hnonzero
    apply q_ext
    rw [q_normal_zero]
    exact hz
  rcases n_inverse_exists R (qNormal z) hn with ⟨w, hw⟩
  refine ⟨qOfNormal w, ?_⟩
  apply q_ext
  rw [q_normal_mul, q_normal_of_normal R w, q_normal_one]
  exact hw

theorem q_inverse_unique
    (R : RStageIntegrationCertificate) {z w v : QBOMA}
    (hw : qMul z w = qOne) (hv : qMul z v = qOne) :
    w = v := by
  calc
    w = qMul w qOne := (q_mul_one_right R w).symm
    _ = qMul w (qMul z v) := by rw [hv]
    _ = qMul (qMul w z) v := (q_mul_assoc R w z v).symm
    _ = qMul qOne v := by rw [q_mul_comm R w z, hw]
    _ = v := q_mul_one_left R v

/-- Independent Route-Q field contract at quotient equality and identity. -/
structure QFieldCertificate where
  nontrivial : qZero ≠ qOne
  embeddingInjective : ∀ {a b : RBOMA}, qOfR a = qOfR b → a = b
  addComm : ∀ z w : QBOMA, qAdd z w = qAdd w z
  addAssoc : ∀ z w v : QBOMA, qAdd (qAdd z w) v = qAdd z (qAdd w v)
  addZeroLeft : ∀ z : QBOMA, qAdd qZero z = z
  addInverseRight : ∀ z : QBOMA, qAdd z (qNeg z) = qZero
  mulComm : ∀ z w : QBOMA, qMul z w = qMul w z
  mulAssoc : ∀ z w v : QBOMA, qMul (qMul z w) v = qMul z (qMul w v)
  mulOneLeft : ∀ z : QBOMA, qMul qOne z = z
  distribRight : ∀ z w v : QBOMA,
    qMul z (qAdd w v) = qAdd (qMul z w) (qMul z v)
  inverseExists : ∀ z : QBOMA, z ≠ qZero → ∃ w : QBOMA, qMul z w = qOne
  inverseUnique : ∀ {z w v : QBOMA}, qMul z w = qOne → qMul z v = qOne → w = v
  embeddingZero : qOfR rZero = qZero
  embeddingOne : qOfR rOne = qOne
  embeddingNeg : ∀ a : RBOMA, qOfR (rNeg a) = qNeg (qOfR a)
  embeddingAdd : ∀ a b : RBOMA, qOfR (rAdd a b) = qAdd (qOfR a) (qOfR b)
  embeddingMul : ∀ a b : RBOMA,
    qOfR (rMulCandidate a b) = qMul (qOfR a) (qOfR b)
  imagSquared : qMul qI qI = qNeg qOne
  generation : ∀ z : QBOMA, ∃ a b : RBOMA, z = qCoord a b
  coordinateUnique : ∀ {a b c d : RBOMA}, qCoord a b = qCoord c d → a = c ∧ b = d
  imagNotReal : ¬ ∃ a : RBOMA, qI = qOfR a
  extractorSound : ∀ z : QBOMA, z = qCoord (qRe z) (qIm z)

theorem qFieldCertificate (R : RStageIntegrationCertificate) :
    QFieldCertificate where
  nontrivial := q_zero_ne_one R
  embeddingInjective := @q_ofR_injective
  addComm := q_add_comm R
  addAssoc := q_add_assoc R
  addZeroLeft := q_add_zero_left R
  addInverseRight := q_add_neg_right R
  mulComm := q_mul_comm R
  mulAssoc := q_mul_assoc R
  mulOneLeft := q_mul_one_left R
  distribRight := q_mul_add_right R
  inverseExists := q_inverse_exists R
  inverseUnique := @q_inverse_unique R
  embeddingZero := q_ofR_zero
  embeddingOne := q_ofR_one
  embeddingNeg := q_ofR_neg R
  embeddingAdd := q_ofR_add R
  embeddingMul := q_ofR_mul R
  imagSquared := q_i_squared R
  generation := q_generation R
  coordinateUnique := @q_coordinate_unique R
  imagNotReal := q_i_not_real R
  extractorSound := q_extract_sound R

/-- Independent field witness instantiated on the same whole accepted-R interface. -/
theorem qFieldCertificateFromAcceptedR : QFieldCertificate :=
  qFieldCertificate rStageIntegrationCertificate

end BOMA.C.StageTwo.QQuotientField002

/- ST2-EXP-002: post-completion comparison of independently verified Route Q
   with accepted Route P. The independent Q assembly never contains this file. -/
namespace BOMA.C.StageTwo.PQJunction002

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.PairCore001
open BOMA.C.QuadraticComparison001
open BOMA.C.StageTwo.QQuotientField002

/-- Route Q's completed quotient field instantiates the unchanged common contract. -/
def quotientPresentation
    (R : RStageIntegrationCertificate) :
    QuadraticFieldPresentation R where
  carrier := QBOMA
  zero := qZero
  one := qOne
  neg := qNeg
  add := qAdd
  mul := qMul
  ofR := qOfR
  imag := qI
  coord := qCoord
  nontrivial := q_zero_ne_one R
  addComm := q_add_comm R
  addAssoc := q_add_assoc R
  addZeroLeft := q_add_zero_left R
  addInverseRight := q_add_neg_right R
  mulComm := q_mul_comm R
  mulAssoc := q_mul_assoc R
  mulOneLeft := q_mul_one_left R
  distribRight := q_mul_add_right R
  inverseExists := q_inverse_exists R
  inverseUnique := @q_inverse_unique R
  embeddingInjective := @q_ofR_injective
  embeddingZero := q_ofR_zero
  embeddingOne := q_ofR_one
  embeddingNeg := q_ofR_neg R
  embeddingAdd := q_ofR_add R
  embeddingMul := q_ofR_mul R
  imagSquared := q_i_squared R
  coordinateExpression := by intro a b; rfl
  coordinateGeneration := q_generation R
  coordinateUnique := @q_coordinate_unique R
  coordinateZero := q_coordinate_zero R
  coordinateOne := q_coordinate_one R
  coordinateReal := q_coordinate_real R
  coordinateImag := q_coordinate_imag R
  coordinateNeg := q_coordinate_neg R
  coordinateAdd := q_coordinate_add R
  coordinateMul := q_coordinate_mul R

/-- Normalization descends to the quotient without selecting a representative. -/
def quotientExtractor (R : RStageIntegrationCertificate) :
    CoordinateExtractor (quotientPresentation R) where
  re := qRe
  im := qIm
  sound := q_extract_sound R

/-- Actual mutually inverse R-algebra maps, only after independent Q closure. -/
def pqIsomorphism (R : RStageIntegrationCertificate) :
    ConstructiveQuadraticIsomorphism
      (selectedPresentation R) (quotientPresentation R) :=
  constructiveQuadraticIsomorphism
    (selectedPresentation R) (quotientPresentation R)
    (selectedExtractor R) (quotientExtractor R)

def pairToQuotient (R : RStageIntegrationCertificate) (z : CBOMA) : QBOMA :=
  (pqIsomorphism R).forward z

def quotientToPair (R : RStageIntegrationCertificate) (z : QBOMA) : CBOMA :=
  (pqIsomorphism R).backward z

theorem pairToQuotient_formula
    (R : RStageIntegrationCertificate) (z : CBOMA) :
    pairToQuotient R z = qCoord z.re z.im := rfl

theorem quotientToPair_formula
    (R : RStageIntegrationCertificate) (z : QBOMA) :
    quotientToPair R z = ⟨qRe z, qIm z⟩ := rfl

theorem pair_quotient_inverse_left
    (R : RStageIntegrationCertificate) (z : CBOMA) :
    quotientToPair R (pairToQuotient R z) = z :=
  (pqIsomorphism R).leftInverse z

theorem pair_quotient_inverse_right
    (R : RStageIntegrationCertificate) (z : QBOMA) :
    pairToQuotient R (quotientToPair R z) = z :=
  (pqIsomorphism R).rightInverse z

theorem pair_to_quotient_real
    (R : RStageIntegrationCertificate) (a : RBOMA) :
    pairToQuotient R (cOfR a) = qOfR a :=
  (pqIsomorphism R).preserveReal a

theorem pair_to_quotient_imag
    (R : RStageIntegrationCertificate) :
    pairToQuotient R cI = qI :=
  (pqIsomorphism R).preserveImag

theorem pair_to_quotient_add
    (R : RStageIntegrationCertificate) (z w : CBOMA) :
    pairToQuotient R (cAdd z w) =
      qAdd (pairToQuotient R z) (pairToQuotient R w) :=
  (pqIsomorphism R).preserveAdd z w

theorem pair_to_quotient_mul
    (R : RStageIntegrationCertificate) (z w : CBOMA) :
    pairToQuotient R (cMul z w) =
      qMul (pairToQuotient R z) (pairToQuotient R w) :=
  (pqIsomorphism R).preserveMul z w

/-- Explicit post-field CA-14 research reconvergence; CA-20 remains unchanged. -/
structure QPairJunctionCertificate where
  qField : QFieldCertificate
  universalComparison :
    QuadraticComparisonCertificate
      (selectedPresentation rStageIntegrationCertificate)
      (quotientPresentation rStageIntegrationCertificate)
  isomorphism :
    ConstructiveQuadraticIsomorphism
      (selectedPresentation rStageIntegrationCertificate)
      (quotientPresentation rStageIntegrationCertificate)
  forwardFormula :
    ∀ z : CBOMA, pairToQuotient rStageIntegrationCertificate z = qCoord z.re z.im
  backwardFormula :
    ∀ z : QBOMA,
      quotientToPair rStageIntegrationCertificate z = ⟨qRe z, qIm z⟩

def qPairJunctionCertificate : QPairJunctionCertificate where
  qField := qFieldCertificateFromAcceptedR
  universalComparison :=
    quadraticComparison
      (selectedPresentation rStageIntegrationCertificate)
      (quotientPresentation rStageIntegrationCertificate)
  isomorphism := pqIsomorphism rStageIntegrationCertificate
  forwardFormula := pairToQuotient_formula rStageIntegrationCertificate
  backwardFormula := quotientToPair_formula rStageIntegrationCertificate

end BOMA.C.StageTwo.PQJunction002

/- Rational representation/generation certificate. -/
namespace BOMA.Q.Generation001

open BOMA.Z.Rep001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001

/-- QA-16 core representation theorem: every formal rational is the quotient
class of an explicit accepted-integer numerator and structurally positive
natural denominator. This is a representation theorem, not a universal property. -/
theorem every_q_has_integer_fraction (q : QBOMA) :
    ∃ a : BOMA.Z.Rep001.ZSigned, ∃ d : PosDen,
      q = qmk ⟨a, d⟩ := by
  refine Quotient.inductionOn q ?_
  intro x
  exact ⟨x.num, x.den, rfl⟩

/-- The representation is faithful modulo exactly FracEquiv: equality of two
explicit fraction classes is neither stronger nor weaker than the certified
cross-product relation. -/
theorem integer_fraction_classes_equal_iff
    (a b : BOMA.Z.Rep001.ZSigned) (d e : PosDen) :
    qmk ⟨a, d⟩ = qmk ⟨b, e⟩ ↔
      BOMA.Z.Arithmetic001.zmul a (denZ e) =
      BOMA.Z.Arithmetic001.zmul b (denZ d) := by
  exact qmk_eq_iff

end BOMA.Q.Generation001

/- Final Stage-One rational integration certificate before QA-23 closure. -/
namespace BOMA.Q.Integration001

open BOMA.Z.Rep001
open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.Q.Generation001

/-- The selected rational carrier is nontrivial. -/
theorem q_nontrivial : qZero ≠ qOne := by
  intro h
  exact qone_ne_zero h.symm

/-- Additive-group integration witness. -/
theorem q_additive_package (x y w : QBOMA) :
    qAdd (qAdd x y) w = qAdd x (qAdd y w) ∧
    qAdd x y = qAdd y x ∧
    qAdd x (qNeg x) = qZero := by
  exact ⟨qAdd_assoc x y w, qAdd_comm x y, qAdd_neg_right x⟩

/-- Multiplicative/distributive integration witness. -/
theorem q_ring_package (x y w : QBOMA) :
    qMul (qMul x y) w = qMul x (qMul y w) ∧
    qMul x y = qMul y x ∧
    qMul x (qAdd y w) = qAdd (qMul x y) (qMul x w) := by
  exact ⟨qMul_assoc x y w, qMul_comm x y, qMul_add_right x y w⟩

/-- Every nonzero rational has a unique multiplicative-inverse witness. -/
theorem q_inverse_package (q : QBOMA) (hq : q ≠ qZero) :
    ∃ r : QBOMA, QInvRel q r ∧ ∀ s : QBOMA, QInvRel q s → s = r :=
  q_inverse_exists_unique q hq

/-- The accepted integer embedding is faithful and arithmetic-preserving. -/
theorem q_integer_embedding_package (a b : BOMA.Z.Rep001.ZSigned) :
    qOfZ (zadd a b) = qAdd (qOfZ a) (qOfZ b) ∧
    qOfZ (zmul a b) = qMul (qOfZ a) (qOfZ b) := by
  exact ⟨qOfZ_add a b, qOfZ_mul a b⟩

/-- Rational order is total and exactly extends the accepted integer order. -/
theorem q_order_package (x y : QBOMA) (a b : BOMA.Z.Rep001.ZSigned) :
    (qLE x y ∨ qLE y x) ∧
    (qLE (qOfZ a) (qOfZ b) ↔ zLE a b) := by
  exact ⟨qle_total x y, qOfZ_order a b⟩

/-- Ordered-field compatibility required by QA-15. -/
theorem q_ordered_field_package {x y c : QBOMA}
    (hxy : qLE x y) (hc : qLE qZero c) :
    qLE (qAdd x c) (qAdd y c) ∧
    qLE (qNeg y) (qNeg x) ∧
    qLE (qMul x c) (qMul y c) := by
  exact ⟨qadd_mono_right hxy c, qneg_reverses hxy,
    qmul_mono_right_nonneg hxy hc⟩

/-- Positive inverse behavior is part of the integrated ordered-field interface. -/
theorem q_positive_inverse_package {q r : QBOMA}
    (hq : QPositive q) (hr : QInvRel q r) : QPositive r :=
  inverse_of_positive_is_positive hq hr

/-- Every formal rational has an explicit integer / positive-natural-denominator representative. -/
theorem q_generation_package (q : QBOMA) :
    ∃ a : BOMA.Z.Rep001.ZSigned, ∃ d : PosDen, q = qmk ⟨a, d⟩ :=
  every_q_has_integer_fraction q

end BOMA.Q.Integration001

/- Representation-only Cauchy route probe over accepted BOMA N and Q. -/
namespace BOMA.R.CauchyProbe001

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.R.Gateway001

/-- A rational sequence indexed by the accepted BOMA natural carrier. -/
def QSeq := BOMANat → QBOMA

/-- Cauchy condition using only positive rational epsilon and the accepted N order.
No primitive metric or absolute-value carrier is assumed. -/
def IsCauchy (u : QSeq) : Prop :=
  ∀ eps : QBOMA, qPos eps →
    ∃ N : BOMANat,
      ∀ m n : BOMANat, LE N m → LE N n → qClose eps (u m) (u n)

/-- Candidate Cauchy representation syntax. -/
structure CauchySeq where
  seq : QSeq
  cauchy : IsCauchy seq

/-- Null-difference / asymptotic closeness relation used as the candidate
representation identity. It is only a probe relation here; equivalence laws are
not promoted until proved. -/
def CauchyEquiv (u v : CauchySeq) : Prop :=
  ∀ eps : QBOMA, qPos eps →
    ∃ N : BOMANat,
      ∀ n : BOMANat, LE N n → qClose eps (u.seq n) (v.seq n)

end BOMA.R.CauchyProbe001

/- Deeper Cauchy-route probe: constant rational sequences. -/
namespace BOMA.R.CauchyProbe001

open BOMA.NCore.RB001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001

/-- Zero is its own selected additive inverse. -/
theorem qNeg_zero : qNeg qZero = qZero := by
  symm
  exact qAdd_inverse_unique (x := qZero) (y := qZero) (qAdd_zero_left qZero)

/-- Any rational is epsilon-close to itself for positive epsilon. -/
theorem qClose_refl_of_pos (eps q : QBOMA) (heps : qPos eps) :
    qClose eps q q := by
  unfold qClose
  rw [qAdd_neg_right]
  have hneg : qLE (qNeg eps) (qNeg qZero) := qneg_reverses heps.1
  rw [qNeg_zero] at hneg
  exact ⟨hneg, heps.1⟩

/-- Constant rational sequence. -/
def constSeq (q : QBOMA) : QSeq := fun _ => q

/-- Constant sequences are Cauchy without any Archimedean or density lemma. -/
theorem constSeq_cauchy (q : QBOMA) : IsCauchy (constSeq q) := by
  intro eps heps
  refine ⟨BOMANat.z, ?_⟩
  intro m n hm hn
  exact qClose_refl_of_pos eps q heps

/-- Candidate rational embedding into Cauchy syntax. -/
def cauchyOfQ (q : QBOMA) : CauchySeq :=
  ⟨constSeq q, constSeq_cauchy q⟩

/-- Reflexive identity evidence for the constant embedding. -/
theorem cauchyOfQ_self_equiv (q : QBOMA) :
    CauchyEquiv (cauchyOfQ q) (cauchyOfQ q) := by
  intro eps heps
  refine ⟨BOMANat.z, ?_⟩
  intro n hn
  exact qClose_refl_of_pos eps q heps

end BOMA.R.CauchyProbe001

/- ST2-EXP-003: route-independent rational epsilon algebra for Cauchy identity.
   Only the accepted rational ordered field and shared pre-real gateway are used. -/
namespace BOMA.R.StageTwo.CauchyCloseness003

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001

/-- Negation is involutive in the already accepted rational additive group. -/
theorem qNeg_neg (x : QBOMA) : qNeg (qNeg x) = x := by
  symm
  exact qAdd_inverse_unique (x := qNeg x) (y := x) (qAdd_neg_left x)

/-- Reversing a rational difference negates it. -/
theorem qNeg_difference (x y : QBOMA) :
    qNeg (qAdd x (qNeg y)) = qAdd y (qNeg x) := by
  rw [qNeg_add, qNeg_neg, qAdd_comm]

/-- Accepted rational epsilon-closeness is symmetric. -/
theorem qClose_symm {eps x y : QBOMA} (h : qClose eps x y) :
    qClose eps y x := by
  rcases h with ⟨hlower, hupper⟩
  constructor
  · have hrev := qneg_reverses hupper
    rw [qNeg_difference] at hrev
    exact hrev
  · have hrev := qneg_reverses hlower
    rw [qNeg_difference, qNeg_neg] at hrev
    exact hrev

/-- Independent monotonicity in both arguments of rational addition. -/
theorem qAdd_mono {a b c d : QBOMA}
    (hab : qLE a b) (hcd : qLE c d) : qLE (qAdd a c) (qAdd b d) := by
  apply qle_trans (qadd_mono_right hab c)
  have h := qadd_mono_right hcd b
  rw [qAdd_comm c b, qAdd_comm d b] at h
  exact h

/-- Consecutive rational differences add without introducing a metric. -/
theorem q_difference_chain (x y z : QBOMA) :
    qAdd (qAdd x (qNeg y)) (qAdd y (qNeg z)) = qAdd x (qNeg z) := by
  calc
    qAdd (qAdd x (qNeg y)) (qAdd y (qNeg z)) =
        qAdd x (qAdd (qNeg y) (qAdd y (qNeg z))) :=
      qAdd_assoc x (qNeg y) (qAdd y (qNeg z))
    _ = qAdd x (qAdd (qAdd (qNeg y) y) (qNeg z)) := by
      rw [qAdd_assoc]
    _ = qAdd x (qAdd qZero (qNeg z)) := by rw [qAdd_neg_left]
    _ = qAdd x (qNeg z) := by rw [qAdd_zero_left]

/-- The epsilon triangle inequality stated using only accepted rational order. -/
theorem qClose_triangle {eps delta x y z : QBOMA}
    (hxy : qClose eps x y) (hyz : qClose delta y z) :
    qClose (qAdd eps delta) x z := by
  constructor
  · have h := qAdd_mono hxy.1 hyz.1
    rw [← qNeg_add, q_difference_chain] at h
    exact h
  · have h := qAdd_mono hxy.2 hyz.2
    rw [q_difference_chain] at h
    exact h

/-- Every positive accepted rational has a positive half, with exact sum. -/
theorem positive_half_exists {eps : QBOMA} (heps : qPos eps) :
    ∃ delta : QBOMA, qPos delta ∧ qAdd delta delta = eps := by
  rcases rational_half_exists with ⟨h, hinv, hhpos, _⟩
  have hepsPositive : QPositive eps :=
    ⟨heps.1, fun heq => heps.2 heq.symm⟩
  have hdelta := qlt_mul_left_positive hhpos hepsPositive
  rw [qMul_zero_right] at hdelta
  have hsum : qAdd h h = qOne := by
    calc
      qAdd h h = qAdd (qMul qOne h) (qMul qOne h) := by
        rw [qMul_one_left]
      _ = qMul (qAdd qOne qOne) h :=
        (qMul_add_left qOne qOne h).symm
      _ = qOne := hinv
  refine ⟨qMul eps h, hdelta, ?_⟩
  calc
    qAdd (qMul eps h) (qMul eps h) = qMul eps (qAdd h h) :=
      (qMul_add_right eps h h).symm
    _ = qMul eps qOne := by rw [hsum]
    _ = eps := qMul_one_right eps

/-- Closeness at every positive rational epsilon forces rational equality. -/
theorem qClose_all_positive_reflects {x y : QBOMA}
    (hclose : ∀ eps : QBOMA, qPos eps → qClose eps x y) : x = y := by
  rcases qlt_trichotomy x y with hxy | hxy | hyx
  · have hd := positive_difference_of_lt hxy
    have hdpos : qPos (qAdd y (qNeg x)) :=
      ⟨hd.1, fun heq => hd.2 heq.symm⟩
    rcases positive_half_exists hdpos with ⟨delta, hdelta, hsum⟩
    have hdiff := (qClose_symm (hclose delta hdelta)).2
    have hstrict := qlt_add_right hdelta delta
    rw [qAdd_zero_left, hsum] at hstrict
    exact False.elim (hstrict.2 (qle_antisymm hstrict.1 hdiff))
  · exact hxy
  · have hd := positive_difference_of_lt hyx
    have hdpos : qPos (qAdd x (qNeg y)) :=
      ⟨hd.1, fun heq => hd.2 heq.symm⟩
    rcases positive_half_exists hdpos with ⟨delta, hdelta, hsum⟩
    have hdiff := (hclose delta hdelta).2
    have hstrict := qlt_add_right hdelta delta
    rw [qAdd_zero_left, hsum] at hstrict
    exact False.elim (hstrict.2 (qle_antisymm hstrict.1 hdiff))

end BOMA.R.StageTwo.CauchyCloseness003

/- ST2-EXP-003: independent Cauchy equivalence, formal carrier, and faithful
   rational embedding. No accepted Dedekind carrier or producer is imported. -/
namespace BOMA.R.StageTwo.CauchyQuotient003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003

/-- The old representation-level relation is genuinely reflexive. -/
theorem cauchyEquiv_refl (u : CauchySeq) : CauchyEquiv u u := by
  intro eps heps
  refine ⟨BOMANat.z, ?_⟩
  intro n hn
  exact qClose_refl_of_pos eps (u.seq n) heps

/-- Its symmetry follows from proved rational-difference symmetry. -/
theorem cauchyEquiv_symm {u v : CauchySeq}
    (h : CauchyEquiv u v) : CauchyEquiv v u := by
  intro eps heps
  rcases h eps heps with ⟨N, hN⟩
  exact ⟨N, fun n hn => qClose_symm (hN n hn)⟩

/-- Its transitivity uses an explicitly proved positive epsilon half. -/
theorem cauchyEquiv_trans {u v w : CauchySeq}
    (huv : CauchyEquiv u v) (hvw : CauchyEquiv v w) :
    CauchyEquiv u w := by
  intro eps heps
  rcases positive_half_exists heps with ⟨delta, hdelta, hsum⟩
  rcases huv delta hdelta with ⟨Nu, hNu⟩
  rcases hvw delta hdelta with ⟨Nv, hNv⟩
  rcases le_total Nu Nv with hUV | hVU
  · refine ⟨Nv, ?_⟩
    intro n hn
    have h := qClose_triangle (hNu n (le_trans hUV hn)) (hNv n hn)
    rw [hsum] at h
    exact h
  · refine ⟨Nu, ?_⟩
    intro n hn
    have h := qClose_triangle (hNu n hn) (hNv n (le_trans hVU hn))
    rw [hsum] at h
    exact h

/-- Verified asymptotic identity, rather than raw Lean structure equality. -/
def cauchySetoid : Setoid CauchySeq where
  r := CauchyEquiv
  iseqv := ⟨cauchyEquiv_refl, @cauchyEquiv_symm, @cauchyEquiv_trans⟩

/-- Research Cauchy real carrier; not an accepted replacement for RBOMA. -/
def RCBOMA : Type := Quotient cauchySetoid

/-- Quotient injection of an explicitly verified rational Cauchy sequence. -/
def rCmk (u : CauchySeq) : RCBOMA := Quotient.mk cauchySetoid u

/-- Formal carrier equality is exactly the declared asymptotic identity. -/
theorem rCmk_eq_iff {u v : CauchySeq} : rCmk u = rCmk v ↔ CauchyEquiv u v := by
  constructor
  · exact Quotient.exact
  · intro huv
    exact Quotient.sound huv

/-- Rational embedding by the previously verified constant-sequence producer. -/
def rCOfQ (q : QBOMA) : RCBOMA := rCmk (cauchyOfQ q)

/-- Formal quotient equality between constant sequences reflects QBOMA identity. -/
theorem rCOfQ_injective {q r : QBOMA} (h : rCOfQ q = rCOfQ r) : q = r := by
  have hequiv : CauchyEquiv (cauchyOfQ q) (cauchyOfQ r) :=
    (rCmk_eq_iff).mp h
  apply qClose_all_positive_reflects
  intro eps heps
  rcases hequiv eps heps with ⟨N, hN⟩
  exact hN N (le_refl N)

end BOMA.R.StageTwo.CauchyQuotient003

/- ST2-EXP-003: independent additive structure on the rational Cauchy quotient.
   This file uses accepted Q operations and the verified Cauchy quotient only. -/
namespace BOMA.R.StageTwo.CauchyAdditive003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003

/-- Negating both endpoints preserves rational epsilon-closeness. -/
theorem qClose_neg {eps x y : QBOMA} (h : qClose eps x y) :
    qClose eps (qNeg x) (qNeg y) := by
  have hs := qClose_symm h
  unfold qClose at hs ⊢
  rw [qNeg_neg, qAdd_comm (qNeg x) y]
  exact hs

/-- The difference of two rational sums is the sum of their differences. -/
theorem q_difference_sum (x a y b : QBOMA) :
    qAdd (qAdd x a) (qNeg (qAdd y b)) =
      qAdd (qAdd x (qNeg y)) (qAdd a (qNeg b)) := by
  rw [qNeg_add]
  calc
    qAdd (qAdd x a) (qAdd (qNeg y) (qNeg b)) =
        qAdd x (qAdd a (qAdd (qNeg y) (qNeg b))) :=
      qAdd_assoc x a (qAdd (qNeg y) (qNeg b))
    _ = qAdd x (qAdd (qNeg y) (qAdd a (qNeg b))) :=
      qAdd_exchange x a (qNeg y) (qNeg b)
    _ = qAdd (qAdd x (qNeg y)) (qAdd a (qNeg b)) :=
      (qAdd_assoc x (qNeg y) (qAdd a (qNeg b))).symm

/-- Adding epsilon-close rationals adds their explicit error bounds. -/
theorem qClose_add {eps delta x y a b : QBOMA}
    (hxy : qClose eps x y) (hab : qClose delta a b) :
    qClose (qAdd eps delta) (qAdd x a) (qAdd y b) := by
  constructor
  · have h := qAdd_mono hxy.1 hab.1
    rw [← qNeg_add] at h
    rw [q_difference_sum]
    exact h
  · have h := qAdd_mono hxy.2 hab.2
    rw [q_difference_sum]
    exact h

/-- Pointwise addition of rational sequences. -/
def seqAdd (u v : QSeq) : QSeq := fun n => qAdd (u n) (v n)

/-- Pointwise negation of a rational sequence. -/
def seqNeg (u : QSeq) : QSeq := fun n => qNeg (u n)

/-- Pointwise addition preserves the Cauchy condition. -/
theorem seqAdd_cauchy {u v : QSeq}
    (hu : IsCauchy u) (hv : IsCauchy v) : IsCauchy (seqAdd u v) := by
  intro eps heps
  rcases positive_half_exists heps with ⟨delta, hdelta, hsum⟩
  rcases hu delta hdelta with ⟨Nu, hNu⟩
  rcases hv delta hdelta with ⟨Nv, hNv⟩
  rcases le_total Nu Nv with hUV | hVU
  · refine ⟨Nv, ?_⟩
    intro m n hm hn
    have h := qClose_add
      (hNu m n (le_trans hUV hm) (le_trans hUV hn))
      (hNv m n hm hn)
    rw [hsum] at h
    exact h
  · refine ⟨Nu, ?_⟩
    intro m n hm hn
    have h := qClose_add
      (hNu m n hm hn)
      (hNv m n (le_trans hVU hm) (le_trans hVU hn))
    rw [hsum] at h
    exact h

/-- Pointwise negation preserves the Cauchy condition. -/
theorem seqNeg_cauchy {u : QSeq} (hu : IsCauchy u) : IsCauchy (seqNeg u) := by
  intro eps heps
  rcases hu eps heps with ⟨N, hN⟩
  exact ⟨N, fun m n hm hn => qClose_neg (hN m n hm hn)⟩

/-- Addition on verified Cauchy representatives. -/
def cAddSeq (u v : CauchySeq) : CauchySeq :=
  ⟨seqAdd u.seq v.seq, seqAdd_cauchy u.cauchy v.cauchy⟩

/-- Negation on verified Cauchy representatives. -/
def cNegSeq (u : CauchySeq) : CauchySeq :=
  ⟨seqNeg u.seq, seqNeg_cauchy u.cauchy⟩

/-- Addition respects asymptotic identity in both inputs. -/
theorem cAddSeq_respects {u u' v v' : CauchySeq}
    (hu : CauchyEquiv u u') (hv : CauchyEquiv v v') :
    CauchyEquiv (cAddSeq u v) (cAddSeq u' v') := by
  intro eps heps
  rcases positive_half_exists heps with ⟨delta, hdelta, hsum⟩
  rcases hu delta hdelta with ⟨Nu, hNu⟩
  rcases hv delta hdelta with ⟨Nv, hNv⟩
  rcases le_total Nu Nv with hUV | hVU
  · refine ⟨Nv, ?_⟩
    intro n hn
    have h := qClose_add (hNu n (le_trans hUV hn)) (hNv n hn)
    rw [hsum] at h
    exact h
  · refine ⟨Nu, ?_⟩
    intro n hn
    have h := qClose_add (hNu n hn) (hNv n (le_trans hVU hn))
    rw [hsum] at h
    exact h

/-- Negation respects asymptotic identity. -/
theorem cNegSeq_respects {u v : CauchySeq} (h : CauchyEquiv u v) :
    CauchyEquiv (cNegSeq u) (cNegSeq v) := by
  intro eps heps
  rcases h eps heps with ⟨N, hN⟩
  exact ⟨N, fun n hn => qClose_neg (hN n hn)⟩

/-- Research addition on the Cauchy quotient. -/
def rCAdd : RCBOMA → RCBOMA → RCBOMA :=
  Quotient.lift₂
    (fun u v => rCmk (cAddSeq u v))
    (fun _ _ _ _ hu hv => Quotient.sound (cAddSeq_respects hu hv))

/-- Research negation on the Cauchy quotient. -/
def rCNeg : RCBOMA → RCBOMA :=
  Quotient.lift
    (fun u => rCmk (cNegSeq u))
    (fun _ _ h => Quotient.sound (cNegSeq_respects h))

/-- Research additive zero is the constant rational zero sequence. -/
def rCZero : RCBOMA := rCOfQ qZero

@[simp] theorem rCAdd_mk (u v : CauchySeq) :
    rCAdd (rCmk u) (rCmk v) = rCmk (cAddSeq u v) := rfl

@[simp] theorem rCNeg_mk (u : CauchySeq) :
    rCNeg (rCmk u) = rCmk (cNegSeq u) := rfl

/-- Pointwise equality supplies asymptotic equality without a selector. -/
theorem cauchyEquiv_of_pointwise_eq {u v : CauchySeq}
    (h : ∀ n : BOMANat, u.seq n = v.seq n) : CauchyEquiv u v := by
  intro eps heps
  refine ⟨BOMANat.z, ?_⟩
  intro n hn
  rw [h n]
  exact qClose_refl_of_pos eps (v.seq n) heps

/-- Quotient addition is commutative. -/
theorem rCAdd_comm (x y : RCBOMA) : rCAdd x y = rCAdd y x := by
  refine Quotient.inductionOn x ?_
  intro u
  refine Quotient.inductionOn y ?_
  intro v
  exact Quotient.sound (cauchyEquiv_of_pointwise_eq (fun n => qAdd_comm _ _))

/-- Quotient addition is associative. -/
theorem rCAdd_assoc (x y z : RCBOMA) :
    rCAdd (rCAdd x y) z = rCAdd x (rCAdd y z) := by
  refine Quotient.inductionOn x ?_
  intro u
  refine Quotient.inductionOn y ?_
  intro v
  refine Quotient.inductionOn z ?_
  intro w
  exact Quotient.sound (cauchyEquiv_of_pointwise_eq (fun n => qAdd_assoc _ _ _))

/-- The constant zero sequence is a left identity. -/
theorem rCAdd_zero_left (x : RCBOMA) : rCAdd rCZero x = x := by
  refine Quotient.inductionOn x ?_
  intro u
  exact Quotient.sound
    (cauchyEquiv_of_pointwise_eq (fun n => qAdd_zero_left (u.seq n)))

/-- Pointwise negation gives a right additive inverse. -/
theorem rCAdd_neg_right (x : RCBOMA) : rCAdd x (rCNeg x) = rCZero := by
  refine Quotient.inductionOn x ?_
  intro u
  exact Quotient.sound
    (cauchyEquiv_of_pointwise_eq (fun n => qAdd_neg_right (u.seq n)))

/-- The constant-sequence rational embedding preserves addition. -/
theorem rCOfQ_add (q r : QBOMA) :
    rCAdd (rCOfQ q) (rCOfQ r) = rCOfQ (qAdd q r) := by
  exact Quotient.sound (cauchyEquiv_of_pointwise_eq (fun n => rfl))

/-- The constant-sequence rational embedding preserves negation. -/
theorem rCOfQ_neg (q : QBOMA) : rCNeg (rCOfQ q) = rCOfQ (qNeg q) := by
  exact Quotient.sound (cauchyEquiv_of_pointwise_eq (fun n => rfl))

/-- Independently assembled additive-group-strength research certificate. -/
structure CauchyAdditiveCertificate where
  qEmbeddingInjective : ∀ {q r : QBOMA}, rCOfQ q = rCOfQ r → q = r
  addComm : ∀ x y : RCBOMA, rCAdd x y = rCAdd y x
  addAssoc : ∀ x y z : RCBOMA, rCAdd (rCAdd x y) z = rCAdd x (rCAdd y z)
  addZeroLeft : ∀ x : RCBOMA, rCAdd rCZero x = x
  addInverseRight : ∀ x : RCBOMA, rCAdd x (rCNeg x) = rCZero
  qEmbeddingAdd : ∀ q r : QBOMA,
    rCAdd (rCOfQ q) (rCOfQ r) = rCOfQ (qAdd q r)
  qEmbeddingNeg : ∀ q : QBOMA, rCNeg (rCOfQ q) = rCOfQ (qNeg q)

theorem cauchyAdditiveCertificate : CauchyAdditiveCertificate where
  qEmbeddingInjective := @rCOfQ_injective
  addComm := rCAdd_comm
  addAssoc := rCAdd_assoc
  addZeroLeft := rCAdd_zero_left
  addInverseRight := rCAdd_neg_right
  qEmbeddingAdd := rCOfQ_add
  qEmbeddingNeg := rCOfQ_neg

end BOMA.R.StageTwo.CauchyAdditive003

/- ST2-EXP-003: eventual symmetric boundedness of rational Cauchy sequences.
   This is the explicit prerequisite for pointwise multiplication; it does not
   define multiplication or claim an ordered-field completion. -/
namespace BOMA.R.StageTwo.CauchyBounded003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003

/-- The selected rational negation fixes zero. -/
theorem qNeg_zero : qNeg qZero = qZero := by
  symm
  exact qAdd_inverse_unique (x := qZero) (y := qZero) (qAdd_zero_left qZero)

/-- A symmetric rational interval with radius `B`. -/
def qAbsBound (B x : QBOMA) : Prop :=
  qLE (qNeg B) x ∧ qLE x B

/-- Adding one to a nonnegative rational produces a positive rational. -/
theorem qNonneg_add_one_positive {B : QBOMA} (hB : qLE qZero B) :
    qPos (qAdd B qOne) := by
  constructor
  · have h := qAdd_mono hB qzero_le_one
    rw [qAdd_zero_left] at h
    exact h
  · intro hzero
    have hstep := qadd_mono_right qzero_le_one B
    rw [qAdd_zero_left, qAdd_comm qOne B, hzero.symm] at hstep
    have hBzero : B = qZero := qle_antisymm hstep hB
    rw [hBzero, qAdd_zero_left] at hzero
    exact qone_ne_zero hzero.symm

/-- A positive radius remains positive after adding one. -/
theorem qAdd_one_positive {B : QBOMA} (hB : qPos B) :
    qPos (qAdd B qOne) :=
  qNonneg_add_one_positive hB.1

/-- Every nonnegative rational lies in a positive symmetric interval. -/
theorem nonnegative_has_positive_bound {a : QBOMA} (ha : qLE qZero a) :
    ∃ B : QBOMA, qPos B ∧ qAbsBound B a := by
  let B := qAdd a qOne
  have hBpos : qPos B := qNonneg_add_one_positive ha
  refine ⟨B, hBpos, ?_⟩
  constructor
  · have hneg : qLE (qNeg B) (qNeg qZero) := qneg_reverses hBpos.1
    rw [qNeg_zero] at hneg
    exact qle_trans hneg ha
  · have h := qadd_mono_right qzero_le_one a
    rw [qAdd_zero_left, qAdd_comm qOne a] at h
    exact h

/-- Every rational admits a positive symmetric interval. -/
theorem rational_has_positive_bound (a : QBOMA) :
    ∃ B : QBOMA, qPos B ∧ qAbsBound B a := by
  rcases qle_total qZero a with ha | ha
  · exact nonnegative_has_positive_bound ha
  · have hnega : qLE qZero (qNeg a) := by
      have h := qneg_reverses ha
      rw [qNeg_zero] at h
      exact h
    rcases nonnegative_has_positive_bound hnega with ⟨B, hB, hlower, hupper⟩
    refine ⟨B, hB, ?_⟩
    constructor
    · simpa only [qNeg_neg] using qneg_reverses hupper
    · simpa only [qNeg_neg] using qneg_reverses hlower

/-- Translating a rational difference back by its right endpoint cancels it. -/
theorem q_difference_cancel_right (x a : QBOMA) :
    qAdd (qAdd x (qNeg a)) a = x := by
  calc
    qAdd (qAdd x (qNeg a)) a = qAdd x (qAdd (qNeg a) a) :=
      qAdd_assoc x (qNeg a) a
    _ = qAdd x qZero := by rw [qAdd_neg_left]
    _ = x := qAdd_zero_right x

/-- One-close to a bounded point is bounded by the radius enlarged by one. -/
theorem qClose_one_expands_bound {B x a : QBOMA}
    (ha : qAbsBound B a) (hclose : qClose qOne x a) :
    qAbsBound (qAdd B qOne) x := by
  constructor
  · have hshift := qadd_mono_right hclose.1 a
    rw [q_difference_cancel_right] at hshift
    have hbase := qadd_mono_right ha.1 (qNeg qOne)
    rw [← qNeg_add, qAdd_comm a (qNeg qOne)] at hbase
    exact qle_trans hbase hshift
  · have hshift := qadd_mono_right hclose.2 a
    rw [q_difference_cancel_right, qAdd_comm qOne a] at hshift
    have hbase := qadd_mono_right ha.2 qOne
    exact qle_trans hshift hbase

/-- Eventual symmetric boundedness, with an explicit positive radius. -/
def EventuallyBounded (u : QSeq) : Prop :=
  ∃ B : QBOMA, qPos B ∧
    ∃ N : BOMANat, ∀ n : BOMANat, LE N n → qAbsBound B (u n)

/-- Every accepted-Q Cauchy sequence is eventually bounded. -/
theorem cauchy_eventually_bounded (u : CauchySeq) : EventuallyBounded u.seq := by
  rcases u.cauchy qOne qzero_lt_one with ⟨N, hN⟩
  rcases rational_has_positive_bound (u.seq N) with ⟨B, hB, hBN⟩
  refine ⟨qAdd B qOne, qAdd_one_positive hB, N, ?_⟩
  intro n hn
  exact qClose_one_expands_bound hBN (hN n N hn (le_refl N))

/-- Independently assembled boundedness milestone, retaining the prior
    additive certificate as an explicit dependency. -/
structure CauchyBoundedCertificate where
  additiveCertificate : CauchyAdditiveCertificate
  eventualBounded : ∀ u : CauchySeq, EventuallyBounded u.seq

theorem cauchyBoundedCertificate : CauchyBoundedCertificate where
  additiveCertificate := cauchyAdditiveCertificate
  eventualBounded := cauchy_eventually_bounded

end BOMA.R.StageTwo.CauchyBounded003

/- ST2-EXP-003: rational product estimates under explicit symmetric bounds.
   This is a prerequisite for Cauchy multiplication, not a multiplication
   operation on the quotient and not a field-completion claim. -/
namespace BOMA.R.StageTwo.CauchyProductBounds003

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyBounded003

/-- Negation in the right rational factor. -/
theorem qMul_neg_right (x y : QBOMA) :
    qMul x (qNeg y) = qNeg (qMul x y) := by
  calc
    qMul x (qNeg y) = qMul (qNeg y) x := qMul_comm x (qNeg y)
    _ = qNeg (qMul y x) := qMul_neg_left y x
    _ = qNeg (qMul x y) := congrArg qNeg (qMul_comm y x)

/-- The product of two negated rationals is the original product. -/
theorem qMul_neg_neg (x y : QBOMA) :
    qMul (qNeg x) (qNeg y) = qMul x y := by
  calc
    qMul (qNeg x) (qNeg y) = qNeg (qMul x (qNeg y)) :=
      qMul_neg_left x (qNeg y)
    _ = qNeg (qNeg (qMul x y)) := congrArg qNeg (qMul_neg_right x y)
    _ = qMul x y := qNeg_neg (qMul x y)

/-- A symmetric bound is preserved by negation. -/
theorem qAbsBound_neg {B x : QBOMA} (hx : qAbsBound B x) :
    qAbsBound B (qNeg x) := by
  constructor
  · exact qneg_reverses hx.2
  · simpa only [qNeg_neg] using qneg_reverses hx.1

/-- The upper half of the rational interval-product estimate. -/
theorem qMul_upper_of_bounds {B C x y : QBOMA}
    (hB : qLE qZero B) (hC : qLE qZero C)
    (hx : qAbsBound B x) (hy : qAbsBound C y) :
    qLE (qMul x y) (qMul B C) := by
  have hBC : qLE qZero (qMul B C) := qmul_nonneg hB hC
  rcases qle_total qZero x with hx0 | hx0
  · rcases qle_total qZero y with hy0 | hy0
    · exact qle_trans
        (qmul_mono_right_nonneg hx.2 hy0)
        (qmul_mono_left_nonneg hy.2 hB)
    · have hxy0 := qmul_mono_left_nonneg hy0 hx0
      rw [qMul_zero_right] at hxy0
      exact qle_trans hxy0 hBC
  · rcases qle_total qZero y with hy0 | hy0
    · have hxy0 := qmul_mono_right_nonneg hx0 hy0
      rw [qMul_zero_left] at hxy0
      exact qle_trans hxy0 hBC
    · have hnx : qLE qZero (qNeg x) := by
        have h := qneg_reverses hx0
        rw [BOMA.R.StageTwo.CauchyBounded003.qNeg_zero] at h
        exact h
      have hny : qLE qZero (qNeg y) := by
        have h := qneg_reverses hy0
        rw [BOMA.R.StageTwo.CauchyBounded003.qNeg_zero] at h
        exact h
      have hnxB : qLE (qNeg x) B := by
        simpa only [qNeg_neg] using qneg_reverses hx.1
      have hnyC : qLE (qNeg y) C := by
        simpa only [qNeg_neg] using qneg_reverses hy.1
      have hprod := qle_trans
        (qmul_mono_right_nonneg hnxB hny)
        (qmul_mono_left_nonneg hnyC hB)
      rw [qMul_neg_neg] at hprod
      exact hprod

/-- Products of symmetrically bounded rationals are symmetrically bounded. -/
theorem qAbsBound_mul {B C x y : QBOMA}
    (hB : qLE qZero B) (hC : qLE qZero C)
    (hx : qAbsBound B x) (hy : qAbsBound C y) :
    qAbsBound (qMul B C) (qMul x y) := by
  constructor
  · have hupper := qMul_upper_of_bounds hB hC (qAbsBound_neg hx) hy
    rw [qMul_neg_left] at hupper
    simpa only [qNeg_neg] using qneg_reverses hupper
  · exact qMul_upper_of_bounds hB hC hx hy

/-- Sums of symmetrically bounded rationals add their radii. -/
theorem qAbsBound_add {B C x y : QBOMA}
    (hx : qAbsBound B x) (hy : qAbsBound C y) :
    qAbsBound (qAdd B C) (qAdd x y) := by
  constructor
  · have h := qAdd_mono hx.1 hy.1
    rw [← qNeg_add] at h
    exact h
  · exact qAdd_mono hx.2 hy.2

/-- Algebraic decomposition of the difference between two products. -/
theorem q_product_difference (x y a b : QBOMA) :
    qAdd (qMul x (qAdd y (qNeg b)))
      (qMul b (qAdd x (qNeg a))) =
    qAdd (qMul x y) (qNeg (qMul a b)) := by
  rw [qMul_add_right, qMul_add_right, qMul_neg_right, qMul_neg_right]
  rw [qMul_comm b x, qMul_comm b a]
  exact q_difference_chain (qMul x y) (qMul x b) (qMul a b)

/-- Product closeness from a common endpoint bound and an explicit scale. -/
theorem qClose_mul_of_common_bound
    {eps delta K x a y b : QBOMA}
    (hK : qLE qZero K) (hdelta : qLE qZero delta)
    (hscale : qAdd (qMul K delta) (qMul K delta) = eps)
    (hx : qAbsBound K x) (ha : qAbsBound K a)
    (hy : qAbsBound K y) (hb : qAbsBound K b)
    (hxa : qClose delta x a) (hyb : qClose delta y b) :
    qClose eps (qMul x y) (qMul a b) := by
  have hfirst : qAbsBound (qMul K delta)
      (qMul x (qAdd y (qNeg b))) :=
    qAbsBound_mul hK hdelta hx hyb
  have hsecond : qAbsBound (qMul K delta)
      (qMul b (qAdd x (qNeg a))) :=
    qAbsBound_mul hK hdelta hb hxa
  have hsum := qAbsBound_add hfirst hsecond
  rw [hscale] at hsum
  change qAbsBound eps
    (qAdd (qMul x y) (qNeg (qMul a b)))
  rw [← q_product_difference]
  exact hsum

/-- Product-estimate milestone retaining the verified boundedness producer. -/
structure CauchyProductBoundCertificate where
  boundedCertificate : CauchyBoundedCertificate
  boundMul : ∀ {B C x y : QBOMA},
    qLE qZero B → qLE qZero C →
    qAbsBound B x → qAbsBound C y →
    qAbsBound (qMul B C) (qMul x y)
  productCloseness : ∀ {eps delta K x a y b : QBOMA},
    qLE qZero K → qLE qZero delta →
    qAdd (qMul K delta) (qMul K delta) = eps →
    qAbsBound K x → qAbsBound K a →
    qAbsBound K y → qAbsBound K b →
    qClose delta x a → qClose delta y b →
    qClose eps (qMul x y) (qMul a b)

theorem cauchyProductBoundCertificate : CauchyProductBoundCertificate where
  boundedCertificate := cauchyBoundedCertificate
  boundMul := @qAbsBound_mul
  productCloseness := @qClose_mul_of_common_bound

end BOMA.R.StageTwo.CauchyProductBounds003

/- ST2-EXP-003: pointwise multiplication descends to the independent Cauchy
   quotient. This establishes a commutative-ring-strength milestone only;
   order, inverses, and completeness remain separate obligations. -/
namespace BOMA.R.StageTwo.CauchyMultiplicative003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.Q.Inverse001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyBounded003
open BOMA.R.StageTwo.CauchyProductBounds003

/-- Any two accepted-natural thresholds have a common upper threshold. -/
theorem common_upper_bound (a b : BOMANat) :
    ∃ N : BOMANat, LE a N ∧ LE b N := by
  rcases le_total a b with hab | hba
  · exact ⟨b, hab, le_refl b⟩
  · exact ⟨a, le_refl a, hba⟩

/-- A symmetric bound may be enlarged monotonically. -/
theorem qAbsBound_mono {B K x : QBOMA}
    (hBK : qLE B K) (hx : qAbsBound B x) : qAbsBound K x := by
  constructor
  · exact qle_trans (qneg_reverses hBK) hx.1
  · exact qle_trans hx.2 hBK

/-- The sum of two positive rational radii is positive. -/
theorem qPos_add {B C : QBOMA} (hB : qPos B) (hC : qPos C) :
    qPos (qAdd B C) := by
  constructor
  · have h := qAdd_mono hB.1 hC.1
    rw [qAdd_zero_left] at h
    exact h
  · intro hzero
    have hBsum := qadd_mono_right hC.1 B
    rw [qAdd_zero_left, qAdd_comm C B, hzero.symm] at hBsum
    exact hB.2 (qle_antisymm hB.1 hBsum)

/-- Two Cauchy sequences share one eventual positive symmetric bound. -/
theorem pair_common_eventual_bound (u v : CauchySeq) :
    ∃ K : QBOMA, qPos K ∧
      ∃ N : BOMANat, ∀ n : BOMANat, LE N n →
        qAbsBound K (u.seq n) ∧ qAbsBound K (v.seq n) := by
  rcases cauchy_eventually_bounded u with ⟨B, hB, Nu, hNu⟩
  rcases cauchy_eventually_bounded v with ⟨C, hC, Nv, hNv⟩
  let K := qAdd B C
  have hK : qPos K := qPos_add hB hC
  have hBK : qLE B K := by
    have h := qadd_mono_right hC.1 B
    rw [qAdd_zero_left, qAdd_comm C B] at h
    exact h
  have hCK : qLE C K := by
    have h := qadd_mono_right hB.1 C
    rw [qAdd_zero_left] at h
    exact h
  rcases common_upper_bound Nu Nv with ⟨N, hNuN, hNvN⟩
  refine ⟨K, hK, N, ?_⟩
  intro n hn
  exact ⟨
    qAbsBound_mono hBK (hNu n (le_trans hNuN hn)),
    qAbsBound_mono hCK (hNv n (le_trans hNvN hn))
  ⟩

/-- Four Cauchy sequences share one eventual positive symmetric bound. -/
theorem four_common_eventual_bound (u a v b : CauchySeq) :
    ∃ K : QBOMA, qPos K ∧
      ∃ N : BOMANat, ∀ n : BOMANat, LE N n →
        qAbsBound K (u.seq n) ∧ qAbsBound K (a.seq n) ∧
        qAbsBound K (v.seq n) ∧ qAbsBound K (b.seq n) := by
  rcases pair_common_eventual_bound u a with ⟨K₁, hK₁, N₁, hN₁⟩
  rcases pair_common_eventual_bound v b with ⟨K₂, hK₂, N₂, hN₂⟩
  let K := qAdd K₁ K₂
  have hK : qPos K := qPos_add hK₁ hK₂
  have hK₁K : qLE K₁ K := by
    have h := qadd_mono_right hK₂.1 K₁
    rw [qAdd_zero_left, qAdd_comm K₂ K₁] at h
    exact h
  have hK₂K : qLE K₂ K := by
    have h := qadd_mono_right hK₁.1 K₂
    rw [qAdd_zero_left] at h
    exact h
  rcases common_upper_bound N₁ N₂ with ⟨N, hN₁N, hN₂N⟩
  refine ⟨K, hK, N, ?_⟩
  intro n hn
  rcases hN₁ n (le_trans hN₁N hn) with ⟨hu, ha⟩
  rcases hN₂ n (le_trans hN₂N hn) with ⟨hv, hb⟩
  exact ⟨
    qAbsBound_mono hK₁K hu,
    qAbsBound_mono hK₁K ha,
    qAbsBound_mono hK₂K hv,
    qAbsBound_mono hK₂K hb
  ⟩

/-- A positive scale exists so that two common-bound error terms sum to the
    requested positive epsilon. -/
theorem product_delta_exists {eps K : QBOMA}
    (heps : qPos eps) (hK : qPos K) :
    ∃ delta : QBOMA, qPos delta ∧
      qAdd (qMul K delta) (qMul K delta) = eps := by
  rcases positive_half_exists heps with ⟨half, hhalf, hhalfsum⟩
  have hKPositive : QPositive K :=
    ⟨hK.1, fun h => hK.2 h.symm⟩
  rcases q_inverse_exists K hKPositive.2 with ⟨invK, hinvK⟩
  have hinvPositive : QPositive invK :=
    inverse_of_positive_is_positive hKPositive hinvK
  have hhalfPositive : QPositive half :=
    ⟨hhalf.1, fun h => hhalf.2 h.symm⟩
  let delta := qMul half invK
  have hdeltaNonNeg : qLE qZero delta := by
    unfold delta
    exact qmul_nonneg hhalfPositive.1 hinvPositive.1
  have hdeltaNe : delta ≠ qZero := by
    unfold delta
    exact qMul_ne_zero hhalfPositive.2 hinvPositive.2
  have hdelta : qPos delta :=
    ⟨hdeltaNonNeg, fun h => hdeltaNe h.symm⟩
  have hKdelta : qMul K delta = half := by
    unfold delta
    calc
      qMul K (qMul half invK) = qMul (qMul K half) invK :=
        (qMul_assoc K half invK).symm
      _ = qMul (qMul half K) invK :=
        congrArg (fun t => qMul t invK) (qMul_comm K half)
      _ = qMul half (qMul K invK) := qMul_assoc half K invK
      _ = qMul half qOne := congrArg (fun t => qMul half t) hinvK
      _ = half := qMul_one_right half
  refine ⟨delta, hdelta, ?_⟩
  rw [hKdelta, hhalfsum]

/-- Pointwise multiplication of rational sequences. -/
def seqMul (u v : QSeq) : QSeq := fun n => qMul (u n) (v n)

/-- Pointwise multiplication preserves the Cauchy condition. -/
theorem seqMul_cauchy {u v : QSeq}
    (hu : IsCauchy u) (hv : IsCauchy v) : IsCauchy (seqMul u v) := by
  let U : CauchySeq := ⟨u, hu⟩
  let V : CauchySeq := ⟨v, hv⟩
  rcases pair_common_eventual_bound U V with ⟨K, hK, Nb, hNb⟩
  intro eps heps
  rcases product_delta_exists heps hK with ⟨delta, hdelta, hscale⟩
  rcases hu delta hdelta with ⟨Nu, hNu⟩
  rcases hv delta hdelta with ⟨Nv, hNv⟩
  rcases common_upper_bound Nb Nu with ⟨Nbu, hNbNbu, hNuNbu⟩
  rcases common_upper_bound Nbu Nv with ⟨N, hNbuN, hNvN⟩
  refine ⟨N, ?_⟩
  intro m n hm hn
  have hNbm : LE Nb m := le_trans hNbNbu (le_trans hNbuN hm)
  have hNbn : LE Nb n := le_trans hNbNbu (le_trans hNbuN hn)
  rcases hNb m hNbm with ⟨hUm, hVm⟩
  rcases hNb n hNbn with ⟨hUn, hVn⟩
  exact qClose_mul_of_common_bound hK.1 hdelta.1 hscale
    hUm hUn hVm hVn
    (hNu m n (le_trans hNuNbu (le_trans hNbuN hm))
      (le_trans hNuNbu (le_trans hNbuN hn)))
    (hNv m n (le_trans hNvN hm) (le_trans hNvN hn))

/-- Multiplication on verified Cauchy representatives. -/
def cMulSeq (u v : CauchySeq) : CauchySeq :=
  ⟨seqMul u.seq v.seq, seqMul_cauchy u.cauchy v.cauchy⟩

/-- Pointwise multiplication respects asymptotic identity in both inputs. -/
theorem cMulSeq_respects {u u' v v' : CauchySeq}
    (hu : CauchyEquiv u u') (hv : CauchyEquiv v v') :
    CauchyEquiv (cMulSeq u v) (cMulSeq u' v') := by
  rcases four_common_eventual_bound u u' v v' with ⟨K, hK, Nb, hNb⟩
  intro eps heps
  rcases product_delta_exists heps hK with ⟨delta, hdelta, hscale⟩
  rcases hu delta hdelta with ⟨Nu, hNu⟩
  rcases hv delta hdelta with ⟨Nv, hNv⟩
  rcases common_upper_bound Nb Nu with ⟨Nbu, hNbNbu, hNuNbu⟩
  rcases common_upper_bound Nbu Nv with ⟨N, hNbuN, hNvN⟩
  refine ⟨N, ?_⟩
  intro n hn
  rcases hNb n (le_trans hNbNbu (le_trans hNbuN hn)) with
    ⟨hUn, hU'n, hVn, hV'n⟩
  exact qClose_mul_of_common_bound hK.1 hdelta.1 hscale
    hUn hU'n hVn hV'n
    (hNu n (le_trans hNuNbu (le_trans hNbuN hn)))
    (hNv n (le_trans hNvN hn))

/-- Research multiplication on the Cauchy quotient. -/
def rCMul : RCBOMA → RCBOMA → RCBOMA :=
  Quotient.lift₂
    (fun u v => rCmk (cMulSeq u v))
    (fun _ _ _ _ hu hv => Quotient.sound (cMulSeq_respects hu hv))

/-- Research multiplicative one is the constant rational one sequence. -/
def rCOne : RCBOMA := rCOfQ qOne

@[simp] theorem rCMul_mk (u v : CauchySeq) :
    rCMul (rCmk u) (rCmk v) = rCmk (cMulSeq u v) := rfl

theorem rCMul_comm (x y : RCBOMA) : rCMul x y = rCMul y x := by
  refine Quotient.inductionOn x ?_
  intro u
  refine Quotient.inductionOn y ?_
  intro v
  exact Quotient.sound (cauchyEquiv_of_pointwise_eq (fun n => qMul_comm _ _))

theorem rCMul_assoc (x y z : RCBOMA) :
    rCMul (rCMul x y) z = rCMul x (rCMul y z) := by
  refine Quotient.inductionOn x ?_
  intro u
  refine Quotient.inductionOn y ?_
  intro v
  refine Quotient.inductionOn z ?_
  intro w
  exact Quotient.sound
    (cauchyEquiv_of_pointwise_eq (fun n => qMul_assoc _ _ _))

theorem rCMul_one_left (x : RCBOMA) : rCMul rCOne x = x := by
  refine Quotient.inductionOn x ?_
  intro u
  exact Quotient.sound
    (cauchyEquiv_of_pointwise_eq (fun n => qMul_one_left (u.seq n)))

theorem rCMul_zero_left (x : RCBOMA) : rCMul rCZero x = rCZero := by
  refine Quotient.inductionOn x ?_
  intro u
  exact Quotient.sound
    (cauchyEquiv_of_pointwise_eq (fun n => qMul_zero_left (u.seq n)))

theorem rCMul_add_right (x y z : RCBOMA) :
    rCMul x (rCAdd y z) = rCAdd (rCMul x y) (rCMul x z) := by
  refine Quotient.inductionOn x ?_
  intro u
  refine Quotient.inductionOn y ?_
  intro v
  refine Quotient.inductionOn z ?_
  intro w
  exact Quotient.sound
    (cauchyEquiv_of_pointwise_eq (fun n => qMul_add_right _ _ _))

theorem rCOfQ_mul (q r : QBOMA) :
    rCMul (rCOfQ q) (rCOfQ r) = rCOfQ (qMul q r) := by
  exact Quotient.sound (cauchyEquiv_of_pointwise_eq (fun n => rfl))

/-- Independently assembled commutative-ring-strength research certificate. -/
structure CauchyCommutativeRingCertificate where
  productBoundCertificate : CauchyProductBoundCertificate
  mulComm : ∀ x y : RCBOMA, rCMul x y = rCMul y x
  mulAssoc : ∀ x y z : RCBOMA, rCMul (rCMul x y) z = rCMul x (rCMul y z)
  mulOneLeft : ∀ x : RCBOMA, rCMul rCOne x = x
  mulZeroLeft : ∀ x : RCBOMA, rCMul rCZero x = rCZero
  mulAddRight : ∀ x y z : RCBOMA,
    rCMul x (rCAdd y z) = rCAdd (rCMul x y) (rCMul x z)
  qEmbeddingMul : ∀ q r : QBOMA,
    rCMul (rCOfQ q) (rCOfQ r) = rCOfQ (qMul q r)

theorem cauchyCommutativeRingCertificate : CauchyCommutativeRingCertificate where
  productBoundCertificate := cauchyProductBoundCertificate
  mulComm := rCMul_comm
  mulAssoc := rCMul_assoc
  mulOneLeft := rCMul_one_left
  mulZeroLeft := rCMul_zero_left
  mulAddRight := rCMul_add_right
  qEmbeddingMul := rCOfQ_mul

end BOMA.R.StageTwo.CauchyMultiplicative003

/- ST2-EXP-003: representative-invariant approximate order on the independent
   Cauchy quotient. This file establishes partial-order strength and faithful
   rational order extension; totality remains a separate obligation. -/
namespace BOMA.R.StageTwo.CauchyOrderCore003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyBounded003
open BOMA.R.StageTwo.CauchyMultiplicative003

/-- Upper epsilon-closeness is ordinary order after adding epsilon. -/
theorem qClose_to_le_add {eps x y : QBOMA} (h : qClose eps x y) :
    qLE x (qAdd y eps) := by
  have ht := qadd_mono_right h.2 y
  rw [q_difference_cancel_right, qAdd_comm eps y] at ht
  exact ht

/-- Cancelling the right endpoint from an ordered epsilon translate. -/
theorem q_sum_sub_right (y eps : QBOMA) :
    qAdd (qAdd y eps) (qNeg y) = eps := by
  calc
    qAdd (qAdd y eps) (qNeg y) = qAdd y (qAdd eps (qNeg y)) :=
      qAdd_assoc y eps (qNeg y)
    _ = qAdd y (qAdd (qNeg y) eps) :=
      congrArg (fun t => qAdd y t) (qAdd_comm eps (qNeg y))
    _ = qAdd (qAdd y (qNeg y)) eps :=
      (qAdd_assoc y (qNeg y) eps).symm
    _ = qAdd qZero eps := by rw [qAdd_neg_right]
    _ = eps := qAdd_zero_left eps

/-- An epsilon translate bound is exactly an upper difference bound. -/
theorem qLE_add_to_difference_upper {eps x y : QBOMA}
    (h : qLE x (qAdd y eps)) :
    qLE (qAdd x (qNeg y)) eps := by
  have ht := qadd_mono_right h (qNeg y)
  rw [q_sum_sub_right] at ht
  exact ht

/-- Approximate non-strict order between Cauchy representatives. -/
def CauchyLE (u v : CauchySeq) : Prop :=
  ∀ eps : QBOMA, qPos eps →
    ∃ N : BOMANat, ∀ n : BOMANat, LE N n →
      qLE (u.seq n) (qAdd (v.seq n) eps)

theorem cauchyLE_refl (u : CauchySeq) : CauchyLE u u := by
  intro eps heps
  refine ⟨BOMANat.z, ?_⟩
  intro n hn
  have h := qadd_mono_right heps.1 (u.seq n)
  rw [qAdd_zero_left, qAdd_comm eps (u.seq n)] at h
  exact h

theorem cauchyLE_trans {u v w : CauchySeq}
    (huv : CauchyLE u v) (hvw : CauchyLE v w) : CauchyLE u w := by
  intro eps heps
  rcases positive_half_exists heps with ⟨delta, hdelta, hsum⟩
  rcases huv delta hdelta with ⟨Nu, hNu⟩
  rcases hvw delta hdelta with ⟨Nv, hNv⟩
  rcases common_upper_bound Nu Nv with ⟨N, hNuN, hNvN⟩
  refine ⟨N, ?_⟩
  intro n hn
  have ht := qadd_mono_right (hNv n (le_trans hNvN hn)) delta
  rw [qAdd_assoc, hsum] at ht
  exact qle_trans (hNu n (le_trans hNuN hn)) ht

/-- Replacing the left representative by an asymptotically equal one. -/
theorem cauchyLE_replace_left {u u' v : CauchySeq}
    (hu : CauchyEquiv u u') (hle : CauchyLE u v) : CauchyLE u' v := by
  intro eps heps
  rcases positive_half_exists heps with ⟨delta, hdelta, hsum⟩
  rcases hu delta hdelta with ⟨Nu, hNu⟩
  rcases hle delta hdelta with ⟨Nv, hNv⟩
  rcases common_upper_bound Nu Nv with ⟨N, hNuN, hNvN⟩
  refine ⟨N, ?_⟩
  intro n hn
  have hleft := qClose_to_le_add
    (qClose_symm (hNu n (le_trans hNuN hn)))
  have hright := qadd_mono_right (hNv n (le_trans hNvN hn)) delta
  rw [qAdd_assoc, hsum] at hright
  exact qle_trans hleft hright

/-- Replacing the right representative by an asymptotically equal one. -/
theorem cauchyLE_replace_right {u v v' : CauchySeq}
    (hv : CauchyEquiv v v') (hle : CauchyLE u v) : CauchyLE u v' := by
  intro eps heps
  rcases positive_half_exists heps with ⟨delta, hdelta, hsum⟩
  rcases hle delta hdelta with ⟨Nu, hNu⟩
  rcases hv delta hdelta with ⟨Nv, hNv⟩
  rcases common_upper_bound Nu Nv with ⟨N, hNuN, hNvN⟩
  refine ⟨N, ?_⟩
  intro n hn
  have hright := qadd_mono_right
    (qClose_to_le_add (hNv n (le_trans hNvN hn))) delta
  rw [qAdd_assoc, hsum] at hright
  exact qle_trans (hNu n (le_trans hNuN hn)) hright

/-- Approximate order is independent of both selected representatives. -/
theorem cauchyLE_respects {u u' v v' : CauchySeq}
    (hu : CauchyEquiv u u') (hv : CauchyEquiv v v') :
    CauchyLE u v ↔ CauchyLE u' v' := by
  constructor
  · intro h
    exact cauchyLE_replace_right hv (cauchyLE_replace_left hu h)
  · intro h
    exact cauchyLE_replace_right (cauchyEquiv_symm hv)
      (cauchyLE_replace_left (cauchyEquiv_symm hu) h)

/-- Opposite approximate inequalities force asymptotic equality. -/
theorem cauchyLE_antisymm {u v : CauchySeq}
    (huv : CauchyLE u v) (hvu : CauchyLE v u) : CauchyEquiv u v := by
  intro eps heps
  rcases huv eps heps with ⟨Nu, hNu⟩
  rcases hvu eps heps with ⟨Nv, hNv⟩
  rcases common_upper_bound Nu Nv with ⟨N, hNuN, hNvN⟩
  refine ⟨N, ?_⟩
  intro n hn
  constructor
  · have hrev := qneg_reverses
      (qLE_add_to_difference_upper (hNv n (le_trans hNvN hn)))
    rw [qNeg_difference] at hrev
    exact hrev
  · exact qLE_add_to_difference_upper (hNu n (le_trans hNuN hn))

/-- Approximate order descends to the quotient by the proved Iff transport. -/
def rCLE : RCBOMA → RCBOMA → Prop :=
  Quotient.lift₂
    (fun u v => CauchyLE u v)
    (fun _ _ _ _ hu hv => propext (cauchyLE_respects hu hv))

@[simp] theorem rCLE_mk (u v : CauchySeq) :
    rCLE (rCmk u) (rCmk v) ↔ CauchyLE u v := Iff.rfl

theorem rcle_refl (x : RCBOMA) : rCLE x x := by
  refine Quotient.inductionOn x ?_
  exact cauchyLE_refl

theorem rcle_trans {x y z : RCBOMA}
    (hxy : rCLE x y) (hyz : rCLE y z) : rCLE x z := by
  refine Quotient.inductionOn x ?_ hxy hyz
  intro u huy hyw
  refine Quotient.inductionOn y ?_ huy hyw
  intro v huv hvw
  refine Quotient.inductionOn z ?_ huv hvw
  intro w huv' hvw'
  exact cauchyLE_trans huv' hvw'

theorem rcle_antisymm {x y : RCBOMA}
    (hxy : rCLE x y) (hyx : rCLE y x) : x = y := by
  refine Quotient.inductionOn x ?_ hxy hyx
  intro u huv hvu
  refine Quotient.inductionOn y ?_ huv hvu
  intro v huv' hvu'
  exact Quotient.sound (cauchyLE_antisymm huv' hvu')

/-- The approximate quotient order exactly extends accepted rational order. -/
theorem rCOfQ_order (q r : QBOMA) :
    rCLE (rCOfQ q) (rCOfQ r) ↔ qLE q r := by
  constructor
  · intro h
    rcases qlt_trichotomy q r with hqr | hqr | hrq
    · exact hqr.1
    · rw [hqr]
      exact qle_refl r
    · have hd := positive_difference_of_lt hrq
      have hdpos : qPos (qAdd q (qNeg r)) :=
        ⟨hd.1, fun hz => hd.2 hz.symm⟩
      rcases positive_half_exists hdpos with ⟨delta, hdelta, hsum⟩
      rcases h delta hdelta with ⟨N, hN⟩
      have hqrDelta := hN N (le_refl N)
      have hqeq : qAdd r (qAdd q (qNeg r)) = q := by
        calc
          qAdd r (qAdd q (qNeg r)) = qAdd (qAdd r q) (qNeg r) :=
            (qAdd_assoc r q (qNeg r)).symm
          _ = qAdd (qAdd q r) (qNeg r) :=
            congrArg (fun t => qAdd t (qNeg r)) (qAdd_comm r q)
          _ = qAdd q (qAdd r (qNeg r)) := qAdd_assoc q r (qNeg r)
          _ = qAdd q qZero := by rw [qAdd_neg_right]
          _ = q := qAdd_zero_right q
      have hstrict := qlt_add_right hdelta (qAdd r delta)
      rw [qAdd_zero_left, qAdd_comm delta (qAdd r delta),
        qAdd_assoc, hsum, hqeq] at hstrict
      exact False.elim
        (hstrict.2 (qle_antisymm hstrict.1 hqrDelta))
  · intro hqr
    intro eps heps
    refine ⟨BOMANat.z, ?_⟩
    intro n hn
    have hinc := qadd_mono_right heps.1 r
    rw [qAdd_zero_left, qAdd_comm eps r] at hinc
    exact qle_trans hqr hinc

/-- Independently assembled partial-order-strength research certificate. -/
structure CauchyPartialOrderCertificate where
  ringCertificate : CauchyCommutativeRingCertificate
  orderRefl : ∀ x : RCBOMA, rCLE x x
  orderTrans : ∀ {x y z : RCBOMA}, rCLE x y → rCLE y z → rCLE x z
  orderAntisymm : ∀ {x y : RCBOMA}, rCLE x y → rCLE y x → x = y
  qEmbeddingOrder : ∀ q r : QBOMA, rCLE (rCOfQ q) (rCOfQ r) ↔ qLE q r

theorem cauchyPartialOrderCertificate : CauchyPartialOrderCertificate where
  ringCertificate := cauchyCommutativeRingCertificate
  orderRefl := rcle_refl
  orderTrans := @rcle_trans
  orderAntisymm := @rcle_antisymm
  qEmbeddingOrder := rCOfQ_order

end BOMA.R.StageTwo.CauchyOrderCore003

/- ST2-EXP-003: totality of the independent approximate Cauchy order.
   The witness extraction from failure of an eventual universal bound uses one
   explicit local classical case split. No Dedekind producer is consumed. -/
namespace BOMA.R.StageTwo.CauchyOrderTotal003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003

/-- Classical normal form of failure of approximate Cauchy order. The theorem
    localizes the logical commitment used by totality. -/
theorem not_cauchyLE_witness {u v : CauchySeq} (hnot : ¬ CauchyLE u v) :
    ∃ eps : QBOMA, qPos eps ∧
      ∀ N : BOMANat, ∃ n : BOMANat, LE N n ∧
        ¬ qLE (u.seq n) (qAdd (v.seq n) eps) := by
  classical
  by_cases hex :
      ∃ eps : QBOMA, qPos eps ∧
        ∀ N : BOMANat, ∃ n : BOMANat, LE N n ∧
          ¬ qLE (u.seq n) (qAdd (v.seq n) eps)
  · exact hex
  · have hle : CauchyLE u v := by
      intro eps heps
      by_cases hN :
          ∃ N : BOMANat, ∀ n : BOMANat, LE N n →
            qLE (u.seq n) (qAdd (v.seq n) eps)
      · exact hN
      · have hcounter :
            ∀ N : BOMANat, ∃ n : BOMANat, LE N n ∧
              ¬ qLE (u.seq n) (qAdd (v.seq n) eps) := by
          intro N
          by_cases hc :
              ∃ n : BOMANat, LE N n ∧
                ¬ qLE (u.seq n) (qAdd (v.seq n) eps)
          · exact hc
          · have hall :
                ∀ n : BOMANat, LE N n →
                  qLE (u.seq n) (qAdd (v.seq n) eps) := by
              intro n hn
              by_cases hlePoint : qLE (u.seq n) (qAdd (v.seq n) eps)
              · exact hlePoint
              · exact False.elim (hc ⟨n, hn, hlePoint⟩)
            exact False.elim (hN ⟨N, hall⟩)
        exact False.elim (hex ⟨eps, heps, hcounter⟩)
    exact False.elim (hnot hle)

/-- Any two Cauchy representatives are comparable in approximate order. -/
theorem cauchyLE_total (u v : CauchySeq) :
    CauchyLE u v ∨ CauchyLE v u := by
  classical
  by_cases huv : CauchyLE u v
  · exact Or.inl huv
  · right
    rcases not_cauchyLE_witness huv with ⟨gap, hgap, hcounter⟩
    intro eps heps
    rcases positive_half_exists heps with ⟨delta, hdelta, hsum⟩
    rcases u.cauchy delta hdelta with ⟨Nu, hNu⟩
    rcases v.cauchy delta hdelta with ⟨Nv, hNv⟩
    rcases common_upper_bound Nu Nv with ⟨N, hNuN, hNvN⟩
    rcases hcounter N with ⟨n, hn, hfail⟩
    have hgapOrder : qLE (qAdd (v.seq n) gap) (u.seq n) := by
      rcases qle_total (u.seq n) (qAdd (v.seq n) gap) with hbad | hgood
      · exact False.elim (hfail hbad)
      · exact hgood
    have hvnGap : qLE (v.seq n) (qAdd (v.seq n) gap) := by
      have h := qadd_mono_right hgap.1 (v.seq n)
      rw [qAdd_zero_left, qAdd_comm gap (v.seq n)] at h
      exact h
    have hvnUn : qLE (v.seq n) (u.seq n) := qle_trans hvnGap hgapOrder
    refine ⟨N, ?_⟩
    intro m hm
    have hvmVn := qClose_to_le_add
      (hNv m n (le_trans hNvN hm) (le_trans hNvN hn))
    have hvnDeltaUn := qadd_mono_right hvnUn delta
    have hunUm := qClose_to_le_add
      (hNu n m (le_trans hNuN hn) (le_trans hNuN hm))
    have hunDeltaUm := qadd_mono_right hunUm delta
    rw [qAdd_assoc, hsum] at hunDeltaUm
    exact qle_trans hvmVn (qle_trans hvnDeltaUn hunDeltaUm)

/-- Totality descends to the research quotient. -/
theorem rcle_total (x y : RCBOMA) : rCLE x y ∨ rCLE y x := by
  refine Quotient.inductionOn x ?_
  intro u
  refine Quotient.inductionOn y ?_
  intro v
  exact cauchyLE_total u v

/-- Independently assembled total-order-strength research certificate. -/
structure CauchyTotalOrderCertificate where
  partialOrderCertificate : CauchyPartialOrderCertificate
  orderTotal : ∀ x y : RCBOMA, rCLE x y ∨ rCLE y x
  classicalWitnessExtraction :
    ∀ {u v : CauchySeq}, ¬ CauchyLE u v →
      ∃ eps : QBOMA, qPos eps ∧
        ∀ N : BOMANat, ∃ n : BOMANat, LE N n ∧
          ¬ qLE (u.seq n) (qAdd (v.seq n) eps)

theorem cauchyTotalOrderCertificate : CauchyTotalOrderCertificate where
  partialOrderCertificate := cauchyPartialOrderCertificate
  orderTotal := rcle_total
  classicalWitnessExtraction := @not_cauchyLE_witness

end BOMA.R.StageTwo.CauchyOrderTotal003

/- ST2-EXP-003: compatibility of the total approximate Cauchy order with
   addition and nonnegative multiplication. Inverses and completeness remain
   separate obligations. -/
namespace BOMA.R.StageTwo.CauchyOrderedRing003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyBounded003
open BOMA.R.StageTwo.CauchyProductBounds003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003

/-- Reassociate a translated epsilon after adding a common term. -/
theorem q_add_error_translate (v eps w : QBOMA) :
    qAdd (qAdd v eps) w = qAdd (qAdd v w) eps := by
  calc
    qAdd (qAdd v eps) w = qAdd v (qAdd eps w) := qAdd_assoc v eps w
    _ = qAdd v (qAdd w eps) :=
      congrArg (fun t => qAdd v t) (qAdd_comm eps w)
    _ = qAdd (qAdd v w) eps := (qAdd_assoc v w eps).symm

/-- Approximate order is preserved by a common pointwise right addend. -/
theorem cauchyLE_add_right {u v : CauchySeq}
    (h : CauchyLE u v) (w : CauchySeq) :
    CauchyLE (cAddSeq u w) (cAddSeq v w) := by
  intro eps heps
  rcases h eps heps with ⟨N, hN⟩
  refine ⟨N, ?_⟩
  intro n hn
  have ht := qadd_mono_right (hN n hn) (w.seq n)
  rw [q_add_error_translate] at ht
  exact ht

/-- Quotient approximate order is preserved by a common right addend. -/
theorem rcle_add_right {x y : RCBOMA} (h : rCLE x y) (z : RCBOMA) :
    rCLE (rCAdd x z) (rCAdd y z) := by
  refine Quotient.inductionOn x ?_ h
  intro u huy
  refine Quotient.inductionOn y ?_ huy
  intro v huv
  refine Quotient.inductionOn z ?_ huv
  intro w huv'
  exact cauchyLE_add_right huv' w

/-- Cancelling an added epsilon on the right. -/
theorem q_add_cancel_right (x eps : QBOMA) :
    qAdd (qAdd x eps) (qNeg eps) = x := by
  calc
    qAdd (qAdd x eps) (qNeg eps) = qAdd x (qAdd eps (qNeg eps)) :=
      qAdd_assoc x eps (qNeg eps)
    _ = qAdd x qZero := by rw [qAdd_neg_right]
    _ = x := qAdd_zero_right x

/-- Approximate quotient nonnegativity gives a representative lower bound. -/
theorem qLE_zero_add_to_lower {eps x : QBOMA}
    (h : qLE qZero (qAdd x eps)) : qLE (qNeg eps) x := by
  have ht := qadd_mono_right h (qNeg eps)
  rw [qAdd_zero_left, q_add_cancel_right] at ht
  exact ht

/-- A representative lower bound returns approximate nonnegativity. -/
theorem qLower_to_zero_add {eps x : QBOMA}
    (h : qLE (qNeg eps) x) : qLE qZero (qAdd x eps) := by
  have ht := qadd_mono_right h eps
  rw [qAdd_neg_left] at ht
  exact ht

/-- Signed rational product lower bound from symmetric size bounds and
    approximate nonnegativity of both factors. -/
theorem qMul_approx_nonneg_lower
    {eps delta K x y : QBOMA}
    (heps : qLE qZero eps) (hdelta : qLE qZero delta)
    (hK : qLE qZero K)
    (hscale : qAdd (qMul K delta) (qMul K delta) = eps)
    (hx : qAbsBound K x) (hy : qAbsBound K y)
    (hxLower : qLE (qNeg delta) x)
    (hyLower : qLE (qNeg delta) y) :
    qLE (qNeg eps) (qMul x y) := by
  have htermNonNeg : qLE qZero (qMul K delta) := qmul_nonneg hK hdelta
  have htermEps : qLE (qMul K delta) eps := by
    have h := qadd_mono_right htermNonNeg (qMul K delta)
    rw [qAdd_zero_left, hscale] at h
    exact h
  have hnegEpsZero : qLE (qNeg eps) qZero := by
    have h := qneg_reverses heps
    rw [BOMA.R.StageTwo.CauchyBounded003.qNeg_zero] at h
    exact h
  rcases qle_total qZero x with hx0 | hx0
  · rcases qle_total qZero y with hy0 | hy0
    · exact qle_trans hnegEpsZero (qmul_nonneg hx0 hy0)
    · have hproductLower := qmul_mono_left_nonneg hyLower hx0
      rw [qMul_neg_right] at hproductLower
      have hxTerm := qmul_mono_right_nonneg hx.2 hdelta
      have hneg := qneg_reverses (qle_trans hxTerm htermEps)
      exact qle_trans hneg hproductLower
  · rcases qle_total qZero y with hy0 | hy0
    · have hproductLower := qmul_mono_right_nonneg hxLower hy0
      rw [qMul_neg_left] at hproductLower
      have hyTerm := qmul_mono_right_nonneg hy.2 hdelta
      rw [qMul_comm y delta] at hyTerm
      have hneg := qneg_reverses (qle_trans hyTerm htermEps)
      exact qle_trans hneg hproductLower
    · have hnx : qLE qZero (qNeg x) := by
        have h := qneg_reverses hx0
        rw [BOMA.R.StageTwo.CauchyBounded003.qNeg_zero] at h
        exact h
      have hny : qLE qZero (qNeg y) := by
        have h := qneg_reverses hy0
        rw [BOMA.R.StageTwo.CauchyBounded003.qNeg_zero] at h
        exact h
      have hprod := qmul_nonneg hnx hny
      rw [qMul_neg_neg] at hprod
      exact qle_trans hnegEpsZero hprod

/-- Pointwise multiplication of two approximately nonnegative Cauchy
    representatives is approximately nonnegative. -/
theorem cauchyLE_mul_nonneg (u v : CauchySeq)
    (hu : CauchyLE (cauchyOfQ qZero) u)
    (hv : CauchyLE (cauchyOfQ qZero) v) :
    CauchyLE (cauchyOfQ qZero) (cMulSeq u v) := by
  rcases pair_common_eventual_bound u v with ⟨K, hK, Nb, hNb⟩
  intro eps heps
  rcases product_delta_exists heps hK with ⟨delta, hdelta, hscale⟩
  rcases hu delta hdelta with ⟨Nu, hNu⟩
  rcases hv delta hdelta with ⟨Nv, hNv⟩
  rcases common_upper_bound Nb Nu with ⟨Nbu, hNbNbu, hNuNbu⟩
  rcases common_upper_bound Nbu Nv with ⟨N, hNbuN, hNvN⟩
  refine ⟨N, ?_⟩
  intro n hn
  rcases hNb n (le_trans hNbNbu (le_trans hNbuN hn)) with ⟨hUn, hVn⟩
  have hULower := qLE_zero_add_to_lower
    (hNu n (le_trans hNuNbu (le_trans hNbuN hn)))
  have hVLower := qLE_zero_add_to_lower (hNv n (le_trans hNvN hn))
  exact qLower_to_zero_add
    (qMul_approx_nonneg_lower heps.1 hdelta.1 hK.1 hscale
      hUn hVn hULower hVLower)

/-- Quotient multiplication preserves nonnegativity. -/
theorem rcle_mul_nonneg {x y : RCBOMA}
    (hx : rCLE rCZero x) (hy : rCLE rCZero y) :
    rCLE rCZero (rCMul x y) := by
  refine Quotient.inductionOn x ?_ hx hy
  intro u hxu hyu
  refine Quotient.inductionOn y ?_ hxu hyu
  intro v h0u h0v
  exact cauchyLE_mul_nonneg u v h0u h0v

/-- Independently assembled ordered-commutative-ring-strength certificate. -/
structure CauchyOrderedRingCertificate where
  totalOrderCertificate : CauchyTotalOrderCertificate
  addMonotoneRight : ∀ {x y : RCBOMA}, rCLE x y →
    ∀ z : RCBOMA, rCLE (rCAdd x z) (rCAdd y z)
  mulNonnegative : ∀ {x y : RCBOMA},
    rCLE rCZero x → rCLE rCZero y → rCLE rCZero (rCMul x y)

theorem cauchyOrderedRingCertificate : CauchyOrderedRingCertificate where
  totalOrderCertificate := cauchyTotalOrderCertificate
  addMonotoneRight := @rcle_add_right
  mulNonnegative := @rcle_mul_nonneg

end BOMA.R.StageTwo.CauchyOrderedRing003

/- ST2-EXP-003: a nonzero Cauchy quotient class is eventually separated from
   zero by one fixed positive rational gap on one fixed side. This is the
   prerequisite for a later reciprocal-sequence construction. No Dedekind
   producer and no representative selector is used here. -/
namespace BOMA.R.StageTwo.CauchyNonzeroGap003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyOrderedRing003

/-- Eventually every representative value lies above one fixed positive gap. -/
def EventuallyPositiveGap (u : CauchySeq) : Prop :=
  ∃ delta : QBOMA, qPos delta ∧
    ∃ N : BOMANat, ∀ n : BOMANat, LE N n → qLE delta (u.seq n)

/-- Eventually every representative value lies below one fixed negative gap. -/
def EventuallyNegativeGap (u : CauchySeq) : Prop :=
  ∃ delta : QBOMA, qPos delta ∧
    ∃ N : BOMANat, ∀ n : BOMANat, LE N n → qLE (u.seq n) (qNeg delta)

/-- The fixed-sign separation needed before constructing reciprocal values. -/
def EventuallySignSeparated (u : CauchySeq) : Prop :=
  EventuallyPositiveGap u ∨ EventuallyNegativeGap u

/-- Removing the second half of an exact positive split. -/
theorem q_split_sub_half {gap delta : QBOMA}
    (hsum : qAdd delta delta = gap) :
    qAdd gap (qNeg delta) = delta := by
  calc
    qAdd gap (qNeg delta) =
        qAdd (qAdd delta delta) (qNeg delta) := by rw [hsum]
    _ = qAdd delta (qAdd delta (qNeg delta)) :=
      qAdd_assoc delta delta (qNeg delta)
    _ = qAdd delta qZero := by rw [qAdd_neg_right]
    _ = delta := qAdd_zero_right delta

/-- Adding back one half to minus the full split leaves minus one half. -/
theorem q_neg_split_add_half {gap delta : QBOMA}
    (hsum : qAdd delta delta = gap) :
    qAdd (qNeg gap) delta = qNeg delta := by
  have hneg : qNeg gap = qAdd (qNeg delta) (qNeg delta) := by
    rw [← hsum, qNeg_add]
  rw [hneg]
  calc
    qAdd (qAdd (qNeg delta) (qNeg delta)) delta =
        qAdd (qNeg delta) (qAdd (qNeg delta) delta) :=
      qAdd_assoc (qNeg delta) (qNeg delta) delta
    _ = qAdd (qNeg delta) qZero := by rw [qAdd_neg_left]
    _ = qNeg delta := qAdd_zero_right (qNeg delta)

/-- If a representative is positive in quotient order but not zero, a failed
    reverse inequality supplies an arbitrarily late strict gap. Cauchy
    stability converts that sparse gap into one eventual uniform lower bound. -/
theorem eventually_positive_gap_of_nonzero
    (u : CauchySeq)
    (h0u : rCLE rCZero (rCmk u))
    (hne : rCmk u ≠ rCZero) :
    EventuallyPositiveGap u := by
  have hnot : ¬ rCLE (rCmk u) rCZero := by
    intro hu0
    exact hne (rcle_antisymm hu0 h0u)
  change ¬ CauchyLE u (cauchyOfQ qZero) at hnot
  rcases not_cauchyLE_witness hnot with ⟨gap, hgap, hcounter⟩
  rcases positive_half_exists hgap with ⟨delta, hdelta, hsum⟩
  rcases u.cauchy delta hdelta with ⟨Nc, hNc⟩
  rcases hcounter Nc with ⟨n, hn, hfail⟩
  change ¬ qLE (u.seq n) (qAdd qZero gap) at hfail
  rw [qAdd_zero_left] at hfail
  have hgapUn : qLE gap (u.seq n) := by
    rcases qle_total (u.seq n) gap with hbad | hgood
    · exact False.elim (hfail hbad)
    · exact hgood
  refine ⟨delta, hdelta, Nc, ?_⟩
  intro m hm
  have hclose : qLE (u.seq n) (qAdd (u.seq m) delta) :=
    qClose_to_le_add (hNc n m hn hm)
  have hgapClose : qLE gap (qAdd (u.seq m) delta) :=
    qle_trans hgapUn hclose
  have ht := qadd_mono_right hgapClose (qNeg delta)
  have hleft : qAdd gap (qNeg delta) = delta := q_split_sub_half hsum
  have hright : qAdd (qAdd (u.seq m) delta) (qNeg delta) = u.seq m :=
    q_add_cancel_right (u.seq m) delta
  rw [hleft, hright] at ht
  exact ht

/-- The negative case is symmetric: failure of zero-below-u yields an
    arbitrarily late negative gap, then Cauchy stability makes it uniform. -/
theorem eventually_negative_gap_of_nonzero
    (u : CauchySeq)
    (hu0 : rCLE (rCmk u) rCZero)
    (hne : rCmk u ≠ rCZero) :
    EventuallyNegativeGap u := by
  have hnot : ¬ rCLE rCZero (rCmk u) := by
    intro h0u
    exact hne (rcle_antisymm hu0 h0u)
  change ¬ CauchyLE (cauchyOfQ qZero) u at hnot
  rcases not_cauchyLE_witness hnot with ⟨gap, hgap, hcounter⟩
  rcases positive_half_exists hgap with ⟨delta, hdelta, hsum⟩
  rcases u.cauchy delta hdelta with ⟨Nc, hNc⟩
  rcases hcounter Nc with ⟨n, hn, hfail⟩
  change ¬ qLE qZero (qAdd (u.seq n) gap) at hfail
  have hsumZero : qLE (qAdd (u.seq n) gap) qZero := by
    rcases qle_total qZero (qAdd (u.seq n) gap) with hbad | hgood
    · exact False.elim (hfail hbad)
    · exact hgood
  have hUnNegGap : qLE (u.seq n) (qNeg gap) := by
    have ht := qadd_mono_right hsumZero (qNeg gap)
    have hleft : qAdd (qAdd (u.seq n) gap) (qNeg gap) = u.seq n :=
      q_add_cancel_right (u.seq n) gap
    rw [hleft, qAdd_zero_left] at ht
    exact ht
  refine ⟨delta, hdelta, Nc, ?_⟩
  intro m hm
  have hclose : qLE (u.seq m) (qAdd (u.seq n) delta) :=
    qClose_to_le_add (qClose_symm (hNc n m hn hm))
  have hbound : qLE (qAdd (u.seq n) delta) (qAdd (qNeg gap) delta) :=
    qadd_mono_right hUnNegGap delta
  have ht : qLE (u.seq m) (qAdd (qNeg gap) delta) :=
    qle_trans hclose hbound
  rw [q_neg_split_add_half hsum] at ht
  exact ht

/-- Every nonzero representative class is eventually uniformly separated from
    zero on one side. No inverse witness is selected at this milestone. -/
theorem nonzero_eventually_sign_separated
    (u : CauchySeq) (hne : rCmk u ≠ rCZero) :
    EventuallySignSeparated u := by
  rcases rcle_total rCZero (rCmk u) with h0u | hu0
  · exact Or.inl (eventually_positive_gap_of_nonzero u h0u hne)
  · exact Or.inr (eventually_negative_gap_of_nonzero u hu0 hne)

/-- Integrated prerequisite certificate for the reciprocal stage. -/
structure CauchyNonzeroGapCertificate where
  orderedRingCertificate : CauchyOrderedRingCertificate
  nonzeroSeparated : ∀ (u : CauchySeq), rCmk u ≠ rCZero →
    EventuallySignSeparated u

theorem cauchyNonzeroGapCertificate : CauchyNonzeroGapCertificate where
  orderedRingCertificate := cauchyOrderedRingCertificate
  nonzeroSeparated := nonzero_eventually_sign_separated

end BOMA.R.StageTwo.CauchyNonzeroGap003

/- ST2-EXP-003: nonzero multiplicative inverse witnesses for the independent
   Cauchy quotient. The only new data-selection commitment is explicit:
   `Classical.choose` assembles a rational reciprocal sequence from the accepted
   witness-only Q inverse relation after eventual fixed-sign separation has
   already been proved. No Dedekind producer is consumed. -/
namespace BOMA.R.StageTwo.CauchyInverse003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QPositiveMultiplicativeApprox001
open BOMA.R.QInverseOrder001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyBounded003
open BOMA.R.StageTwo.CauchyProductBounds003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyOrderedRing003
open BOMA.R.StageTwo.CauchyNonzeroGap003

/-- A positive rational lower bound makes every larger rational strictly
    positive. -/
theorem qlt_zero_of_pos_le {a0 a : QBOMA}
    (h0 : qPos a0) (h : qLE a0 a) : qLT qZero a := by
  refine ⟨qle_trans h0.1 h, ?_⟩
  intro hza
  have ha0z : qLE a0 qZero := by
    rw [hza]
    exact h
  have heq : a0 = qZero := qle_antisymm ha0z h0.1
  exact h0.2 heq.symm

/-- Inverse witnesses reverse a non-strict positive lower bound. -/
theorem q_inverse_le_of_positive_lower
    {a0 a a0inv ainv : QBOMA}
    (h0 : qPos a0) (h : qLE a0 a)
    (h0inv : QInvRel a0 a0inv) (hainv : QInvRel a ainv) :
    qLE ainv a0inv := by
  rcases qlt_trichotomy a0 a with hlt | heq | hrev
  · exact (q_inverse_strict_antitone
      (qlt_zero_of_pos_le h0 (qle_refl a0)) hlt h0inv hainv).1
  · have hainv0 : QInvRel a0 ainv := by
      rw [heq]
      exact hainv
    rw [q_inverse_unique hainv0 h0inv]
    exact qle_refl a0inv
  · have haeq : a = a0 := qle_antisymm hrev.1 h
    exact False.elim (hrev.2 haeq)

/-- A nonnegative rational below a nonnegative radius satisfies the symmetric
    bound used by the existing product-estimate infrastructure. -/
theorem qAbsBound_of_nonneg_le {K x : QBOMA}
    (hK : qLE qZero K) (hx0 : qLE qZero x) (hxK : qLE x K) :
    qAbsBound K x := by
  constructor
  · have hneg : qLE (qNeg K) qZero := by
      have ht := qneg_reverses hK
      rw [BOMA.R.StageTwo.CauchyBounded003.qNeg_zero] at ht
      exact ht
    exact qle_trans hneg hx0
  · exact hxK

/-- Difference of two inverse witnesses, factored through the original
    rational difference. -/
theorem q_reciprocal_difference
    {a b ainv binv : QBOMA}
    (hainv : QInvRel a ainv) (hbinv : QInvRel b binv) :
    qAdd ainv (qNeg binv) =
      qMul (qAdd b (qNeg a)) (qMul ainv binv) := by
  have hfirst : qMul b (qMul ainv binv) = ainv := by
    calc
      qMul b (qMul ainv binv) =
          qMul (qMul b ainv) binv :=
        (qMul_assoc b ainv binv).symm
      _ = qMul (qMul ainv b) binv := by
        rw [qMul_comm b ainv]
      _ = qMul ainv (qMul b binv) := qMul_assoc ainv b binv
      _ = qMul ainv qOne := congrArg (fun t => qMul ainv t) hbinv
      _ = ainv := qMul_one_right ainv
  have hsecond : qMul (qNeg a) (qMul ainv binv) = qNeg binv := by
    rw [qMul_neg_left]
    apply congrArg qNeg
    calc
      qMul a (qMul ainv binv) =
          qMul (qMul a ainv) binv :=
        (qMul_assoc a ainv binv).symm
      _ = qMul qOne binv := congrArg (fun t => qMul t binv) hainv
      _ = binv := qMul_one_left binv
  symm
  calc
    qMul (qAdd b (qNeg a)) (qMul ainv binv) =
        qAdd (qMul b (qMul ainv binv))
          (qMul (qNeg a) (qMul ainv binv)) :=
      qMul_add_left b (qNeg a) (qMul ainv binv)
    _ = qAdd ainv (qNeg binv) := by rw [hfirst, hsecond]

/-- Reciprocals of two positive rationals sharing one positive lower bound are
    epsilon-close whenever the originals are close at a correspondingly scaled
    radius. -/
theorem qClose_reciprocals_of_positive_lower
    {eps eta a0 a b a0inv ainv binv : QBOMA}
    (h0 : qPos a0)
    (ha : qLE a0 a) (hb : qLE a0 b)
    (h0inv : QInvRel a0 a0inv)
    (hainv : QInvRel a ainv) (hbinv : QInvRel b binv)
    (heta : qLE qZero eta)
    (hscale : qMul eta (qMul a0inv a0inv) = eps)
    (hab : qClose eta a b) :
    qClose eps ainv binv := by
  have h0strict := qlt_zero_of_pos_le h0 (qle_refl a0)
  have hainv0 := qlt_zero_inverse (qlt_zero_of_pos_le h0 ha) hainv
  have hbinv0 := qlt_zero_inverse (qlt_zero_of_pos_le h0 hb) hbinv
  have h0inv0 := qlt_zero_inverse h0strict h0inv
  have hainvBound : qLE ainv a0inv :=
    q_inverse_le_of_positive_lower h0 ha h0inv hainv
  have hbinvBound : qLE binv a0inv :=
    q_inverse_le_of_positive_lower h0 hb h0inv hbinv
  have hainvAbs : qAbsBound a0inv ainv :=
    qAbsBound_of_nonneg_le h0inv0.1 hainv0.1 hainvBound
  have hbinvAbs : qAbsBound a0inv binv :=
    qAbsBound_of_nonneg_le h0inv0.1 hbinv0.1 hbinvBound
  have hdiff : qAbsBound eta (qAdd b (qNeg a)) := by
    have ht := qClose_symm hab
    exact ht
  have hinvProd : qAbsBound (qMul a0inv a0inv) (qMul ainv binv) :=
    qAbsBound_mul h0inv0.1 h0inv0.1 hainvAbs hbinvAbs
  have hall :
      qAbsBound (qMul eta (qMul a0inv a0inv))
        (qMul (qAdd b (qNeg a)) (qMul ainv binv)) :=
    qAbsBound_mul heta (qmul_nonneg h0inv0.1 h0inv0.1) hdiff hinvProd
  rw [hscale] at hall
  change qAbsBound eps (qAdd ainv (qNeg binv))
  rw [q_reciprocal_difference hainv hbinv]
  exact hall

/-- Positive rational products remain positive in the `qPos` interface. -/
theorem qPos_mul {a b : QBOMA} (ha : qPos a) (hb : qPos b) :
    qPos (qMul a b) := by
  have haP : QPositive a := ⟨ha.1, fun hz => ha.2 hz.symm⟩
  have hbP : QPositive b := ⟨hb.1, fun hz => hb.2 hz.symm⟩
  refine ⟨qmul_nonneg haP.1 hbP.1, ?_⟩
  intro hzero
  exact qMul_ne_zero haP.2 hbP.2 hzero.symm

/-- Exact reciprocal-Cauchy scale: eps*a0*a0 cancels two copies of a0⁻¹. -/
theorem reciprocal_scale
    {eps a0 a0inv : QBOMA} (h0inv : QInvRel a0 a0inv) :
    qMul (qMul eps (qMul a0 a0)) (qMul a0inv a0inv) = eps := by
  have hpair :
      qMul (qMul a0 a0) (qMul a0inv a0inv) =
        qMul (qMul a0 a0inv) (qMul a0 a0inv) := by
    calc
      qMul (qMul a0 a0) (qMul a0inv a0inv) =
          qMul (qMul (qMul a0 a0) a0inv) a0inv :=
        (qMul_assoc (qMul a0 a0) a0inv a0inv).symm
      _ = qMul (qMul a0 (qMul a0 a0inv)) a0inv := by
        rw [qMul_assoc a0 a0 a0inv]
      _ = qMul (qMul a0 (qMul a0inv a0)) a0inv := by
        rw [qMul_comm a0 a0inv]
      _ = qMul (qMul (qMul a0 a0inv) a0) a0inv := by
        rw [← qMul_assoc a0 a0inv a0]
      _ = qMul (qMul a0 a0inv) (qMul a0 a0inv) :=
        qMul_assoc (qMul a0 a0inv) a0 a0inv
  calc
    qMul (qMul eps (qMul a0 a0)) (qMul a0inv a0inv) =
        qMul eps (qMul (qMul a0 a0) (qMul a0inv a0inv)) :=
      qMul_assoc eps (qMul a0 a0) (qMul a0inv a0inv)
    _ = qMul eps (qMul (qMul a0 a0inv) (qMul a0 a0inv)) := by
      rw [hpair]
    _ = qMul eps (qMul qOne qOne) := by rw [h0inv]
    _ = eps := by rw [qMul_one_left, qMul_one_right]

/-- A positive eventual gap makes every late rational term nonzero. -/
theorem positive_gap_term_nonzero
    {u : CauchySeq} {a0 : QBOMA} {N n : BOMANat}
    (h0 : qPos a0)
    (hN : ∀ k : BOMANat, LE N k → qLE a0 (u.seq k))
    (hn : LE N n) : u.seq n ≠ qZero := by
  intro hzero
  have ha0z : qLE a0 qZero := by
    rw [← hzero]
    exact hN n hn
  have heq : a0 = qZero := qle_antisymm ha0z h0.1
  exact h0.2 heq.symm

/-- Explicit Choice boundary: from the accepted pointwise existential rational
    inverse relation, assemble one reciprocal sequence. All late selected values
    are proved inverse witnesses; early values are irrelevant to the quotient. -/
theorem positive_gap_inverse_sequence_exists
    (u : CauchySeq) (hgap : EventuallyPositiveGap u) :
    ∃ v : CauchySeq,
      CauchyEquiv (cMulSeq u v) (cauchyOfQ qOne) := by
  classical
  rcases hgap with ⟨a0, h0, N0, hN0⟩
  have hpoint : ∀ n : BOMANat,
      ∃ r : QBOMA, LE N0 n → QInvRel (u.seq n) r := by
    intro n
    by_cases hn : LE N0 n
    · have hnz := positive_gap_term_nonzero h0 hN0 hn
      rcases q_inverse_exists (u.seq n) hnz with ⟨r, hr⟩
      exact ⟨r, fun _ => hr⟩
    · exact ⟨qZero, fun h => False.elim (hn h)⟩
  let vseq : QSeq := fun n => Classical.choose (hpoint n)
  have hv : ∀ n : BOMANat, LE N0 n → QInvRel (u.seq n) (vseq n) := by
    intro n hn
    exact (Classical.choose_spec (hpoint n)) hn
  have ha0nz : a0 ≠ qZero := fun hz => h0.2 hz.symm
  rcases q_inverse_exists a0 ha0nz with ⟨a0inv, ha0inv⟩
  have hvCauchy : IsCauchy vseq := by
    intro eps heps
    let eta := qMul eps (qMul a0 a0)
    have heta : qPos eta := by
      unfold eta
      exact qPos_mul heps (qPos_mul h0 h0)
    rcases u.cauchy eta heta with ⟨Nu, hNu⟩
    rcases common_upper_bound N0 Nu with ⟨N, hN0N, hNuN⟩
    refine ⟨N, ?_⟩
    intro m n hm hn
    have hm0 : LE N0 m := le_trans hN0N hm
    have hn0 : LE N0 n := le_trans hN0N hn
    have huma := hN0 m hm0
    have huna := hN0 n hn0
    have humInv := hv m hm0
    have hunInv := hv n hn0
    have huClose := hNu m n (le_trans hNuN hm) (le_trans hNuN hn)
    apply qClose_reciprocals_of_positive_lower
      h0 huma huna ha0inv humInv hunInv heta.1
    · unfold eta
      exact reciprocal_scale ha0inv
    · exact huClose
  let v : CauchySeq := ⟨vseq, hvCauchy⟩
  refine ⟨v, ?_⟩
  intro eps heps
  refine ⟨N0, ?_⟩
  intro n hn
  have hprod := hv n hn
  change qClose eps (qMul (u.seq n) (vseq n)) qOne
  rw [hprod]
  exact qClose_refl_of_pos eps qOne heps

/-- A negative eventual gap becomes a positive gap after pointwise negation. -/
theorem negative_gap_to_positive_neg
    {u : CauchySeq} (hgap : EventuallyNegativeGap u) :
    EventuallyPositiveGap (cNegSeq u) := by
  rcases hgap with ⟨a0, h0, N, hN⟩
  refine ⟨a0, h0, N, ?_⟩
  intro n hn
  have ht := qneg_reverses (hN n hn)
  rw [qNeg_neg] at ht
  exact ht

/-- Multiplying by the negations of both factors gives the original product. -/
theorem cMul_neg_neg_pointwise (u v : CauchySeq) :
    CauchyEquiv (cMulSeq u v) (cMulSeq (cNegSeq u) (cNegSeq v)) := by
  exact cauchyEquiv_of_pointwise_eq (fun n => by
    change qMul (u.seq n) (v.seq n) =
      qMul (qNeg (u.seq n)) (qNeg (v.seq n))
    exact (qMul_neg_neg (u.seq n) (v.seq n)).symm)

/-- Representative-level nonzero inverse witness, handling either eventual
    sign without changing the accepted quotient identity. -/
theorem representative_inverse_exists
    (u : CauchySeq) (hne : rCmk u ≠ rCZero) :
    ∃ v : CauchySeq,
      CauchyEquiv (cMulSeq u v) (cauchyOfQ qOne) := by
  rcases nonzero_eventually_sign_separated u hne with hpos | hneg
  · exact positive_gap_inverse_sequence_exists u hpos
  · have hposNeg := negative_gap_to_positive_neg hneg
    rcases positive_gap_inverse_sequence_exists (cNegSeq u) hposNeg with
      ⟨v, hv⟩
    let nv := cNegSeq v
    refine ⟨nv, ?_⟩
    have hsame :
        CauchyEquiv (cMulSeq u nv) (cMulSeq (cNegSeq u) v) := by
      exact cauchyEquiv_of_pointwise_eq (fun n => by
        change qMul (u.seq n) (qNeg (v.seq n)) =
          qMul (qNeg (u.seq n)) (v.seq n)
        rw [qMul_neg_right, qMul_neg_left])
    exact cauchyEquiv_trans hsame hv

/-- Research quotient-level inverse relation. -/
def RCInvRel (x y : RCBOMA) : Prop := rCMul x y = rCOne

/-- Every nonzero research Cauchy class has a multiplicative inverse witness.
    The witness is branch-only and does not alter accepted R-BLOCK-001. -/
theorem rC_inverse_exists (x : RCBOMA) (hx : x ≠ rCZero) :
    ∃ y : RCBOMA, RCInvRel x y := by
  refine Quotient.inductionOn x ?_ hx
  intro u hu
  rcases representative_inverse_exists u hu with ⟨v, hv⟩
  refine ⟨rCmk v, ?_⟩
  unfold RCInvRel
  change rCmk (cMulSeq u v) = rCmk (cauchyOfQ qOne)
  exact Quotient.sound hv

/-- Right one law, derived from commutativity and the verified left law. -/
theorem rCMul_one_right (x : RCBOMA) : rCMul x rCOne = x := by
  rw [rCMul_comm, rCMul_one_left]

/-- Multiplicative inverse witnesses are unique in the research commutative
    monoid, so the exported contract remains witness-only rather than a global
    inverse operation. -/
theorem rC_inverse_unique {x y z : RCBOMA}
    (hy : RCInvRel x y) (hz : RCInvRel x z) : y = z := by
  unfold RCInvRel at hy hz
  calc
    y = rCMul rCOne y := (rCMul_one_left y).symm
    _ = rCMul (rCMul x z) y := congrArg (fun t => rCMul t y) hz.symm
    _ = rCMul x (rCMul z y) := rCMul_assoc x z y
    _ = rCMul x (rCMul y z) :=
      congrArg (fun t => rCMul x t) (rCMul_comm z y)
    _ = rCMul (rCMul x y) z := (rCMul_assoc x y z).symm
    _ = rCMul rCOne z := congrArg (fun t => rCMul t z) hy
    _ = z := rCMul_one_left z

/-- Unique witness form of the research field inverse contract. -/
theorem rC_inverse_exists_unique (x : RCBOMA) (hx : x ≠ rCZero) :
    ∃ y : RCBOMA, RCInvRel x y ∧
      ∀ z : RCBOMA, RCInvRel x z → z = y := by
  rcases rC_inverse_exists x hx with ⟨y, hy⟩
  refine ⟨y, hy, ?_⟩
  intro z hz
  exact rC_inverse_unique hz hy

/-- Independent ordered-field-strength certificate. Completeness remains a
    separate gate and is deliberately absent from this structure. -/
structure CauchyOrderedFieldCertificate where
  orderedRingCertificate : CauchyOrderedRingCertificate
  nonzeroGapCertificate : CauchyNonzeroGapCertificate
  inverseExistsUnique : ∀ (x : RCBOMA), x ≠ rCZero →
    ∃ y : RCBOMA, RCInvRel x y ∧
      ∀ z : RCBOMA, RCInvRel x z → z = y
  choiceBoundary : ∀ (u : CauchySeq), EventuallyPositiveGap u →
    ∃ v : CauchySeq, CauchyEquiv (cMulSeq u v) (cauchyOfQ qOne)

theorem cauchyOrderedFieldCertificate : CauchyOrderedFieldCertificate where
  orderedRingCertificate := cauchyOrderedRingCertificate
  nonzeroGapCertificate := cauchyNonzeroGapCertificate
  inverseExistsUnique := rC_inverse_exists_unique
  choiceBoundary := positive_gap_inverse_sequence_exists

end BOMA.R.StageTwo.CauchyInverse003

/- ST2-EXP-003 completeness prerequisite: an explicit positive rational scale
   indexed by accepted BOMANat and tending to zero. The scale chooses one
   accepted-Q inverse witness for each positive successor natural. This exposes
   the countable data-selection boundary before any diagonal completion proof. -/
namespace BOMA.R.StageTwo.CauchyScale003

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001
open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QArchimedeanUpperBound001
open BOMA.R.QArchimedeanScaling001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyInverse003

/-- Accepted natural order is preserved by the canonical Q embedding. -/
theorem qOfN_mono {m n : BOMANat} (h : LE m n) :
    qLE (qOfN m) (qOfN n) := by
  unfold qOfN
  exact (qOfZ_order (embedN m) (embedN n)).2
    ((embedN_order m n).2 h)

/-- Every natural is below its successor. -/
theorem le_self_succ (n : BOMANat) : LE n (s n) := by
  change LEAdd n (s n)
  refine ⟨s z, ?_⟩
  simpa using (add_s_right n z)

/-- The embedded successor natural is strictly positive in accepted Q. -/
theorem qOfN_succ_pos (n : BOMANat) : qPos (qOfN (s n)) := by
  have hle : qLE qZero (qOfN (s n)) := by
    change qLE (qOfZ (embedN z)) (qOfZ (embedN (s n)))
    exact (qOfZ_order (embedN z) (embedN (s n))).2
      ((embedN_order z (s n)).2 (z_le (s n)))
  have hne : qZero ≠ qOfN (s n) := by
    intro heq
    have hback : qLE (qOfN (s n)) qZero := by
      rw [← heq]
      exact qle_refl qZero
    have hzord : zLE (embedN (s n)) (embedN z) := by
      change qLE (qOfZ (embedN (s n))) (qOfZ (embedN z)) at hback
      exact (qOfZ_order (embedN (s n)) (embedN z)).1 hback
    have hnz : LE (s n) z := (embedN_order (s n) z).1 hzord
    exact not_s_le_z n hnz
  exact ⟨hle, hne⟩

/-- Nonzero form used by the accepted witness-only inverse theorem. -/
theorem qOfN_succ_ne_zero (n : BOMANat) : qOfN (s n) ≠ qZero := by
  intro h
  exact (qOfN_succ_pos n).2 h.symm

/-- One explicit selected reciprocal of the embedded positive natural n+1.
    This is deliberately noncomputable and source-attributed to Choice. -/
noncomputable def qCauchyScale (n : BOMANat) : QBOMA := by
  classical
  exact Classical.choose (q_inverse_exists (qOfN (s n)) (qOfN_succ_ne_zero n))

/-- The selected scale value is the accepted-Q inverse witness of n+1. -/
theorem qCauchyScale_inv (n : BOMANat) :
    QInvRel (qOfN (s n)) (qCauchyScale n) := by
  classical
  unfold qCauchyScale
  exact Classical.choose_spec
    (q_inverse_exists (qOfN (s n)) (qOfN_succ_ne_zero n))

/-- Every scale value is positive. -/
theorem qCauchyScale_pos (n : BOMANat) : qPos (qCauchyScale n) := by
  have hbase : QPositive (qOfN (s n)) :=
    ⟨(qOfN_succ_pos n).1, qOfN_succ_ne_zero n⟩
  have hinv : QPositive (qCauchyScale n) :=
    inverse_of_positive_is_positive hbase (qCauchyScale_inv n)
  exact ⟨hinv.1, fun h => hinv.2 h.symm⟩

/-- The successor embedding is monotone along accepted natural order. -/
theorem qOfN_succ_mono {m n : BOMANat} (h : LE m n) :
    qLE (qOfN (s m)) (qOfN (s n)) :=
  qOfN_mono ((le_s_iff).2 h)

/-- The reciprocal scale is order reversing. -/
theorem qCauchyScale_antitone {m n : BOMANat} (h : LE m n) :
    qLE (qCauchyScale n) (qCauchyScale m) := by
  exact q_inverse_le_of_positive_lower
    (qOfN_succ_pos m)
    (qOfN_succ_mono h)
    (qCauchyScale_inv m)
    (qCauchyScale_inv n)

/-- Multiplying the Archimedean inequality by the selected reciprocal of n+1
    isolates that reciprocal below the positive step. -/
theorem scale_le_of_one_le_mul {n : BOMANat} {eps : QBOMA}
    (heps : qPos eps)
    (h : qLE qOne (qMul (qOfN (s n)) eps)) :
    qLE (qCauchyScale n) eps := by
  have hsnonneg : qLE qZero (qCauchyScale n) := (qCauchyScale_pos n).1
  have hm := qmul_mono_right_nonneg h hsnonneg
  have hleft : qMul qOne (qCauchyScale n) = qCauchyScale n :=
    qMul_one_left (qCauchyScale n)
  have hright :
      qMul (qMul (qOfN (s n)) eps) (qCauchyScale n) = eps := by
    calc
      qMul (qMul (qOfN (s n)) eps) (qCauchyScale n) =
          qMul eps (qMul (qOfN (s n)) (qCauchyScale n)) := by
        calc
          qMul (qMul (qOfN (s n)) eps) (qCauchyScale n) =
              qMul (qMul eps (qOfN (s n))) (qCauchyScale n) := by
            rw [qMul_comm (qOfN (s n)) eps]
          _ = qMul eps (qMul (qOfN (s n)) (qCauchyScale n)) :=
            qMul_assoc eps (qOfN (s n)) (qCauchyScale n)
      _ = qMul eps qOne :=
        congrArg (fun t => qMul eps t) (qCauchyScale_inv n)
      _ = eps := qMul_one_right eps
  rw [hleft, hright] at hm
  exact hm

/-- The selected positive rational scale tends to zero: every positive rational
    epsilon eventually dominates all later scale values. -/
theorem qCauchyScale_tends_zero (eps : QBOMA) (heps : qPos eps) :
    ∃ N : BOMANat, ∀ n : BOMANat, LE N n → qLE (qCauchyScale n) eps := by
  rcases q_archimedean_scale qOne eps heps with ⟨k, hk⟩
  let N := s k
  have hkN : LE k N := by
    unfold N
    exact le_self_succ k
  have hqkN : qLE (qOfN k) (qOfN N) := qOfN_mono hkN
  have hprod : qLE (qMul (qOfN k) eps) (qMul (qOfN N) eps) :=
    qmul_mono_right_nonneg hqkN heps.1
  have hOneN : qLE qOne (qMul (qOfN N) eps) := qle_trans hk hprod
  have hNscale : qLE (qCauchyScale k) eps := by
    unfold N at hOneN
    exact scale_le_of_one_le_mul heps hOneN
  refine ⟨k, ?_⟩
  intro n hn
  exact qle_trans (qCauchyScale_antitone hn) hNscale

/-- Machine-checkable certificate for the decreasing rational scale. -/
structure CauchyScaleCertificate where
  positive : ∀ n : BOMANat, qPos (qCauchyScale n)
  antitone : ∀ {m n : BOMANat}, LE m n →
    qLE (qCauchyScale n) (qCauchyScale m)
  tendsZero : ∀ eps : QBOMA, qPos eps →
    ∃ N : BOMANat, ∀ n : BOMANat, LE N n → qLE (qCauchyScale n) eps
  selectedInverse : ∀ n : BOMANat,
    QInvRel (qOfN (s n)) (qCauchyScale n)

theorem cauchyScaleCertificate : CauchyScaleCertificate where
  positive := qCauchyScale_pos
  antitone := qCauchyScale_antitone
  tendsZero := qCauchyScale_tends_zero
  selectedInverse := qCauchyScale_inv

end BOMA.R.StageTwo.CauchyScale003

/- ST2-EXP-003 completeness core: define the exact sequence-level Cauchy and
   convergence contract on the independently constructed quotient field. This
   file proves only the closeness calculus needed by a later diagonal limit; it
   does not claim completeness. -/
namespace BOMA.R.StageTwo.CauchyCompletionCore003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderedRing003
open BOMA.R.StageTwo.CauchyInverse003
open BOMA.R.StageTwo.CauchyScale003

/-- Symmetric rational-radius closeness on the research Cauchy quotient. -/
def rCClose (eps : QBOMA) (x y : RCBOMA) : Prop :=
  rCLE x (rCAdd y (rCOfQ eps)) ∧
  rCLE y (rCAdd x (rCOfQ eps))

/-- A sequence of research Cauchy quotient classes. -/
abbrev RCSeq := BOMANat → RCBOMA

/-- Exact sequential Cauchy contract on the experimental carrier. -/
def IsRCCauchy (u : RCSeq) : Prop :=
  ∀ eps : QBOMA, qPos eps →
    ∃ N : BOMANat, ∀ m n : BOMANat,
      LE N m → LE N n → rCClose eps (u m) (u n)

/-- Exact sequential convergence contract on the experimental carrier. -/
def RCConverges (u : RCSeq) (x : RCBOMA) : Prop :=
  ∀ eps : QBOMA, qPos eps →
    ∃ N : BOMANat, ∀ n : BOMANat, LE N n → rCClose eps (u n) x

/-- The eventual-limit statement required for branch Cauchy completeness. -/
def RCCauchyComplete : Prop :=
  ∀ u : RCSeq, IsRCCauchy u → ∃ x : RCBOMA, RCConverges u x

/-- Positive embedded rational errors are nonnegative in the quotient order. -/
theorem rCOfQ_nonneg {eps : QBOMA} (heps : qPos eps) :
    rCLE rCZero (rCOfQ eps) := by
  have hq : qLE qZero eps := heps.1
  exact (rCOfQ_order qZero eps).2 hq

/-- Any point is below itself plus a positive rational error. -/
theorem rcle_self_add_error (x : RCBOMA) {eps : QBOMA} (heps : qPos eps) :
    rCLE x (rCAdd x (rCOfQ eps)) := by
  have h := rcle_add_right (rCOfQ_nonneg heps) x
  have hleft : rCAdd rCZero x = x := rCAdd_zero_left x
  have hright : rCAdd (rCOfQ eps) x = rCAdd x (rCOfQ eps) :=
    rCAdd_comm (rCOfQ eps) x
  rw [hleft, hright] at h
  exact h

/-- Closeness is reflexive at every positive radius. -/
theorem rCClose_refl {eps : QBOMA} (heps : qPos eps) (x : RCBOMA) :
    rCClose eps x x := by
  exact ⟨rcle_self_add_error x heps, rcle_self_add_error x heps⟩

/-- Closeness is symmetric by definition. -/
theorem rCClose_symm {eps : QBOMA} {x y : RCBOMA}
    (h : rCClose eps x y) : rCClose eps y x := ⟨h.2, h.1⟩

/-- Reassociate two rational error embeddings after quotient addition. -/
theorem rC_add_two_errors (x : RCBOMA) (eps delta : QBOMA) :
    rCAdd (rCAdd x (rCOfQ delta)) (rCOfQ eps) =
      rCAdd x (rCOfQ (qAdd delta eps)) := by
  calc
    rCAdd (rCAdd x (rCOfQ delta)) (rCOfQ eps) =
        rCAdd x (rCAdd (rCOfQ delta) (rCOfQ eps)) :=
      rCAdd_assoc x (rCOfQ delta) (rCOfQ eps)
    _ = rCAdd x (rCOfQ (qAdd delta eps)) := by
      rw [← rCOfQ_add]

/-- Triangle composition for quotient closeness with additive radii. -/
theorem rCClose_trans_add {eps delta : QBOMA} {x y z : RCBOMA}
    (hxy : rCClose eps x y) (hyz : rCClose delta y z) :
    rCClose (qAdd delta eps) x z := by
  constructor
  · have h1 := hxy.1
    have h2 := rcle_add_right hyz.1 (rCOfQ eps)
    have hchain :
        rCLE x (rCAdd (rCAdd z (rCOfQ delta)) (rCOfQ eps)) :=
      rcle_trans h1 h2
    rw [rC_add_two_errors] at hchain
    exact hchain
  · have h1 := hyz.2
    have h2 := rcle_add_right hxy.2 (rCOfQ delta)
    have hchain :
        rCLE z (rCAdd (rCAdd x (rCOfQ eps)) (rCOfQ delta)) :=
      rcle_trans h1 h2
    have hnorm :
        rCAdd (rCAdd x (rCOfQ eps)) (rCOfQ delta) =
          rCAdd x (rCOfQ (qAdd delta eps)) := by
      calc
        rCAdd (rCAdd x (rCOfQ eps)) (rCOfQ delta) =
            rCAdd x (rCAdd (rCOfQ eps) (rCOfQ delta)) :=
          rCAdd_assoc x (rCOfQ eps) (rCOfQ delta)
        _ = rCAdd x (rCOfQ (qAdd eps delta)) := by rw [← rCOfQ_add]
        _ = rCAdd x (rCOfQ (qAdd delta eps)) := by
          rw [qAdd_comm eps delta]
    rw [hnorm] at hchain
    exact hchain

/-- Enlarging a positive error radius preserves quotient closeness. -/
theorem rCClose_mono {eps delta : QBOMA} {x y : RCBOMA}
    (h : rCClose eps x y) (hed : qLE eps delta) :
    rCClose delta x y := by
  have herr : rCLE (rCOfQ eps) (rCOfQ delta) :=
    (rCOfQ_order eps delta).2 hed
  have hy := rcle_add_right herr y
  have hx := rcle_add_right herr x
  have hy' :
      rCLE (rCAdd y (rCOfQ eps)) (rCAdd y (rCOfQ delta)) := by
    rw [rCAdd_comm y (rCOfQ eps), rCAdd_comm y (rCOfQ delta)]
    exact hy
  have hx' :
      rCLE (rCAdd x (rCOfQ eps)) (rCAdd x (rCOfQ delta)) := by
    rw [rCAdd_comm x (rCOfQ eps), rCAdd_comm x (rCOfQ delta)]
    exact hx
  exact ⟨rcle_trans h.1 hy', rcle_trans h.2 hx'⟩

/-- A constant quotient sequence converges to its constant value. -/
theorem constant_converges (x : RCBOMA) :
    RCConverges (fun _ => x) x := by
  intro eps heps
  refine ⟨BOMA.NCore.RB001.BOMANat.z, ?_⟩
  intro n _
  exact rCClose_refl heps x

/-- Machine-checkable statement boundary for the later diagonal proof. -/
structure CauchyCompletionCoreCertificate where
  closeRefl : ∀ {eps : QBOMA}, qPos eps → ∀ x : RCBOMA, rCClose eps x x
  closeSymm : ∀ {eps : QBOMA} {x y : RCBOMA},
    rCClose eps x y → rCClose eps y x
  closeTriangle : ∀ {eps delta : QBOMA} {x y z : RCBOMA},
    rCClose eps x y → rCClose delta y z →
      rCClose (qAdd delta eps) x z
  closeMonotone : ∀ {eps delta : QBOMA} {x y : RCBOMA},
    rCClose eps x y → qLE eps delta → rCClose delta x y
  scale : CauchyScaleCertificate
  orderedField : CauchyOrderedFieldCertificate

theorem cauchyCompletionCoreCertificate : CauchyCompletionCoreCertificate where
  closeRefl := @rCClose_refl
  closeSymm := @rCClose_symm
  closeTriangle := @rCClose_trans_add
  closeMonotone := @rCClose_mono
  scale := cauchyScaleCertificate
  orderedField := cauchyOrderedFieldCertificate

end BOMA.R.StageTwo.CauchyCompletionCore003

/- ST2-EXP-003 completeness prerequisite: rational-radius closeness on the
   research quotient reflects accepted rational closeness on embedded Q, and
   every quotient class admits an arbitrarily close embedded-rational witness.
   This is still independent of the selected Dedekind real producer. -/
namespace BOMA.R.StageTwo.CauchyDensity003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderedRing003
open BOMA.R.StageTwo.CauchyCompletionCore003

/-- A positive rational increment enlarges any rational endpoint. -/
theorem qLE_self_add_pos (x : QBOMA) {eps : QBOMA} (heps : qPos eps) :
    qLE x (qAdd x eps) := by
  have h := qadd_mono_right heps.1 x
  rw [qAdd_zero_left, qAdd_comm eps x] at h
  exact h

/-- Symmetric additive error bounds are exactly the existing rational
    difference-based closeness predicate. -/
theorem qClose_iff_add_bounds {eps x y : QBOMA} :
    qClose eps x y ↔
      qLE x (qAdd y eps) ∧ qLE y (qAdd x eps) := by
  constructor
  · intro h
    exact ⟨qClose_to_le_add h, qClose_to_le_add (qClose_symm h)⟩
  · rintro ⟨hxy, hyx⟩
    constructor
    · have hrev := qneg_reverses (qLE_add_to_difference_upper hyx)
      rw [qNeg_difference] at hrev
      exact hrev
    · exact qLE_add_to_difference_upper hxy

/-- On constant embedded rationals, quotient closeness is exactly accepted
    rational closeness at the same radius. -/
theorem rCClose_ofQ_iff {eps q r : QBOMA} :
    rCClose eps (rCOfQ q) (rCOfQ r) ↔ qClose eps q r := by
  unfold rCClose
  rw [rCOfQ_add, rCOfQ_add,
    rCOfQ_order q (qAdd r eps), rCOfQ_order r (qAdd q eps)]
  exact qClose_iff_add_bounds.symm

/-- Every independently constructed Cauchy quotient class has an embedded
    rational approximation at every positive rational radius. The witness is
    one sufficiently late term of an arbitrary quotient representative; no
    Dedekind cut or accepted real producer is used. -/
theorem rational_approximation_exists (x : RCBOMA) (eps : QBOMA)
    (heps : qPos eps) :
    ∃ q : QBOMA, rCClose eps x (rCOfQ q) := by
  refine Quotient.inductionOn x ?_
  intro u
  rcases u.cauchy eps heps with ⟨N, hN⟩
  refine ⟨u.seq N, ?_⟩
  constructor
  · rw [rCOfQ_add]
    apply (rCLE_mk u (cauchyOfQ (qAdd (u.seq N) eps))).2
    intro eta heta
    refine ⟨N, ?_⟩
    intro n hn
    have hclose := hN n N hn (le_refl N)
    have hbase : qLE (u.seq n) (qAdd (u.seq N) eps) :=
      qClose_to_le_add hclose
    exact qle_trans hbase (qLE_self_add_pos (qAdd (u.seq N) eps) heta)
  · change rCLE (rCmk (cauchyOfQ (u.seq N)))
      (rCmk (cAddSeq u (cauchyOfQ eps)))
    apply (rCLE_mk (cauchyOfQ (u.seq N))
      (cAddSeq u (cauchyOfQ eps))).2
    intro eta heta
    refine ⟨N, ?_⟩
    intro n hn
    have hclose := hN N n (le_refl N) hn
    have hbase : qLE (u.seq N) (qAdd (u.seq n) eps) :=
      qClose_to_le_add hclose
    exact qle_trans hbase (qLE_self_add_pos (qAdd (u.seq n) eps) heta)

/-- Machine-checkable density boundary for the later completeness selector. -/
structure CauchyDensityCertificate where
  embeddedClose : ∀ {eps q r : QBOMA},
    rCClose eps (rCOfQ q) (rCOfQ r) ↔ qClose eps q r
  dense : ∀ x : RCBOMA, ∀ eps : QBOMA, qPos eps →
    ∃ q : QBOMA, rCClose eps x (rCOfQ q)
  completionCore : CauchyCompletionCoreCertificate

theorem cauchyDensityCertificate : CauchyDensityCertificate where
  embeddedClose := @rCClose_ofQ_iff
  dense := rational_approximation_exists
  completionCore := cauchyCompletionCoreCertificate

end BOMA.R.StageTwo.CauchyDensity003

/- ST2-EXP-003 completeness selector: choose one rational approximation to each
   term of an RCBOMA sequence at the explicit vanishing radius qCauchyScale n.
   This is the countable data-selection boundary required by the frozen Plan.
   No Dedekind producer or standard real carrier is used. -/
namespace BOMA.R.StageTwo.CauchyApproximation003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyScale003
open BOMA.R.StageTwo.CauchyCompletionCore003
open BOMA.R.StageTwo.CauchyDensity003

/-- Explicit Choice boundary: one rational approximation is selected for each
    quotient term and each accepted-natural index. -/
noncomputable def qApproxAtScale (x : RCBOMA) (n : BOMANat) : QBOMA := by
  classical
  exact Classical.choose
    (rational_approximation_exists x (qCauchyScale n) (qCauchyScale_pos n))

/-- The selected rational really approximates the quotient term at the declared
    vanishing scale. -/
theorem qApproxAtScale_close (x : RCBOMA) (n : BOMANat) :
    rCClose (qCauchyScale n) x (rCOfQ (qApproxAtScale x n)) := by
  classical
  unfold qApproxAtScale
  exact Classical.choose_spec
    (rational_approximation_exists x (qCauchyScale n) (qCauchyScale_pos n))

/-- Selected rational approximation sequence for a quotient-valued sequence. -/
noncomputable def qApproxSeq (u : RCSeq) : QSeq :=
  fun n => qApproxAtScale (u n) n

/-- A Cauchy sequence in the independently constructed quotient has a selected
    rational approximation sequence which is itself Cauchy in accepted Q.

    Error budget: quarter + half + quarter = epsilon. -/
theorem qApproxSeq_cauchy {u : RCSeq} (hu : IsRCCauchy u) :
    IsCauchy (qApproxSeq u) := by
  intro eps heps
  rcases positive_half_exists heps with ⟨half, hhalf, hhalfSum⟩
  rcases positive_half_exists hhalf with ⟨quarter, hquarter, hquarterSum⟩
  rcases qCauchyScale_tends_zero quarter hquarter with ⟨Ns, hNs⟩
  rcases hu half hhalf with ⟨Nu, hNu⟩
  rcases common_upper_bound Ns Nu with ⟨N, hNsN, hNuN⟩
  refine ⟨N, ?_⟩
  intro m n hm hn
  have hsm : qLE (qCauchyScale m) quarter :=
    hNs m (le_trans hNsN hm)
  have hsn : qLE (qCauchyScale n) quarter :=
    hNs n (le_trans hNsN hn)
  have ham : rCClose quarter (u m) (rCOfQ (qApproxSeq u m)) := by
    exact rCClose_mono (qApproxAtScale_close (u m) m) hsm
  have han : rCClose quarter (u n) (rCOfQ (qApproxSeq u n)) := by
    exact rCClose_mono (qApproxAtScale_close (u n) n) hsn
  have hum : rCClose half (u m) (u n) :=
    hNu m n (le_trans hNuN hm) (le_trans hNuN hn)
  have hleft : rCClose quarter (rCOfQ (qApproxSeq u m)) (u m) :=
    rCClose_symm ham
  have hchain1 := rCClose_trans_add hleft hum
  have hchain2 := rCClose_trans_add hchain1 han
  have hradius : qAdd quarter (qAdd half quarter) = eps := by
    calc
      qAdd quarter (qAdd half quarter) =
          qAdd (qAdd quarter half) quarter :=
        (qAdd_assoc quarter half quarter).symm
      _ = qAdd (qAdd half quarter) quarter := by
        rw [qAdd_comm quarter half]
      _ = qAdd half (qAdd quarter quarter) :=
        qAdd_assoc half quarter quarter
      _ = qAdd half half := by rw [hquarterSum]
      _ = eps := hhalfSum
  rw [hradius] at hchain2
  exact (rCClose_ofQ_iff).1 hchain2

/-- Package the selected rational sequence as an actual rational Cauchy
    representative for the eventual quotient limit. -/
noncomputable def approxCauchySeq (u : RCSeq) (hu : IsRCCauchy u) : CauchySeq :=
  ⟨qApproxSeq u, qApproxSeq_cauchy hu⟩

/-- Machine-checkable statement of the countable approximation boundary. -/
structure CauchyApproximationCertificate where
  selectedClose : ∀ x : RCBOMA, ∀ n : BOMANat,
    rCClose (qCauchyScale n) x (rCOfQ (qApproxAtScale x n))
  selectedCauchy : ∀ {u : RCSeq}, IsRCCauchy u → IsCauchy (qApproxSeq u)
  density : CauchyDensityCertificate

theorem cauchyApproximationCertificate : CauchyApproximationCertificate where
  selectedClose := qApproxAtScale_close
  selectedCauchy := @qApproxSeq_cauchy
  density := cauchyDensityCertificate

end BOMA.R.StageTwo.CauchyApproximation003

/- ST2-EXP-003: sequential completeness of the independently constructed
   rational-Cauchy quotient. The proof uses the explicit countable rational
   approximation selector and vanishing rational scale already exposed in
   earlier sources. It does not import the selected Dedekind real producer and
   does not claim the Dedekind least-upper-bound contract. -/
namespace BOMA.R.StageTwo.CauchyCompletion003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyScale003
open BOMA.R.StageTwo.CauchyCompletionCore003
open BOMA.R.StageTwo.CauchyDensity003
open BOMA.R.StageTwo.CauchyApproximation003

/-- The embedded terms of any accepted-Q Cauchy representative converge, in
    quotient closeness, to the quotient class represented by that sequence. -/
theorem embedded_terms_converge_to_class (d : CauchySeq) :
    RCConverges (fun n => rCOfQ (d.seq n)) (rCmk d) := by
  intro eps heps
  rcases d.cauchy eps heps with ⟨N, hN⟩
  refine ⟨N, ?_⟩
  intro n hn
  constructor
  · change rCLE (rCmk (cauchyOfQ (d.seq n)))
      (rCmk (cAddSeq d (cauchyOfQ eps)))
    apply (rCLE_mk (cauchyOfQ (d.seq n))
      (cAddSeq d (cauchyOfQ eps))).2
    intro eta heta
    refine ⟨N, ?_⟩
    intro j hj
    have hclose := hN n j hn hj
    have hbase : qLE (d.seq n) (qAdd (d.seq j) eps) :=
      qClose_to_le_add hclose
    exact qle_trans hbase (qLE_self_add_pos (qAdd (d.seq j) eps) heta)
  · rw [rCOfQ_add]
    apply (rCLE_mk d (cauchyOfQ (qAdd (d.seq n) eps))).2
    intro eta heta
    refine ⟨N, ?_⟩
    intro j hj
    have hclose := hN j n hj hn
    have hbase : qLE (d.seq j) (qAdd (d.seq n) eps) :=
      qClose_to_le_add hclose
    exact qle_trans hbase (qLE_self_add_pos (qAdd (d.seq n) eps) heta)

/-- The explicit selected rational approximation sequence supplies a quotient
    limit for the original quotient-valued Cauchy sequence. -/
theorem selected_approximation_converges {u : RCSeq} (hu : IsRCCauchy u) :
    RCConverges u (rCmk (approxCauchySeq u hu)) := by
  intro eps heps
  rcases positive_half_exists heps with ⟨half, hhalf, hhalfSum⟩
  rcases qCauchyScale_tends_zero half hhalf with ⟨Ns, hNs⟩
  rcases embedded_terms_converge_to_class (approxCauchySeq u hu) half hhalf with
    ⟨Nd, hNd⟩
  rcases common_upper_bound Ns Nd with ⟨N, hNsN, hNdN⟩
  refine ⟨N, ?_⟩
  intro n hn
  have hscale : qLE (qCauchyScale n) half :=
    hNs n (le_trans hNsN hn)
  have happ : rCClose half (u n) (rCOfQ (qApproxSeq u n)) :=
    rCClose_mono (qApproxAtScale_close (u n) n) hscale
  have hlimit :
      rCClose half (rCOfQ (qApproxSeq u n))
        (rCmk (approxCauchySeq u hu)) := by
    simpa [approxCauchySeq] using hNd n (le_trans hNdN hn)
  have hchain := rCClose_trans_add happ hlimit
  rw [hhalfSum] at hchain
  exact hchain

/-- The independent rational-Cauchy quotient is sequentially Cauchy complete
    under the exact contract declared in CauchyCompletionCore003. -/
theorem rCCauchyComplete : RCCauchyComplete := by
  intro u hu
  exact ⟨rCmk (approxCauchySeq u hu), selected_approximation_converges hu⟩

/-- Completion milestone package. Sequential completeness is deliberately kept
    distinct from the still-open accepted Dedekind least-upper-bound bridge. -/
structure CauchyCompletionCertificate where
  approximation : CauchyApproximationCertificate
  embeddedTermsConverge : ∀ d : CauchySeq,
    RCConverges (fun n => rCOfQ (d.seq n)) (rCmk d)
  complete : RCCauchyComplete

theorem cauchyCompletionCertificate : CauchyCompletionCertificate where
  approximation := cauchyApproximationCertificate
  embeddedTermsConverge := embedded_terms_converge_to_class
  complete := rCCauchyComplete

end BOMA.R.StageTwo.CauchyCompletion003

/- ST2-EXP-003 H4 prerequisite: rational bracketing of a nonempty bounded
   family in the independently constructed Cauchy carrier. For every positive
   rational step delta, find adjacent embedded rationals b and b+delta such
   that b is not an upper bound while b+delta is an upper bound.

   This source uses only the independent Cauchy route plus shared rational
   Archimedean scaling. It does not import the selected Dedekind carrier. -/
namespace BOMA.R.StageTwo.CauchyLUBBracket003

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QArchimedeanScaling001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyOrderedRing003
open BOMA.R.StageTwo.CauchyCompletionCore003
open BOMA.R.StageTwo.CauchyDensity003

/-- The exact H4 upper-bound predicate on the research Cauchy carrier. -/
def RCUpperBound (F : RCBOMA → Prop) (U : RCBOMA) : Prop :=
  ∀ x : RCBOMA, F x → rCLE x U

/-- Strict order derived from the already verified quotient partial order. -/
def rCLT (x y : RCBOMA) : Prop := rCLE x y ∧ x ≠ y

/-- Embedded rational strict order is preserved exactly. -/
theorem rCOfQ_strict {q r : QBOMA} (h : qLT q r) :
    rCLT (rCOfQ q) (rCOfQ r) := by
  refine ⟨(rCOfQ_order q r).2 h.1, ?_⟩
  intro heq
  exact h.2 (rCOfQ_injective heq)

/-- Strict/non-strict transitivity on the research quotient. -/
theorem rclt_trans_le {x y z : RCBOMA}
    (hxy : rCLT x y) (hyz : rCLE y z) : rCLT x z := by
  refine ⟨rcle_trans hxy.1 hyz, ?_⟩
  intro hxz
  have hyx : rCLE y x := by
    rw [hxz]
    exact hyz
  exact hxy.2 (rcle_antisymm hxy.1 hyx)

/-- Non-strict/strict transitivity on the research quotient. -/
theorem rcle_trans_lt {x y z : RCBOMA}
    (hxy : rCLE x y) (hyz : rCLT y z) : rCLT x z := by
  refine ⟨rcle_trans hxy hyz.1, ?_⟩
  intro hxz
  have zleY : rCLE z y := by
    rw [← hxz]
    exact hxy
  exact hyz.2 (rcle_antisymm hyz.1 zleY)

/-- Zero is also a right additive identity on the quotient. -/
theorem rCAdd_zero_right (x : RCBOMA) : rCAdd x rCZero = x := by
  calc
    rCAdd x rCZero = rCAdd rCZero x := rCAdd_comm x rCZero
    _ = x := rCAdd_zero_left x

/-- An upper bound remains an upper bound when enlarged. -/
theorem rcUpperBound_mono {F : RCBOMA → Prop} {U V : RCBOMA}
    (hU : RCUpperBound F U) (hUV : rCLE U V) : RCUpperBound F V := by
  intro x hx
  exact rcle_trans (hU x hx) hUV

/-- Failure of the upper-bound property has an explicit family witness.
    This is proposition-level classical witness extraction, not data used to
    define the later limit sequence. -/
theorem not_rcUpperBound_witness {F : RCBOMA → Prop} {U : RCBOMA}
    (hnot : ¬ RCUpperBound F U) :
    ∃ x : RCBOMA, F x ∧ ¬ rCLE x U := by
  classical
  by_cases hex : ∃ x : RCBOMA, F x ∧ ¬ rCLE x U
  · exact hex
  · have hUB : RCUpperBound F U := by
      intro x hx
      by_cases hle : rCLE x U
      · exact hle
      · exact False.elim (hex ⟨x, hx, hle⟩)
    exact False.elim (hnot hUB)

/-- Subtracting one positive rational step from an endpoint is strictly lower. -/
theorem q_sub_step_lt (q delta : QBOMA) (hdelta : qPos delta) :
    qLT (qAdd (qAdd q (qNeg delta)) (qNeg delta))
      (qAdd q (qNeg delta)) := by
  have hneg : qLT (qNeg delta) qZero := by
    have ht := qlt_add_right hdelta (qNeg delta)
    rw [qAdd_zero_left, qAdd_neg_right] at ht
    exact ht
  have ht := qlt_add_right hneg (qAdd q (qNeg delta))
  have hleft :
      qAdd (qNeg delta) (qAdd q (qNeg delta)) =
        qAdd (qAdd q (qNeg delta)) (qNeg delta) := by
    exact qAdd_comm (qNeg delta) (qAdd q (qNeg delta))
  rw [hleft, qAdd_zero_left] at ht
  exact ht

/-- Density gives a rational strictly below any quotient point. -/
theorem rational_strict_lower_exists (x : RCBOMA) (delta : QBOMA)
    (hdelta : qPos delta) :
    ∃ a : QBOMA, rCLT (rCOfQ a) x := by
  rcases rational_approximation_exists x delta hdelta with ⟨q, hq⟩
  let y : QBOMA := qAdd q (qNeg delta)
  let a : QBOMA := qAdd y (qNeg delta)
  have htranslated := rcle_add_right hq.2 (rCOfQ (qNeg delta))
  have hyx : rCLE (rCOfQ y) x := by
    have hleft :
        rCAdd (rCOfQ q) (rCOfQ (qNeg delta)) = rCOfQ y := by
      unfold y
      exact rCOfQ_add q (qNeg delta)
    have hright :
        rCAdd (rCAdd x (rCOfQ delta)) (rCOfQ (qNeg delta)) = x := by
      calc
        rCAdd (rCAdd x (rCOfQ delta)) (rCOfQ (qNeg delta)) =
            rCAdd x (rCAdd (rCOfQ delta) (rCOfQ (qNeg delta))) :=
          rCAdd_assoc x (rCOfQ delta) (rCOfQ (qNeg delta))
        _ = rCAdd x (rCOfQ (qAdd delta (qNeg delta))) := by
          rw [rCOfQ_add]
        _ = rCAdd x (rCOfQ qZero) := by rw [qAdd_neg_right]
        _ = rCAdd x rCZero := by rfl
        _ = x := rCAdd_zero_right x
    rw [hleft, hright] at htranslated
    exact htranslated
  refine ⟨a, ?_⟩
  apply rclt_trans_le (rCOfQ_strict (q_sub_step_lt q delta hdelta))
  exact hyx

/-- Density also gives a rational endpoint above any quotient point. -/
theorem rational_upper_exists (x : RCBOMA) (delta : QBOMA)
    (hdelta : qPos delta) :
    ∃ b : QBOMA, rCLE x (rCOfQ b) := by
  rcases rational_approximation_exists x delta hdelta with ⟨q, hq⟩
  refine ⟨qAdd q delta, ?_⟩
  have h := hq.1
  rw [rCOfQ_add] at h
  exact h

/-- A nonempty family has a rational point which is not an upper bound. -/
theorem family_rational_nonupper_exists
    (F : RCBOMA → Prop) (hne : ∃ x : RCBOMA, F x)
    (delta : QBOMA) (hdelta : qPos delta) :
    ∃ a : QBOMA, ¬ RCUpperBound F (rCOfQ a) := by
  rcases hne with ⟨x, hx⟩
  rcases rational_strict_lower_exists x delta hdelta with ⟨a, hax⟩
  refine ⟨a, ?_⟩
  intro hUB
  have hxa := hUB x hx
  exact hax.2 (rcle_antisymm hax.1 hxa)

/-- An explicit quotient upper bound can be enlarged to an embedded rational
    upper bound. -/
theorem family_rational_upper_exists
    (F : RCBOMA → Prop) (U : RCBOMA) (hUB : RCUpperBound F U)
    (delta : QBOMA) (hdelta : qPos delta) :
    ∃ u : QBOMA, RCUpperBound F (rCOfQ u) := by
  rcases rational_upper_exists U delta hdelta with ⟨u, hUu⟩
  exact ⟨u, rcUpperBound_mono hUB hUu⟩

/-- Route-independent rational grid used only for H4 bracketing. -/
def h4Grid (a delta : QBOMA) (n : BOMANat) : QBOMA :=
  qAdd a (qMul (qOfN n) delta)

@[simp] theorem h4Grid_zero (a delta : QBOMA) : h4Grid a delta z = a := by
  unfold h4Grid
  rw [qOfN_zero, qMul_zero_left, qAdd_zero_right]

/-- Advancing the natural index advances by exactly one rational step. -/
theorem h4Grid_succ (a delta : QBOMA) (n : BOMANat) :
    h4Grid a delta (s n) = qAdd (h4Grid a delta n) delta := by
  unfold h4Grid
  have hsucc : qOfN (s n) = qAdd (qOfN n) qOne := by
    have h := qOfN_add n (s z)
    simpa using h
  rw [hsucc, qMul_add_left, qMul_one_left]
  exact (qAdd_assoc a (qMul (qOfN n) delta) delta).symm

/-- A rational translated-gap bound places the endpoint below the grid point. -/
theorem qle_h4Grid_of_gap_bound {a u delta : QBOMA} {n : BOMANat}
    (h : qLE (qAdd u (qNeg a)) (qMul (qOfN n) delta)) :
    qLE u (h4Grid a delta n) := by
  have ht := qadd_mono_right h a
  have hleft : qAdd (qAdd u (qNeg a)) a = u := by
    calc
      qAdd (qAdd u (qNeg a)) a = qAdd u (qAdd (qNeg a) a) :=
        qAdd_assoc u (qNeg a) a
      _ = qAdd u qZero := by rw [qAdd_neg_left]
      _ = u := qAdd_zero_right u
  have hright : qAdd (qMul (qOfN n) delta) a = h4Grid a delta n := by
    unfold h4Grid
    exact qAdd_comm (qMul (qOfN n) delta) a
  rw [hleft, hright] at ht
  exact ht

/-- A rational grid eventually reaches an upper bound already known at a
    rational endpoint. -/
theorem h4Grid_eventually_upper
    (F : RCBOMA → Prop) (a u delta : QBOMA)
    (hu : RCUpperBound F (rCOfQ u)) (hdelta : qPos delta) :
    ∃ n : BOMANat, RCUpperBound F (rCOfQ (h4Grid a delta n)) := by
  rcases q_archimedean_scale (qAdd u (qNeg a)) delta hdelta with ⟨n, hn⟩
  have hugrid : qLE u (h4Grid a delta n) := qle_h4Grid_of_gap_bound hn
  exact ⟨n, rcUpperBound_mono hu ((rCOfQ_order _ _).2 hugrid)⟩

/-- Finite classical search for the first upper-bound grid point. -/
theorem h4Grid_first_upper
    (F : RCBOMA → Prop) (a delta : QBOMA)
    (ha : ¬ RCUpperBound F (rCOfQ a)) :
    ∀ n : BOMANat,
      RCUpperBound F (rCOfQ (h4Grid a delta n)) →
      ∃ b r : QBOMA,
        ¬ RCUpperBound F (rCOfQ b) ∧
        RCUpperBound F (rCOfQ r) ∧
        r = qAdd b delta := by
  intro n
  induction n with
  | z =>
      intro hupper
      have hbase : RCUpperBound F (rCOfQ a) := by
        simpa using hupper
      exact False.elim (ha hbase)
  | s n ih =>
      intro hupper
      rcases Classical.em (RCUpperBound F (rCOfQ (h4Grid a delta n))) with hprev | hprev
      · exact ih hprev
      · refine ⟨h4Grid a delta n, h4Grid a delta (s n), hprev, hupper, ?_⟩
        exact h4Grid_succ a delta n

/-- For every positive rational step there is an adjacent rational bracket
    straddling the family upper-bound frontier. -/
theorem rational_lub_bracket_exists
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U)
    (delta : QBOMA) (hdelta : qPos delta) :
    ∃ b r : QBOMA,
      ¬ RCUpperBound F (rCOfQ b) ∧
      RCUpperBound F (rCOfQ r) ∧
      r = qAdd b delta := by
  rcases family_rational_nonupper_exists F hne delta hdelta with ⟨a, ha⟩
  rcases family_rational_upper_exists F U hUB delta hdelta with ⟨u, hu⟩
  rcases h4Grid_eventually_upper F a u delta hu hdelta with ⟨n, hn⟩
  exact h4Grid_first_upper F a delta ha n hn

/-- H4 bracketing certificate. -/
structure CauchyLUBBracketCertificate where
  bracket : ∀ (F : RCBOMA → Prop),
    (∃ x : RCBOMA, F x) →
    ∀ U : RCBOMA, RCUpperBound F U →
    ∀ delta : QBOMA, qPos delta →
      ∃ b r : QBOMA,
        ¬ RCUpperBound F (rCOfQ b) ∧
        RCUpperBound F (rCOfQ r) ∧
        r = qAdd b delta
  completion : BOMA.R.StageTwo.CauchyCompletion003.CauchyCompletionCertificate

theorem cauchyLUBBracketCertificate : CauchyLUBBracketCertificate where
  bracket := rational_lub_bracket_exists
  completion := BOMA.R.StageTwo.CauchyCompletion003.cauchyCompletionCertificate

end BOMA.R.StageTwo.CauchyLUBBracket003

/- ST2-EXP-003 H4 sequence stage: choose one rational lower endpoint from
   each verified shrinking upper-bound bracket and prove that the resulting
   rational sequence is Cauchy. The only new data selection is the explicit
   countable Classical.choose of one bracket lower endpoint at each accepted
   natural index. No selected Dedekind carrier is imported. -/
namespace BOMA.R.StageTwo.CauchyLUBSequence003

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyScale003
open BOMA.R.StageTwo.CauchyLUBBracket003

/-- Explicit Choice boundary: one lower rational endpoint from the verified
    H4 bracket at scale qCauchyScale n. -/
noncomputable def h4Lower
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U)
    (n : BOMANat) : QBOMA := by
  classical
  exact Classical.choose
    (rational_lub_bracket_exists F hne U hUB
      (qCauchyScale n) (qCauchyScale_pos n))

/-- The selected lower endpoint retains a matching upper endpoint exactly one
    shrinking rational scale above it. -/
theorem h4Lower_spec
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U)
    (n : BOMANat) :
    ∃ r : QBOMA,
      ¬ RCUpperBound F (rCOfQ (h4Lower F hne U hUB n)) ∧
      RCUpperBound F (rCOfQ r) ∧
      r = qAdd (h4Lower F hne U hUB n) (qCauchyScale n) := by
  classical
  unfold h4Lower
  exact Classical.choose_spec
    (rational_lub_bracket_exists F hne U hUB
      (qCauchyScale n) (qCauchyScale_pos n))

/-- Any selected lower endpoint lies below every later selected bracket upper
    endpoint. This follows from a family witness above the first non-upper
    endpoint and the second endpoint's verified upper-bound property. -/
theorem h4Lower_cross_le
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U)
    (m n : BOMANat) :
    qLE (h4Lower F hne U hUB m)
      (qAdd (h4Lower F hne U hUB n) (qCauchyScale n)) := by
  rcases h4Lower_spec F hne U hUB m with ⟨rm, hnotm, hubm, hrm⟩
  rcases h4Lower_spec F hne U hUB n with ⟨rn, hnotn, hubn, hrn⟩
  rcases not_rcUpperBound_witness hnotm with ⟨x, hxF, hnotx⟩
  have hLowerX : rCLE (rCOfQ (h4Lower F hne U hUB m)) x := by
    rcases rcle_total x (rCOfQ (h4Lower F hne U hUB m)) with hbad | hgood
    · exact False.elim (hnotx hbad)
    · exact hgood
  have hxUpper : rCLE x (rCOfQ rn) := hubn x hxF
  have hchain :
      rCLE (rCOfQ (h4Lower F hne U hUB m)) (rCOfQ rn) :=
    rcle_trans hLowerX hxUpper
  rw [hrn] at hchain
  exact (rCOfQ_order _ _).1 hchain

/-- Mutual epsilon-translate bounds are exactly enough for rational closeness. -/
theorem qClose_of_mutual_le_add {eps x y : QBOMA}
    (hxy : qLE x (qAdd y eps))
    (hyx : qLE y (qAdd x eps)) :
    qClose eps x y := by
  constructor
  · have hdiff : qLE (qAdd y (qNeg x)) eps :=
      qLE_add_to_difference_upper hyx
    have hneg := qneg_reverses hdiff
    rw [qNeg_difference] at hneg
    exact hneg
  · exact qLE_add_to_difference_upper hxy

/-- The chosen lower endpoints form a rational Cauchy sequence because each
    endpoint lies below every other endpoint plus that other's shrinking scale. -/
theorem h4Lower_cauchy
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U) :
    IsCauchy (fun n => h4Lower F hne U hUB n) := by
  intro eps heps
  rcases qCauchyScale_tends_zero eps heps with ⟨N, hN⟩
  refine ⟨N, ?_⟩
  intro m n hm hn
  have hmn0 := h4Lower_cross_le F hne U hUB m n
  have hnm0 := h4Lower_cross_le F hne U hUB n m
  have hscaleN : qLE (qCauchyScale n) eps := hN n hn
  have hscaleM : qLE (qCauchyScale m) eps := hN m hm
  have hincN := qadd_mono_right hscaleN (h4Lower F hne U hUB n)
  have hincM := qadd_mono_right hscaleM (h4Lower F hne U hUB m)
  rw [qAdd_comm (qCauchyScale n) (h4Lower F hne U hUB n),
      qAdd_comm eps (h4Lower F hne U hUB n)] at hincN
  rw [qAdd_comm (qCauchyScale m) (h4Lower F hne U hUB m),
      qAdd_comm eps (h4Lower F hne U hUB m)] at hincM
  have hmn :
      qLE (h4Lower F hne U hUB m)
        (qAdd (h4Lower F hne U hUB n) eps) :=
    qle_trans hmn0 hincN
  have hnm :
      qLE (h4Lower F hne U hUB n)
        (qAdd (h4Lower F hne U hUB m) eps) :=
    qle_trans hnm0 hincM
  exact qClose_of_mutual_le_add hmn hnm

/-- The H4 lower-bracket sequence packaged as an accepted-style Cauchy
    representative for the research quotient. -/
noncomputable def h4LowerCauchySeq
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U) : CauchySeq :=
  ⟨fun n => h4Lower F hne U hUB n, h4Lower_cauchy F hne U hUB⟩

/-- H4 sequence-stage certificate. -/
structure CauchyLUBSequenceCertificate where
  bracket : CauchyLUBBracketCertificate
  lowerCauchy : ∀ (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U),
      IsCauchy (fun n => h4Lower F hne U hUB n)

theorem cauchyLUBSequenceCertificate : CauchyLUBSequenceCertificate where
  bracket := cauchyLUBBracketCertificate
  lowerCauchy := by
    intro F hne U hUB
    exact h4Lower_cauchy F hne U hUB

end BOMA.R.StageTwo.CauchyLUBSequence003

/- ST2-EXP-003 H4: derive the accepted least-upper-bound contract on the
   independently constructed rational-Cauchy quotient. The proof uses shrinking
   rational brackets, their selected Cauchy endpoint sequences, and closure of
   the quotient order under Cauchy representative classes. It imports no
   selected Dedekind carrier or lower-cut construction. -/
namespace BOMA.R.StageTwo.CauchyLUB003

open BOMA.NCore.RB001
open BOMA.NArithmetic.Order001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyScale003
open BOMA.R.StageTwo.CauchyLUBBracket003
open BOMA.R.StageTwo.CauchyLUBSequence003

/-- Local accepted-natural common upper bound. Keeping this lemma in the H4
    source avoids relying on an unrelated namespace-open side effect. -/
theorem h4_common_upper_bound (a b : BOMANat) :
    ∃ N : BOMANat, LE a N ∧ LE b N := by
  rcases le_total a b with hab | hba
  · exact ⟨b, hab, le_refl b⟩
  · exact ⟨a, le_refl a, hba⟩

/-- The matching upper endpoint is definitionally the selected lower endpoint
    plus the current shrinking rational scale. -/
noncomputable def h4UpperValue
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U)
    (n : BOMANat) : QBOMA :=
  qAdd (h4Lower F hne U hUB n) (qCauchyScale n)

/-- Each explicit upper value is a genuine upper bound of the family. -/
theorem h4Upper_bound
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U)
    (n : BOMANat) :
    RCUpperBound F (rCOfQ (h4UpperValue F hne U hUB n)) := by
  rcases h4Lower_spec F hne U hUB n with ⟨r, hnot, hrUB, hr⟩
  unfold h4UpperValue
  rw [← hr]
  exact hrUB

/-- Each selected lower endpoint is genuinely below the upper-bound frontier. -/
theorem h4Lower_nonupper
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U)
    (n : BOMANat) :
    ¬ RCUpperBound F (rCOfQ (h4Lower F hne U hUB n)) := by
  rcases h4Lower_spec F hne U hUB n with ⟨r, hnot, hrUB, hr⟩
  exact hnot

/-- The upper endpoints are also a rational Cauchy sequence. Cross-bracketing
    already places each lower endpoint below every other upper endpoint; only
    the vanishing local scale remains to be absorbed into epsilon. -/
theorem h4Upper_cauchy
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U) :
    IsCauchy (fun n => h4UpperValue F hne U hUB n) := by
  intro eps heps
  rcases qCauchyScale_tends_zero eps heps with ⟨N, hN⟩
  refine ⟨N, ?_⟩
  intro m n hm hn
  have hmn0 := h4Lower_cross_le F hne U hUB m n
  have hnm0 := h4Lower_cross_le F hne U hUB n m
  have hmn1 := qadd_mono_right hmn0 (qCauchyScale m)
  have hnm1 := qadd_mono_right hnm0 (qCauchyScale n)
  change qLE (h4UpperValue F hne U hUB m)
    (qAdd (h4UpperValue F hne U hUB n) (qCauchyScale m)) at hmn1
  change qLE (h4UpperValue F hne U hUB n)
    (qAdd (h4UpperValue F hne U hUB m) (qCauchyScale n)) at hnm1
  have hincM := qadd_mono_right (hN m hm) (h4UpperValue F hne U hUB n)
  have hincN := qadd_mono_right (hN n hn) (h4UpperValue F hne U hUB m)
  rw [qAdd_comm (qCauchyScale m) (h4UpperValue F hne U hUB n),
      qAdd_comm eps (h4UpperValue F hne U hUB n)] at hincM
  rw [qAdd_comm (qCauchyScale n) (h4UpperValue F hne U hUB m),
      qAdd_comm eps (h4UpperValue F hne U hUB m)] at hincN
  have hmn : qLE (h4UpperValue F hne U hUB m)
      (qAdd (h4UpperValue F hne U hUB n) eps) :=
    qle_trans hmn1 hincM
  have hnm : qLE (h4UpperValue F hne U hUB n)
      (qAdd (h4UpperValue F hne U hUB m) eps) :=
    qle_trans hnm1 hincN
  exact qClose_of_mutual_le_add hmn hnm

/-- Upper endpoints packaged as a Cauchy representative. -/
noncomputable def h4UpperCauchySeq
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U) : CauchySeq :=
  ⟨fun n => h4UpperValue F hne U hUB n, h4Upper_cauchy F hne U hUB⟩

/-- The shrinking bracket width makes lower and upper endpoint sequences
    asymptotically identical. -/
theorem h4LowerUpper_equiv
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U) :
    CauchyEquiv (h4LowerCauchySeq F hne U hUB)
      (h4UpperCauchySeq F hne U hUB) := by
  intro eps heps
  rcases qCauchyScale_tends_zero eps heps with ⟨N, hN⟩
  refine ⟨N, ?_⟩
  intro n hn
  have hscale : qLE (qCauchyScale n) eps := hN n hn
  have hlowUp : qLE (h4Lower F hne U hUB n)
      (h4UpperValue F hne U hUB n) := by
    have ht := qadd_mono_right (qCauchyScale_pos n).1 (h4Lower F hne U hUB n)
    rw [qAdd_zero_left, qAdd_comm (qCauchyScale n) (h4Lower F hne U hUB n)] at ht
    exact ht
  have hUpErr : qLE (h4UpperValue F hne U hUB n)
      (qAdd (h4UpperValue F hne U hUB n) eps) := by
    have ht := qadd_mono_right heps.1 (h4UpperValue F hne U hUB n)
    rw [qAdd_zero_left, qAdd_comm eps (h4UpperValue F hne U hUB n)] at ht
    exact ht
  have hLowerToUpperErr : qLE (h4Lower F hne U hUB n)
      (qAdd (h4UpperValue F hne U hUB n) eps) :=
    qle_trans hlowUp hUpErr
  have hUpperToLowerErr : qLE (h4UpperValue F hne U hUB n)
      (qAdd (h4Lower F hne U hUB n) eps) := by
    unfold h4UpperValue
    have ht := qadd_mono_right hscale (h4Lower F hne U hUB n)
    rw [qAdd_comm (qCauchyScale n) (h4Lower F hne U hUB n),
        qAdd_comm eps (h4Lower F hne U hUB n)] at ht
    exact ht
  exact qClose_of_mutual_le_add hLowerToUpperErr hUpperToLowerErr

/-- If a fixed quotient point lies below every embedded term of a Cauchy
    representative, it lies below the quotient class represented by that
    sequence. This is the order-closure lemma needed for the upper-bound half. -/
theorem rcle_pointwise_to_class
    (d : CauchySeq) (x : RCBOMA)
    (h : ∀ n : BOMANat, rCLE x (rCOfQ (d.seq n))) :
    rCLE x (rCmk d) := by
  refine Quotient.inductionOn x ?_ h
  intro u hu
  change CauchyLE u d
  intro eps heps
  rcases positive_half_exists heps with ⟨delta, hdelta, hsum⟩
  rcases d.cauchy delta hdelta with ⟨Nd, hNd⟩
  have hfixed := hu Nd
  change CauchyLE u (cauchyOfQ (d.seq Nd)) at hfixed
  rcases hfixed delta hdelta with ⟨Nu, hNu⟩
  rcases h4_common_upper_bound Nd Nu with ⟨N, hNdN, hNuN⟩
  refine ⟨N, ?_⟩
  intro n hn
  have huFixed := hNu n (le_trans hNuN hn)
  change qLE (u.seq n) (qAdd (d.seq Nd) delta) at huFixed
  have hfixedToN := qClose_to_le_add
    (hNd Nd n (le_refl Nd) (le_trans hNdN hn))
  have hmove := qadd_mono_right hfixedToN delta
  rw [qAdd_assoc, hsum] at hmove
  exact qle_trans huFixed hmove

/-- Dually, if every embedded term of a Cauchy representative lies below a
    fixed quotient point, then the represented quotient class lies below it. -/
theorem rcle_class_to_pointwise
    (d : CauchySeq) (B : RCBOMA)
    (h : ∀ n : BOMANat, rCLE (rCOfQ (d.seq n)) B) :
    rCLE (rCmk d) B := by
  refine Quotient.inductionOn B ?_ h
  intro v hv
  change CauchyLE d v
  intro eps heps
  rcases positive_half_exists heps with ⟨delta, hdelta, hsum⟩
  rcases d.cauchy delta hdelta with ⟨Nd, hNd⟩
  have hfixed := hv Nd
  change CauchyLE (cauchyOfQ (d.seq Nd)) v at hfixed
  rcases hfixed delta hdelta with ⟨Nv, hNv⟩
  rcases h4_common_upper_bound Nd Nv with ⟨N, hNdN, hNvN⟩
  refine ⟨N, ?_⟩
  intro n hn
  have hnToFixed := qClose_to_le_add
    (qClose_symm (hNd Nd n (le_refl Nd) (le_trans hNdN hn)))
  have hfixedV := hNv n (le_trans hNvN hn)
  change qLE (d.seq Nd) (qAdd (v.seq n) delta) at hfixedV
  have hmove := qadd_mono_right hfixedV delta
  rw [qAdd_assoc, hsum] at hmove
  exact qle_trans hnToFixed hmove

/-- The independently constructed supremum candidate is the quotient class of
    the selected lower-endpoint Cauchy sequence. -/
noncomputable def h4Sup
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U) : RCBOMA :=
  rCmk (h4LowerCauchySeq F hne U hUB)

/-- Every family member lies below the Cauchy supremum candidate. -/
theorem member_le_h4Sup
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U)
    (x : RCBOMA) (hx : F x) :
    rCLE x (h4Sup F hne U hUB) := by
  have hpoint : ∀ n : BOMANat,
      rCLE x (rCOfQ ((h4UpperCauchySeq F hne U hUB).seq n)) := by
    intro n
    exact h4Upper_bound F hne U hUB n x hx
  have hUpperClass :=
    rcle_pointwise_to_class (h4UpperCauchySeq F hne U hUB) x hpoint
  have heq :
      rCmk (h4LowerCauchySeq F hne U hUB) =
        rCmk (h4UpperCauchySeq F hne U hUB) :=
    Quotient.sound (h4LowerUpper_equiv F hne U hUB)
  unfold h4Sup
  rw [← heq] at hUpperClass
  exact hUpperClass

/-- The Cauchy supremum candidate lies below every common upper bound. -/
theorem h4Sup_le_of_upper
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U)
    (B : RCBOMA) (hB : RCUpperBound F B) :
    rCLE (h4Sup F hne U hUB) B := by
  have hpoint : ∀ n : BOMANat,
      rCLE (rCOfQ ((h4LowerCauchySeq F hne U hUB).seq n)) B := by
    intro n
    have hnot := h4Lower_nonupper F hne U hUB n
    rcases not_rcUpperBound_witness hnot with ⟨x, hxF, hnotx⟩
    have hLowerX : rCLE (rCOfQ (h4Lower F hne U hUB n)) x := by
      rcases rcle_total x (rCOfQ (h4Lower F hne U hUB n)) with hbad | hgood
      · exact False.elim (hnotx hbad)
      · exact hgood
    exact rcle_trans hLowerX (hB x hxF)
  unfold h4Sup
  exact rcle_class_to_pointwise (h4LowerCauchySeq F hne U hUB) B hpoint

/-- Exact H4 least-upper-bound theorem, matching the accepted RA-11 contract
    but proved on RCBOMA without importing the selected Dedekind producer. -/
theorem rCauchy_lub_exists
    (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U) :
    ∃ s : RCBOMA,
      (∀ x : RCBOMA, F x → rCLE x s) ∧
      (∀ B : RCBOMA, RCUpperBound F B → rCLE s B) := by
  refine ⟨h4Sup F hne U hUB, ?_, ?_⟩
  · intro x hx
    exact member_le_h4Sup F hne U hUB x hx
  · intro B hB
    exact h4Sup_le_of_upper F hne U hUB B hB

/-- H4 completion certificate. -/
structure CauchyLUBCertificate where
  sequence : CauchyLUBSequenceCertificate
  lub : ∀ (F : RCBOMA → Prop)
    (hne : ∃ x : RCBOMA, F x)
    (U : RCBOMA) (hUB : RCUpperBound F U),
      ∃ s : RCBOMA,
        (∀ x : RCBOMA, F x → rCLE x s) ∧
        (∀ B : RCBOMA, RCUpperBound F B → rCLE s B)

theorem cauchyLUBCertificate : CauchyLUBCertificate where
  sequence := cauchyLUBSequenceCertificate
  lub := by
    intro F hne U hUB
    exact rCauchy_lub_exists F hne U hUB

end BOMA.R.StageTwo.CauchyLUB003

/- ST2-EXP-011: scalar-generic quadratic comparison core.

This research-only source extracts exactly the coordinate-level declaration
closure used by CQuadraticComparison001. It deliberately refers to no concrete
real-scalar implementation or transport route, and introduces no global
coordinate or inverse selector. Functional maps remain conditional on explicit
CoordinateExtractor data. -/
namespace BOMA.C.StageTwo.ComparisonInterface011

/-- Operations on the scalar carrier that occur syntactically in quadratic
    coordinate formulas. No field, order, completeness, or inverse law is
    bundled here. -/
structure ScalarOps where
  carrier : Type
  zero : carrier
  one : carrier
  neg : carrier → carrier
  add : carrier → carrier → carrier
  mul : carrier → carrier → carrier

/-- Minimal presentation required by the actual comparison declaration closure.
    Algebraic laws that the comparison proofs do not consume are intentionally
    absent. -/
structure QuadraticPresentation (S : ScalarOps) where
  carrier : Type
  zero : carrier
  one : carrier
  neg : carrier → carrier
  add : carrier → carrier → carrier
  mul : carrier → carrier → carrier
  ofScalar : S.carrier → carrier
  imag : carrier
  coord : S.carrier → S.carrier → carrier
  coordinateGeneration : ∀ x : carrier, ∃ a b : S.carrier, x = coord a b
  coordinateUnique : ∀ {a b c d : S.carrier},
    coord a b = coord c d → a = c ∧ b = d
  coordinateZero : coord S.zero S.zero = zero
  coordinateOne : coord S.one S.zero = one
  coordinateReal : ∀ a : S.carrier, coord a S.zero = ofScalar a
  coordinateImag : coord S.zero S.one = imag
  coordinateNeg : ∀ a b : S.carrier,
    neg (coord a b) = coord (S.neg a) (S.neg b)
  coordinateAdd : ∀ a b c d : S.carrier,
    add (coord a b) (coord c d) = coord (S.add a c) (S.add b d)
  coordinateMul : ∀ a b c d : S.carrier,
    mul (coord a b) (coord c d) =
      coord
        (S.add (S.mul a c) (S.neg (S.mul b d)))
        (S.add (S.mul a d) (S.mul b c))

/-- Same scalar coordinates define the representation-neutral graph. -/
def Related {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (x : A.carrier) (y : B.carrier) : Prop :=
  ∃ a b : S.carrier, x = A.coord a b ∧ y = B.coord a b

theorem related_total_left {S : ScalarOps}
    (A B : QuadraticPresentation S) (x : A.carrier) :
    ∃ y : B.carrier, Related A B x y := by
  rcases A.coordinateGeneration x with ⟨a, b, hx⟩
  exact ⟨B.coord a b, a, b, hx, rfl⟩

theorem related_total_right {S : ScalarOps}
    (A B : QuadraticPresentation S) (y : B.carrier) :
    ∃ x : A.carrier, Related A B x y := by
  rcases B.coordinateGeneration y with ⟨a, b, hy⟩
  exact ⟨A.coord a b, a, b, rfl, hy⟩

theorem related_right_unique {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x : A.carrier} {y z : B.carrier}
    (hy : Related A B x y) (hz : Related A B x z) : y = z := by
  rcases hy with ⟨a, b, hxa, hya⟩
  rcases hz with ⟨c, d, hxc, hzc⟩
  rcases A.coordinateUnique (hxa.symm.trans hxc) with ⟨hac, hbd⟩
  cases hac
  cases hbd
  exact hya.trans hzc.symm

theorem related_left_unique {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x z : A.carrier} {y : B.carrier}
    (hx : Related A B x y) (hz : Related A B z y) : x = z := by
  rcases hx with ⟨a, b, hxa, hya⟩
  rcases hz with ⟨c, d, hzc, hyc⟩
  rcases B.coordinateUnique (hya.symm.trans hyc) with ⟨hac, hbd⟩
  cases hac
  cases hbd
  exact hxa.trans hzc.symm

theorem related_symm {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x : A.carrier} {y : B.carrier}
    (h : Related A B x y) : Related B A y x := by
  rcases h with ⟨a, b, hx, hy⟩
  exact ⟨a, b, hy, hx⟩

theorem related_zero {S : ScalarOps}
    (A B : QuadraticPresentation S) : Related A B A.zero B.zero :=
  ⟨S.zero, S.zero, A.coordinateZero.symm, B.coordinateZero.symm⟩

theorem related_one {S : ScalarOps}
    (A B : QuadraticPresentation S) : Related A B A.one B.one :=
  ⟨S.one, S.zero, A.coordinateOne.symm, B.coordinateOne.symm⟩

theorem related_real {S : ScalarOps}
    (A B : QuadraticPresentation S) (a : S.carrier) :
    Related A B (A.ofScalar a) (B.ofScalar a) :=
  ⟨a, S.zero, (A.coordinateReal a).symm, (B.coordinateReal a).symm⟩

theorem related_imag {S : ScalarOps}
    (A B : QuadraticPresentation S) : Related A B A.imag B.imag :=
  ⟨S.zero, S.one, A.coordinateImag.symm, B.coordinateImag.symm⟩

theorem related_neg {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x : A.carrier} {y : B.carrier}
    (h : Related A B x y) : Related A B (A.neg x) (B.neg y) := by
  rcases h with ⟨a, b, hx, hy⟩
  refine ⟨S.neg a, S.neg b, ?_, ?_⟩
  · rw [hx, A.coordinateNeg a b]
  · rw [hy, B.coordinateNeg a b]

theorem related_add {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w) :
    Related A B (A.add x z) (B.add y w) := by
  rcases hxy with ⟨a, b, hx, hy⟩
  rcases hzw with ⟨c, d, hz, hw⟩
  refine ⟨S.add a c, S.add b d, ?_, ?_⟩
  · rw [hx, hz, A.coordinateAdd a b c d]
  · rw [hy, hw, B.coordinateAdd a b c d]

theorem related_mul {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w) :
    Related A B (A.mul x z) (B.mul y w) := by
  rcases hxy with ⟨a, b, hx, hy⟩
  rcases hzw with ⟨c, d, hz, hw⟩
  refine ⟨S.add (S.mul a c) (S.neg (S.mul b d)),
    S.add (S.mul a d) (S.mul b c), ?_, ?_⟩
  · rw [hx, hz, A.coordinateMul a b c d]
  · rw [hy, hw, B.coordinateMul a b c d]

/-- Preserve a supplied inverse witness. This theorem does not select, construct,
    or globally store an inverse. -/
theorem related_inverse_witness {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w)
    (hxz : A.mul x z = A.one) : B.mul y w = B.one := by
  have h := related_mul A B hxy hzw
  rw [hxz] at h
  exact related_right_unique A B h (related_one A B)

/-- Relation-level comparison package. -/
structure QuadraticComparisonCertificate {S : ScalarOps}
    (A B : QuadraticPresentation S) where
  totalLeft : ∀ x : A.carrier, ∃ y : B.carrier, Related A B x y
  totalRight : ∀ y : B.carrier, ∃ x : A.carrier, Related A B x y
  uniqueRight : ∀ {x : A.carrier} {y z : B.carrier},
    Related A B x y → Related A B x z → y = z
  uniqueLeft : ∀ {x z : A.carrier} {y : B.carrier},
    Related A B x y → Related A B z y → x = z
  preserveZero : Related A B A.zero B.zero
  preserveOne : Related A B A.one B.one
  preserveReal : ∀ a : S.carrier, Related A B (A.ofScalar a) (B.ofScalar a)
  preserveImag : Related A B A.imag B.imag
  preserveNeg : ∀ {x : A.carrier} {y : B.carrier},
    Related A B x y → Related A B (A.neg x) (B.neg y)
  preserveAdd : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      Related A B (A.add x z) (B.add y w)
  preserveMul : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      Related A B (A.mul x z) (B.mul y w)
  preserveInverse : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      A.mul x z = A.one → B.mul y w = B.one

theorem quadraticComparison {S : ScalarOps}
    (A B : QuadraticPresentation S) :
    QuadraticComparisonCertificate A B where
  totalLeft := related_total_left A B
  totalRight := related_total_right A B
  uniqueRight := @related_right_unique S A B
  uniqueLeft := @related_left_unique S A B
  preserveZero := related_zero A B
  preserveOne := related_one A B
  preserveReal := related_real A B
  preserveImag := related_imag A B
  preserveNeg := @related_neg S A B
  preserveAdd := @related_add S A B
  preserveMul := @related_mul S A B
  preserveInverse := @related_inverse_witness S A B

/-- Explicit constructive coordinate data. It is never synthesized from the
    existential totality theorem. -/
structure CoordinateExtractor {S : ScalarOps}
    (A : QuadraticPresentation S) where
  re : A.carrier → S.carrier
  im : A.carrier → S.carrier
  sound : ∀ x : A.carrier, x = A.coord (re x) (im x)

/-- Functional comparison exists only after explicit extractor data is supplied. -/
def coordinateMap {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (E : CoordinateExtractor A) (x : A.carrier) : B.carrier :=
  B.coord (E.re x) (E.im x)

theorem coordinate_map_related {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (E : CoordinateExtractor A) (x : A.carrier) :
    Related A B x (coordinateMap A B E x) :=
  ⟨E.re x, E.im x, E.sound x, rfl⟩

theorem coordinate_map_zero {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A) :
    coordinateMap A B E A.zero = B.zero :=
  related_right_unique A B
    (coordinate_map_related A B E A.zero) (related_zero A B)

theorem coordinate_map_one {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A) :
    coordinateMap A B E A.one = B.one :=
  related_right_unique A B
    (coordinate_map_related A B E A.one) (related_one A B)

theorem coordinate_map_real {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A)
    (a : S.carrier) :
    coordinateMap A B E (A.ofScalar a) = B.ofScalar a :=
  related_right_unique A B
    (coordinate_map_related A B E (A.ofScalar a)) (related_real A B a)

theorem coordinate_map_imag {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A) :
    coordinateMap A B E A.imag = B.imag :=
  related_right_unique A B
    (coordinate_map_related A B E A.imag) (related_imag A B)

theorem coordinate_map_neg {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A)
    (x : A.carrier) :
    coordinateMap A B E (A.neg x) = B.neg (coordinateMap A B E x) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.neg x))
    (related_neg A B (coordinate_map_related A B E x))

theorem coordinate_map_add {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A)
    (x y : A.carrier) :
    coordinateMap A B E (A.add x y) =
      B.add (coordinateMap A B E x) (coordinateMap A B E y) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.add x y))
    (related_add A B
      (coordinate_map_related A B E x)
      (coordinate_map_related A B E y))

theorem coordinate_map_mul {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A)
    (x y : A.carrier) :
    coordinateMap A B E (A.mul x y) =
      B.mul (coordinateMap A B E x) (coordinateMap A B E y) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.mul x y))
    (related_mul A B
      (coordinate_map_related A B E x)
      (coordinate_map_related A B E y))

theorem coordinate_maps_inverse_left {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B)
    (x : A.carrier) :
    coordinateMap B A EB (coordinateMap A B EA x) = x := by
  have hforward := coordinate_map_related A B EA x
  have hbackward :=
    related_symm B A
      (coordinate_map_related B A EB (coordinateMap A B EA x))
  exact related_left_unique A B hbackward hforward

theorem coordinate_maps_inverse_right {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B)
    (y : B.carrier) :
    coordinateMap A B EA (coordinateMap B A EB y) = y :=
  coordinate_maps_inverse_left B A EB EA y

/-- Functional isomorphism package, explicitly conditional on extractor data. -/
structure ConstructiveQuadraticIsomorphism {S : ScalarOps}
    (A B : QuadraticPresentation S) where
  forward : A.carrier → B.carrier
  backward : B.carrier → A.carrier
  leftInverse : ∀ x : A.carrier, backward (forward x) = x
  rightInverse : ∀ y : B.carrier, forward (backward y) = y
  preserveZero : forward A.zero = B.zero
  preserveOne : forward A.one = B.one
  preserveReal : ∀ a : S.carrier, forward (A.ofScalar a) = B.ofScalar a
  preserveImag : forward A.imag = B.imag
  preserveNeg : ∀ x : A.carrier, forward (A.neg x) = B.neg (forward x)
  preserveAdd : ∀ x y : A.carrier,
    forward (A.add x y) = B.add (forward x) (forward y)
  preserveMul : ∀ x y : A.carrier,
    forward (A.mul x y) = B.mul (forward x) (forward y)

def constructiveQuadraticIsomorphism {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B) :
    ConstructiveQuadraticIsomorphism A B where
  forward := coordinateMap A B EA
  backward := coordinateMap B A EB
  leftInverse := coordinate_maps_inverse_left A B EA EB
  rightInverse := coordinate_maps_inverse_right A B EA EB
  preserveZero := coordinate_map_zero A B EA
  preserveOne := coordinate_map_one A B EA
  preserveReal := coordinate_map_real A B EA
  preserveImag := coordinate_map_imag A B EA
  preserveNeg := coordinate_map_neg A B EA
  preserveAdd := coordinate_map_add A B EA
  preserveMul := coordinate_map_mul A B EA

end BOMA.C.StageTwo.ComparisonInterface011

/- Fixed Cauchy scalar certificate for 015. No changed scalar assumption.
Scalar proof provenance is recorded separately. -/
namespace BOMA.C.StageTwo.ScalarInterface015

open BOMA.Q.Quotient001
open BOMA.Q.Integration001
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyOrderedRing003
open BOMA.R.StageTwo.CauchyInverse003

/-- The alternative real zero and one are distinct by faithfulness of the
    constant accepted-rational embedding. -/
theorem rC_nontrivial : rCZero ≠ rCOne := by
  intro h
  have hq : rCOfQ qZero = rCOfQ qOne := h
  exact q_nontrivial (rCOfQ_injective hq)

/-- Right additive zero derived from commutativity and the verified left law. -/
theorem rCAdd_zero_right (x : RCBOMA) : rCAdd x rCZero = x := by
  rw [rCAdd_comm x rCZero, rCAdd_zero_left x]

/-- Negation fixes zero without any equality decision. -/
theorem rCNeg_zero : rCNeg rCZero = rCZero := by
  have h := rCAdd_neg_right rCZero
  rw [rCAdd_zero_left] at h
  exact h

/-- Additive inverse witnesses are unique in the alternative real additive
    group. -/
theorem rC_add_inverse_unique {x y : RCBOMA}
    (hxy : rCAdd x y = rCZero) : y = rCNeg x := by
  calc
    y = rCAdd rCZero y := (rCAdd_zero_left y).symm
    _ = rCAdd (rCAdd x (rCNeg x)) y := by rw [rCAdd_neg_right x]
    _ = rCAdd x (rCAdd (rCNeg x) y) := rCAdd_assoc x (rCNeg x) y
    _ = rCAdd x (rCAdd y (rCNeg x)) := by
      rw [rCAdd_comm (rCNeg x) y]
    _ = rCAdd (rCAdd x y) (rCNeg x) :=
      (rCAdd_assoc x y (rCNeg x)).symm
    _ = rCAdd rCZero (rCNeg x) := by rw [hxy]
    _ = rCNeg x := rCAdd_zero_left (rCNeg x)

/-- Alternative-real negation is involutive. -/
theorem rCNeg_involutive (x : RCBOMA) : rCNeg (rCNeg x) = x := by
  have hleft : rCAdd (rCNeg x) x = rCZero := by
    calc
      rCAdd (rCNeg x) x = rCAdd x (rCNeg x) := rCAdd_comm (rCNeg x) x
      _ = rCZero := rCAdd_neg_right x
  exact (rC_add_inverse_unique hleft).symm

/-- Right multiplicative zero derived from commutativity. -/
theorem rCMul_zero_right (x : RCBOMA) : rCMul x rCZero = rCZero := by
  rw [rCMul_comm x rCZero, rCMul_zero_left x]

/-- Right multiplicative one derived from commutativity. -/
theorem rCMul_one_right_local (x : RCBOMA) : rCMul x rCOne = x := by
  rw [rCMul_comm x rCOne, rCMul_one_left x]

/-- Multiplication by an additive inverse on the right negates the product. -/
theorem rCMul_neg_right (x y : RCBOMA) :
    rCMul x (rCNeg y) = rCNeg (rCMul x y) := by
  have hd := rCMul_add_right x y (rCNeg y)
  have hsum :
      rCAdd (rCMul x y) (rCMul x (rCNeg y)) = rCZero := by
    calc
      rCAdd (rCMul x y) (rCMul x (rCNeg y)) =
          rCMul x (rCAdd y (rCNeg y)) := hd.symm
      _ = rCMul x rCZero := by rw [rCAdd_neg_right y]
      _ = rCZero := rCMul_zero_right x
  exact rC_add_inverse_unique hsum

/-- Multiplication by an additive inverse on the left negates the product. -/
theorem rCMul_neg_left (x y : RCBOMA) :
    rCMul (rCNeg x) y = rCNeg (rCMul x y) := by
  calc
    rCMul (rCNeg x) y = rCMul y (rCNeg x) := rCMul_comm (rCNeg x) y
    _ = rCNeg (rCMul y x) := rCMul_neg_right y x
    _ = rCNeg (rCMul x y) := by rw [rCMul_comm y x]

/-- Squaring a negated alternative real gives the same square. -/
theorem rCMul_neg_neg_same (x : RCBOMA) :
    rCMul (rCNeg x) (rCNeg x) = rCMul x x := by
  calc
    rCMul (rCNeg x) (rCNeg x) = rCNeg (rCMul x (rCNeg x)) :=
      rCMul_neg_left x (rCNeg x)
    _ = rCNeg (rCNeg (rCMul x x)) := by rw [rCMul_neg_right x x]
    _ = rCMul x x := rCNeg_involutive _

structure CauchyScalarCertificate where
  orderTrans :
    ∀ {x y z : RCBOMA}, rCLE x y → rCLE y z → rCLE x z
  orderAntisymm :
    ∀ {x y : RCBOMA}, rCLE x y → rCLE y x → x = y
  orderTotal :
    ∀ x y : RCBOMA, rCLE x y ∨ rCLE y x
  nontrivial :
    rCZero ≠ rCOne
  addComm :
    ∀ x y : RCBOMA, rCAdd x y = rCAdd y x
  addAssoc :
    ∀ x y z : RCBOMA, rCAdd (rCAdd x y) z = rCAdd x (rCAdd y z)
  addZeroLeft :
    ∀ x : RCBOMA, rCAdd rCZero x = x
  addInverseRight :
    ∀ x : RCBOMA, rCAdd x (rCNeg x) = rCZero
  addTranslateOrderIff :
    ∀ x y c : RCBOMA, rCLE (rCAdd x c) (rCAdd y c) ↔ rCLE x y
  negOrderReversing :
    ∀ {x y : RCBOMA}, rCLE x y → rCLE (rCNeg y) (rCNeg x)
  mulComm :
    ∀ x y : RCBOMA, rCMul x y = rCMul y x
  mulAssoc :
    ∀ x y z : RCBOMA,
      rCMul (rCMul x y) z =
      rCMul x (rCMul y z)
  mulOneLeft :
    ∀ x : RCBOMA, rCMul rCOne x = x
  distribRight :
    ∀ x y z : RCBOMA,
      rCMul x (rCAdd y z) =
      rCAdd (rCMul x y) (rCMul x z)
  orderMulNonneg :
    ∀ {a b c : RCBOMA},
      rCLE a b → rCLE rCZero c →
      rCLE (rCMul a c) (rCMul b c)
  inverseExists :
    ∀ x : RCBOMA, x ≠ rCZero →
      ∃ y : RCBOMA, rCMul x y = rCOne


theorem translate_iff (x y c : RCBOMA) :
    rCLE (rCAdd x c) (rCAdd y c) ↔ rCLE x y := by
  constructor
  · intro h
    have ht := rcle_add_right h (rCNeg c)
    rw [rCAdd_assoc, rCAdd_assoc, rCAdd_neg_right, rCAdd_zero_right,
      rCAdd_zero_right] at ht
    exact ht
  · intro h
    exact rcle_add_right h c

theorem neg_reversing {x y : RCBOMA} (h : rCLE x y) :
    rCLE (rCNeg y) (rCNeg x) := by
  apply (translate_iff (rCNeg y) (rCNeg x) y).1
  rw [rCAdd_comm (rCNeg y) y, rCAdd_neg_right,
    rCAdd_comm (rCNeg x) y]
  have ht := rcle_add_right h (rCNeg x)
  rw [rCAdd_neg_right] at ht
  exact ht

theorem mul_monotone {a b c : RCBOMA}
    (hab : rCLE a b) (hc : rCLE rCZero c) :
    rCLE (rCMul a c) (rCMul b c) := by
  have hdiff := rcle_add_right hab (rCNeg a)
  rw [rCAdd_neg_right] at hdiff
  have hp := rcle_mul_nonneg hc hdiff
  rw [rCMul_add_right, rCMul_neg_right,
    rCMul_comm c b, rCMul_comm c a] at hp
  apply (translate_iff (rCMul a c) (rCMul b c) (rCNeg (rCMul a c))).1
  rw [rCAdd_neg_right]
  exact hp

theorem cauchyScalarCertificate : CauchyScalarCertificate where
  orderTrans := @rcle_trans
  orderAntisymm := @rcle_antisymm
  orderTotal := rcle_total
  nontrivial := rC_nontrivial
  addComm := rCAdd_comm
  addAssoc := rCAdd_assoc
  addZeroLeft := rCAdd_zero_left
  addInverseRight := rCAdd_neg_right
  addTranslateOrderIff := translate_iff
  negOrderReversing := @neg_reversing
  mulComm := rCMul_comm
  mulAssoc := rCMul_assoc
  mulOneLeft := rCMul_one_left
  distribRight := rCMul_add_right
  orderMulNonneg := @mul_monotone
  inverseExists := rC_inverse_exists

end BOMA.C.StageTwo.ScalarInterface015

/- Adapted proof pattern; see ST2-EXP-015_IMPLEMENTATION_PROVENANCE_001.md. -/
/- C-stage fixed-Cauchy-R interface sufficiency probe.

Purpose:
  derive the order facts needed by likely C constructions from an abstract
  CauchyScalarCertificate first, then instantiate the result with the
  fixed Cauchy R certificate. The abstract proof does not unfold LowerCut,
  CutEquiv, quotient representatives, or the selected earlier scalar
  multiplication/inverse implementations.

This file does not construct a complex carrier and does not select C-DP-001.
-/
namespace BOMA.C.StageTwo.ScalarConsequences015

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.C.StageTwo.ScalarInterface015


/-- Zero is fixed by negation, derived only from the fixed scalar additive interface. -/
theorem neg_zero_from_interface
    (C : CauchyScalarCertificate) :
    rCNeg rCZero = rCZero := by
  calc
    rCNeg rCZero = rCAdd rCZero (rCNeg rCZero) :=
      (C.addZeroLeft (rCNeg rCZero)).symm
    _ = rCZero := C.addInverseRight rCZero

/-- Additive inverse witnesses are unique, derived from the fixed scalar additive laws. -/
theorem add_inverse_unique_from_interface
    (C : CauchyScalarCertificate)
    {x y : RCBOMA}
    (hxy : rCAdd x y = rCZero) :
    y = rCNeg x := by
  calc
    y = rCAdd rCZero y := (C.addZeroLeft y).symm
    _ = rCAdd (rCAdd x (rCNeg x)) y := by
      rw [C.addInverseRight x]
    _ = rCAdd x (rCAdd (rCNeg x) y) :=
      C.addAssoc x (rCNeg x) y
    _ = rCAdd x (rCAdd y (rCNeg x)) := by
      rw [C.addComm (rCNeg x) y]
    _ = rCAdd (rCAdd x y) (rCNeg x) :=
      (C.addAssoc x y (rCNeg x)).symm
    _ = rCAdd rCZero (rCNeg x) := by rw [hxy]
    _ = rCNeg x := C.addZeroLeft (rCNeg x)

/-- Negation is involutive, derived from fixed scalar additive commutativity and inverse uniqueness. -/
theorem neg_involutive_from_interface
    (C : CauchyScalarCertificate)
    (x : RCBOMA) :
    rCNeg (rCNeg x) = x := by
  have hleft : rCAdd (rCNeg x) x = rCZero := by
    calc
      rCAdd (rCNeg x) x = rCAdd x (rCNeg x) := C.addComm (rCNeg x) x
      _ = rCZero := C.addInverseRight x
  exact (add_inverse_unique_from_interface C hleft).symm

/-- Right zero-annihilation follows from distributivity and the fixed scalar additive group laws. -/
theorem mul_zero_right_from_interface
    (C : CauchyScalarCertificate)
    (x : RCBOMA) :
    rCMul x rCZero = rCZero := by
  let p : RCBOMA := rCMul x rCZero
  have hdist := C.distribRight x rCZero rCZero
  have h00 : rCAdd rCZero rCZero = rCZero := C.addZeroLeft rCZero
  have hp : p = rCAdd p p := by
    unfold p
    rw [h00] at hdist
    exact hdist
  have hnegleft : rCAdd (rCNeg p) p = rCZero := by
    calc
      rCAdd (rCNeg p) p = rCAdd p (rCNeg p) := C.addComm (rCNeg p) p
      _ = rCZero := C.addInverseRight p
  have hcancel := congrArg (fun t => rCAdd (rCNeg p) t) hp
  have hz_eq_p : rCZero = p := by
    calc
      rCZero = rCAdd (rCNeg p) p := hnegleft.symm
      _ = rCAdd (rCNeg p) (rCAdd p p) := hcancel
      _ = rCAdd (rCAdd (rCNeg p) p) p :=
        (C.addAssoc (rCNeg p) p p).symm
      _ = rCAdd rCZero p := by rw [hnegleft]
      _ = p := C.addZeroLeft p
  exact hz_eq_p.symm

/-- Left zero-annihilation follows from fixed scalar multiplication commutativity. -/
theorem mul_zero_left_from_interface
    (C : CauchyScalarCertificate)
    (x : RCBOMA) :
    rCMul rCZero x = rCZero := by
  calc
    rCMul rCZero x = rCMul x rCZero := C.mulComm rCZero x
    _ = rCZero := mul_zero_right_from_interface C x

/-- Multiplication by an additive inverse on the right negates the product. -/
theorem mul_neg_right_from_interface
    (C : CauchyScalarCertificate)
    (x y : RCBOMA) :
    rCMul x (rCNeg y) = rCNeg (rCMul x y) := by
  have hd := C.distribRight x y (rCNeg y)
  have hy0 : rCAdd y (rCNeg y) = rCZero := C.addInverseRight y
  have hsum :
      rCAdd (rCMul x y) (rCMul x (rCNeg y)) = rCZero := by
    calc
      rCAdd (rCMul x y) (rCMul x (rCNeg y)) =
          rCMul x (rCAdd y (rCNeg y)) := hd.symm
      _ = rCMul x rCZero := by rw [hy0]
      _ = rCZero := mul_zero_right_from_interface C x
  exact add_inverse_unique_from_interface C hsum

/-- Multiplication by an additive inverse on the left negates the product. -/
theorem mul_neg_left_from_interface
    (C : CauchyScalarCertificate)
    (x y : RCBOMA) :
    rCMul (rCNeg x) y = rCNeg (rCMul x y) := by
  calc
    rCMul (rCNeg x) y = rCMul y (rCNeg x) :=
      C.mulComm (rCNeg x) y
    _ = rCNeg (rCMul y x) := mul_neg_right_from_interface C y x
    _ = rCNeg (rCMul x y) := by rw [C.mulComm y x]

/-- Squaring a negated value gives the same square, using only fixed scalar field laws. -/
theorem mul_neg_neg_same_from_interface
    (C : CauchyScalarCertificate)
    (x : RCBOMA) :
    rCMul (rCNeg x) (rCNeg x) = rCMul x x := by
  calc
    rCMul (rCNeg x) (rCNeg x) =
        rCNeg (rCMul x (rCNeg x)) :=
      mul_neg_left_from_interface C x (rCNeg x)
    _ = rCNeg (rCNeg (rCMul x x)) := by
      rw [mul_neg_right_from_interface C x x]
    _ = rCMul x x := neg_involutive_from_interface C _

/-- C-RL-001 at the abstract fixed-Cauchy-R interface level: every square is nonnegative.

The proof branches only on total order supplied by the certificate. The
negative branch replaces x by -x and uses identities proved above from the
same abstract interface. -/
theorem square_nonnegative_of_interface
    (C : CauchyScalarCertificate)
    (x : RCBOMA) :
    rCLE rCZero (rCMul x x) := by
  rcases C.orderTotal rCZero x with h0x | hx0
  · have h := C.orderMulNonneg (a := rCZero) (b := x) (c := x) h0x h0x
    rw [mul_zero_left_from_interface C x] at h
    exact h
  · have h0nx0 := C.negOrderReversing hx0
    have h0nx : rCLE rCZero (rCNeg x) := by
      rw [neg_zero_from_interface C] at h0nx0
      exact h0nx0
    have h := C.orderMulNonneg
      (a := rCZero) (b := rCNeg x) (c := rCNeg x) h0nx h0nx
    rw [mul_zero_left_from_interface C (rCNeg x),
        mul_neg_neg_same_from_interface C x] at h
    exact h

/-- One is nonnegative as the square of one, at the abstract interface level. -/
theorem zero_le_one_of_interface
    (C : CauchyScalarCertificate) :
    rCLE rCZero rCOne := by
  have h := square_nonnegative_of_interface C rCOne
  rw [C.mulOneLeft rCOne] at h
  exact h

/-- C-RL-002 at the abstract fixed-Cauchy-R interface level: -1 is not a square. -/
theorem minus_one_not_square_of_interface
    (C : CauchyScalarCertificate) :
    ¬ ∃ x : RCBOMA, rCMul x x = rCNeg rCOne := by
  rintro ⟨x, hx⟩
  have hsq : rCLE rCZero (rCNeg rCOne) := by
    have h := square_nonnegative_of_interface C x
    rw [hx] at h
    exact h
  have h10raw := C.negOrderReversing hsq
  have h10 : rCLE rCOne rCZero := by
    rw [neg_involutive_from_interface C rCOne,
        neg_zero_from_interface C] at h10raw
    exact h10raw
  have h01 : rCLE rCZero rCOne := zero_le_one_of_interface C
  have hEq : rCZero = rCOne := C.orderAntisymm h01 h10
  exact C.nontrivial hEq

/-- C-RL-001 instantiated on the fixed Cauchy R integration certificate. -/
theorem square_nonnegative_from_accepted_R (x : RCBOMA) :
    rCLE rCZero (rCMul x x) :=
  square_nonnegative_of_interface cauchyScalarCertificate x

/-- C-RL-002 instantiated on the fixed Cauchy R integration certificate.

This is the route-neutral C boundary fact needed to prevent a future
imaginary generator from collapsing into the embedded real line. -/
theorem minus_one_not_square_from_accepted_R :
    ¬ ∃ x : RCBOMA, rCMul x x = rCNeg rCOne :=
  minus_one_not_square_of_interface cauchyScalarCertificate

end BOMA.C.StageTwo.ScalarConsequences015

/- Adapted proof pattern; see ST2-EXP-015_IMPLEMENTATION_PROVENANCE_001.md. -/
/- ST2-EXP-015 Route Q: noncanonical quadratic-expression quotient probe.

This is a formal-expression / normalization / quotient-style adjunction
candidate. It is not a claim that a full polynomial ring R[X] has already
been constructed. All coefficient-normal-form declarations are local to this
namespace; the source does not import the Route P probe.
-/
namespace BOMA.C.StageTwo.QExpression015

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.C.StageTwo.ScalarInterface015

open BOMA.C.StageTwo.ScalarConsequences015

/-- Route-Q-local quadratic normal form; independent of Route P declarations. -/
structure NormalForm where
  re : RCBOMA
  im : RCBOMA

/-- Core Lean does not supply a generated structure-extensionality lemma. -/
theorem normal_ext {u v : NormalForm}
    (hre : u.re = v.re) (him : u.im = v.im) :
    u = v := by
  cases u
  cases v
  cases hre
  cases him
  rfl

def nfReal (a : RCBOMA) : NormalForm := ⟨a, rCZero⟩
def nfImag : NormalForm := ⟨rCZero, rCOne⟩

def nfNeg (u : NormalForm) : NormalForm :=
  ⟨rCNeg u.re, rCNeg u.im⟩

def nfAdd (u v : NormalForm) : NormalForm :=
  ⟨rCAdd u.re v.re, rCAdd u.im v.im⟩

def nfMul (u v : NormalForm) : NormalForm :=
  ⟨rCAdd (rCMul u.re v.re)
      (rCNeg (rCMul u.im v.im)),
   rCAdd (rCMul u.re v.im)
      (rCMul u.im v.re)⟩

/-- Freely written finite quadratic-adjunction expressions. -/
inductive Expr where
  | coeff : RCBOMA → Expr
  | generator : Expr
  | neg : Expr → Expr
  | add : Expr → Expr → Expr
  | mul : Expr → Expr → Expr

/-- Evaluation modulo the declared generator relation X² = -1. -/
def normalize : Expr → NormalForm
  | .coeff a => nfReal a
  | .generator => nfImag
  | .neg e => nfNeg (normalize e)
  | .add e f => nfAdd (normalize e) (normalize f)
  | .mul e f => nfMul (normalize e) (normalize f)

def exprEquiv (e f : Expr) : Prop := normalize e = normalize f

def exprSetoid : Setoid Expr where
  r := exprEquiv
  iseqv :=
    ⟨(fun _ => rfl),
      (fun h => h.symm),
      (fun h₁ h₂ => h₁.trans h₂)⟩

/-- Route-Q carrier: syntax modulo equal quadratic normal forms. -/
def QuotientCandidate : Type := Quotient exprSetoid

def qmk (e : Expr) : QuotientCandidate :=
  Quotient.mk exprSetoid e

theorem qmk_eq_iff {e f : Expr} :
    qmk e = qmk f ↔ normalize e = normalize f := by
  constructor
  · intro h
    exact Quotient.exact h
  · intro h
    exact Quotient.sound h

theorem neg_respects {e e' : Expr}
    (h : exprEquiv e e') :
    exprEquiv (.neg e) (.neg e') := by
  change nfNeg (normalize e) = nfNeg (normalize e')
  rw [h]

theorem add_respects {e e' f f' : Expr}
    (he : exprEquiv e e')
    (hf : exprEquiv f f') :
    exprEquiv (.add e f) (.add e' f') := by
  change nfAdd (normalize e) (normalize f) =
    nfAdd (normalize e') (normalize f')
  rw [he, hf]

theorem mul_respects {e e' f f' : Expr}
    (he : exprEquiv e e')
    (hf : exprEquiv f f') :
    exprEquiv (.mul e f) (.mul e' f') := by
  change nfMul (normalize e) (normalize f) =
    nfMul (normalize e') (normalize f')
  rw [he, hf]

def neg : QuotientCandidate → QuotientCandidate :=
  Quotient.lift
    (fun e => qmk (.neg e))
    (fun _ _ h => Quotient.sound (neg_respects h))

def add : QuotientCandidate → QuotientCandidate → QuotientCandidate :=
  Quotient.lift₂
    (fun e f => qmk (.add e f))
    (fun _ _ _ _ he hf => Quotient.sound (add_respects he hf))

def mul : QuotientCandidate → QuotientCandidate → QuotientCandidate :=
  Quotient.lift₂
    (fun e f => qmk (.mul e f))
    (fun _ _ _ _ he hf => Quotient.sound (mul_respects he hf))

def ofR (a : RCBOMA) : QuotientCandidate := qmk (.coeff a)
def zero : QuotientCandidate := ofR rCZero
def one : QuotientCandidate := ofR rCOne
def imag : QuotientCandidate := qmk .generator

theorem add_zero_right_from_interface
    (C : CauchyScalarCertificate) (x : RCBOMA) :
    rCAdd x rCZero = x := by
  calc
    rCAdd x rCZero = rCAdd rCZero x := C.addComm x rCZero
    _ = x := C.addZeroLeft x

theorem mul_one_right_from_interface
    (C : CauchyScalarCertificate) (x : RCBOMA) :
    rCMul x rCOne = x := by
  calc
    rCMul x rCOne = rCMul rCOne x := C.mulComm x rCOne
    _ = x := C.mulOneLeft x

/-- P/Q-03: quotient identity preserves faithful real coefficients. -/
theorem ofR_injective {a b : RCBOMA}
    (h : ofR a = ofR b) : a = b := by
  have hn : normalize (.coeff a) = normalize (.coeff b) :=
    (qmk_eq_iff.mp h)
  exact congrArg NormalForm.re hn

/-- Route-local normal form of a formal real-plus-imaginary expression. -/
theorem normalized_coordinate_expression
    (C : CauchyScalarCertificate) (a b : RCBOMA) :
    normalize (.add (.coeff a) (.mul (.coeff b) .generator)) =
      ⟨a, b⟩ := by
  apply normal_ext
  · change
      rCAdd a
        (rCAdd (rCMul b rCZero)
          (rCNeg (rCMul rCZero rCOne))) = a
    rw [mul_zero_right_from_interface C b,
        mul_zero_left_from_interface C rCOne,
        neg_zero_from_interface C,
        C.addZeroLeft rCZero,
        add_zero_right_from_interface C a]
  · change
      rCAdd rCZero
        (rCAdd (rCMul b rCOne)
          (rCMul rCZero rCZero)) = b
    rw [mul_one_right_from_interface C b,
        mul_zero_left_from_interface C rCZero,
        add_zero_right_from_interface C b,
        C.addZeroLeft b]

/-- P/Q-06: quotient identity enforces the declared quadratic relation. -/
theorem imag_squared
    (C : CauchyScalarCertificate) :
    mul imag imag = neg one := by
  apply Quotient.sound
  change nfMul nfImag nfImag = nfNeg (nfReal rCOne)
  apply normal_ext
  · change
      rCAdd (rCMul rCZero rCZero)
        (rCNeg (rCMul rCOne rCOne)) = rCNeg rCOne
    rw [mul_zero_left_from_interface C rCZero,
        C.mulOneLeft rCOne,
        C.addZeroLeft (rCNeg rCOne)]
  · change
      rCAdd (rCMul rCZero rCOne)
        (rCMul rCOne rCZero) = rCNeg rCZero
    rw [mul_zero_left_from_interface C rCOne,
        C.mulOneLeft rCZero,
        C.addZeroLeft rCZero,
        neg_zero_from_interface C]

/-- Every raw expression is equivalent to its declared quadratic normal form. -/
theorem representative_decomposition
    (C : CauchyScalarCertificate) (e : Expr) :
    qmk e =
      add (ofR (normalize e).re)
        (mul (ofR (normalize e).im) imag) := by
  apply Quotient.sound
  change
    normalize e =
      normalize
        (.add (.coeff (normalize e).re)
          (.mul (.coeff (normalize e).im) .generator))
  rw [normalized_coordinate_expression C
      (normalize e).re (normalize e).im]

/-- P/Q-07: every quotient value has a real/imaginary decomposition. -/
theorem decomposition
    (C : CauchyScalarCertificate) (z : QuotientCandidate) :
    ∃ a b : RCBOMA, z = add (ofR a) (mul (ofR b) imag) := by
  refine Quotient.inductionOn z ?_
  intro e
  exact ⟨(normalize e).re, (normalize e).im,
    representative_decomposition C e⟩

/-- P/Q-08: quotient equality retains unique real/imaginary coordinates. -/
theorem decomposition_unique
    (C : CauchyScalarCertificate)
    {a b a' b' : RCBOMA}
    (h : add (ofR a) (mul (ofR b) imag) =
      add (ofR a') (mul (ofR b') imag)) :
    a = a' ∧ b = b' := by
  have hn :
      normalize (.add (.coeff a) (.mul (.coeff b) .generator)) =
      normalize (.add (.coeff a') (.mul (.coeff b') .generator)) :=
    Quotient.exact h
  rw [normalized_coordinate_expression C a b,
      normalized_coordinate_expression C a' b'] at hn
  exact ⟨congrArg NormalForm.re hn,
         congrArg NormalForm.im hn⟩

/-- P/Q-09: the quotient generator cannot equal an embedded real. -/
theorem imag_not_real
    (C : CauchyScalarCertificate) :
    ¬ ∃ a : RCBOMA, imag = ofR a := by
  rintro ⟨a, ha⟩
  have hn : normalize .generator = normalize (.coeff a) :=
    Quotient.exact ha
  have h : rCOne = rCZero := congrArg NormalForm.im hn
  exact C.nontrivial h.symm

end BOMA.C.StageTwo.QExpression015

/- Adapted proof pattern; see ST2-EXP-015_IMPLEMENTATION_PROVENANCE_001.md. -/
/- ST2-EXP-015: independent Route-Q-local quadratic normal-form operations.
This source reuses only Route Q's own NormalForm and fixed Cauchy real interface. -/
namespace BOMA.C.StageTwo.QNormalRoute015

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.C.StageTwo.ScalarInterface015

open BOMA.C.StageTwo.ScalarConsequences015

/-- Q-local normalization carrier: never the selected Route P carrier. -/
abbrev NormalForm : Type := BOMA.C.StageTwo.QExpression015.NormalForm

theorem normal_ext {u v : NormalForm}
    (hre : u.re = v.re) (him : u.im = v.im) :
    u = v :=
  BOMA.C.StageTwo.QExpression015.normal_ext hre him

def zero : NormalForm := BOMA.C.StageTwo.QExpression015.nfReal rCZero
def one : NormalForm := BOMA.C.StageTwo.QExpression015.nfReal rCOne
def ofR (a : RCBOMA) : NormalForm := BOMA.C.StageTwo.QExpression015.nfReal a
def imag : NormalForm := BOMA.C.StageTwo.QExpression015.nfImag
def neg (u : NormalForm) : NormalForm := BOMA.C.StageTwo.QExpression015.nfNeg u
def add (u v : NormalForm) : NormalForm := BOMA.C.StageTwo.QExpression015.nfAdd u v
def mul (u v : NormalForm) : NormalForm := BOMA.C.StageTwo.QExpression015.nfMul u v

theorem add_zero_right_from_interface
    (C : CauchyScalarCertificate) (x : RCBOMA) :
    rCAdd x rCZero = x := by
  calc
    rCAdd x rCZero = rCAdd rCZero x := C.addComm x rCZero
    _ = x := C.addZeroLeft x

theorem mul_one_right_from_interface
    (C : CauchyScalarCertificate) (x : RCBOMA) :
    rCMul x rCOne = x := by
  calc
    rCMul x rCOne = rCMul rCOne x := C.mulComm x rCOne
    _ = x := C.mulOneLeft x

/-- P/Q-03: route-local real embedding is faithful. -/
theorem ofR_injective {a b : RCBOMA}
    (h : ofR a = ofR b) : a = b :=
  congrArg BOMA.C.StageTwo.QExpression015.NormalForm.re h

/-- Multiplication by the route-local generator extracts an imaginary coefficient. -/
theorem embed_mul_imag
    (C : CauchyScalarCertificate) (b : RCBOMA) :
    mul (ofR b) imag = ⟨rCZero, b⟩ := by
  apply normal_ext
  · change
      rCAdd (rCMul b rCZero)
        (rCNeg (rCMul rCZero rCOne)) = rCZero
    rw [mul_zero_right_from_interface C b,
        mul_zero_left_from_interface C rCOne,
        neg_zero_from_interface C,
        C.addZeroLeft rCZero]
  · change
      rCAdd (rCMul b rCOne)
        (rCMul rCZero rCZero) = b
    rw [mul_one_right_from_interface C b,
        mul_zero_left_from_interface C rCZero,
        add_zero_right_from_interface C b]

/-- Normal form of a real-plus-imaginary route-local expression. -/
theorem coordinate_expression
    (C : CauchyScalarCertificate) (a b : RCBOMA) :
    add (ofR a) (mul (ofR b) imag) = ⟨a, b⟩ := by
  rw [embed_mul_imag C b]
  apply normal_ext
  · exact add_zero_right_from_interface C a
  · exact C.addZeroLeft b

/-- P/Q-06: the distinguished generator squares to negative one. -/
theorem imag_squared
    (C : CauchyScalarCertificate) :
    mul imag imag = neg one := by
  apply normal_ext
  · change
      rCAdd (rCMul rCZero rCZero)
        (rCNeg (rCMul rCOne rCOne)) = rCNeg rCOne
    rw [mul_zero_left_from_interface C rCZero,
        C.mulOneLeft rCOne,
        C.addZeroLeft (rCNeg rCOne)]
  · change
      rCAdd (rCMul rCZero rCOne)
        (rCMul rCOne rCZero) = rCNeg rCZero
    rw [mul_zero_left_from_interface C rCOne,
        C.mulOneLeft rCZero,
        C.addZeroLeft rCZero,
        neg_zero_from_interface C]

/-- P/Q-07: every route-local candidate has a real/imaginary decomposition. -/
theorem decomposition
    (C : CauchyScalarCertificate) (z : NormalForm) :
    ∃ a b : RCBOMA, z = add (ofR a) (mul (ofR b) imag) := by
  refine ⟨z.re, z.im, ?_⟩
  rw [coordinate_expression C z.re z.im]

/-- P/Q-08: real/imaginary coordinates are unique at Route Q normal-form equality. -/
theorem decomposition_unique
    (C : CauchyScalarCertificate)
    {a b a' b' : RCBOMA}
    (h : add (ofR a) (mul (ofR b) imag) =
      add (ofR a') (mul (ofR b') imag)) :
    a = a' ∧ b = b' := by
  rw [coordinate_expression C a b,
      coordinate_expression C a' b'] at h
  exact ⟨congrArg BOMA.C.StageTwo.QExpression015.NormalForm.re h,
         congrArg BOMA.C.StageTwo.QExpression015.NormalForm.im h⟩

/-- P/Q-09: the imaginary generator is not in the embedded real line. -/
theorem imag_not_real
    (C : CauchyScalarCertificate) :
    ¬ ∃ a : RCBOMA, imag = ofR a := by
  rintro ⟨a, ha⟩
  have h : rCOne = rCZero := congrArg BOMA.C.StageTwo.QExpression015.NormalForm.im ha
  exact C.nontrivial h.symm

end BOMA.C.StageTwo.QNormalRoute015

/- Adapted proof pattern; see ST2-EXP-015_IMPLEMENTATION_PROVENANCE_001.md. -/
/- ST2-EXP-015: independent commutative ring on Route Q's own NormalForm.
No selected pair-route declaration or field producer is referenced. -/
namespace BOMA.C.StageTwo.QNormalCore015

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.C.StageTwo.ScalarInterface015

open BOMA.C.StageTwo.ScalarConsequences015

/-- The Q-local carrier is Route Q's own canonical normalization record. -/
abbrev QNormal : Type := BOMA.C.StageTwo.QNormalRoute015.NormalForm

/-- The Q-normal identity is record equality, equivalent to coordinate equality. -/
theorem n_ext {z w : QNormal}
    (hre : z.re = w.re) (him : z.im = w.im) : z = w :=
  BOMA.C.StageTwo.QNormalRoute015.normal_ext hre him

def nZero : QNormal := BOMA.C.StageTwo.QNormalRoute015.zero
def nOne : QNormal := BOMA.C.StageTwo.QNormalRoute015.one
def nOfR (a : RCBOMA) : QNormal := BOMA.C.StageTwo.QNormalRoute015.ofR a
def nI : QNormal := BOMA.C.StageTwo.QNormalRoute015.imag
def nNeg (z : QNormal) : QNormal := BOMA.C.StageTwo.QNormalRoute015.neg z
def nAdd (z w : QNormal) : QNormal := BOMA.C.StageTwo.QNormalRoute015.add z w
def nMul (z w : QNormal) : QNormal := BOMA.C.StageTwo.QNormalRoute015.mul z w

/-- Scalar additive reassociation needed by the explicit equational normalizer. -/
theorem r_add_left_comm_from_interface
    (C : CauchyScalarCertificate) (a b c : RCBOMA) :
    rCAdd a (rCAdd b c) = rCAdd b (rCAdd a c) := by
  calc
    rCAdd a (rCAdd b c) = rCAdd (rCAdd a b) c := (C.addAssoc a b c).symm
    _ = rCAdd (rCAdd b a) c := by rw [C.addComm a b]
    _ = rCAdd b (rCAdd a c) := C.addAssoc b a c

/-- Scalar multiplicative reassociation needed by the explicit normalizer. -/
theorem r_mul_left_comm_from_interface
    (C : CauchyScalarCertificate) (a b c : RCBOMA) :
    rCMul a (rCMul b c) =
      rCMul b (rCMul a c) := by
  calc
    rCMul a (rCMul b c) =
        rCMul (rCMul a b) c := (C.mulAssoc a b c).symm
    _ = rCMul (rCMul b a) c := by rw [C.mulComm a b]
    _ = rCMul b (rCMul a c) := C.mulAssoc b a c

/-- Distribution in the first scalar argument is derived, not assumed. -/
theorem r_mul_add_left_from_interface
    (C : CauchyScalarCertificate) (a b c : RCBOMA) :
    rCMul (rCAdd a b) c =
      rCAdd (rCMul a c) (rCMul b c) := by
  calc
    rCMul (rCAdd a b) c = rCMul c (rCAdd a b) :=
      C.mulComm (rCAdd a b) c
    _ = rCAdd (rCMul c a) (rCMul c b) :=
      C.distribRight c a b
    _ = rCAdd (rCMul a c) (rCMul b c) := by
      rw [C.mulComm c a, C.mulComm c b]

/-- Additive inverse distributes over scalar addition using inverse uniqueness. -/
theorem r_neg_add_from_interface
    (C : CauchyScalarCertificate) (a b : RCBOMA) :
    rCNeg (rCAdd a b) = rCAdd (rCNeg a) (rCNeg b) := by
  have h : rCAdd (rCAdd a b) (rCAdd (rCNeg a) (rCNeg b)) = rCZero := by
    calc
      rCAdd (rCAdd a b) (rCAdd (rCNeg a) (rCNeg b)) =
          rCAdd a (rCAdd b (rCAdd (rCNeg a) (rCNeg b))) :=
        C.addAssoc a b (rCAdd (rCNeg a) (rCNeg b))
      _ = rCAdd a (rCAdd (rCNeg a) (rCAdd b (rCNeg b))) := by
        rw [r_add_left_comm_from_interface C b (rCNeg a) (rCNeg b)]
      _ = rCAdd (rCAdd a (rCNeg a)) (rCAdd b (rCNeg b)) :=
        (C.addAssoc a (rCNeg a) (rCAdd b (rCNeg b))).symm
      _ = rCZero := by
        rw [C.addInverseRight a, C.addInverseRight b, C.addZeroLeft rCZero]
  exact (add_inverse_unique_from_interface C h).symm

/-- The canonical complex zero and unit remain distinct. -/
theorem n_zero_ne_one (C : CauchyScalarCertificate) :
    nZero ≠ nOne := by
  intro h
  exact C.nontrivial (congrArg BOMA.C.StageTwo.QExpression015.NormalForm.re h)

/-- The Q-normal real embedding is faithful. -/
theorem n_ofR_injective {a b : RCBOMA} (h : nOfR a = nOfR b) : a = b :=
  BOMA.C.StageTwo.QNormalRoute015.ofR_injective h

theorem n_add_comm (C : CauchyScalarCertificate) (z w : QNormal) :
    nAdd z w = nAdd w z := by
  apply n_ext
  · exact C.addComm z.re w.re
  · exact C.addComm z.im w.im

theorem n_add_assoc
    (C : CauchyScalarCertificate) (z w v : QNormal) :
    nAdd (nAdd z w) v = nAdd z (nAdd w v) := by
  apply n_ext
  · exact C.addAssoc z.re w.re v.re
  · exact C.addAssoc z.im w.im v.im

theorem n_add_zero_left (C : CauchyScalarCertificate) (z : QNormal) :
    nAdd nZero z = z := by
  apply n_ext
  · exact C.addZeroLeft z.re
  · exact C.addZeroLeft z.im

theorem n_add_zero_right (C : CauchyScalarCertificate) (z : QNormal) :
    nAdd z nZero = z := by
  rw [n_add_comm C z nZero, n_add_zero_left C z]

theorem n_add_neg_right (C : CauchyScalarCertificate) (z : QNormal) :
    nAdd z (nNeg z) = nZero := by
  apply n_ext
  · exact C.addInverseRight z.re
  · exact C.addInverseRight z.im

theorem n_add_neg_left (C : CauchyScalarCertificate) (z : QNormal) :
    nAdd (nNeg z) z = nZero := by
  rw [n_add_comm C (nNeg z) z, n_add_neg_right C z]

theorem n_neg_involutive (C : CauchyScalarCertificate) (z : QNormal) :
    nNeg (nNeg z) = z := by
  apply n_ext
  · exact neg_involutive_from_interface C z.re
  · exact neg_involutive_from_interface C z.im

theorem n_mul_comm (C : CauchyScalarCertificate) (z w : QNormal) :
    nMul z w = nMul w z := by
  cases z <;> cases w <;>
    simp [nMul, BOMA.C.StageTwo.QNormalRoute015.mul, BOMA.C.StageTwo.QExpression015.nfMul, C.mulComm, C.addComm]

/-- Associativity is an explicit consequence of the fixed Cauchy real ring laws. -/
theorem n_mul_assoc
    (C : CauchyScalarCertificate) (z w v : QNormal) :
    nMul (nMul z w) v = nMul z (nMul w v) := by
  cases z <;> cases w <;> cases v <;>
    simp [nMul, BOMA.C.StageTwo.QNormalRoute015.mul, BOMA.C.StageTwo.QExpression015.nfMul,
      r_mul_add_left_from_interface C, C.distribRight,
      mul_neg_left_from_interface C, mul_neg_right_from_interface C,
      r_neg_add_from_interface C, neg_involutive_from_interface C,
      C.mulAssoc, C.mulComm, r_mul_left_comm_from_interface C,
      C.addAssoc, C.addComm, r_add_left_comm_from_interface C]

theorem n_mul_one_left (C : CauchyScalarCertificate) (z : QNormal) :
    nMul nOne z = z := by
  apply n_ext
  · change
      rCAdd (rCMul rCOne z.re)
        (rCNeg (rCMul rCZero z.im)) = z.re
    rw [C.mulOneLeft z.re, mul_zero_left_from_interface C z.im,
      neg_zero_from_interface C,
      BOMA.C.StageTwo.QNormalRoute015.add_zero_right_from_interface C z.re]
  · change
      rCAdd (rCMul rCOne z.im)
        (rCMul rCZero z.re) = z.im
    rw [C.mulOneLeft z.im, mul_zero_left_from_interface C z.re,
      BOMA.C.StageTwo.QNormalRoute015.add_zero_right_from_interface C z.im]

theorem n_mul_one_right (C : CauchyScalarCertificate) (z : QNormal) :
    nMul z nOne = z := by
  rw [n_mul_comm C z nOne, n_mul_one_left C z]

/-- Right distribution is proved independently from the abstract real interface. -/
theorem n_mul_add_right
    (C : CauchyScalarCertificate) (z w v : QNormal) :
    nMul z (nAdd w v) = nAdd (nMul z w) (nMul z v) := by
  cases z <;> cases w <;> cases v <;>
    simp [nMul, nAdd, BOMA.C.StageTwo.QNormalRoute015.mul, BOMA.C.StageTwo.QExpression015.nfMul,
      BOMA.C.StageTwo.QNormalRoute015.add, BOMA.C.StageTwo.QExpression015.nfAdd,
      r_mul_add_left_from_interface C, C.distribRight,
      mul_neg_left_from_interface C, mul_neg_right_from_interface C,
      r_neg_add_from_interface C, neg_involutive_from_interface C,
      C.mulAssoc, C.mulComm, r_mul_left_comm_from_interface C,
      C.addAssoc, C.addComm, r_add_left_comm_from_interface C]

theorem n_mul_add_left
    (C : CauchyScalarCertificate) (z w v : QNormal) :
    nMul (nAdd z w) v = nAdd (nMul z v) (nMul w v) := by
  calc
    nMul (nAdd z w) v = nMul v (nAdd z w) :=
      n_mul_comm C (nAdd z w) v
    _ = nAdd (nMul v z) (nMul v w) := n_mul_add_right C v z w
    _ = nAdd (nMul z v) (nMul w v) := by
      rw [n_mul_comm C v z, n_mul_comm C v w]

theorem n_mul_zero_left (C : CauchyScalarCertificate) (z : QNormal) :
    nMul nZero z = nZero := by
  apply n_ext
  · change
      rCAdd (rCMul rCZero z.re)
        (rCNeg (rCMul rCZero z.im)) = rCZero
    rw [mul_zero_left_from_interface C z.re,
      mul_zero_left_from_interface C z.im,
      neg_zero_from_interface C, C.addZeroLeft rCZero]
  · change
      rCAdd (rCMul rCZero z.im)
        (rCMul rCZero z.re) = rCZero
    rw [mul_zero_left_from_interface C z.im,
      mul_zero_left_from_interface C z.re, C.addZeroLeft rCZero]

theorem n_mul_zero_right (C : CauchyScalarCertificate) (z : QNormal) :
    nMul z nZero = nZero := by
  rw [n_mul_comm C z nZero, n_mul_zero_left C z]

theorem n_ofR_zero : nOfR rCZero = nZero := rfl

theorem n_ofR_one : nOfR rCOne = nOne := rfl

theorem n_ofR_neg (C : CauchyScalarCertificate) (a : RCBOMA) :
    nOfR (rCNeg a) = nNeg (nOfR a) := by
  apply n_ext
  · rfl
  · exact (neg_zero_from_interface C).symm

theorem n_ofR_add (C : CauchyScalarCertificate) (a b : RCBOMA) :
    nOfR (rCAdd a b) = nAdd (nOfR a) (nOfR b) := by
  apply n_ext
  · rfl
  · exact (C.addZeroLeft rCZero).symm

theorem n_ofR_mul (C : CauchyScalarCertificate) (a b : RCBOMA) :
    nOfR (rCMul a b) = nMul (nOfR a) (nOfR b) := by
  apply n_ext
  · change
      rCMul a b =
        rCAdd (rCMul a b) (rCNeg (rCMul rCZero rCZero))
    rw [mul_zero_left_from_interface C rCZero,
      neg_zero_from_interface C,
      BOMA.C.StageTwo.QNormalRoute015.add_zero_right_from_interface C
        (rCMul a b)]
  · change
      rCZero = rCAdd (rCMul a rCZero) (rCMul rCZero b)
    rw [mul_zero_right_from_interface C a,
      mul_zero_left_from_interface C b, C.addZeroLeft rCZero]

theorem n_i_squared (C : CauchyScalarCertificate) :
    nMul nI nI = nNeg nOne :=
  BOMA.C.StageTwo.QNormalRoute015.imag_squared C

theorem n_generation (C : CauchyScalarCertificate) (z : QNormal) :
    ∃ a b : RCBOMA, z = nAdd (nOfR a) (nMul (nOfR b) nI) :=
  BOMA.C.StageTwo.QNormalRoute015.decomposition C z

theorem n_coordinate_unique
    (C : CauchyScalarCertificate) {a b a' b' : RCBOMA}
    (h : nAdd (nOfR a) (nMul (nOfR b) nI) =
      nAdd (nOfR a') (nMul (nOfR b') nI)) :
    a = a' ∧ b = b' :=
  BOMA.C.StageTwo.QNormalRoute015.decomposition_unique C h

theorem n_i_not_real (C : CauchyScalarCertificate) :
    ¬ ∃ a : RCBOMA, nI = nOfR a :=
  BOMA.C.StageTwo.QNormalRoute015.imag_not_real C

/-- Precisely scoped Q-normal integration surface: ring, not field. -/
structure QNormalRingCertificate where
  nontrivial : nZero ≠ nOne
  embeddingInjective : ∀ {a b : RCBOMA}, nOfR a = nOfR b → a = b
  addComm : ∀ z w : QNormal, nAdd z w = nAdd w z
  addAssoc : ∀ z w v : QNormal, nAdd (nAdd z w) v = nAdd z (nAdd w v)
  addZeroLeft : ∀ z : QNormal, nAdd nZero z = z
  addInverseRight : ∀ z : QNormal, nAdd z (nNeg z) = nZero
  mulComm : ∀ z w : QNormal, nMul z w = nMul w z
  mulAssoc : ∀ z w v : QNormal, nMul (nMul z w) v = nMul z (nMul w v)
  mulOneLeft : ∀ z : QNormal, nMul nOne z = z
  distribRight : ∀ z w v : QNormal,
    nMul z (nAdd w v) = nAdd (nMul z w) (nMul z v)
  mulZeroRight : ∀ z : QNormal, nMul z nZero = nZero
  embeddingZero : nOfR rCZero = nZero
  embeddingOne : nOfR rCOne = nOne
  embeddingNeg : ∀ a : RCBOMA, nOfR (rCNeg a) = nNeg (nOfR a)
  embeddingAdd : ∀ a b : RCBOMA,
    nOfR (rCAdd a b) = nAdd (nOfR a) (nOfR b)
  embeddingMul : ∀ a b : RCBOMA,
    nOfR (rCMul a b) = nMul (nOfR a) (nOfR b)
  imagSquared : nMul nI nI = nNeg nOne
  generation : ∀ z : QNormal,
    ∃ a b : RCBOMA, z = nAdd (nOfR a) (nMul (nOfR b) nI)
  coordinateUnique : ∀ {a b a' b' : RCBOMA},
    nAdd (nOfR a) (nMul (nOfR b) nI) =
      nAdd (nOfR a') (nMul (nOfR b') nI) → a = a' ∧ b = b'
  imagNotReal : ¬ ∃ a : RCBOMA, nI = nOfR a

/-- Abstract real-interface construction; no real representation is unfolded. -/
theorem qNormalRingCertificate
    (C : CauchyScalarCertificate) : QNormalRingCertificate where
  nontrivial := n_zero_ne_one C
  embeddingInjective := @n_ofR_injective
  addComm := n_add_comm C
  addAssoc := n_add_assoc C
  addZeroLeft := n_add_zero_left C
  addInverseRight := n_add_neg_right C
  mulComm := n_mul_comm C
  mulAssoc := n_mul_assoc C
  mulOneLeft := n_mul_one_left C
  distribRight := n_mul_add_right C
  mulZeroRight := n_mul_zero_right C
  embeddingZero := n_ofR_zero
  embeddingOne := n_ofR_one
  embeddingNeg := n_ofR_neg C
  embeddingAdd := n_ofR_add C
  embeddingMul := n_ofR_mul C
  imagSquared := n_i_squared C
  generation := n_generation C
  coordinateUnique := @n_coordinate_unique C
  imagNotReal := n_i_not_real C

/-- Instantiate the ring-core certificate on the accepted Stage-One real export. -/
theorem qNormalRingCertificateFromCauchyR : QNormalRingCertificate :=
  qNormalRingCertificate cauchyScalarCertificate

end BOMA.C.StageTwo.QNormalCore015

/- Adapted proof pattern; see ST2-EXP-015_IMPLEMENTATION_PROVENANCE_001.md. -/
/- ST2-EXP-015: independent Route-Q-normal-form norm and inverse witnesses.
The proof uses only fixed Cauchy R and Route Q's own normal-form ring. -/
namespace BOMA.C.StageTwo.QNormalNormInverse015

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.C.StageTwo.ScalarInterface015

open BOMA.C.StageTwo.ScalarConsequences015
open BOMA.C.StageTwo.QNormalCore015

/-- Conjugation reverses the Q-normal imaginary coordinate. -/
def nConj (z : QNormal) : QNormal := ⟨z.re, rCNeg z.im⟩

/-- The real-valued Q-normal coordinate norm is the sum of two squares. -/
def nNorm (z : QNormal) : RCBOMA :=
  rCAdd (rCMul z.re z.re) (rCMul z.im z.im)

theorem n_conj_involutive
    (C : CauchyScalarCertificate) (z : QNormal) :
    nConj (nConj z) = z := by
  apply n_ext
  · rfl
  · exact neg_involutive_from_interface C z.im

theorem n_conj_ofR
    (C : CauchyScalarCertificate) (a : RCBOMA) :
    nConj (nOfR a) = nOfR a := by
  apply n_ext
  · rfl
  · exact neg_zero_from_interface C

theorem n_conj_add
    (C : CauchyScalarCertificate) (z w : QNormal) :
    nConj (nAdd z w) = nAdd (nConj z) (nConj w) := by
  apply n_ext
  · rfl
  · exact r_neg_add_from_interface C z.im w.im

theorem n_norm_conj
    (C : CauchyScalarCertificate) (z : QNormal) :
    nNorm (nConj z) = nNorm z := by
  change
    rCAdd (rCMul z.re z.re)
      (rCMul (rCNeg z.im) (rCNeg z.im)) =
    rCAdd (rCMul z.re z.re)
      (rCMul z.im z.im)
  rw [mul_neg_neg_same_from_interface C z.im]

/-- The norm product has exactly the embedded real norm and zero imaginary part. -/
theorem n_mul_conj
    (C : CauchyScalarCertificate) (z : QNormal) :
    nMul z (nConj z) = nOfR (nNorm z) := by
  apply n_ext
  · change
      rCAdd (rCMul z.re z.re)
        (rCNeg (rCMul z.im (rCNeg z.im))) =
      rCAdd (rCMul z.re z.re) (rCMul z.im z.im)
    rw [mul_neg_right_from_interface C z.im z.im,
      neg_involutive_from_interface C (rCMul z.im z.im)]
  · change
      rCAdd (rCMul z.re (rCNeg z.im))
        (rCMul z.im z.re) = rCZero
    rw [mul_neg_right_from_interface C z.re z.im,
      C.mulComm z.im z.re,
      C.addComm (rCNeg (rCMul z.re z.im))
        (rCMul z.re z.im),
      C.addInverseRight (rCMul z.re z.im)]

theorem n_conj_mul
    (C : CauchyScalarCertificate) (z : QNormal) :
    nMul (nConj z) z = nOfR (nNorm z) := by
  rw [n_mul_comm C (nConj z) z, n_mul_conj C z]

/-- A nonnegative sum equal to zero has zero first summand. -/
theorem r_nonnegative_sum_zero_left
    (C : CauchyScalarCertificate) {a b : RCBOMA}
    (h0a : rCLE rCZero a) (h0b : rCLE rCZero b)
    (hsum : rCAdd a b = rCZero) : a = rCZero := by
  have ha0 : rCLE a rCZero := by
    have h := (C.addTranslateOrderIff rCZero b a).2 h0b
    rw [C.addZeroLeft a, C.addComm b a, hsum] at h
    exact h
  exact C.orderAntisymm ha0 h0a

/-- A nonnegative sum equal to zero has zero second summand. -/
theorem r_nonnegative_sum_zero_right
    (C : CauchyScalarCertificate) {a b : RCBOMA}
    (h0a : rCLE rCZero a) (h0b : rCLE rCZero b)
    (hsum : rCAdd a b = rCZero) : b = rCZero := by
  apply r_nonnegative_sum_zero_left C h0b h0a
  rw [C.addComm b a, hsum]

theorem n_norm_nonnegative
    (C : CauchyScalarCertificate) (z : QNormal) :
    rCLE rCZero (nNorm z) := by
  have h0re := square_nonnegative_of_interface C z.re
  have h0im := square_nonnegative_of_interface C z.im
  have h :=
    (C.addTranslateOrderIff rCZero
      (rCMul z.im z.im) (rCMul z.re z.re)).2 h0im
  rw [C.addZeroLeft (rCMul z.re z.re),
    C.addComm (rCMul z.im z.im)
      (rCMul z.re z.re)] at h
  exact C.orderTrans h0re h

theorem n_norm_zero_real_square
    (C : CauchyScalarCertificate) (z : QNormal)
    (hnorm : nNorm z = rCZero) :
    rCMul z.re z.re = rCZero := by
  exact r_nonnegative_sum_zero_left C
    (square_nonnegative_of_interface C z.re)
    (square_nonnegative_of_interface C z.im) hnorm

theorem n_norm_zero_imaginary_square
    (C : CauchyScalarCertificate) (z : QNormal)
    (hnorm : nNorm z = rCZero) :
    rCMul z.im z.im = rCZero := by
  exact r_nonnegative_sum_zero_right C
    (square_nonnegative_of_interface C z.re)
    (square_nonnegative_of_interface C z.im) hnorm

/-- A zero real square contradicts any proposed nonzero real witness.

The conclusion is deliberately double-negated equality, not equality; the
abstract real interface does not provide stable or decidable equality. -/
theorem r_square_zero_not_nonzero
    (C : CauchyScalarCertificate) {a : RCBOMA}
    (hsquare : rCMul a a = rCZero) : ¬ a ≠ rCZero := by
  intro hnonzero
  rcases C.inverseExists a hnonzero with ⟨t, ht⟩
  have hzero : a = rCZero := by
    calc
      a = rCMul a rCOne :=
        (BOMA.C.StageTwo.QNormalRoute015.mul_one_right_from_interface C a).symm
      _ = rCMul a (rCMul a t) := by rw [ht]
      _ = rCMul (rCMul a a) t :=
        (C.mulAssoc a a t).symm
      _ = rCMul rCZero t := by rw [hsquare]
      _ = rCZero := mul_zero_left_from_interface C t
  exact hnonzero hzero

/-- Zero norm entails only double-negated zero coordinates and zero complex value. -/
theorem n_norm_zero_not_nonzero
    (C : CauchyScalarCertificate) (z : QNormal)
    (hnorm : nNorm z = rCZero) : ¬ z ≠ nZero := by
  intro hnonzero
  have hre := r_square_zero_not_nonzero C
    (n_norm_zero_real_square C z hnorm)
  have him := r_square_zero_not_nonzero C
    (n_norm_zero_imaginary_square C z hnorm)
  apply hre
  intro hzre
  apply him
  intro hzim
  apply hnonzero
  apply n_ext
  · exact hzre
  · exact hzim

/-- A supplied nonzero complex hypothesis constructively makes its norm nonzero. -/
theorem n_norm_nonzero
    (C : CauchyScalarCertificate) {z : QNormal}
    (hnonzero : z ≠ nZero) : nNorm z ≠ rCZero := by
  intro hnorm
  exact n_norm_zero_not_nonzero C z hnorm hnonzero

/-- A real inverse witness for the norm determines a complex inverse witness. -/
theorem n_inverse_from_real_witness
    (C : CauchyScalarCertificate) (z : QNormal) (t : RCBOMA)
    (ht : rCMul (nNorm z) t = rCOne) :
    nMul z (nMul (nOfR t) (nConj z)) = nOne := by
  calc
    nMul z (nMul (nOfR t) (nConj z)) =
        nMul z (nMul (nConj z) (nOfR t)) := by
      rw [n_mul_comm C (nOfR t) (nConj z)]
    _ = nMul (nMul z (nConj z)) (nOfR t) :=
      (n_mul_assoc C z (nConj z) (nOfR t)).symm
    _ = nMul (nOfR (nNorm z)) (nOfR t) := by rw [n_mul_conj C z]
    _ = nOfR (rCMul (nNorm z) t) :=
      (n_ofR_mul C (nNorm z) t).symm
    _ = nOfR rCOne := by rw [ht]
    _ = nOne := n_ofR_one

/-- The field interface supplies existential witnesses, never a global selector. -/
theorem n_inverse_exists
    (C : CauchyScalarCertificate) (z : QNormal)
    (hnonzero : z ≠ nZero) :
    ∃ w : QNormal, nMul z w = nOne := by
  rcases C.inverseExists (nNorm z) (n_norm_nonzero C hnonzero) with ⟨t, ht⟩
  exact ⟨nMul (nOfR t) (nConj z), n_inverse_from_real_witness C z t ht⟩

theorem n_inverse_left_of_right
    (C : CauchyScalarCertificate) {z w : QNormal}
    (hzw : nMul z w = nOne) :
    nMul w z = nOne := by
  rw [n_mul_comm C w z, hzw]

/-- Inverse witnesses are unique by the already verified ring laws. -/
theorem n_inverse_unique
    (C : CauchyScalarCertificate) {z w v : QNormal}
    (hw : nMul z w = nOne)
    (hv : nMul z v = nOne) : w = v := by
  calc
    w = nMul w nOne := (n_mul_one_right C w).symm
    _ = nMul w (nMul z v) := by rw [hv]
    _ = nMul (nMul w z) v := (n_mul_assoc C w z v).symm
    _ = nMul nOne v := by rw [n_mul_comm C w z, hw]
    _ = v := n_mul_one_left C v

/-- Complete Q-normal field-strength certificate with witness-only inversion. -/
structure QNormalFieldCertificate where
  ring : QNormalRingCertificate
  normNonnegative : ∀ z : QNormal, rCLE rCZero (nNorm z)
  normNonzero : ∀ z : QNormal, z ≠ nZero → nNorm z ≠ rCZero
  conjugateProduct : ∀ z : QNormal, nMul z (nConj z) = nOfR (nNorm z)
  inverseExists : ∀ z : QNormal, z ≠ nZero → ∃ w : QNormal, nMul z w = nOne
  inverseUnique : ∀ {z w v : QNormal},
    nMul z w = nOne → nMul z v = nOne → w = v

/-- Field closure is derived from the abstract fixed Cauchy real certificate alone. -/
theorem qNormalFieldCertificate
    (C : CauchyScalarCertificate) : QNormalFieldCertificate where
  ring := qNormalRingCertificate C
  normNonnegative := n_norm_nonnegative C
  normNonzero := fun _ h => n_norm_nonzero C h
  conjugateProduct := n_mul_conj C
  inverseExists := n_inverse_exists C
  inverseUnique := @n_inverse_unique C

/-- Instantiate the witness-field certificate on the fixed Cauchy real export. -/
theorem qNormalFieldCertificateFromCauchyR : QNormalFieldCertificate :=
  qNormalFieldCertificate cauchyScalarCertificate

end BOMA.C.StageTwo.QNormalNormInverse015

/- Adapted proof pattern; see ST2-EXP-015_IMPLEMENTATION_PROVENANCE_001.md. -/
/- ST2-EXP-015: independent field on the retained quadratic-expression quotient.
Every result is proved from fixed Cauchy R and Route Q's own normalized witness field. -/
namespace BOMA.C.StageTwo.QQuotientField015

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.C.StageTwo.ScalarInterface015

open BOMA.C.StageTwo.QNormalCore015
open BOMA.C.StageTwo.QNormalNormInverse015

abbrev QBOMA : Type := BOMA.C.StageTwo.QExpression015.QuotientCandidate
abbrev qZero : QBOMA := BOMA.C.StageTwo.QExpression015.zero
abbrev qOne : QBOMA := BOMA.C.StageTwo.QExpression015.one
abbrev qOfR (a : RCBOMA) : QBOMA := BOMA.C.StageTwo.QExpression015.ofR a
abbrev qI : QBOMA := BOMA.C.StageTwo.QExpression015.imag
abbrev qNeg (z : QBOMA) : QBOMA := BOMA.C.StageTwo.QExpression015.neg z
abbrev qAdd (z w : QBOMA) : QBOMA := BOMA.C.StageTwo.QExpression015.add z w
abbrev qMul (z w : QBOMA) : QBOMA := BOMA.C.StageTwo.QExpression015.mul z w

/-- Constructive canonical normal form; no representative choice is involved. -/
def qNormal : QBOMA → QNormal :=
  Quotient.lift BOMA.C.StageTwo.QExpression015.normalize
    (fun _ _ h => h)

/-- Quotient identity is exactly equality of canonical normal forms. -/
theorem q_ext {z w : QBOMA}
    (h : qNormal z = qNormal w) : z = w := by
  revert h
  refine Quotient.inductionOn₂ z w ?_
  intro e f h
  exact Quotient.sound h

theorem q_normal_zero : qNormal qZero = nZero := rfl

theorem q_normal_one : qNormal qOne = nOne := rfl

theorem q_normal_ofR (a : RCBOMA) : qNormal (qOfR a) = nOfR a := rfl

theorem q_normal_imag : qNormal qI = nI := rfl

theorem q_normal_neg (z : QBOMA) :
    qNormal (qNeg z) = nNeg (qNormal z) := by
  refine Quotient.inductionOn z ?_
  intro e
  rfl

theorem q_normal_add (z w : QBOMA) :
    qNormal (qAdd z w) = nAdd (qNormal z) (qNormal w) := by
  refine Quotient.inductionOn₂ z w ?_
  intro e f
  rfl

theorem q_normal_mul (z w : QBOMA) :
    qNormal (qMul z w) = nMul (qNormal z) (qNormal w) := by
  refine Quotient.inductionOn₂ z w ?_
  intro e f
  rfl

theorem q_zero_ne_one (R : CauchyScalarCertificate) :
    qZero ≠ qOne := by
  intro h
  exact R.nontrivial (BOMA.C.StageTwo.QExpression015.ofR_injective h)

theorem q_ofR_injective {a b : RCBOMA} (h : qOfR a = qOfR b) :
    a = b :=
  BOMA.C.StageTwo.QExpression015.ofR_injective h

theorem q_add_comm (R : CauchyScalarCertificate) (z w : QBOMA) :
    qAdd z w = qAdd w z := by
  apply q_ext
  rw [q_normal_add, q_normal_add]
  exact n_add_comm R (qNormal z) (qNormal w)

theorem q_add_assoc (R : CauchyScalarCertificate) (z w v : QBOMA) :
    qAdd (qAdd z w) v = qAdd z (qAdd w v) := by
  apply q_ext
  rw [q_normal_add, q_normal_add, q_normal_add, q_normal_add]
  exact n_add_assoc R (qNormal z) (qNormal w) (qNormal v)

theorem q_add_zero_left (R : CauchyScalarCertificate) (z : QBOMA) :
    qAdd qZero z = z := by
  apply q_ext
  rw [q_normal_add, q_normal_zero]
  exact n_add_zero_left R (qNormal z)

theorem q_add_neg_right (R : CauchyScalarCertificate) (z : QBOMA) :
    qAdd z (qNeg z) = qZero := by
  apply q_ext
  rw [q_normal_add, q_normal_neg, q_normal_zero]
  exact n_add_neg_right R (qNormal z)

theorem q_mul_comm (R : CauchyScalarCertificate) (z w : QBOMA) :
    qMul z w = qMul w z := by
  apply q_ext
  rw [q_normal_mul, q_normal_mul]
  exact n_mul_comm R (qNormal z) (qNormal w)

theorem q_mul_assoc (R : CauchyScalarCertificate) (z w v : QBOMA) :
    qMul (qMul z w) v = qMul z (qMul w v) := by
  apply q_ext
  rw [q_normal_mul, q_normal_mul, q_normal_mul, q_normal_mul]
  exact n_mul_assoc R (qNormal z) (qNormal w) (qNormal v)

theorem q_mul_one_left (R : CauchyScalarCertificate) (z : QBOMA) :
    qMul qOne z = z := by
  apply q_ext
  rw [q_normal_mul, q_normal_one]
  exact n_mul_one_left R (qNormal z)

theorem q_mul_one_right (R : CauchyScalarCertificate) (z : QBOMA) :
    qMul z qOne = z := by
  rw [q_mul_comm R z qOne, q_mul_one_left R z]

theorem q_mul_add_right
    (R : CauchyScalarCertificate) (z w v : QBOMA) :
    qMul z (qAdd w v) = qAdd (qMul z w) (qMul z v) := by
  apply q_ext
  rw [q_normal_mul, q_normal_add, q_normal_add, q_normal_mul, q_normal_mul]
  exact n_mul_add_right R (qNormal z) (qNormal w) (qNormal v)

theorem q_mul_zero_right (R : CauchyScalarCertificate) (z : QBOMA) :
    qMul z qZero = qZero := by
  apply q_ext
  rw [q_normal_mul, q_normal_zero]
  exact n_mul_zero_right R (qNormal z)

theorem q_ofR_zero : qOfR rCZero = qZero := rfl

theorem q_ofR_one : qOfR rCOne = qOne := rfl

theorem q_ofR_neg (R : CauchyScalarCertificate) (a : RCBOMA) :
    qOfR (rCNeg a) = qNeg (qOfR a) := by
  apply q_ext
  rw [q_normal_ofR, q_normal_neg, q_normal_ofR]
  exact n_ofR_neg R a

theorem q_ofR_add (R : CauchyScalarCertificate) (a b : RCBOMA) :
    qOfR (rCAdd a b) = qAdd (qOfR a) (qOfR b) := by
  apply q_ext
  rw [q_normal_ofR, q_normal_add, q_normal_ofR, q_normal_ofR]
  exact n_ofR_add R a b

theorem q_ofR_mul (R : CauchyScalarCertificate) (a b : RCBOMA) :
    qOfR (rCMul a b) = qMul (qOfR a) (qOfR b) := by
  apply q_ext
  rw [q_normal_ofR, q_normal_mul, q_normal_ofR, q_normal_ofR]
  exact n_ofR_mul R a b

theorem q_i_squared (R : CauchyScalarCertificate) :
    qMul qI qI = qNeg qOne :=
  BOMA.C.StageTwo.QExpression015.imag_squared R

def qCoord (a b : RCBOMA) : QBOMA :=
  qAdd (qOfR a) (qMul (qOfR b) qI)

theorem q_normal_coord (R : CauchyScalarCertificate) (a b : RCBOMA) :
    qNormal (qCoord a b) = ⟨a, b⟩ := by
  exact BOMA.C.StageTwo.QExpression015.normalized_coordinate_expression R a b

theorem q_generation (R : CauchyScalarCertificate) (z : QBOMA) :
    ∃ a b : RCBOMA, z = qCoord a b :=
  BOMA.C.StageTwo.QExpression015.decomposition R z

theorem q_coordinate_unique
    (R : CauchyScalarCertificate) {a b c d : RCBOMA}
    (h : qCoord a b = qCoord c d) : a = c ∧ b = d :=
  BOMA.C.StageTwo.QExpression015.decomposition_unique R h

theorem q_i_not_real (R : CauchyScalarCertificate) :
    ¬ ∃ a : RCBOMA, qI = qOfR a :=
  BOMA.C.StageTwo.QExpression015.imag_not_real R

def qRe (z : QBOMA) : RCBOMA := (qNormal z).re
def qIm (z : QBOMA) : RCBOMA := (qNormal z).im

theorem q_extract_sound (R : CauchyScalarCertificate) (z : QBOMA) :
    z = qCoord (qRe z) (qIm z) := by
  apply q_ext
  rw [q_normal_coord R]
  change qNormal z = ⟨(qNormal z).re, (qNormal z).im⟩
  cases qNormal z
  rfl

theorem q_coordinate_zero (R : CauchyScalarCertificate) :
    qCoord rCZero rCZero = qZero := by
  apply q_ext
  rw [q_normal_coord R, q_normal_zero]
  rfl

theorem q_coordinate_one (R : CauchyScalarCertificate) :
    qCoord rCOne rCZero = qOne := by
  apply q_ext
  rw [q_normal_coord R, q_normal_one]
  rfl

theorem q_coordinate_real (R : CauchyScalarCertificate) (a : RCBOMA) :
    qCoord a rCZero = qOfR a := by
  apply q_ext
  rw [q_normal_coord R, q_normal_ofR]
  rfl

theorem q_coordinate_imag (R : CauchyScalarCertificate) :
    qCoord rCZero rCOne = qI := by
  apply q_ext
  rw [q_normal_coord R, q_normal_imag]
  rfl

theorem q_coordinate_neg (R : CauchyScalarCertificate) (a b : RCBOMA) :
    qNeg (qCoord a b) = qCoord (rCNeg a) (rCNeg b) := by
  apply q_ext
  rw [q_normal_neg, q_normal_coord R, q_normal_coord R]
  rfl

theorem q_coordinate_add
    (R : CauchyScalarCertificate) (a b c d : RCBOMA) :
    qAdd (qCoord a b) (qCoord c d) =
      qCoord (rCAdd a c) (rCAdd b d) := by
  apply q_ext
  rw [q_normal_add, q_normal_coord R, q_normal_coord R, q_normal_coord R]
  rfl

theorem q_coordinate_mul
    (R : CauchyScalarCertificate) (a b c d : RCBOMA) :
    qMul (qCoord a b) (qCoord c d) =
      qCoord
        (rCAdd (rCMul a c) (rCNeg (rCMul b d)))
        (rCAdd (rCMul a d) (rCMul b c)) := by
  apply q_ext
  rw [q_normal_mul, q_normal_coord R, q_normal_coord R, q_normal_coord R]
  rfl

/-- Encode a Q-local normal form by the quotient's declared expression syntax. -/
def qOfNormal (u : QNormal) : QBOMA := qCoord u.re u.im

theorem q_normal_of_normal
    (R : CauchyScalarCertificate) (u : QNormal) :
    qNormal (qOfNormal u) = u := by
  change qNormal (qCoord u.re u.im) = u
  rw [q_normal_coord R]

theorem q_inverse_exists
    (R : CauchyScalarCertificate) (z : QBOMA)
    (hnonzero : z ≠ qZero) :
    ∃ w : QBOMA, qMul z w = qOne := by
  have hn : qNormal z ≠ nZero := by
    intro hz
    apply hnonzero
    apply q_ext
    rw [q_normal_zero]
    exact hz
  rcases n_inverse_exists R (qNormal z) hn with ⟨w, hw⟩
  refine ⟨qOfNormal w, ?_⟩
  apply q_ext
  rw [q_normal_mul, q_normal_of_normal R w, q_normal_one]
  exact hw

theorem q_inverse_unique
    (R : CauchyScalarCertificate) {z w v : QBOMA}
    (hw : qMul z w = qOne) (hv : qMul z v = qOne) :
    w = v := by
  calc
    w = qMul w qOne := (q_mul_one_right R w).symm
    _ = qMul w (qMul z v) := by rw [hv]
    _ = qMul (qMul w z) v := (q_mul_assoc R w z v).symm
    _ = qMul qOne v := by rw [q_mul_comm R w z, hw]
    _ = v := q_mul_one_left R v

/-- Independent Route-Q field contract at quotient equality and identity. -/
structure QFieldCertificate where
  nontrivial : qZero ≠ qOne
  embeddingInjective : ∀ {a b : RCBOMA}, qOfR a = qOfR b → a = b
  addComm : ∀ z w : QBOMA, qAdd z w = qAdd w z
  addAssoc : ∀ z w v : QBOMA, qAdd (qAdd z w) v = qAdd z (qAdd w v)
  addZeroLeft : ∀ z : QBOMA, qAdd qZero z = z
  addInverseRight : ∀ z : QBOMA, qAdd z (qNeg z) = qZero
  mulComm : ∀ z w : QBOMA, qMul z w = qMul w z
  mulAssoc : ∀ z w v : QBOMA, qMul (qMul z w) v = qMul z (qMul w v)
  mulOneLeft : ∀ z : QBOMA, qMul qOne z = z
  distribRight : ∀ z w v : QBOMA,
    qMul z (qAdd w v) = qAdd (qMul z w) (qMul z v)
  inverseExists : ∀ z : QBOMA, z ≠ qZero → ∃ w : QBOMA, qMul z w = qOne
  inverseUnique : ∀ {z w v : QBOMA}, qMul z w = qOne → qMul z v = qOne → w = v
  embeddingZero : qOfR rCZero = qZero
  embeddingOne : qOfR rCOne = qOne
  embeddingNeg : ∀ a : RCBOMA, qOfR (rCNeg a) = qNeg (qOfR a)
  embeddingAdd : ∀ a b : RCBOMA, qOfR (rCAdd a b) = qAdd (qOfR a) (qOfR b)
  embeddingMul : ∀ a b : RCBOMA,
    qOfR (rCMul a b) = qMul (qOfR a) (qOfR b)
  imagSquared : qMul qI qI = qNeg qOne
  generation : ∀ z : QBOMA, ∃ a b : RCBOMA, z = qCoord a b
  coordinateUnique : ∀ {a b c d : RCBOMA}, qCoord a b = qCoord c d → a = c ∧ b = d
  imagNotReal : ¬ ∃ a : RCBOMA, qI = qOfR a
  extractorSound : ∀ z : QBOMA, z = qCoord (qRe z) (qIm z)

theorem qFieldCertificate (R : CauchyScalarCertificate) :
    QFieldCertificate where
  nontrivial := q_zero_ne_one R
  embeddingInjective := @q_ofR_injective
  addComm := q_add_comm R
  addAssoc := q_add_assoc R
  addZeroLeft := q_add_zero_left R
  addInverseRight := q_add_neg_right R
  mulComm := q_mul_comm R
  mulAssoc := q_mul_assoc R
  mulOneLeft := q_mul_one_left R
  distribRight := q_mul_add_right R
  inverseExists := q_inverse_exists R
  inverseUnique := @q_inverse_unique R
  embeddingZero := q_ofR_zero
  embeddingOne := q_ofR_one
  embeddingNeg := q_ofR_neg R
  embeddingAdd := q_ofR_add R
  embeddingMul := q_ofR_mul R
  imagSquared := q_i_squared R
  generation := q_generation R
  coordinateUnique := @q_coordinate_unique R
  imagNotReal := q_i_not_real R
  extractorSound := q_extract_sound R

/-- Independent field witness instantiated on the same whole fixed-Cauchy-R interface. -/
theorem qFieldCertificateFromCauchyR : QFieldCertificate :=
  qFieldCertificate cauchyScalarCertificate

end BOMA.C.StageTwo.QQuotientField015

/- ST2-EXP-015: independent Q comparison presentation and full Claim meanings. -/
namespace BOMA.C.StageTwo.QPresentation015

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.C.StageTwo.ScalarInterface015
open BOMA.C.StageTwo.QQuotientField015
open BOMA.C.StageTwo.ComparisonInterface011

def scalarOps : ScalarOps where
  carrier := RCBOMA
  zero := rCZero
  one := rCOne
  neg := rCNeg
  add := rCAdd
  mul := rCMul

def qPresentation : QuadraticPresentation scalarOps where
  carrier := QBOMA
  zero := qZero
  one := qOne
  neg := qNeg
  add := qAdd
  mul := qMul
  ofScalar := qOfR
  imag := qI
  coord := qCoord
  coordinateGeneration := q_generation cauchyScalarCertificate
  coordinateUnique := @q_coordinate_unique cauchyScalarCertificate
  coordinateZero := q_coordinate_zero cauchyScalarCertificate
  coordinateOne := q_coordinate_one cauchyScalarCertificate
  coordinateReal := q_coordinate_real cauchyScalarCertificate
  coordinateImag := q_coordinate_imag cauchyScalarCertificate
  coordinateNeg := q_coordinate_neg cauchyScalarCertificate
  coordinateAdd := q_coordinate_add cauchyScalarCertificate
  coordinateMul := q_coordinate_mul cauchyScalarCertificate

def qExtractor : CoordinateExtractor qPresentation where
  re := qRe
  im := qIm
  sound := q_extract_sound cauchyScalarCertificate

theorem qNativeComparison (B : QuadraticPresentation scalarOps) :
    QuadraticComparisonCertificate qPresentation B :=
  quadraticComparison qPresentation B

def qNativeFunctionalComparison (B : QuadraticPresentation scalarOps)
    (E : CoordinateExtractor B) :
    ConstructiveQuadraticIsomorphism qPresentation B :=
  constructiveQuadraticIsomorphism qPresentation B qExtractor E

/-- Nine-family research meaning, with field and comparison roots kept distinct. -/
structure NativeQFullCertificate where
  field : QFieldCertificate
  comparison : ∀ B : QuadraticPresentation scalarOps,
    QuadraticComparisonCertificate qPresentation B
  functionalComparison : ∀ B : QuadraticPresentation scalarOps,
    CoordinateExtractor B → ConstructiveQuadraticIsomorphism qPresentation B

def nativeQFullCertificate : NativeQFullCertificate where
  field := qFieldCertificateFromCauchyR
  comparison := qNativeComparison
  functionalComparison := qNativeFunctionalComparison

end BOMA.C.StageTwo.QPresentation015

/- ST2-EXP-003 H6: research-only rebuild of the selected quadratic complex
   meaning over the independently completed Cauchy real carrier.

   This source consumes only the independent Cauchy real interface already
   proved through H4.  The exact Dedekind/Cauchy Junction is a governance
   prerequisite for admitting H6, not a mathematical source dependency here.

   The construction deliberately mirrors the accepted selected pair meaning:
   a rank-two real-coordinate carrier, faithful real embedding, distinguished
   I with I^2 = -1, unique real coordinates, commutative-ring laws, conjugate
   norm, and witness-only nonzero inversion.  It does not modify or re-export
   accepted C-BLOCK-001/C-BLOCK-002 and introduces no global inverse selector. -/
namespace BOMA.C.StageTwo.CauchyQuadratic003

open BOMA.Q.Quotient001
open BOMA.Q.Integration001
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyOrderedRing003
open BOMA.R.StageTwo.CauchyInverse003
open BOMA.R.StageTwo.CauchyLUB003

/-- The alternative real zero and one are distinct by faithfulness of the
    constant accepted-rational embedding. -/
theorem rC_nontrivial : rCZero ≠ rCOne := by
  intro h
  have hq : rCOfQ qZero = rCOfQ qOne := h
  exact q_nontrivial (rCOfQ_injective hq)

/-- Right additive zero derived from commutativity and the verified left law. -/
theorem rCAdd_zero_right (x : RCBOMA) : rCAdd x rCZero = x := by
  rw [rCAdd_comm x rCZero, rCAdd_zero_left x]

/-- Negation fixes zero without any equality decision. -/
theorem rCNeg_zero : rCNeg rCZero = rCZero := by
  have h := rCAdd_neg_right rCZero
  rw [rCAdd_zero_left] at h
  exact h

/-- Additive inverse witnesses are unique in the alternative real additive
    group. -/
theorem rC_add_inverse_unique {x y : RCBOMA}
    (hxy : rCAdd x y = rCZero) : y = rCNeg x := by
  calc
    y = rCAdd rCZero y := (rCAdd_zero_left y).symm
    _ = rCAdd (rCAdd x (rCNeg x)) y := by rw [rCAdd_neg_right x]
    _ = rCAdd x (rCAdd (rCNeg x) y) := rCAdd_assoc x (rCNeg x) y
    _ = rCAdd x (rCAdd y (rCNeg x)) := by
      rw [rCAdd_comm (rCNeg x) y]
    _ = rCAdd (rCAdd x y) (rCNeg x) :=
      (rCAdd_assoc x y (rCNeg x)).symm
    _ = rCAdd rCZero (rCNeg x) := by rw [hxy]
    _ = rCNeg x := rCAdd_zero_left (rCNeg x)

/-- Alternative-real negation is involutive. -/
theorem rCNeg_involutive (x : RCBOMA) : rCNeg (rCNeg x) = x := by
  have hleft : rCAdd (rCNeg x) x = rCZero := by
    calc
      rCAdd (rCNeg x) x = rCAdd x (rCNeg x) := rCAdd_comm (rCNeg x) x
      _ = rCZero := rCAdd_neg_right x
  exact (rC_add_inverse_unique hleft).symm

/-- Right multiplicative zero derived from commutativity. -/
theorem rCMul_zero_right (x : RCBOMA) : rCMul x rCZero = rCZero := by
  rw [rCMul_comm x rCZero, rCMul_zero_left x]

/-- Right multiplicative one derived from commutativity. -/
theorem rCMul_one_right_local (x : RCBOMA) : rCMul x rCOne = x := by
  rw [rCMul_comm x rCOne, rCMul_one_left x]

/-- Multiplication by an additive inverse on the right negates the product. -/
theorem rCMul_neg_right (x y : RCBOMA) :
    rCMul x (rCNeg y) = rCNeg (rCMul x y) := by
  have hd := rCMul_add_right x y (rCNeg y)
  have hsum :
      rCAdd (rCMul x y) (rCMul x (rCNeg y)) = rCZero := by
    calc
      rCAdd (rCMul x y) (rCMul x (rCNeg y)) =
          rCMul x (rCAdd y (rCNeg y)) := hd.symm
      _ = rCMul x rCZero := by rw [rCAdd_neg_right y]
      _ = rCZero := rCMul_zero_right x
  exact rC_add_inverse_unique hsum

/-- Multiplication by an additive inverse on the left negates the product. -/
theorem rCMul_neg_left (x y : RCBOMA) :
    rCMul (rCNeg x) y = rCNeg (rCMul x y) := by
  calc
    rCMul (rCNeg x) y = rCMul y (rCNeg x) := rCMul_comm (rCNeg x) y
    _ = rCNeg (rCMul y x) := rCMul_neg_right y x
    _ = rCNeg (rCMul x y) := by rw [rCMul_comm y x]

/-- Squaring a negated alternative real gives the same square. -/
theorem rCMul_neg_neg_same (x : RCBOMA) :
    rCMul (rCNeg x) (rCNeg x) = rCMul x x := by
  calc
    rCMul (rCNeg x) (rCNeg x) = rCNeg (rCMul x (rCNeg x)) :=
      rCMul_neg_left x (rCNeg x)
    _ = rCNeg (rCNeg (rCMul x x)) := by rw [rCMul_neg_right x x]
    _ = rCMul x x := rCNeg_involutive _

/-- Additive left-commutation helper for explicit pair normalizations. -/
theorem rCAdd_left_comm (a b c : RCBOMA) :
    rCAdd a (rCAdd b c) = rCAdd b (rCAdd a c) := by
  calc
    rCAdd a (rCAdd b c) = rCAdd (rCAdd a b) c :=
      (rCAdd_assoc a b c).symm
    _ = rCAdd (rCAdd b a) c := by rw [rCAdd_comm a b]
    _ = rCAdd b (rCAdd a c) := rCAdd_assoc b a c

/-- Multiplicative left-commutation helper. -/
theorem rCMul_left_comm (a b c : RCBOMA) :
    rCMul a (rCMul b c) = rCMul b (rCMul a c) := by
  calc
    rCMul a (rCMul b c) = rCMul (rCMul a b) c :=
      (rCMul_assoc a b c).symm
    _ = rCMul (rCMul b a) c := by rw [rCMul_comm a b]
    _ = rCMul b (rCMul a c) := rCMul_assoc b a c

/-- Distribution in the first alternative-real argument. -/
theorem rCMul_add_left (a b c : RCBOMA) :
    rCMul (rCAdd a b) c = rCAdd (rCMul a c) (rCMul b c) := by
  calc
    rCMul (rCAdd a b) c = rCMul c (rCAdd a b) := rCMul_comm (rCAdd a b) c
    _ = rCAdd (rCMul c a) (rCMul c b) := rCMul_add_right c a b
    _ = rCAdd (rCMul a c) (rCMul b c) := by
      rw [rCMul_comm c a, rCMul_comm c b]

/-- Negation distributes over alternative-real addition. -/
theorem rCNeg_add (a b : RCBOMA) :
    rCNeg (rCAdd a b) = rCAdd (rCNeg a) (rCNeg b) := by
  have h :
      rCAdd (rCAdd a b) (rCAdd (rCNeg a) (rCNeg b)) = rCZero := by
    calc
      rCAdd (rCAdd a b) (rCAdd (rCNeg a) (rCNeg b)) =
          rCAdd a (rCAdd b (rCAdd (rCNeg a) (rCNeg b))) :=
        rCAdd_assoc a b (rCAdd (rCNeg a) (rCNeg b))
      _ = rCAdd a (rCAdd (rCNeg a) (rCAdd b (rCNeg b))) := by
        rw [rCAdd_left_comm b (rCNeg a) (rCNeg b)]
      _ = rCAdd (rCAdd a (rCNeg a)) (rCAdd b (rCNeg b)) :=
        (rCAdd_assoc a (rCNeg a) (rCAdd b (rCNeg b))).symm
      _ = rCZero := by
        rw [rCAdd_neg_right a, rCAdd_neg_right b, rCAdd_zero_left]
  exact (rC_add_inverse_unique h).symm

/-- Every alternative-real square is nonnegative, derived only from the
    independently proved Cauchy total ordered-ring laws. -/
theorem rC_square_nonnegative (x : RCBOMA) : rCLE rCZero (rCMul x x) := by
  rcases rcle_total rCZero x with h0x | hx0
  · exact rcle_mul_nonneg h0x h0x
  · have h0nx : rCLE rCZero (rCNeg x) := by
      have h := rcle_add_right hx0 (rCNeg x)
      rw [rCAdd_neg_right x, rCAdd_zero_left] at h
      exact h
    have h := rcle_mul_nonneg h0nx h0nx
    rw [rCMul_neg_neg_same x] at h
    exact h

/-- Research H6 carrier: the same selected quadratic pair meaning, now with
    independently constructed Cauchy-real coordinates. -/
structure CCBOMA where
  re : RCBOMA
  im : RCBOMA

/-- Coordinate extensionality is the exact identity of the H6 pair carrier. -/
theorem cc_ext {z w : CCBOMA}
    (hre : z.re = w.re) (him : z.im = w.im) : z = w := by
  cases z
  cases w
  cases hre
  cases him
  rfl

def ccZero : CCBOMA := ⟨rCZero, rCZero⟩
def ccOne : CCBOMA := ⟨rCOne, rCZero⟩
def ccOfR (a : RCBOMA) : CCBOMA := ⟨a, rCZero⟩
def ccI : CCBOMA := ⟨rCZero, rCOne⟩
def ccNeg (z : CCBOMA) : CCBOMA := ⟨rCNeg z.re, rCNeg z.im⟩
def ccAdd (z w : CCBOMA) : CCBOMA :=
  ⟨rCAdd z.re w.re, rCAdd z.im w.im⟩
def ccMul (z w : CCBOMA) : CCBOMA :=
  ⟨rCAdd (rCMul z.re w.re) (rCNeg (rCMul z.im w.im)),
   rCAdd (rCMul z.re w.im) (rCMul z.im w.re)⟩

/-- The alternative-real embedding into the H6 pair carrier is faithful. -/
theorem cc_ofR_injective {a b : RCBOMA} (h : ccOfR a = ccOfR b) : a = b :=
  congrArg CCBOMA.re h

/-- Multiplication of an embedded real by I exposes its imaginary coordinate. -/
theorem cc_embed_mul_i (b : RCBOMA) : ccMul (ccOfR b) ccI = ⟨rCZero, b⟩ := by
  apply cc_ext
  · change
      rCAdd (rCMul b rCZero) (rCNeg (rCMul rCZero rCOne)) = rCZero
    rw [rCMul_zero_right b, rCMul_zero_left rCOne,
      rCNeg_zero, rCAdd_zero_left]
  · change rCAdd (rCMul b rCOne) (rCMul rCZero rCZero) = b
    rw [rCMul_one_right_local b, rCMul_zero_left rCZero, rCAdd_zero_right b]

/-- Every coordinate pair has the expected real-plus-imaginary normal form. -/
theorem cc_coordinate_expression (a b : RCBOMA) :
    ccAdd (ccOfR a) (ccMul (ccOfR b) ccI) = ⟨a, b⟩ := by
  rw [cc_embed_mul_i b]
  apply cc_ext
  · exact rCAdd_zero_right a
  · exact rCAdd_zero_left b

/-- The distinguished H6 generator squares to negative one. -/
theorem cc_i_squared : ccMul ccI ccI = ccNeg ccOne := by
  apply cc_ext
  · change
      rCAdd (rCMul rCZero rCZero) (rCNeg (rCMul rCOne rCOne)) = rCNeg rCOne
    rw [rCMul_zero_left rCZero, rCMul_one_left rCOne, rCAdd_zero_left]
  · change
      rCAdd (rCMul rCZero rCOne) (rCMul rCOne rCZero) = rCNeg rCZero
    rw [rCMul_zero_left rCOne, rCMul_zero_right rCOne,
      rCAdd_zero_left, rCNeg_zero]

/-- Every H6 value has real/imaginary coordinates. -/
theorem cc_generation (z : CCBOMA) :
    ∃ a b : RCBOMA, z = ccAdd (ccOfR a) (ccMul (ccOfR b) ccI) := by
  refine ⟨z.re, z.im, ?_⟩
  rw [cc_coordinate_expression z.re z.im]

/-- H6 coordinates are unique at the actual pair equality. -/
theorem cc_coordinate_unique {a b a' b' : RCBOMA}
    (h : ccAdd (ccOfR a) (ccMul (ccOfR b) ccI) =
      ccAdd (ccOfR a') (ccMul (ccOfR b') ccI)) :
    a = a' ∧ b = b' := by
  rw [cc_coordinate_expression a b, cc_coordinate_expression a' b'] at h
  exact ⟨congrArg CCBOMA.re h, congrArg CCBOMA.im h⟩

/-- The H6 imaginary generator does not collapse into the embedded real line. -/
theorem cc_i_not_real : ¬ ∃ a : RCBOMA, ccI = ccOfR a := by
  rintro ⟨a, ha⟩
  have h : rCOne = rCZero := congrArg CCBOMA.im ha
  exact rC_nontrivial h.symm

theorem cc_zero_ne_one : ccZero ≠ ccOne := by
  intro h
  exact rC_nontrivial (congrArg CCBOMA.re h)

theorem cc_add_comm (z w : CCBOMA) : ccAdd z w = ccAdd w z := by
  apply cc_ext
  · exact rCAdd_comm z.re w.re
  · exact rCAdd_comm z.im w.im

theorem cc_add_assoc (z w v : CCBOMA) :
    ccAdd (ccAdd z w) v = ccAdd z (ccAdd w v) := by
  apply cc_ext
  · exact rCAdd_assoc z.re w.re v.re
  · exact rCAdd_assoc z.im w.im v.im

theorem cc_add_zero_left (z : CCBOMA) : ccAdd ccZero z = z := by
  apply cc_ext
  · exact rCAdd_zero_left z.re
  · exact rCAdd_zero_left z.im

theorem cc_add_zero_right (z : CCBOMA) : ccAdd z ccZero = z := by
  rw [cc_add_comm z ccZero, cc_add_zero_left z]

theorem cc_add_neg_right (z : CCBOMA) : ccAdd z (ccNeg z) = ccZero := by
  apply cc_ext
  · exact rCAdd_neg_right z.re
  · exact rCAdd_neg_right z.im

theorem cc_mul_comm (z w : CCBOMA) : ccMul z w = ccMul w z := by
  cases z <;> cases w <;>
    simp [ccMul, rCMul_comm, rCAdd_comm]

theorem cc_mul_assoc (z w v : CCBOMA) :
    ccMul (ccMul z w) v = ccMul z (ccMul w v) := by
  cases z <;> cases w <;> cases v <;>
    simp [ccMul, rCMul_add_left, rCMul_add_right,
      rCMul_neg_left, rCMul_neg_right, rCNeg_add, rCNeg_involutive,
      rCMul_assoc, rCMul_comm, rCMul_left_comm,
      rCAdd_assoc, rCAdd_comm, rCAdd_left_comm]

theorem cc_mul_one_left (z : CCBOMA) : ccMul ccOne z = z := by
  apply cc_ext
  · change
      rCAdd (rCMul rCOne z.re) (rCNeg (rCMul rCZero z.im)) = z.re
    rw [rCMul_one_left z.re, rCMul_zero_left z.im,
      rCNeg_zero, rCAdd_zero_right z.re]
  · change rCAdd (rCMul rCOne z.im) (rCMul rCZero z.re) = z.im
    rw [rCMul_one_left z.im, rCMul_zero_left z.re, rCAdd_zero_right z.im]

theorem cc_mul_one_right (z : CCBOMA) : ccMul z ccOne = z := by
  rw [cc_mul_comm z ccOne, cc_mul_one_left z]

theorem cc_mul_add_right (z w v : CCBOMA) :
    ccMul z (ccAdd w v) = ccAdd (ccMul z w) (ccMul z v) := by
  cases z <;> cases w <;> cases v <;>
    simp [ccMul, ccAdd, rCMul_add_left, rCMul_add_right,
      rCMul_neg_left, rCMul_neg_right, rCNeg_add, rCNeg_involutive,
      rCMul_assoc, rCMul_comm, rCMul_left_comm,
      rCAdd_assoc, rCAdd_comm, rCAdd_left_comm]

theorem cc_mul_zero_left (z : CCBOMA) : ccMul ccZero z = ccZero := by
  apply cc_ext
  · change rCAdd (rCMul rCZero z.re) (rCNeg (rCMul rCZero z.im)) = rCZero
    rw [rCMul_zero_left z.re, rCMul_zero_left z.im,
      rCNeg_zero, rCAdd_zero_left]
  · change rCAdd (rCMul rCZero z.im) (rCMul rCZero z.re) = rCZero
    rw [rCMul_zero_left z.im, rCMul_zero_left z.re, rCAdd_zero_left]

theorem cc_mul_zero_right (z : CCBOMA) : ccMul z ccZero = ccZero := by
  rw [cc_mul_comm z ccZero, cc_mul_zero_left z]

theorem cc_ofR_zero : ccOfR rCZero = ccZero := rfl

theorem cc_ofR_one : ccOfR rCOne = ccOne := rfl

theorem cc_ofR_neg (a : RCBOMA) : ccOfR (rCNeg a) = ccNeg (ccOfR a) := by
  apply cc_ext
  · rfl
  · exact rCNeg_zero.symm

theorem cc_ofR_add (a b : RCBOMA) :
    ccOfR (rCAdd a b) = ccAdd (ccOfR a) (ccOfR b) := by
  apply cc_ext
  · rfl
  · exact (rCAdd_zero_left rCZero).symm

theorem cc_ofR_mul (a b : RCBOMA) :
    ccOfR (rCMul a b) = ccMul (ccOfR a) (ccOfR b) := by
  apply cc_ext
  · change
      rCMul a b = rCAdd (rCMul a b) (rCNeg (rCMul rCZero rCZero))
    rw [rCMul_zero_left rCZero, rCNeg_zero, rCAdd_zero_right]
  · change rCZero = rCAdd (rCMul a rCZero) (rCMul rCZero b)
    rw [rCMul_zero_right a, rCMul_zero_left b, rCAdd_zero_left]

/-- Research H6 commutative-ring and quadratic-coordinate package. -/
structure CauchyPairRingCertificate where
  nontrivial : ccZero ≠ ccOne
  embeddingInjective : ∀ {a b : RCBOMA}, ccOfR a = ccOfR b → a = b
  addComm : ∀ z w : CCBOMA, ccAdd z w = ccAdd w z
  addAssoc : ∀ z w v : CCBOMA, ccAdd (ccAdd z w) v = ccAdd z (ccAdd w v)
  addZeroLeft : ∀ z : CCBOMA, ccAdd ccZero z = z
  addInverseRight : ∀ z : CCBOMA, ccAdd z (ccNeg z) = ccZero
  mulComm : ∀ z w : CCBOMA, ccMul z w = ccMul w z
  mulAssoc : ∀ z w v : CCBOMA, ccMul (ccMul z w) v = ccMul z (ccMul w v)
  mulOneLeft : ∀ z : CCBOMA, ccMul ccOne z = z
  distribRight : ∀ z w v : CCBOMA,
    ccMul z (ccAdd w v) = ccAdd (ccMul z w) (ccMul z v)
  mulZeroRight : ∀ z : CCBOMA, ccMul z ccZero = ccZero
  embeddingZero : ccOfR rCZero = ccZero
  embeddingOne : ccOfR rCOne = ccOne
  embeddingNeg : ∀ a : RCBOMA, ccOfR (rCNeg a) = ccNeg (ccOfR a)
  embeddingAdd : ∀ a b : RCBOMA,
    ccOfR (rCAdd a b) = ccAdd (ccOfR a) (ccOfR b)
  embeddingMul : ∀ a b : RCBOMA,
    ccOfR (rCMul a b) = ccMul (ccOfR a) (ccOfR b)
  imagSquared : ccMul ccI ccI = ccNeg ccOne
  generation : ∀ z : CCBOMA,
    ∃ a b : RCBOMA, z = ccAdd (ccOfR a) (ccMul (ccOfR b) ccI)
  coordinateUnique : ∀ {a b a' b' : RCBOMA},
    ccAdd (ccOfR a) (ccMul (ccOfR b) ccI) =
      ccAdd (ccOfR a') (ccMul (ccOfR b') ccI) → a = a' ∧ b = b'
  imagNotReal : ¬ ∃ a : RCBOMA, ccI = ccOfR a

theorem cauchyPairRingCertificate : CauchyPairRingCertificate where
  nontrivial := cc_zero_ne_one
  embeddingInjective := @cc_ofR_injective
  addComm := cc_add_comm
  addAssoc := cc_add_assoc
  addZeroLeft := cc_add_zero_left
  addInverseRight := cc_add_neg_right
  mulComm := cc_mul_comm
  mulAssoc := cc_mul_assoc
  mulOneLeft := cc_mul_one_left
  distribRight := cc_mul_add_right
  mulZeroRight := cc_mul_zero_right
  embeddingZero := cc_ofR_zero
  embeddingOne := cc_ofR_one
  embeddingNeg := cc_ofR_neg
  embeddingAdd := cc_ofR_add
  embeddingMul := cc_ofR_mul
  imagSquared := cc_i_squared
  generation := cc_generation
  coordinateUnique := @cc_coordinate_unique
  imagNotReal := cc_i_not_real

/-- Conjugation reverses the alternative-real imaginary coordinate. -/
def ccConj (z : CCBOMA) : CCBOMA := ⟨z.re, rCNeg z.im⟩

/-- The H6 real-valued norm is the sum of the two alternative-real squares. -/
def ccNorm (z : CCBOMA) : RCBOMA := rCAdd (rCMul z.re z.re) (rCMul z.im z.im)

theorem cc_conj_involutive (z : CCBOMA) : ccConj (ccConj z) = z := by
  apply cc_ext
  · rfl
  · exact rCNeg_involutive z.im

theorem cc_mul_conj (z : CCBOMA) : ccMul z (ccConj z) = ccOfR (ccNorm z) := by
  apply cc_ext
  · change
      rCAdd (rCMul z.re z.re) (rCNeg (rCMul z.im (rCNeg z.im))) =
        rCAdd (rCMul z.re z.re) (rCMul z.im z.im)
    rw [rCMul_neg_right z.im z.im, rCNeg_involutive]
  · change rCAdd (rCMul z.re (rCNeg z.im)) (rCMul z.im z.re) = rCZero
    rw [rCMul_neg_right z.re z.im, rCMul_comm z.im z.re,
      rCAdd_comm (rCNeg (rCMul z.re z.im)) (rCMul z.re z.im),
      rCAdd_neg_right]

/-- A nonnegative alternative-real sum equal to zero has zero first summand. -/
theorem rC_nonnegative_sum_zero_left {a b : RCBOMA}
    (h0a : rCLE rCZero a) (h0b : rCLE rCZero b)
    (hsum : rCAdd a b = rCZero) : a = rCZero := by
  have ha0 : rCLE a rCZero := by
    have h := rcle_add_right h0b a
    rw [rCAdd_zero_left a, rCAdd_comm b a, hsum] at h
    exact h
  exact rcle_antisymm ha0 h0a

/-- A nonnegative alternative-real sum equal to zero has zero second summand. -/
theorem rC_nonnegative_sum_zero_right {a b : RCBOMA}
    (h0a : rCLE rCZero a) (h0b : rCLE rCZero b)
    (hsum : rCAdd a b = rCZero) : b = rCZero := by
  apply rC_nonnegative_sum_zero_left h0b h0a
  rw [rCAdd_comm b a, hsum]

theorem cc_norm_nonnegative (z : CCBOMA) : rCLE rCZero (ccNorm z) := by
  have h0re := rC_square_nonnegative z.re
  have h0im := rC_square_nonnegative z.im
  have h := rcle_add_right h0im (rCMul z.re z.re)
  rw [rCAdd_zero_left, rCAdd_comm (rCMul z.im z.im) (rCMul z.re z.re)] at h
  exact rcle_trans h0re h

theorem cc_norm_zero_real_square (z : CCBOMA) (hnorm : ccNorm z = rCZero) :
    rCMul z.re z.re = rCZero := by
  exact rC_nonnegative_sum_zero_left
    (rC_square_nonnegative z.re) (rC_square_nonnegative z.im) hnorm

theorem cc_norm_zero_imag_square (z : CCBOMA) (hnorm : ccNorm z = rCZero) :
    rCMul z.im z.im = rCZero := by
  exact rC_nonnegative_sum_zero_right
    (rC_square_nonnegative z.re) (rC_square_nonnegative z.im) hnorm

/-- A zero square contradicts any supplied alternative-real nonzero witness. -/
theorem rC_square_zero_not_nonzero {a : RCBOMA}
    (hsquare : rCMul a a = rCZero) : ¬ a ≠ rCZero := by
  intro hnonzero
  rcases rC_inverse_exists a hnonzero with ⟨t, ht⟩
  unfold RCInvRel at ht
  have hzero : a = rCZero := by
    calc
      a = rCMul a rCOne := (rCMul_one_right_local a).symm
      _ = rCMul a (rCMul a t) := by rw [ht]
      _ = rCMul (rCMul a a) t := (rCMul_assoc a a t).symm
      _ = rCMul rCZero t := by rw [hsquare]
      _ = rCZero := rCMul_zero_left t
  exact hnonzero hzero

/-- Zero norm contradicts a supplied nonzero H6 complex witness. -/
theorem cc_norm_zero_not_nonzero (z : CCBOMA)
    (hnorm : ccNorm z = rCZero) : ¬ z ≠ ccZero := by
  intro hnonzero
  have hre := rC_square_zero_not_nonzero (cc_norm_zero_real_square z hnorm)
  have him := rC_square_zero_not_nonzero (cc_norm_zero_imag_square z hnorm)
  apply hre
  intro hzre
  apply him
  intro hzim
  apply hnonzero
  apply cc_ext
  · exact hzre
  · exact hzim

theorem cc_norm_nonzero {z : CCBOMA}
    (hnonzero : z ≠ ccZero) : ccNorm z ≠ rCZero := by
  intro hnorm
  exact cc_norm_zero_not_nonzero z hnorm hnonzero

/-- A real inverse witness for the H6 norm determines a complex inverse
    witness; no inverse selector is introduced. -/
theorem cc_inverse_from_real_witness (z : CCBOMA) (t : RCBOMA)
    (ht : rCMul (ccNorm z) t = rCOne) :
    ccMul z (ccMul (ccOfR t) (ccConj z)) = ccOne := by
  calc
    ccMul z (ccMul (ccOfR t) (ccConj z)) =
        ccMul z (ccMul (ccConj z) (ccOfR t)) := by
      rw [cc_mul_comm (ccOfR t) (ccConj z)]
    _ = ccMul (ccMul z (ccConj z)) (ccOfR t) :=
      (cc_mul_assoc z (ccConj z) (ccOfR t)).symm
    _ = ccMul (ccOfR (ccNorm z)) (ccOfR t) := by rw [cc_mul_conj z]
    _ = ccOfR (rCMul (ccNorm z) t) := (cc_ofR_mul (ccNorm z) t).symm
    _ = ccOfR rCOne := by rw [ht]
    _ = ccOne := cc_ofR_one

/-- H6 preserves the witness-only field interface. -/
theorem cc_inverse_exists (z : CCBOMA) (hnonzero : z ≠ ccZero) :
    ∃ w : CCBOMA, ccMul z w = ccOne := by
  rcases rC_inverse_exists (ccNorm z) (cc_norm_nonzero hnonzero) with ⟨t, ht⟩
  unfold RCInvRel at ht
  exact ⟨ccMul (ccOfR t) (ccConj z), cc_inverse_from_real_witness z t ht⟩

/-- H6 inverse witnesses are unique by the proved commutative-ring laws. -/
theorem cc_inverse_unique {z w v : CCBOMA}
    (hw : ccMul z w = ccOne) (hv : ccMul z v = ccOne) : w = v := by
  calc
    w = ccMul w ccOne := (cc_mul_one_right w).symm
    _ = ccMul w (ccMul z v) := by rw [hv]
    _ = ccMul (ccMul w z) v := (cc_mul_assoc w z v).symm
    _ = ccMul ccOne v := by rw [cc_mul_comm w z, hw]
    _ = v := cc_mul_one_left v

/-- Full research-only H6 certificate.  It explicitly packages the independently
    completed H4 real route together with the selected quadratic-field meaning
    rebuilt natively over that real carrier. -/
structure CauchyQuadraticFieldCertificate where
  realRoute : CauchyLUBCertificate
  ring : CauchyPairRingCertificate
  normNonnegative : ∀ z : CCBOMA, rCLE rCZero (ccNorm z)
  normNonzero : ∀ z : CCBOMA, z ≠ ccZero → ccNorm z ≠ rCZero
  conjugateProduct : ∀ z : CCBOMA, ccMul z (ccConj z) = ccOfR (ccNorm z)
  inverseExists : ∀ z : CCBOMA, z ≠ ccZero → ∃ w : CCBOMA, ccMul z w = ccOne
  inverseUnique : ∀ {z w v : CCBOMA},
    ccMul z w = ccOne → ccMul z v = ccOne → w = v

theorem cauchyQuadraticFieldCertificate : CauchyQuadraticFieldCertificate where
  realRoute := cauchyLUBCertificate
  ring := cauchyPairRingCertificate
  normNonnegative := cc_norm_nonnegative
  normNonzero := fun _ h => cc_norm_nonzero h
  conjugateProduct := cc_mul_conj
  inverseExists := cc_inverse_exists
  inverseUnique := @cc_inverse_unique

end BOMA.C.StageTwo.CauchyQuadratic003

/- ST2-EXP-011 Gate E: native Cauchy/H6 instantiation of the scalar-generic
   quadratic comparison core.

This source is intended to be assembled only after the independent Cauchy real
manifest and the H6 Cauchy quadratic rebuild. It contains no Dedekind/H5
transport and does not consume the accepted RBOMA comparison adapter. -/
namespace BOMA.C.StageTwo.ComparisonInterface011.NativeCauchy

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.C.StageTwo.CauchyQuadratic003
open BOMA.C.StageTwo.ComparisonInterface011

/-- Native alternative-real scalar operations. -/
def cauchyScalarOps : ScalarOps where
  carrier := RCBOMA
  zero := rCZero
  one := rCOne
  neg := rCNeg
  add := rCAdd
  mul := rCMul

/-- H6 itself is directly a minimal comparison presentation over RCBOMA.
    Coordinate laws are definitional for the H6 pair carrier. -/
def h6Presentation : QuadraticPresentation cauchyScalarOps where
  carrier := CCBOMA
  zero := ccZero
  one := ccOne
  neg := ccNeg
  add := ccAdd
  mul := ccMul
  ofScalar := ccOfR
  imag := ccI
  coord := fun a b => ⟨a, b⟩
  coordinateGeneration := by
    intro z
    exact ⟨z.re, z.im, by cases z; rfl⟩
  coordinateUnique := by
    intro a b c d h
    exact ⟨congrArg CCBOMA.re h, congrArg CCBOMA.im h⟩
  coordinateZero := rfl
  coordinateOne := rfl
  coordinateReal := by intro a; rfl
  coordinateImag := rfl
  coordinateNeg := by intro a b; rfl
  coordinateAdd := by intro a b c d; rfl
  coordinateMul := by intro a b c d; rfl

/-- Gate E: relation-level comparison elaborates natively over RCBOMA/H6. -/
theorem h6NativeSelfComparison :
    QuadraticComparisonCertificate h6Presentation h6Presentation :=
  quadraticComparison h6Presentation h6Presentation

/-- H6 has explicit pair projections, hence explicit extractor data; no choice
    principle is introduced by the generic comparison layer. -/
def h6Extractor : CoordinateExtractor h6Presentation where
  re := fun z => z.re
  im := fun z => z.im
  sound := by intro z; cases z; rfl

/-- Functional comparison is available only because h6Extractor is supplied. -/
def h6NativeSelfIsomorphism :
    ConstructiveQuadraticIsomorphism h6Presentation h6Presentation :=
  constructiveQuadraticIsomorphism
    h6Presentation h6Presentation h6Extractor h6Extractor

end BOMA.C.StageTwo.ComparisonInterface011.NativeCauchy

/- ST2-EXP-014: full nine-Claim C meaning assembled natively over RCBOMA.

This source does not rebuild the H6 mathematics. It packages the already
verified H6 Cauchy quadratic field content together with the ST2-EXP-011 native
comparison interface, producing a research-only full C Claim-surface
certificate. No H5/Dedekind implementation transport or global selector is
introduced here. -/
namespace BOMA.C.StageTwo.CauchyNativeFullC014

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.C.StageTwo.CauchyQuadratic003
open BOMA.C.StageTwo.ComparisonInterface011
open BOMA.C.StageTwo.ComparisonInterface011.NativeCauchy

/-- Relation-level comparison from the native H6 presentation to any other
    quadratic presentation over the same Cauchy scalar operations. -/
theorem cauchyNativeComparison
    (B : QuadraticPresentation cauchyScalarOps) :
    QuadraticComparisonCertificate h6Presentation B :=
  quadraticComparison h6Presentation B

/-- Functional comparison remains conditional on explicit target coordinate
    extractor data. The source extractor is explicit pair projection data from
    H6, not a selected global witness. -/
def cauchyNativeFunctionalComparison
    (B : QuadraticPresentation cauchyScalarOps)
    (E : CoordinateExtractor B) :
    ConstructiveQuadraticIsomorphism h6Presentation B :=
  constructiveQuadraticIsomorphism
    h6Presentation B h6Extractor E

/-- Research-only full C Claim-surface package over the independent Cauchy real
    producer. It mirrors the accepted Stage-One C integration *meaning* while
    preserving the narrower ST2-EXP-011 comparison interface. -/
structure CauchyNativeFullCCertificate where
  field : CauchyQuadraticFieldCertificate
  generatorSquared : ccMul ccI ccI = ccNeg ccOne
  realGeneration : ∀ z : CCBOMA,
    ∃ a b : RCBOMA, z = ccAdd (ccOfR a) (ccMul (ccOfR b) ccI)
  coordinateUnique : ∀ {a b c d : RCBOMA},
    ccAdd (ccOfR a) (ccMul (ccOfR b) ccI) =
      ccAdd (ccOfR c) (ccMul (ccOfR d) ccI) → a = c ∧ b = d
  imaginaryNotReal : ¬ ∃ a : RCBOMA, ccI = ccOfR a
  comparison : ∀ (B : QuadraticPresentation cauchyScalarOps),
    QuadraticComparisonCertificate h6Presentation B
  functionalComparison : ∀ (B : QuadraticPresentation cauchyScalarOps),
    CoordinateExtractor B →
      ConstructiveQuadraticIsomorphism h6Presentation B

/-- Full research-only nine-Claim closure root for ST2-EXP-014. -/
def cauchyNativeFullCCertificate : CauchyNativeFullCCertificate where
  field := cauchyQuadraticFieldCertificate
  generatorSquared := cc_i_squared
  realGeneration := cc_generation
  coordinateUnique := @cc_coordinate_unique
  imaginaryNotReal := cc_i_not_real
  comparison := cauchyNativeComparison
  functionalComparison := cauchyNativeFunctionalComparison

/-- Explicit Claim-root aliases make the nine-family audit independent of
    incidental structure-field projection names. -/
theorem claim_rembed_injective {a b : RCBOMA}
    (h : ccOfR a = ccOfR b) : a = b :=
  cc_ofR_injective h

theorem claim_i_squared : ccMul ccI ccI = ccNeg ccOne :=
  cc_i_squared

theorem claim_generated (z : CCBOMA) :
    ∃ a b : RCBOMA, z = ccAdd (ccOfR a) (ccMul (ccOfR b) ccI) :=
  cc_generation z

theorem claim_coordinate_unique {a b c d : RCBOMA}
    (h : ccAdd (ccOfR a) (ccMul (ccOfR b) ccI) =
      ccAdd (ccOfR c) (ccMul (ccOfR d) ccI)) : a = c ∧ b = d :=
  cc_coordinate_unique h

theorem claim_imaginary_not_real : ¬ ∃ a : RCBOMA, ccI = ccOfR a :=
  cc_i_not_real

end BOMA.C.StageTwo.CauchyNativeFullC014

/- ST2-EXP-015 Gate C: admitted only after independent native Q closure. -/
namespace BOMA.C.StageTwo.NativePQ015

open BOMA.C.StageTwo.ComparisonInterface011
open BOMA.C.StageTwo.ComparisonInterface011.NativeCauchy
open BOMA.C.StageTwo.QPresentation015
open BOMA.C.StageTwo.QQuotientField015
open BOMA.C.StageTwo.CauchyQuadratic003
open BOMA.C.StageTwo.CauchyNativeFullC014

/-- Both extractors are explicit representation data. -/
def pqIsomorphism : ConstructiveQuadraticIsomorphism h6Presentation qPresentation :=
  constructiveQuadraticIsomorphism h6Presentation qPresentation h6Extractor qExtractor

def qpIsomorphism : ConstructiveQuadraticIsomorphism qPresentation h6Presentation :=
  constructiveQuadraticIsomorphism qPresentation h6Presentation qExtractor h6Extractor

def pToQ (z : CCBOMA) : QBOMA := pqIsomorphism.forward z
def qToP (z : QBOMA) : CCBOMA := pqIsomorphism.backward z

theorem pToQ_formula (z : CCBOMA) : pToQ z = qCoord z.re z.im := rfl
theorem qToP_formula (z : QBOMA) : qToP z = ⟨qRe z, qIm z⟩ := rfl

theorem forward_inverse_witness {x y : CCBOMA} (h : ccMul x y = ccOne) :
    qMul (pToQ x) (pToQ y) = qOne := by
  calc
    qMul (pToQ x) (pToQ y) = pToQ (ccMul x y) :=
      (pqIsomorphism.preserveMul x y).symm
    _ = pToQ ccOne := congrArg pToQ h
    _ = qOne := pqIsomorphism.preserveOne

theorem reverse_inverse_witness {x y : QBOMA} (h : qMul x y = qOne) :
    ccMul (qToP x) (qToP y) = ccOne := by
  calc
    ccMul (qToP x) (qToP y) = qToP (qMul x y) :=
      (qpIsomorphism.preserveMul x y).symm
    _ = qToP qOne := congrArg qToP h
    _ = ccOne := qpIsomorphism.preserveOne

structure NativePQJunctionCertificate where
  independentQ : NativeQFullCertificate
  fixedP : CauchyNativeFullCCertificate
  comparison : QuadraticComparisonCertificate h6Presentation qPresentation
  forward : ConstructiveQuadraticIsomorphism h6Presentation qPresentation
  reverse : ConstructiveQuadraticIsomorphism qPresentation h6Presentation
  forwardInverseWitness : ∀ {x y : CCBOMA}, ccMul x y = ccOne →
    qMul (pToQ x) (pToQ y) = qOne
  reverseInverseWitness : ∀ {x y : QBOMA}, qMul x y = qOne →
    ccMul (qToP x) (qToP y) = ccOne

def nativePQJunctionCertificate : NativePQJunctionCertificate where
  independentQ := nativeQFullCertificate
  fixedP := cauchyNativeFullCCertificate
  comparison := quadraticComparison h6Presentation qPresentation
  forward := pqIsomorphism
  reverse := qpIsomorphism
  forwardInverseWitness := @forward_inverse_witness
  reverseInverseWitness := @reverse_inverse_witness

end BOMA.C.StageTwo.NativePQ015

/- ST2-EXP-003 H5 comparison foundation.

   This file is intentionally COMBINED rather than independent: the workflow
   assembles the unchanged accepted Dedekind R manifest first, then the
   research-only Cauchy addendum ending in this source.  No accepted producer
   is modified and no research Junction is declared here.

   The first comparison layer constructs canonical (choice-selected) LUB maps
   in both directions from the same accepted rational carrier.  Each map is
   proved to preserve the rational embedding exactly and to be monotone.  The
   later H5 layer may prove order reflection / mutual inverse laws and only then
   decide whether an R-field research Junction is justified. -/
namespace BOMA.R.StageTwo.DedekindCauchyComparison003

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindStrictOrder001
open BOMA.R.DedekindCompleteness001
open BOMA.R.DedekindRationalDensity001
open BOMA.R.DedekindArchimedean001
open BOMA.R.StageIntegration002
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyLUBBracket003
open BOMA.R.StageTwo.CauchyLUB003

/-- Accepted Dedekind reals have an embedded rational strictly below them.
    This is representation elimination only; it introduces no new selector. -/
theorem dedekind_rational_strict_lower_exists (x : RBOMA) :
    ∃ q : QBOMA, rLT (rOfQ q) x := by
  refine Quotient.inductionOn x ?_
  intro A
  rcases A.nonempty with ⟨a, ha⟩
  rcases A.rounded ha with ⟨b, hb, hab⟩
  refine ⟨b, ?_⟩
  change rLT (rmk (principalCut b)) (rmk A)
  apply (rlt_mk_iff (principalCut b) A).2
  constructor
  · intro q hq
    exact A.downward hb hq.1
  · intro hEq
    have hbb : (principalCut b).lower b := (hEq b).2 hb
    exact (qlt_irrefl b) hbb

/-- Accepted Archimedean evidence gives a rational (non-strict) upper bound. -/
theorem dedekind_rational_upper_exists (x : RBOMA) :
    ∃ q : QBOMA, rLE x (rOfQ q) := by
  rcases r_archimedean_strict_upper x with ⟨n, hn⟩
  exact ⟨qOfN n, hn.1⟩

/-- One explicit rational upper endpoint for a Cauchy real.  The only choice
    here is the already localized rational-approximation witness exported by
    the independent route. -/
noncomputable def cUpperQ (x : RCBOMA) : QBOMA :=
  Classical.choose (rational_upper_exists x qOne qzero_lt_one)

theorem cUpperQ_spec (x : RCBOMA) :
    rCLE x (rCOfQ (cUpperQ x)) :=
  Classical.choose_spec (rational_upper_exists x qOne qzero_lt_one)

/-- One explicit rational upper endpoint for an accepted Dedekind real. -/
noncomputable def dUpperQ (x : RBOMA) : QBOMA :=
  Classical.choose (dedekind_rational_upper_exists x)

theorem dUpperQ_spec (x : RBOMA) :
    rLE x (rOfQ (dUpperQ x)) :=
  Classical.choose_spec (dedekind_rational_upper_exists x)

/-- Dedekind-side image of all accepted rationals lying below a Cauchy real. -/
def CToDFamily (x : RCBOMA) (y : RBOMA) : Prop :=
  ∃ q : QBOMA, y = rOfQ q ∧ rCLE (rCOfQ q) x

/-- Cauchy-side image of all accepted rationals lying below a Dedekind real. -/
def DToCFamily (x : RBOMA) (y : RCBOMA) : Prop :=
  ∃ q : QBOMA, y = rCOfQ q ∧ rLE (rOfQ q) x

theorem cToDFamily_nonempty (x : RCBOMA) :
    ∃ y : RBOMA, CToDFamily x y := by
  rcases rational_strict_lower_exists x qOne qzero_lt_one with ⟨q, hq⟩
  exact ⟨rOfQ q, q, rfl, hq.1⟩

theorem cToDFamily_upper (x : RCBOMA) :
    RUpperBound (CToDFamily x) (rOfQ (cUpperQ x)) := by
  intro y hy
  rcases hy with ⟨q, rfl, hqx⟩
  apply (rOfQ_order q (cUpperQ x)).2
  apply (rCOfQ_order q (cUpperQ x)).1
  exact rcle_trans hqx (cUpperQ_spec x)

theorem dToCFamily_nonempty (x : RBOMA) :
    ∃ y : RCBOMA, DToCFamily x y := by
  rcases dedekind_rational_strict_lower_exists x with ⟨q, hq⟩
  exact ⟨rCOfQ q, q, rfl, hq.1⟩

theorem dToCFamily_upper (x : RBOMA) :
    RCUpperBound (DToCFamily x) (rCOfQ (dUpperQ x)) := by
  intro y hy
  rcases hy with ⟨q, rfl, hqx⟩
  apply (rCOfQ_order q (dUpperQ x)).2
  apply (rOfQ_order q (dUpperQ x)).1
  exact rLE_trans hqx (dUpperQ_spec x)

/-- The accepted Dedekind LUB of the rational envelope below a Cauchy real. -/
theorem cToD_lub_exists (x : RCBOMA) :
    ∃ s : RBOMA,
      (∀ y : RBOMA, CToDFamily x y → rLE y s) ∧
      (∀ B : RBOMA, RUpperBound (CToDFamily x) B → rLE s B) :=
  rDedekind_lub_exists
    (CToDFamily x)
    (cToDFamily_nonempty x)
    (rOfQ (cUpperQ x))
    (cToDFamily_upper x)

/-- H5 comparison map from the independent Cauchy carrier into the accepted
    Dedekind carrier.  Choice selects the LUB already proved to exist. -/
noncomputable def cToD (x : RCBOMA) : RBOMA :=
  Classical.choose (cToD_lub_exists x)

theorem cToD_spec (x : RCBOMA) :
    (∀ y : RBOMA, CToDFamily x y → rLE y (cToD x)) ∧
    (∀ B : RBOMA, RUpperBound (CToDFamily x) B → rLE (cToD x) B) :=
  Classical.choose_spec (cToD_lub_exists x)

/-- The independent Cauchy LUB of the rational envelope below a Dedekind real. -/
theorem dToC_lub_exists (x : RBOMA) :
    ∃ s : RCBOMA,
      (∀ y : RCBOMA, DToCFamily x y → rCLE y s) ∧
      (∀ B : RCBOMA, RCUpperBound (DToCFamily x) B → rCLE s B) :=
  rCauchy_lub_exists
    (DToCFamily x)
    (dToCFamily_nonempty x)
    (rCOfQ (dUpperQ x))
    (dToCFamily_upper x)

/-- H5 comparison map from the accepted Dedekind carrier into the independent
    Cauchy carrier.  Choice selects the independently proved H4 LUB. -/
noncomputable def dToC (x : RBOMA) : RCBOMA :=
  Classical.choose (dToC_lub_exists x)

theorem dToC_spec (x : RBOMA) :
    (∀ y : RCBOMA, DToCFamily x y → rCLE y (dToC x)) ∧
    (∀ B : RCBOMA, RCUpperBound (DToCFamily x) B → rCLE (dToC x) B) :=
  Classical.choose_spec (dToC_lub_exists x)

/-- The Cauchy-to-Dedekind comparison fixes every accepted rational exactly. -/
theorem cToD_rational (q : QBOMA) :
    cToD (rCOfQ q) = rOfQ q := by
  apply rLE_antisymm
  · apply (cToD_spec (rCOfQ q)).2
    intro y hy
    rcases hy with ⟨r, rfl, hrq⟩
    exact (rOfQ_order r q).2 ((rCOfQ_order r q).1 hrq)
  · apply (cToD_spec (rCOfQ q)).1
    exact ⟨q, rfl, rcle_refl (rCOfQ q)⟩

/-- The Dedekind-to-Cauchy comparison fixes every accepted rational exactly. -/
theorem dToC_rational (q : QBOMA) :
    dToC (rOfQ q) = rCOfQ q := by
  apply rcle_antisymm
  · apply (dToC_spec (rOfQ q)).2
    intro y hy
    rcases hy with ⟨r, rfl, hrq⟩
    exact (rCOfQ_order r q).2 ((rOfQ_order r q).1 hrq)
  · apply (dToC_spec (rOfQ q)).1
    exact ⟨q, rfl, rLE_refl (rOfQ q)⟩

/-- The first comparison map is monotone. -/
theorem cToD_mono {x y : RCBOMA} (hxy : rCLE x y) :
    rLE (cToD x) (cToD y) := by
  apply (cToD_spec x).2
  intro z hz
  apply (cToD_spec y).1
  rcases hz with ⟨q, rfl, hqx⟩
  exact ⟨q, rfl, rcle_trans hqx hxy⟩

/-- The reverse comparison map is monotone. -/
theorem dToC_mono {x y : RBOMA} (hxy : rLE x y) :
    rCLE (dToC x) (dToC y) := by
  apply (dToC_spec x).2
  intro z hz
  apply (dToC_spec y).1
  rcases hz with ⟨q, rfl, hqx⟩
  exact ⟨q, rfl, rLE_trans hqx hxy⟩

/-- Machine-checkable H5 foundation.  This is deliberately weaker than a
    research Junction: no injectivity, mutual inverse, or field-homomorphism
    claim is made until those properties are separately proved. -/
structure DedekindCauchyComparisonFoundationCertificate where
  acceptedRoute : RStageIntegrationCertificate
  cauchyRoute : CauchyLUBCertificate
  cToDMap : RCBOMA → RBOMA
  dToCMap : RBOMA → RCBOMA
  cToDRational : ∀ q : QBOMA, cToDMap (rCOfQ q) = rOfQ q
  dToCRational : ∀ q : QBOMA, dToCMap (rOfQ q) = rCOfQ q
  cToDMonotone : ∀ {x y : RCBOMA}, rCLE x y → rLE (cToDMap x) (cToDMap y)
  dToCMonotone : ∀ {x y : RBOMA}, rLE x y → rCLE (dToCMap x) (dToCMap y)

noncomputable def dedekindCauchyComparisonFoundationCertificate :
    DedekindCauchyComparisonFoundationCertificate where
  acceptedRoute := rStageIntegrationCertificate
  cauchyRoute := cauchyLUBCertificate
  cToDMap := cToD
  dToCMap := dToC
  cToDRational := cToD_rational
  dToCRational := dToC_rational
  cToDMonotone := @cToD_mono
  dToCMonotone := @dToC_mono

end BOMA.R.StageTwo.DedekindCauchyComparison003

/- ST2-EXP-003 H5 comparison density layer.

   This source extends the already verified H5 foundation without changing it.
   It proves strict density of the accepted rational image inside the
   independently constructed Cauchy real order.  The proof uses only the
   independent Cauchy ordered-field route and its rational approximation/gap
   interfaces; it does not use the selected Dedekind density theorem.

   This is still pre-reconvergence: no order reflection, mutual inverse,
   field-isomorphism, or research Junction claim is made here. -/
namespace BOMA.R.StageTwo.DedekindCauchyComparison003

open BOMA.NCore.RB001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.CauchyProbe001
open BOMA.R.StageTwo.CauchyCloseness003
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderedRing003
open BOMA.R.StageTwo.CauchyNonzeroGap003
open BOMA.R.StageTwo.CauchyCompletionCore003
open BOMA.R.StageTwo.CauchyDensity003
open BOMA.R.StageTwo.CauchyLUBBracket003

/-- Left additive inverse derived from commutativity and the verified right
    inverse law. -/
theorem h5_rCAdd_neg_left (x : RCBOMA) :
    rCAdd (rCNeg x) x = rCZero := by
  rw [rCAdd_comm, rCAdd_neg_right]

/-- Right-additive cancellation on the independent Cauchy quotient. -/
theorem h5_rCAdd_right_cancel {x y z : RCBOMA}
    (h : rCAdd x z = rCAdd y z) : x = y := by
  have ht := congrArg (fun t => rCAdd t (rCNeg z)) h
  calc
    x = rCAdd x rCZero := (rCAdd_zero_right x).symm
    _ = rCAdd x (rCAdd z (rCNeg z)) := by rw [rCAdd_neg_right]
    _ = rCAdd (rCAdd x z) (rCNeg z) :=
      (rCAdd_assoc x z (rCNeg z)).symm
    _ = rCAdd (rCAdd y z) (rCNeg z) := ht
    _ = rCAdd y (rCAdd z (rCNeg z)) :=
      rCAdd_assoc y z (rCNeg z)
    _ = rCAdd y rCZero := by rw [rCAdd_neg_right]
    _ = y := rCAdd_zero_right y

/-- Strict Cauchy order is preserved by a common additive translate. -/
theorem h5_rclt_add_right {x y : RCBOMA}
    (hxy : rCLT x y) (z : RCBOMA) :
    rCLT (rCAdd x z) (rCAdd y z) := by
  refine ⟨rcle_add_right hxy.1 z, ?_⟩
  intro heq
  exact hxy.2 (h5_rCAdd_right_cancel heq)

/-- A strictly positive Cauchy real admits a positive embedded rational below
    it.  This is extracted from the independently verified eventual positive
    gap of a nonzero Cauchy representative. -/
theorem h5_positive_rational_below {x : RCBOMA}
    (h0x : rCLT rCZero x) :
    ∃ delta : QBOMA, qPos delta ∧ rCLE (rCOfQ delta) x := by
  refine Quotient.inductionOn x ?_ h0x
  intro u hu
  have hgap := eventually_positive_gap_of_nonzero
    u hu.1 (fun h => hu.2 h.symm)
  rcases hgap with ⟨delta, hdelta, N, hN⟩
  refine ⟨delta, hdelta, ?_⟩
  change CauchyLE (cauchyOfQ delta) u
  intro eps heps
  refine ⟨N, ?_⟩
  intro n hn
  change qLE delta (qAdd (u.seq n) eps)
  exact qle_trans (hN n hn) (qLE_self_add_pos (u.seq n) heps)

/-- The accepted rational image is strictly order-dense in the independently
    constructed Cauchy carrier.  No selected Dedekind theorem occurs in this
    proof. -/
theorem rC_rational_image_dense {x y : RCBOMA}
    (hxy : rCLT x y) :
    ∃ q : QBOMA,
      rCLT x (rCOfQ q) ∧ rCLT (rCOfQ q) y := by
  let d : RCBOMA := rCAdd y (rCNeg x)
  have h0d : rCLE rCZero d := by
    have ht := rcle_add_right hxy.1 (rCNeg x)
    rw [rCAdd_neg_right x] at ht
    exact ht
  have hdne : d ≠ rCZero := by
    intro hd0
    have ht := congrArg (fun t => rCAdd t x) hd0
    have hleft : rCAdd d x = y := by
      unfold d
      calc
        rCAdd (rCAdd y (rCNeg x)) x =
            rCAdd y (rCAdd (rCNeg x) x) :=
          rCAdd_assoc y (rCNeg x) x
        _ = rCAdd y rCZero := by rw [h5_rCAdd_neg_left]
        _ = y := rCAdd_zero_right y
    have hright : rCAdd rCZero x = x := rCAdd_zero_left x
    rw [hleft, hright] at ht
    exact hxy.2 ht.symm
  have h0dStrict : rCLT rCZero d :=
    ⟨h0d, fun h => hdne h.symm⟩
  rcases h5_positive_rational_below h0dStrict with
    ⟨delta, hdelta, hdeltaD⟩
  rcases positive_half_exists hdelta with
    ⟨half, hhalf, hhalfSum⟩
  rcases positive_half_exists hhalf with
    ⟨quarter, hquarter, hquarterSum⟩
  rcases rational_approximation_exists x quarter hquarter with
    ⟨a, ha⟩
  let q : QBOMA := qAdd a half

  have hquarterHalf : qLT quarter half := by
    have ht := qlt_add_right hquarter quarter
    rw [qAdd_zero_left, hquarterSum] at ht
    exact ht
  have hthreeDelta : qLT (qAdd quarter half) delta := by
    have ht := qlt_add_right hquarterHalf half
    rw [hhalfSum] at ht
    exact ht

  refine ⟨q, ?_, ?_⟩
  · have hxApprox : rCLE x (rCOfQ (qAdd a quarter)) := by
      have ht := ha.1
      rw [rCOfQ_add] at ht
      exact ht
    have hApproxStrict :
        rCLT (rCOfQ (qAdd a quarter)) (rCOfQ q) := by
      apply rCOfQ_strict
      have ht := qlt_add_right hquarterHalf a
      change qLT (qAdd quarter a) (qAdd half a) at ht
      rw [qAdd_comm quarter a, qAdd_comm half a] at ht
      exact ht
    exact rcle_trans_lt hxApprox hApproxStrict
  · have hqToThree :
        rCLE (rCOfQ q)
          (rCAdd x (rCOfQ (qAdd quarter half))) := by
      have ht := rcle_add_right ha.2 (rCOfQ half)
      have hleft :
          rCAdd (rCOfQ a) (rCOfQ half) = rCOfQ q := by
        unfold q
        exact rCOfQ_add a half
      have hright :
          rCAdd (rCAdd x (rCOfQ quarter)) (rCOfQ half) =
            rCAdd x (rCOfQ (qAdd quarter half)) := by
        calc
          rCAdd (rCAdd x (rCOfQ quarter)) (rCOfQ half) =
              rCAdd x (rCAdd (rCOfQ quarter) (rCOfQ half)) :=
            rCAdd_assoc x (rCOfQ quarter) (rCOfQ half)
          _ = rCAdd x (rCOfQ (qAdd quarter half)) := by
            rw [rCOfQ_add]
      rw [hleft, hright] at ht
      exact ht
    have hthreeToDelta :
        rCLT (rCAdd x (rCOfQ (qAdd quarter half)))
          (rCAdd x (rCOfQ delta)) := by
      have ht := h5_rclt_add_right (rCOfQ_strict hthreeDelta) x
      rw [rCAdd_comm (rCOfQ (qAdd quarter half)) x,
        rCAdd_comm (rCOfQ delta) x] at ht
      exact ht
    have hqToDelta :
        rCLT (rCOfQ q) (rCAdd x (rCOfQ delta)) :=
      rcle_trans_lt hqToThree hthreeToDelta
    have hxdeltaY : rCLE (rCAdd x (rCOfQ delta)) y := by
      have ht := rcle_add_right hdeltaD x
      have hright : rCAdd d x = y := by
        unfold d
        calc
          rCAdd (rCAdd y (rCNeg x)) x =
              rCAdd y (rCAdd (rCNeg x) x) :=
            rCAdd_assoc y (rCNeg x) x
          _ = rCAdd y rCZero := by rw [h5_rCAdd_neg_left]
          _ = y := rCAdd_zero_right y
      rw [rCAdd_comm (rCOfQ delta) x, hright] at ht
      exact ht
    exact rclt_trans_le hqToDelta hxdeltaY

/-- Machine-checkable H5 density milestone, deliberately weaker than order
    reflection or an isomorphism certificate. -/
structure DedekindCauchyComparisonDensityCertificate where
  foundation : DedekindCauchyComparisonFoundationCertificate
  cauchyRationalDense : ∀ {x y : RCBOMA}, rCLT x y →
    ∃ q : QBOMA,
      rCLT x (rCOfQ q) ∧ rCLT (rCOfQ q) y

noncomputable def dedekindCauchyComparisonDensityCertificate :
    DedekindCauchyComparisonDensityCertificate where
  foundation := dedekindCauchyComparisonFoundationCertificate
  cauchyRationalDense := @rC_rational_image_dense

end BOMA.R.StageTwo.DedekindCauchyComparison003

/- ST2-EXP-003 H5 order-reflection layer.

   This source builds on the exact-verified H5 foundation and Cauchy rational
   density milestone.  It first proves that each LUB comparison map reflects
   rational lower bounds, then upgrades that fact to reflection of the full
   non-strict orders in both directions.

   The result is order-embedding strength only.  Surjectivity, mutual inverse,
   order isomorphism, field isomorphism, and any research Junction remain
   outside this source. -/
namespace BOMA.R.StageTwo.DedekindCauchyComparison003

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindStrictOrder001
open BOMA.R.DedekindRationalDensity001
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyLUBBracket003

/-- A rational below the Dedekind image of a Cauchy real was already below the
    original Cauchy real.  The contradiction uses the independently proved
    Cauchy rational density and the leastness of `cToD`. -/
theorem cToD_rational_lower_reflect {q : QBOMA} {x : RCBOMA}
    (hq : rLE (rOfQ q) (cToD x)) :
    rCLE (rCOfQ q) x := by
  rcases rcle_total (rCOfQ q) x with hqx | hxq
  · exact hqx
  · by_cases hqx : rCLE (rCOfQ q) x
    · exact hqx
    · have hxqNe : x ≠ rCOfQ q := by
        intro hEq
        apply hqx
        rw [← hEq]
        exact rcle_refl x
      have hxqStrict : rCLT x (rCOfQ q) := ⟨hxq, hxqNe⟩
      rcases rC_rational_image_dense hxqStrict with
        ⟨r, hxr, hrq⟩
      have hcToDr : rLE (cToD x) (rOfQ r) := by
        apply (cToD_spec x).2
        intro z hz
        rcases hz with ⟨s, rfl, hsx⟩
        apply (rOfQ_order s r).2
        apply (rCOfQ_order s r).1
        exact rcle_trans hsx hxr.1
      have hqrQ : qLE q r :=
        (rOfQ_order q r).1 (rLE_trans hq hcToDr)
      have hrqQ : qLT r q := by
        refine ⟨(rCOfQ_order r q).1 hrq.1, ?_⟩
        intro heq
        apply hrq.2
        exact congrArg rCOfQ heq
      exact False.elim (hrqQ.2 (qle_antisymm hrqQ.1 hqrQ))

/-- Symmetrically, a rational below the Cauchy image of an accepted Dedekind
    real was already below that Dedekind real.  This direction uses the
    accepted Dedekind rational-density theorem. -/
theorem dToC_rational_lower_reflect {q : QBOMA} {x : RBOMA}
    (hq : rCLE (rCOfQ q) (dToC x)) :
    rLE (rOfQ q) x := by
  rcases rLE_total_classical (rOfQ q) x with hqx | hxq
  · exact hqx
  · by_cases hqx : rLE (rOfQ q) x
    · exact hqx
    · have hxqNe : x ≠ rOfQ q := by
        intro hEq
        apply hqx
        rw [← hEq]
        exact rLE_refl x
      have hxqStrict : rLT x (rOfQ q) := ⟨hxq, hxqNe⟩
      rcases r_rational_image_dense hxqStrict with
        ⟨r, hxr, hrq⟩
      have hdToCr : rCLE (dToC x) (rCOfQ r) := by
        apply (dToC_spec x).2
        intro z hz
        rcases hz with ⟨s, rfl, hsx⟩
        apply (rCOfQ_order s r).2
        apply (rOfQ_order s r).1
        exact rLE_trans hsx hxr.1
      have hqrQ : qLE q r :=
        (rCOfQ_order q r).1 (rcle_trans hq hdToCr)
      have hrqQ : qLT r q := (rOfQ_strict_order r q).1 hrq
      exact False.elim (hrqQ.2 (qle_antisymm hrqQ.1 hqrQ))

/-- `cToD` reflects the full non-strict order. -/
theorem cToD_order_reflect {x y : RCBOMA}
    (hmap : rLE (cToD x) (cToD y)) :
    rCLE x y := by
  rcases rcle_total x y with hxy | hyx
  · exact hxy
  · by_cases hxy : rCLE x y
    · exact hxy
    · have hyxNe : y ≠ x := by
        intro hEq
        apply hxy
        rw [← hEq]
        exact rcle_refl y
      have hyxStrict : rCLT y x := ⟨hyx, hyxNe⟩
      rcases rC_rational_image_dense hyxStrict with
        ⟨q, hyq, hqx⟩
      have hqCx : rLE (rOfQ q) (cToD x) := by
        apply (cToD_spec x).1
        exact ⟨q, rfl, hqx.1⟩
      have hqCy : rLE (rOfQ q) (cToD y) :=
        rLE_trans hqCx hmap
      have hqY : rCLE (rCOfQ q) y :=
        cToD_rational_lower_reflect hqCy
      exact False.elim (hyq.2 (rcle_antisymm hyq.1 hqY))

/-- `dToC` reflects the full non-strict order. -/
theorem dToC_order_reflect {x y : RBOMA}
    (hmap : rCLE (dToC x) (dToC y)) :
    rLE x y := by
  rcases rLE_total_classical x y with hxy | hyx
  · exact hxy
  · by_cases hxy : rLE x y
    · exact hxy
    · have hyxNe : y ≠ x := by
        intro hEq
        apply hxy
        rw [← hEq]
        exact rLE_refl y
      have hyxStrict : rLT y x := ⟨hyx, hyxNe⟩
      rcases r_rational_image_dense hyxStrict with
        ⟨q, hyq, hqx⟩
      have hqCx : rCLE (rCOfQ q) (dToC x) := by
        apply (dToC_spec x).1
        exact ⟨q, rfl, hqx.1⟩
      have hqCy : rCLE (rCOfQ q) (dToC y) :=
        rcle_trans hqCx hmap
      have hqY : rLE (rOfQ q) y :=
        dToC_rational_lower_reflect hqCy
      exact False.elim (hyq.2 (rLE_antisymm hyq.1 hqY))

/-- Exact order equivalence induced by the first comparison map. -/
theorem cToD_order_iff {x y : RCBOMA} :
    rLE (cToD x) (cToD y) ↔ rCLE x y :=
  ⟨cToD_order_reflect, cToD_mono⟩

/-- Exact order equivalence induced by the reverse comparison map. -/
theorem dToC_order_iff {x y : RBOMA} :
    rCLE (dToC x) (dToC y) ↔ rLE x y :=
  ⟨dToC_order_reflect, dToC_mono⟩

/-- Machine-checkable order-reflection milestone.  This packages two order
    embeddings, not an isomorphism. -/
structure DedekindCauchyOrderReflectionCertificate where
  density : DedekindCauchyComparisonDensityCertificate
  cToDRationalLowerReflect : ∀ {q : QBOMA} {x : RCBOMA},
    rLE (rOfQ q) (cToD x) → rCLE (rCOfQ q) x
  dToCRationalLowerReflect : ∀ {q : QBOMA} {x : RBOMA},
    rCLE (rCOfQ q) (dToC x) → rLE (rOfQ q) x
  cToDOrderIff : ∀ {x y : RCBOMA},
    rLE (cToD x) (cToD y) ↔ rCLE x y
  dToCOrderIff : ∀ {x y : RBOMA},
    rCLE (dToC x) (dToC y) ↔ rLE x y

noncomputable def dedekindCauchyOrderReflectionCertificate :
    DedekindCauchyOrderReflectionCertificate where
  density := dedekindCauchyComparisonDensityCertificate
  cToDRationalLowerReflect := @cToD_rational_lower_reflect
  dToCRationalLowerReflect := @dToC_rational_lower_reflect
  cToDOrderIff := @cToD_order_iff
  dToCOrderIff := @dToC_order_iff

end BOMA.R.StageTwo.DedekindCauchyComparison003

/- ST2-EXP-003 H5 mutual-inverse layer.

   This source builds only after the exact-verified H5 order-reflection
   milestone.  The two LUB comparison maps are proved mutually inverse by
   showing that the rational lower envelope selected by each composite is
   exactly the rational lower envelope of the original point.

   This yields an order-isomorphism certificate.  It does not yet claim
   preservation of addition, multiplication, inverses, or a field isomorphism,
   and it does not create a research Junction. -/
namespace BOMA.R.StageTwo.DedekindCauchyComparison003

open BOMA.Q.Quotient001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindStrictOrder001
open BOMA.R.DedekindRationalDensity001
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyLUBBracket003

/-- Going Cauchy → Dedekind → Cauchy returns the original Cauchy real. -/
theorem dToC_cToD (x : RCBOMA) :
    dToC (cToD x) = x := by
  apply rcle_antisymm
  · apply (dToC_spec (cToD x)).2
    intro y hy
    rcases hy with ⟨q, rfl, hq⟩
    exact cToD_rational_lower_reflect hq
  · rcases rcle_total x (dToC (cToD x)) with hforward | hback
    · exact hforward
    · by_cases hforward : rCLE x (dToC (cToD x))
      · exact hforward
      · have hne : dToC (cToD x) ≠ x := by
          intro hEq
          apply hforward
          rw [hEq]
          exact rcle_refl x
        have hstrict : rCLT (dToC (cToD x)) x := ⟨hback, hne⟩
        rcases rC_rational_image_dense hstrict with
          ⟨q, hcompq, hqx⟩
        have hqD : rLE (rOfQ q) (cToD x) := by
          apply (cToD_spec x).1
          exact ⟨q, rfl, hqx.1⟩
        have hqC : rCLE (rCOfQ q) (dToC (cToD x)) := by
          apply (dToC_spec (cToD x)).1
          exact ⟨q, rfl, hqD⟩
        exact False.elim
          (hcompq.2 (rcle_antisymm hcompq.1 hqC))

/-- Going Dedekind → Cauchy → Dedekind returns the original accepted real. -/
theorem cToD_dToC (x : RBOMA) :
    cToD (dToC x) = x := by
  apply rLE_antisymm
  · apply (cToD_spec (dToC x)).2
    intro y hy
    rcases hy with ⟨q, rfl, hq⟩
    exact dToC_rational_lower_reflect hq
  · rcases rLE_total_classical x (cToD (dToC x)) with hforward | hback
    · exact hforward
    · by_cases hforward : rLE x (cToD (dToC x))
      · exact hforward
      · have hne : cToD (dToC x) ≠ x := by
          intro hEq
          apply hforward
          rw [hEq]
          exact rLE_refl x
        have hstrict : rLT (cToD (dToC x)) x := ⟨hback, hne⟩
        rcases r_rational_image_dense hstrict with
          ⟨q, hcompq, hqx⟩
        have hqC : rCLE (rCOfQ q) (dToC x) := by
          apply (dToC_spec x).1
          exact ⟨q, rfl, hqx.1⟩
        have hqD : rLE (rOfQ q) (cToD (dToC x)) := by
          apply (cToD_spec (dToC x)).1
          exact ⟨q, rfl, hqC⟩
        exact False.elim
          (hcompq.2 (rLE_antisymm hcompq.1 hqD))

/-- Machine-checkable H5 order-isomorphism package.  The word
    "order-isomorphism" here is intentionally limited to the mutually inverse
    maps and exact order equivalences already proved; no field operations are
    included. -/
structure DedekindCauchyOrderIsomorphismCertificate where
  reflection : DedekindCauchyOrderReflectionCertificate
  cToDMap : RCBOMA → RBOMA
  dToCMap : RBOMA → RCBOMA
  cToDOrderIff : ∀ {x y : RCBOMA},
    rLE (cToDMap x) (cToDMap y) ↔ rCLE x y
  dToCOrderIff : ∀ {x y : RBOMA},
    rCLE (dToCMap x) (dToCMap y) ↔ rLE x y
  leftInverse : ∀ x : RCBOMA, dToCMap (cToDMap x) = x
  rightInverse : ∀ x : RBOMA, cToDMap (dToCMap x) = x

noncomputable def dedekindCauchyOrderIsomorphismCertificate :
    DedekindCauchyOrderIsomorphismCertificate where
  reflection := dedekindCauchyOrderReflectionCertificate
  cToDMap := cToD
  dToCMap := dToC
  cToDOrderIff := @cToD_order_iff
  dToCOrderIff := @dToC_order_iff
  leftInverse := dToC_cToD
  rightInverse := cToD_dToC

end BOMA.R.StageTwo.DedekindCauchyComparison003

/- ST2-EXP-003 H5 additive-preservation layer.

   This source starts only after the exact-verified Dedekind/Cauchy order
   isomorphism milestone.  It proves preservation of addition by characterizing
   strict rational lower bounds of a sum on both carriers, then derives zero
   and negation preservation from the already certified rational embedding and
   additive-inverse uniqueness.

   Multiplication, nonzero inverse preservation, field isomorphism, and any
   research Junction remain outside this source. -/
namespace BOMA.R.StageTwo.DedekindCauchyComparison003

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionEmbedding001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindOrderAdditive001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindStrictOrder001
open BOMA.R.DedekindRationalDensity001
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyOrderedRing003
open BOMA.R.StageTwo.CauchyLUBBracket003

/-- Left additive inverse on the independent Cauchy carrier, derived from the
    already certified right inverse and commutativity. -/
theorem rCAdd_neg_left_h5 (x : RCBOMA) :
    rCAdd (rCNeg x) x = rCZero := by
  calc
    rCAdd (rCNeg x) x = rCAdd x (rCNeg x) := rCAdd_comm _ _
    _ = rCZero := rCAdd_neg_right x

/-- Cancel a right summand on the independent Cauchy additive group. -/
theorem rCAdd_sub_right_h5 (x y : RCBOMA) :
    rCAdd (rCAdd x y) (rCNeg y) = x := by
  calc
    rCAdd (rCAdd x y) (rCNeg y) =
        rCAdd x (rCAdd y (rCNeg y)) := rCAdd_assoc x y (rCNeg y)
    _ = rCAdd x rCZero := by rw [rCAdd_neg_right]
    _ = x := rCAdd_zero_right x

/-- Right cancellation on the independent Cauchy additive group. -/
theorem rCAdd_right_cancel_h5 {x y z : RCBOMA}
    (h : rCAdd x z = rCAdd y z) : x = y := by
  have ht := congrArg (fun t => rCAdd t (rCNeg z)) h
  rw [rCAdd_sub_right_h5, rCAdd_sub_right_h5] at ht
  exact ht

/-- Strict Cauchy order is preserved by a common right additive translate. -/
theorem rclt_add_right_h5 {x y : RCBOMA}
    (hxy : rCLT x y) (z : RCBOMA) :
    rCLT (rCAdd x z) (rCAdd y z) := by
  refine ⟨rcle_add_right hxy.1 z, ?_⟩
  intro hEq
  exact hxy.2 (rCAdd_right_cancel_h5 hEq)

/-- A strict rational lower bound of a Cauchy sum can be split into strict
    rational lower bounds of the two summands. -/
theorem rC_rational_strict_below_add_split
    {q : QBOMA} {x y : RCBOMA}
    (hq : rCLT (rCOfQ q) (rCAdd x y)) :
    ∃ a b : QBOMA,
      rCLT (rCOfQ a) x ∧
      rCLT (rCOfQ b) y ∧
      qLT q (qAdd a b) := by
  have hsubY0 := rclt_add_right_h5 hq (rCNeg y)
  have hsubY : rCLT (rCAdd (rCOfQ q) (rCNeg y)) x := by
    rw [rCAdd_sub_right_h5 x y] at hsubY0
    exact hsubY0
  rcases rC_rational_image_dense hsubY with ⟨a, hsubYa, hax⟩
  have hqAy0 := rclt_add_right_h5 hsubYa y
  have hleftY :
      rCAdd (rCAdd (rCOfQ q) (rCNeg y)) y = rCOfQ q := by
    calc
      rCAdd (rCAdd (rCOfQ q) (rCNeg y)) y =
          rCAdd (rCOfQ q) (rCAdd (rCNeg y) y) :=
        rCAdd_assoc (rCOfQ q) (rCNeg y) y
      _ = rCAdd (rCOfQ q) rCZero := by rw [rCAdd_neg_left_h5]
      _ = rCOfQ q := rCAdd_zero_right _
  rw [hleftY] at hqAy0
  have hsubA0 := rclt_add_right_h5 hqAy0 (rCNeg (rCOfQ a))
  have hleftA :
      rCAdd (rCOfQ q) (rCNeg (rCOfQ a)) =
        rCOfQ (qAdd q (qNeg a)) := by
    rw [rCOfQ_neg, rCOfQ_add]
  have hrightA :
      rCAdd (rCAdd (rCOfQ a) y) (rCNeg (rCOfQ a)) = y := by
    calc
      rCAdd (rCAdd (rCOfQ a) y) (rCNeg (rCOfQ a)) =
          rCAdd (rCAdd y (rCOfQ a)) (rCNeg (rCOfQ a)) := by
        rw [rCAdd_comm (rCOfQ a) y]
      _ = rCAdd y (rCAdd (rCOfQ a) (rCNeg (rCOfQ a))) :=
        rCAdd_assoc y (rCOfQ a) (rCNeg (rCOfQ a))
      _ = rCAdd y rCZero := by rw [rCAdd_neg_right]
      _ = y := rCAdd_zero_right y
  rw [hleftA, hrightA] at hsubA0
  rcases rC_rational_image_dense hsubA0 with ⟨b, hqAb, hby⟩
  have hqAbQ : qLT (qAdd q (qNeg a)) b := by
    refine ⟨(rCOfQ_order _ _).1 hqAb.1, ?_⟩
    intro hEq
    apply hqAb.2
    exact congrArg rCOfQ hEq
  exact ⟨a, b, hax, hby, qlt_add_back_left hqAbQ⟩

/-- Conversely, strict rational lower bounds of both Cauchy summands combine
    into a strict rational lower bound of their sum. -/
theorem rC_rational_strict_below_add_of_split
    {q a b : QBOMA} {x y : RCBOMA}
    (hax : rCLT (rCOfQ a) x)
    (hby : rCLT (rCOfQ b) y)
    (hq : qLT q (qAdd a b)) :
    rCLT (rCOfQ q) (rCAdd x y) := by
  have hqsum : rCLT (rCOfQ q) (rCOfQ (qAdd a b)) := rCOfQ_strict hq
  have hsum1 :
      rCLE (rCAdd (rCOfQ a) (rCOfQ b))
        (rCAdd x (rCOfQ b)) :=
    rcle_add_right hax.1 (rCOfQ b)
  have hsum2raw := rcle_add_right hby.1 x
  have hsum2 :
      rCLE (rCAdd x (rCOfQ b)) (rCAdd x y) := by
    rw [rCAdd_comm (rCOfQ b) x, rCAdd_comm y x] at hsum2raw
    exact hsum2raw
  have hsum :
      rCLE (rCOfQ (qAdd a b)) (rCAdd x y) := by
    rw [← rCOfQ_add]
    exact rcle_trans hsum1 hsum2
  exact rclt_trans_le hqsum hsum

/-- Exact Cauchy-side strict rational lower-envelope characterization of
    addition. -/
theorem rC_rational_strict_below_add_iff
    {q : QBOMA} {x y : RCBOMA} :
    rCLT (rCOfQ q) (rCAdd x y) ↔
      ∃ a b : QBOMA,
        rCLT (rCOfQ a) x ∧
        rCLT (rCOfQ b) y ∧
        qLT q (qAdd a b) := by
  constructor
  · exact rC_rational_strict_below_add_split
  · rintro ⟨a, b, hax, hby, hq⟩
    exact rC_rational_strict_below_add_of_split hax hby hq

/-- A principal rational Dedekind real lies strictly below an explicit lower
    cut exactly when its rational endpoint belongs to that cut. -/
theorem rOfQ_strict_mk_iff_lower (q : QBOMA) (A : LowerCut) :
    rLT (rOfQ q) (rmk A) ↔ A.lower q := by
  constructor
  · intro h
    change rLT (rmk (principalCut q)) (rmk A) at h
    rcases (rlt_mk_iff (principalCut q) A).1 h with ⟨hInc, hNotEq⟩
    classical
    by_cases hqA : A.lower q
    · exact hqA
    · exfalso
      apply hNotEq
      intro p
      constructor
      · intro hp
        exact hInc p hp
      · intro hpA
        rcases qlt_trichotomy p q with hpq | hpq | hqp
        · exact hpq
        · subst p
          exact False.elim (hqA hpA)
        · exact False.elim (hqA (A.downward hpA hqp.1))
  · intro hqA
    change rLT (rmk (principalCut q)) (rmk A)
    apply (rlt_mk_iff (principalCut q) A).2
    constructor
    · intro p hp
      exact A.downward hqA hp.1
    · intro hEq
      have hqq : (principalCut q).lower q := (hEq q).2 hqA
      exact (qlt_irrefl q) hqq

/-- Exact accepted-Dedekind strict rational lower-envelope characterization of
    addition, exposed without selecting representatives. -/
theorem r_rational_strict_below_add_iff
    {q : QBOMA} {x y : RBOMA} :
    rLT (rOfQ q) (rAdd x y) ↔
      ∃ a b : QBOMA,
        rLT (rOfQ a) x ∧
        rLT (rOfQ b) y ∧
        qLT q (qAdd a b) := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  constructor
  · intro h
    change rLT (rOfQ q) (rmk (cutAdd A B)) at h
    have hcut : (cutAdd A B).lower q :=
      (rOfQ_strict_mk_iff_lower q (cutAdd A B)).1 h
    rcases hcut with ⟨a, b, ha, hb, hq⟩
    exact ⟨a, b,
      (rOfQ_strict_mk_iff_lower a A).2 ha,
      (rOfQ_strict_mk_iff_lower b B).2 hb,
      hq⟩
  · rintro ⟨a, b, ha, hb, hq⟩
    have hcut : (cutAdd A B).lower q :=
      ⟨a, b,
        (rOfQ_strict_mk_iff_lower a A).1 ha,
        (rOfQ_strict_mk_iff_lower b B).1 hb,
        hq⟩
    have hm := (rOfQ_strict_mk_iff_lower q (cutAdd A B)).2 hcut
    change rLT (rOfQ q) (rmk (cutAdd A B))
    exact hm

/-- The H5 comparison map preserves and reflects strict rational lower bounds. -/
theorem cToD_rational_strict_iff {q : QBOMA} {x : RCBOMA} :
    rLT (rOfQ q) (cToD x) ↔ rCLT (rCOfQ q) x := by
  constructor
  · intro h
    refine ⟨cToD_rational_lower_reflect h.1, ?_⟩
    intro hEq
    apply h.2
    have hm := congrArg cToD hEq
    rw [cToD_rational] at hm
    exact hm
  · intro h
    constructor
    · have hm := cToD_mono h.1
      rw [cToD_rational] at hm
      exact hm
    · intro hEq
      apply h.2
      have hm : cToD (rCOfQ q) = cToD x := by
        rw [cToD_rational]
        exact hEq
      have hi := congrArg dToC hm
      simpa only [dToC_cToD] using hi

/-- If every embedded rational strictly below x is strictly below y, then x≤y
    on the accepted Dedekind carrier. -/
theorem rLE_of_rational_strict_lower_imp {x y : RBOMA}
    (h : ∀ q : QBOMA, rLT (rOfQ q) x → rLT (rOfQ q) y) :
    rLE x y := by
  rcases rLE_total_classical x y with hxy | hyx
  · exact hxy
  · by_cases hxy : rLE x y
    · exact hxy
    · have hyxNe : y ≠ x := by
        intro hEq
        apply hxy
        rw [hEq]
        exact rLE_refl x
      have hyxStrict : rLT y x := ⟨hyx, hyxNe⟩
      rcases r_rational_image_dense hyxStrict with ⟨q, hyq, hqx⟩
      have hqy : rLT (rOfQ q) y := h q hqx
      exact False.elim (hyq.2 (rLE_antisymm hyq.1 hqy.1))

/-- Accepted Dedekind reals are equal when they have the same strict rational
    lower envelope. -/
theorem r_eq_of_rational_strict_lower_iff {x y : RBOMA}
    (h : ∀ q : QBOMA,
      rLT (rOfQ q) x ↔ rLT (rOfQ q) y) :
    x = y := by
  apply rLE_antisymm
  · apply rLE_of_rational_strict_lower_imp
    intro q hqx
    exact (h q).1 hqx
  · apply rLE_of_rational_strict_lower_imp
    intro q hqy
    exact (h q).2 hqy

/-- Strict rational lower bounds coincide for the image of a Cauchy sum and
    the accepted Dedekind sum of the two images. -/
theorem cToD_add_rational_strict_iff
    (q : QBOMA) (x y : RCBOMA) :
    rLT (rOfQ q) (cToD (rCAdd x y)) ↔
      rLT (rOfQ q) (rAdd (cToD x) (cToD y)) := by
  constructor
  · intro h
    have hCsum : rCLT (rCOfQ q) (rCAdd x y) :=
      (cToD_rational_strict_iff).1 h
    rcases (rC_rational_strict_below_add_iff).1 hCsum with
      ⟨a, b, hax, hby, hq⟩
    apply (r_rational_strict_below_add_iff).2
    exact ⟨a, b,
      (cToD_rational_strict_iff).2 hax,
      (cToD_rational_strict_iff).2 hby,
      hq⟩
  · intro h
    rcases (r_rational_strict_below_add_iff).1 h with
      ⟨a, b, hax, hby, hq⟩
    apply (cToD_rational_strict_iff).2
    apply (rC_rational_strict_below_add_iff).2
    exact ⟨a, b,
      (cToD_rational_strict_iff).1 hax,
      (cToD_rational_strict_iff).1 hby,
      hq⟩

/-- The explicit H5 order isomorphism preserves addition. -/
theorem cToD_add (x y : RCBOMA) :
    cToD (rCAdd x y) = rAdd (cToD x) (cToD y) := by
  apply r_eq_of_rational_strict_lower_iff
  intro q
  exact cToD_add_rational_strict_iff q x y

/-- The reverse H5 map preserves addition. -/
theorem dToC_add (x y : RBOMA) :
    dToC (rAdd x y) = rCAdd (dToC x) (dToC y) := by
  have h := congrArg dToC (cToD_add (dToC x) (dToC y))
  rw [dToC_cToD, cToD_dToC, cToD_dToC] at h
  exact h.symm

/-- The forward H5 map preserves additive zero. -/
theorem cToD_zero : cToD rCZero = rZero := by
  change cToD (rCOfQ qZero) = rOfQ qZero
  exact cToD_rational qZero

/-- The reverse H5 map preserves additive zero. -/
theorem dToC_zero : dToC rZero = rCZero := by
  change dToC (rOfQ qZero) = rCOfQ qZero
  exact dToC_rational qZero

/-- Addition preservation plus uniqueness of additive inverse forces forward
    preservation of negation. -/
theorem cToD_neg (x : RCBOMA) :
    cToD (rCNeg x) = rNeg (cToD x) := by
  apply rAdd_inverse_unique (x := cToD x)
  have h := cToD_add x (rCNeg x)
  rw [rCAdd_neg_right, cToD_zero] at h
  exact h.symm

/-- The reverse H5 map preserves negation as well. -/
theorem dToC_neg (x : RBOMA) :
    dToC (rNeg x) = rCNeg (dToC x) := by
  have h := congrArg dToC (cToD_neg (dToC x))
  rw [dToC_cToD, cToD_dToC] at h
  exact h.symm

/-- Machine-checkable additive-group preservation milestone.  Multiplication
    and field inverses are intentionally absent. -/
structure DedekindCauchyAdditivePreservationCertificate where
  orderIso : DedekindCauchyOrderIsomorphismCertificate
  forwardAdd : ∀ x y : RCBOMA,
    cToD (rCAdd x y) = rAdd (cToD x) (cToD y)
  reverseAdd : ∀ x y : RBOMA,
    dToC (rAdd x y) = rCAdd (dToC x) (dToC y)
  forwardZero : cToD rCZero = rZero
  reverseZero : dToC rZero = rCZero
  forwardNeg : ∀ x : RCBOMA, cToD (rCNeg x) = rNeg (cToD x)
  reverseNeg : ∀ x : RBOMA, dToC (rNeg x) = rCNeg (dToC x)

noncomputable def dedekindCauchyAdditivePreservationCertificate :
    DedekindCauchyAdditivePreservationCertificate where
  orderIso := dedekindCauchyOrderIsomorphismCertificate
  forwardAdd := cToD_add
  reverseAdd := dToC_add
  forwardZero := cToD_zero
  reverseZero := dToC_zero
  forwardNeg := cToD_neg
  reverseNeg := dToC_neg

end BOMA.R.StageTwo.DedekindCauchyComparison003

/- ST2-EXP-003 H5 multiplicative-preservation layer.

   This source starts only after the exact-verified additive-preservation
   milestone.  Nonnegative products are compared by an exact strict-rational
   lower-envelope characterization.  Signed multiplication is then recovered
   from the four sign quadrants using the already verified preservation of
   order and negation.

   Nonzero inverse-relation preservation, the final field-isomorphism package,
   and any research Junction remain outside this source. -/
namespace BOMA.R.StageTwo.DedekindCauchyComparison003

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QPositiveMultiplicativeApprox001
open BOMA.R.QInverseOrder001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindSignedMulSignLaws001
open BOMA.R.DedekindOrderedRing001
open BOMA.R.DedekindStrictOrder001
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyOrderCore003
open BOMA.R.StageTwo.CauchyOrderTotal003
open BOMA.R.StageTwo.CauchyOrderedRing003
open BOMA.R.StageTwo.CauchyInverse003
open BOMA.R.StageTwo.CauchyLUBBracket003

/-- Left cancellation in the independent Cauchy additive group. -/
theorem rCAdd_left_cancel_h5 {x y z : RCBOMA}
    (h : rCAdd x y = rCAdd x z) : y = z := by
  apply rCAdd_right_cancel_h5 (z := x)
  rw [rCAdd_comm y x, rCAdd_comm z x]
  exact h

/-- Additive inverses are unique on the independent Cauchy carrier. -/
theorem rCAdd_inverse_unique_h5 {x y : RCBOMA}
    (h : rCAdd x y = rCZero) : y = rCNeg x := by
  apply rCAdd_left_cancel_h5 (x := x)
  calc
    rCAdd x y = rCZero := h
    _ = rCAdd x (rCNeg x) := (rCAdd_neg_right x).symm

/-- Cauchy negation is involutive. -/
theorem rCNeg_involutive_h5 (x : RCBOMA) : rCNeg (rCNeg x) = x := by
  symm
  exact rCAdd_inverse_unique_h5 (rCAdd_neg_left_h5 x)

/-- Negation sends a nonpositive Cauchy real to a nonnegative one. -/
theorem rCNeg_nonneg_of_nonpos_h5 {x : RCBOMA}
    (hx0 : rCLE x rCZero) :
    rCLE rCZero (rCNeg x) := by
  have ht := rcle_add_right hx0 (rCNeg x)
  rw [rCAdd_neg_right, rCAdd_zero_left] at ht
  exact ht

/-- Negation sends a nonnegative Cauchy real to a nonpositive one. -/
theorem rCNeg_nonpos_of_nonneg_h5 {x : RCBOMA}
    (h0x : rCLE rCZero x) :
    rCLE (rCNeg x) rCZero := by
  have ht := rcle_add_right h0x (rCNeg x)
  rw [rCAdd_zero_left, rCAdd_neg_right] at ht
  exact ht

/-- Right zero law for research multiplication. -/
theorem rCMul_zero_right_h5 (x : RCBOMA) :
    rCMul x rCZero = rCZero := by
  rw [rCMul_comm, rCMul_zero_left]

/-- Multiplication by an additive inverse on the right negates the product. -/
theorem rCMul_neg_right_h5 (x y : RCBOMA) :
    rCMul x (rCNeg y) = rCNeg (rCMul x y) := by
  apply rCAdd_inverse_unique_h5 (x := rCMul x y)
  calc
    rCAdd (rCMul x y) (rCMul x (rCNeg y)) =
        rCMul x (rCAdd y (rCNeg y)) :=
      (rCMul_add_right x y (rCNeg y)).symm
    _ = rCMul x rCZero := by rw [rCAdd_neg_right]
    _ = rCZero := rCMul_zero_right_h5 x

/-- Left negation compatibility follows from commutativity. -/
theorem rCMul_neg_left_h5 (x y : RCBOMA) :
    rCMul (rCNeg x) y = rCNeg (rCMul x y) := by
  calc
    rCMul (rCNeg x) y = rCMul y (rCNeg x) := rCMul_comm _ _
    _ = rCNeg (rCMul y x) := rCMul_neg_right_h5 y x
    _ = rCNeg (rCMul x y) := congrArg rCNeg (rCMul_comm y x)

/-- Negating both Cauchy factors leaves the product unchanged. -/
theorem rCMul_neg_neg_h5 (x y : RCBOMA) :
    rCMul (rCNeg x) (rCNeg y) = rCMul x y := by
  rw [rCMul_neg_left_h5, rCMul_neg_right_h5, rCNeg_involutive_h5]

/-- Cauchy order is equivalent to nonnegativity of the additive difference. -/
theorem rcle_iff_nonneg_difference_h5 (x y : RCBOMA) :
    rCLE x y ↔ rCLE rCZero (rCAdd y (rCNeg x)) := by
  constructor
  · intro hxy
    have ht := rcle_add_right hxy (rCNeg x)
    rw [rCAdd_neg_right] at ht
    exact ht
  · intro hdiff
    have ht := rcle_add_right hdiff x
    have hright : rCAdd (rCAdd y (rCNeg x)) x = y := by
      calc
        rCAdd (rCAdd y (rCNeg x)) x =
            rCAdd y (rCAdd (rCNeg x) x) :=
          rCAdd_assoc y (rCNeg x) x
        _ = rCAdd y rCZero := by rw [rCAdd_neg_left_h5]
        _ = y := rCAdd_zero_right y
    rw [rCAdd_zero_left, hright] at ht
    exact ht

/-- A nonnegative left Cauchy factor preserves non-strict order. -/
theorem rCMul_mono_left_nonneg_h5
    {x y c : RCBOMA}
    (hxy : rCLE x y)
    (h0c : rCLE rCZero c) :
    rCLE (rCMul c x) (rCMul c y) := by
  have hdiff : rCLE rCZero (rCAdd y (rCNeg x)) :=
    (rcle_iff_nonneg_difference_h5 x y).1 hxy
  have hprod :
      rCLE rCZero (rCMul c (rCAdd y (rCNeg x))) :=
    rcle_mul_nonneg h0c hdiff
  have hrepr :
      rCMul c (rCAdd y (rCNeg x)) =
        rCAdd (rCMul c y) (rCNeg (rCMul c x)) := by
    calc
      rCMul c (rCAdd y (rCNeg x)) =
          rCAdd (rCMul c y) (rCMul c (rCNeg x)) :=
        rCMul_add_right c y (rCNeg x)
      _ = rCAdd (rCMul c y) (rCNeg (rCMul c x)) := by
        rw [rCMul_neg_right_h5]
  rw [hrepr] at hprod
  exact (rcle_iff_nonneg_difference_h5
    (rCMul c x) (rCMul c y)).2 hprod

/-- A nonnegative right Cauchy factor preserves non-strict order. -/
theorem rCMul_mono_right_nonneg_h5
    {x y c : RCBOMA}
    (hxy : rCLE x y)
    (h0c : rCLE rCZero c) :
    rCLE (rCMul x c) (rCMul y c) := by
  rw [rCMul_comm x c, rCMul_comm y c]
  exact rCMul_mono_left_nonneg_h5 hxy h0c

/-- Multiplication by a nonzero common right factor is cancellative. -/
theorem rCMul_right_cancel_nonzero_h5
    {x y c : RCBOMA}
    (hc : c ≠ rCZero)
    (h : rCMul x c = rCMul y c) : x = y := by
  rcases rC_inverse_exists c hc with ⟨z, hz⟩
  have hcz := hz
  unfold RCInvRel at hcz
  calc
    x = rCMul x rCOne := (rCMul_one_right x).symm
    _ = rCMul x (rCMul c z) := congrArg (fun t => rCMul x t) hcz.symm
    _ = rCMul (rCMul x c) z := (rCMul_assoc x c z).symm
    _ = rCMul (rCMul y c) z := congrArg (fun t => rCMul t z) h
    _ = rCMul y (rCMul c z) := rCMul_assoc y c z
    _ = rCMul y rCOne := congrArg (fun t => rCMul y t) hcz
    _ = y := rCMul_one_right y

/-- Multiplication by a strictly positive right Cauchy factor preserves strict
    order. -/
theorem rclt_mul_right_positive_h5
    {x y c : RCBOMA}
    (hxy : rCLT x y)
    (h0c : rCLT rCZero c) :
    rCLT (rCMul x c) (rCMul y c) := by
  refine ⟨rCMul_mono_right_nonneg_h5 hxy.1 h0c.1, ?_⟩
  intro hEq
  have hc : c ≠ rCZero := fun h => h0c.2 h.symm
  exact hxy.2 (rCMul_right_cancel_nonzero_h5 hc hEq)

/-- A multiplicative inverse witness of a strictly positive Cauchy real is
    strictly positive. -/
theorem rC_inverse_positive_h5
    {x y : RCBOMA}
    (h0x : rCLT rCZero x)
    (hy : RCInvRel x y) :
    rCLT rCZero y := by
  have hxy := hy
  unfold RCInvRel at hxy
  have hyNe : y ≠ rCZero := by
    intro h0
    have hone : rCZero = rCOne := by
      calc
        rCZero = rCMul x rCZero := (rCMul_zero_right_h5 x).symm
        _ = rCMul x y := congrArg (fun t => rCMul x t) h0.symm
        _ = rCOne := hxy
    exact (rCOfQ_strict qzero_lt_one).2 hone
  rcases rcle_total rCZero y with h0y | hy0
  · exact ⟨h0y, fun h => hyNe h.symm⟩
  · have h0ny : rCLE rCZero (rCNeg y) :=
      rCNeg_nonneg_of_nonpos_h5 hy0
    have hprod : rCLE rCZero (rCMul x (rCNeg y)) :=
      rcle_mul_nonneg h0x.1 h0ny
    have hnegone : rCMul x (rCNeg y) = rCNeg rCOne := by
      rw [rCMul_neg_right_h5, hxy]
    rw [hnegone] at hprod
    have hone0 := rcle_add_right hprod rCOne
    rw [rCAdd_zero_left, rCAdd_neg_left_h5] at hone0
    have h0one : rCLE rCZero rCOne :=
      (rCOfQ_order qZero qOne).2 qzero_le_one
    have heq : rCZero = rCOne := rcle_antisymm h0one hone0
    exact False.elim ((rCOfQ_strict qzero_lt_one).2 heq)

/-- If q is nonnegative and strictly below a product of nonnegative Cauchy
    reals, positive rational factors can be chosen below each input with a
    rational product still strictly above q. -/
theorem rC_nonneg_product_inner_witness
    {q : QBOMA} {x y : RCBOMA}
    (h0q : qLE qZero q)
    (h0x : rCLE rCZero x)
    (h0y : rCLE rCZero y)
    (hq : rCLT (rCOfQ q) (rCMul x y)) :
    ∃ a b : QBOMA,
      qLT qZero a ∧ qLT qZero b ∧
      rCLT (rCOfQ a) x ∧
      rCLT (rCOfQ b) y ∧
      qLT q (qMul a b) := by
  have hyNe : y ≠ rCZero := by
    intro hy0
    have hprod0 : rCMul x y = rCZero := by
      rw [hy0, rCMul_zero_right_h5]
    have hq0 : rCLT (rCOfQ q) rCZero := by
      rw [← hprod0]
      exact hq
    have h0qC : rCLE rCZero (rCOfQ q) :=
      (rCOfQ_order qZero q).2 h0q
    exact hq0.2 (rcle_antisymm hq0.1 h0qC)
  have hyPos : rCLT rCZero y :=
    ⟨h0y, fun h => hyNe h.symm⟩
  rcases rC_inverse_exists y hyNe with ⟨z, hz⟩
  have hzPos : rCLT rCZero z := rC_inverse_positive_h5 hyPos hz
  have hqz0 := rclt_mul_right_positive_h5 hq hzPos
  have hyz := hz
  unfold RCInvRel at hyz
  have hright : rCMul (rCMul x y) z = x := by
    calc
      rCMul (rCMul x y) z = rCMul x (rCMul y z) :=
        rCMul_assoc x y z
      _ = rCMul x rCOne := congrArg (fun t => rCMul x t) hyz
      _ = x := rCMul_one_right x
  rw [hright] at hqz0
  rcases rC_rational_image_dense hqz0 with ⟨a, hqza, hax⟩
  have h0qC : rCLE rCZero (rCOfQ q) :=
    (rCOfQ_order qZero q).2 h0q
  have h0qz : rCLE rCZero (rCMul (rCOfQ q) z) :=
    rcle_mul_nonneg h0qC hzPos.1
  have h0aLE : rCLE rCZero (rCOfQ a) :=
    rcle_trans h0qz hqza.1
  have h0aNe : rCZero ≠ rCOfQ a := by
    intro h0a
    have haBack : rCLE (rCOfQ a) (rCMul (rCOfQ q) z) := by
      rw [← h0a]
      exact h0qz
    exact hqza.2 (rcle_antisymm hqza.1 haBack)
  have h0a : rCLT rCZero (rCOfQ a) := ⟨h0aLE, h0aNe⟩
  have haQ : qLT qZero a := by
    refine ⟨(rCOfQ_order qZero a).1 h0a.1, ?_⟩
    intro hEq
    apply h0a.2
    exact congrArg rCOfQ hEq
  have hqay0 := rclt_mul_right_positive_h5 hqza hyPos
  have hzy : rCMul z y = rCOne := by
    rw [rCMul_comm]
    exact hyz
  have hleft :
      rCMul (rCMul (rCOfQ q) z) y = rCOfQ q := by
    calc
      rCMul (rCMul (rCOfQ q) z) y =
          rCMul (rCOfQ q) (rCMul z y) := rCMul_assoc _ _ _
      _ = rCMul (rCOfQ q) rCOne := congrArg (fun t => rCMul (rCOfQ q) t) hzy
      _ = rCOfQ q := rCMul_one_right _
  rw [hleft] at hqay0
  have haNe : a ≠ qZero := fun h => haQ.2 h.symm
  rcases q_inverse_exists a haNe with ⟨ainv, hainv⟩
  have hainvPosQ : qLT qZero ainv := qlt_zero_inverse haQ hainv
  have hainvPosC : rCLT rCZero (rCOfQ ainv) :=
    rCOfQ_strict hainvPosQ
  have hqb0 := rclt_mul_right_positive_h5 hqay0 hainvPosC
  have hainvEq := hainv
  unfold QInvRel at hainvEq
  have hleftInv :
      rCMul (rCOfQ q) (rCOfQ ainv) = rCOfQ (qMul q ainv) :=
    rCOfQ_mul q ainv
  have hrightInv :
      rCMul (rCMul (rCOfQ a) y) (rCOfQ ainv) = y := by
    calc
      rCMul (rCMul (rCOfQ a) y) (rCOfQ ainv) =
          rCMul (rCMul y (rCOfQ a)) (rCOfQ ainv) := by
        rw [rCMul_comm (rCOfQ a) y]
      _ = rCMul y (rCMul (rCOfQ a) (rCOfQ ainv)) :=
        rCMul_assoc y (rCOfQ a) (rCOfQ ainv)
      _ = rCMul y (rCOfQ (qMul a ainv)) := by rw [rCOfQ_mul]
      _ = rCMul y (rCOfQ qOne) := by rw [hainvEq]
      _ = y := rCMul_one_right y
  rw [hleftInv, hrightInv] at hqb0
  rcases rC_rational_image_dense hqb0 with ⟨b, hqInvb, hby⟩
  have hqInvbQ : qLT (qMul q ainv) b := by
    refine ⟨(rCOfQ_order _ _).1 hqInvb.1, ?_⟩
    intro hEq
    apply hqInvb.2
    exact congrArg rCOfQ hEq
  have h0qInv : qLE qZero (qMul q ainv) :=
    qmul_nonneg h0q hainvPosQ.1
  have h0b : qLT qZero b :=
    BOMA.R.DedekindAddition001.qle_lt_trans h0qInv hqInvbQ
  have hmul := qmul_lt_left_positive hqInvbQ haQ
  have hleftQ : qMul a (qMul q ainv) = q := by
    calc
      qMul a (qMul q ainv) = qMul q (qMul a ainv) := by
        rw [← qMul_assoc, qMul_comm a q, qMul_assoc]
      _ = qMul q qOne := by rw [hainvEq]
      _ = q := qMul_one_right q
  rw [hleftQ] at hmul
  exact ⟨a, b, haQ, h0b, hax, hby, hmul⟩

/-- Exact strict rational lower-envelope description of a nonnegative Cauchy
    product. -/
theorem rC_rational_strict_below_mul_nonneg_iff
    {q : QBOMA} {x y : RCBOMA}
    (h0x : rCLE rCZero x)
    (h0y : rCLE rCZero y) :
    rCLT (rCOfQ q) (rCMul x y) ↔
      qLT q qZero ∨
      ∃ a b : QBOMA,
        qLT qZero a ∧ qLT qZero b ∧
        rCLT (rCOfQ a) x ∧
        rCLT (rCOfQ b) y ∧
        qLT q (qMul a b) := by
  constructor
  · intro hq
    rcases qlt_trichotomy q qZero with hneg | heq | hpos
    · exact Or.inl hneg
    · right
      apply rC_nonneg_product_inner_witness (q := q) (x := x) (y := y)
      · rw [heq]
        exact qle_refl qZero
      · exact h0x
      · exact h0y
      · exact hq
    · right
      exact rC_nonneg_product_inner_witness hpos.1 h0x h0y hq
  · intro h
    rcases h with hneg | hprod
    · have h0prod : rCLE rCZero (rCMul x y) :=
        rcle_mul_nonneg h0x h0y
      refine ⟨rcle_trans ((rCOfQ_order q qZero).2 hneg.1) h0prod, ?_⟩
      intro hEq
      have hprodq : rCLE rCZero (rCOfQ q) := by
        rw [hEq]
        exact h0prod
      have hq0 : rCLE (rCOfQ q) rCZero :=
        (rCOfQ_order q qZero).2 hneg.1
      have heq0 := rcle_antisymm hq0 hprodq
      exact hneg.2 (rCOfQ_injective heq0)
    · rcases hprod with ⟨a, b, h0a, h0b, hax, hby, hqab⟩
      have hAB : rCLT (rCOfQ q) (rCOfQ (qMul a b)) :=
        rCOfQ_strict hqab
      have h0aC : rCLE rCZero (rCOfQ a) :=
        (rCOfQ_order qZero a).2 h0a.1
      have h0bC : rCLE rCZero (rCOfQ b) :=
        (rCOfQ_order qZero b).2 h0b.1
      have h1 :
          rCLE (rCMul (rCOfQ a) (rCOfQ b))
            (rCMul x (rCOfQ b)) :=
        rCMul_mono_right_nonneg_h5 hax.1 h0bC
      have h2 :
          rCLE (rCMul x (rCOfQ b)) (rCMul x y) :=
        rCMul_mono_left_nonneg_h5 hby.1 h0x
      have hrat :
          rCLE (rCOfQ (qMul a b)) (rCMul x y) := by
        rw [← rCOfQ_mul]
        exact rcle_trans h1 h2
      exact rclt_trans_le hAB hrat

/-- Exact strict rational lower-envelope description of the accepted Dedekind
    nonnegative multiplication kernel. -/
theorem r_rational_strict_below_mul_nonneg_envelope_iff
    {q : QBOMA} {x y : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y) :
    rLT (rOfQ q) (rMulNonnegEnvelope x y) ↔
      qLT q qZero ∨
      ∃ a b : QBOMA,
        qLT qZero a ∧ qLT qZero b ∧
        rLT (rOfQ a) x ∧
        rLT (rOfQ b) y ∧
        qLT q (qMul a b) := by
  refine Quotient.inductionOn x ?_ h0x
  intro A h0A
  refine Quotient.inductionOn y ?_ h0y
  intro B h0B
  have h0Ac : CutLE (principalCut qZero) A := by
    change rLE (rmk (principalCut qZero)) (rmk A) at h0A
    exact (rLE_mk_iff (principalCut qZero) A).1 h0A
  have h0Bc : CutLE (principalCut qZero) B := by
    change rLE (rmk (principalCut qZero)) (rmk B) at h0B
    exact (rLE_mk_iff (principalCut qZero) B).1 h0B
  have hPosA := cutPosPart_of_nonneg h0Ac
  have hPosB := cutPosPart_of_nonneg h0Bc
  constructor
  · intro h
    change rLT (rOfQ q) (rmk (cutMulNonnegEnvelope A B)) at h
    have hcut : (cutMulNonnegEnvelope A B).lower q :=
      (rOfQ_strict_mk_iff_lower q (cutMulNonnegEnvelope A B)).1 h
    rcases hcut with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨a, b, ha, hb, h0a, h0b, hqab⟩
      exact Or.inr ⟨a, b, h0a, h0b,
        (rOfQ_strict_mk_iff_lower a A).2 ((hPosA a).1 ha),
        (rOfQ_strict_mk_iff_lower b B).2 ((hPosB b).1 hb),
        hqab⟩
  · intro h
    change rLT (rOfQ q) (rmk (cutMulNonnegEnvelope A B))
    apply (rOfQ_strict_mk_iff_lower q (cutMulNonnegEnvelope A B)).2
    rcases h with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨a, b, h0a, h0b, ha, hb, hqab⟩
      exact Or.inr ⟨a, b,
        (hPosA a).2 ((rOfQ_strict_mk_iff_lower a A).1 ha),
        (hPosB b).2 ((rOfQ_strict_mk_iff_lower b B).1 hb),
        h0a, h0b, hqab⟩

/-- Nonnegative accepted signed multiplication has the same rational envelope
    as its underlying nonnegative kernel. -/
theorem r_rational_strict_below_mul_nonneg_iff
    {q : QBOMA} {x y : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y) :
    rLT (rOfQ q) (rMulCandidate x y) ↔
      qLT q qZero ∨
      ∃ a b : QBOMA,
        qLT qZero a ∧ qLT qZero b ∧
        rLT (rOfQ a) x ∧
        rLT (rOfQ b) y ∧
        qLT q (qMul a b) := by
  rw [rMulCandidate_of_nonneg_nonneg h0x h0y]
  exact r_rational_strict_below_mul_nonneg_envelope_iff h0x h0y

/-- The forward H5 map transports Cauchy nonnegativity to Dedekind
    nonnegativity. -/
theorem cToD_nonneg_h5 {x : RCBOMA}
    (h0x : rCLE rCZero x) :
    rLE rZero (cToD x) := by
  have h := cToD_mono h0x
  rw [cToD_zero] at h
  exact h

/-- The forward H5 map transports Cauchy nonpositivity as well. -/
theorem cToD_nonpos_h5 {x : RCBOMA}
    (hx0 : rCLE x rCZero) :
    rLE (cToD x) rZero := by
  have h := cToD_mono hx0
  rw [cToD_zero] at h
  exact h

/-- The explicit H5 comparison map preserves multiplication on the nonnegative
    quadrant. -/
theorem cToD_mul_nonneg
    {x y : RCBOMA}
    (h0x : rCLE rCZero x)
    (h0y : rCLE rCZero y) :
    cToD (rCMul x y) = rMulCandidate (cToD x) (cToD y) := by
  apply r_eq_of_rational_strict_lower_iff
  intro q
  constructor
  · intro h
    have hC : rCLT (rCOfQ q) (rCMul x y) :=
      (cToD_rational_strict_iff).1 h
    rcases (rC_rational_strict_below_mul_nonneg_iff h0x h0y).1 hC with
      hneg | hprod
    · exact (r_rational_strict_below_mul_nonneg_iff
        (cToD_nonneg_h5 h0x) (cToD_nonneg_h5 h0y)).2 (Or.inl hneg)
    · rcases hprod with ⟨a, b, h0a, h0b, hax, hby, hqab⟩
      apply (r_rational_strict_below_mul_nonneg_iff
        (cToD_nonneg_h5 h0x) (cToD_nonneg_h5 h0y)).2
      exact Or.inr ⟨a, b, h0a, h0b,
        (cToD_rational_strict_iff).2 hax,
        (cToD_rational_strict_iff).2 hby,
        hqab⟩
  · intro h
    have hD := (r_rational_strict_below_mul_nonneg_iff
      (cToD_nonneg_h5 h0x) (cToD_nonneg_h5 h0y)).1 h
    apply (cToD_rational_strict_iff).2
    apply (rC_rational_strict_below_mul_nonneg_iff h0x h0y).2
    rcases hD with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨a, b, h0a, h0b, hax, hby, hqab⟩
      exact Or.inr ⟨a, b, h0a, h0b,
        (cToD_rational_strict_iff).1 hax,
        (cToD_rational_strict_iff).1 hby,
        hqab⟩

/-- The forward H5 map preserves signed multiplication in all four sign
    quadrants. -/
theorem cToD_mul (x y : RCBOMA) :
    cToD (rCMul x y) = rMulCandidate (cToD x) (cToD y) := by
  rcases rcle_total rCZero x with h0x | hx0
  · rcases rcle_total rCZero y with h0y | hy0
    · exact cToD_mul_nonneg h0x h0y
    · have h0ny : rCLE rCZero (rCNeg y) :=
        rCNeg_nonneg_of_nonpos_h5 hy0
      have h := cToD_mul_nonneg h0x h0ny
      rw [rCMul_neg_right_h5, cToD_neg, cToD_neg,
          rMulCandidate_neg_right] at h
      have ht := congrArg rNeg h
      simpa only [rNeg_involutive] using ht
  · rcases rcle_total rCZero y with h0y | hy0
    · have h0nx : rCLE rCZero (rCNeg x) :=
        rCNeg_nonneg_of_nonpos_h5 hx0
      have h := cToD_mul_nonneg h0nx h0y
      rw [rCMul_neg_left_h5, cToD_neg, cToD_neg,
          rMulCandidate_neg_left] at h
      have ht := congrArg rNeg h
      simpa only [rNeg_involutive] using ht
    · have h0nx : rCLE rCZero (rCNeg x) :=
        rCNeg_nonneg_of_nonpos_h5 hx0
      have h0ny : rCLE rCZero (rCNeg y) :=
        rCNeg_nonneg_of_nonpos_h5 hy0
      have h := cToD_mul_nonneg h0nx h0ny
      rw [rCMul_neg_neg_h5, cToD_neg, cToD_neg,
          rMulCandidate_neg_left, rMulCandidate_neg_right,
          rNeg_involutive] at h
      exact h

/-- The reverse H5 map preserves signed multiplication. -/
theorem dToC_mul (x y : RBOMA) :
    dToC (rMulCandidate x y) = rCMul (dToC x) (dToC y) := by
  have h := congrArg dToC (cToD_mul (dToC x) (dToC y))
  rw [dToC_cToD, cToD_dToC, cToD_dToC] at h
  exact h.symm

/-- Multiplicative one is preserved in the forward direction. -/
theorem cToD_one : cToD rCOne = rOne := by
  change cToD (rCOfQ qOne) = rOfQ qOne
  exact cToD_rational qOne

/-- Multiplicative one is preserved in the reverse direction. -/
theorem dToC_one : dToC rOne = rCOne := by
  change dToC (rOfQ qOne) = rCOfQ qOne
  exact dToC_rational qOne

/-- Machine-checkable ordered-ring preservation milestone.  Inverse relations
    and the final field-isomorphism claim are intentionally absent. -/
structure DedekindCauchyMultiplicativePreservationCertificate where
  additive : DedekindCauchyAdditivePreservationCertificate
  forwardMul : ∀ x y : RCBOMA,
    cToD (rCMul x y) = rMulCandidate (cToD x) (cToD y)
  reverseMul : ∀ x y : RBOMA,
    dToC (rMulCandidate x y) = rCMul (dToC x) (dToC y)
  forwardOne : cToD rCOne = rOne
  reverseOne : dToC rOne = rCOne

noncomputable def dedekindCauchyMultiplicativePreservationCertificate :
    DedekindCauchyMultiplicativePreservationCertificate where
  additive := dedekindCauchyAdditivePreservationCertificate
  forwardMul := cToD_mul
  reverseMul := dToC_mul
  forwardOne := cToD_one
  reverseOne := dToC_one

end BOMA.R.StageTwo.DedekindCauchyComparison003

/- ST2-EXP-003 H5 inverse-preservation and field-isomorphism layer.

   This source starts only after the exact-verified multiplicative-preservation
   milestone.  Both completed real routes intentionally expose multiplicative
   inverses through unique witness relations rather than a newly selected global
   inverse operation.  The comparison therefore preserves and reflects that
   exact witness relation, together with nonzeroness.

   This file packages the resulting order/field-structure isomorphism at theorem
   level.  It does not declare a research Junction, does not modify accepted R,
   and does not start the downstream C rebuild. -/
namespace BOMA.R.StageTwo.DedekindCauchyComparison003

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindNonzeroInverse004
open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.StageTwo.CauchyInverse003

/-- Forward comparison preserves and reflects zero, hence nonzeroness. -/
theorem cToD_ne_zero_iff {x : RCBOMA} :
    cToD x ≠ rZero ↔ x ≠ rCZero := by
  constructor
  · intro hx h0
    apply hx
    rw [h0, cToD_zero]
  · intro hx h0
    apply hx
    have h := congrArg dToC h0
    rw [dToC_cToD, dToC_zero] at h
    exact h

/-- Reverse comparison preserves and reflects zero, hence nonzeroness. -/
theorem dToC_ne_zero_iff {x : RBOMA} :
    dToC x ≠ rCZero ↔ x ≠ rZero := by
  constructor
  · intro hx h0
    apply hx
    rw [h0, dToC_zero]
  · intro hx h0
    apply hx
    have h := congrArg cToD h0
    rw [cToD_dToC, cToD_zero] at h
    exact h

/-- The forward H5 map preserves and reflects the exact multiplicative inverse
    witness relation. -/
theorem cToD_inverse_relation_iff {x y : RCBOMA} :
    RCInvRel x y ↔ rMulCandidate (cToD x) (cToD y) = rOne := by
  unfold RCInvRel
  constructor
  · intro h
    have hm := congrArg cToD h
    rw [cToD_mul, cToD_one] at hm
    exact hm
  · intro h
    have hm : cToD (rCMul x y) = cToD rCOne := by
      rw [cToD_mul, cToD_one]
      exact h
    have hi := congrArg dToC hm
    simpa only [dToC_cToD] using hi

/-- The reverse H5 map preserves and reflects the accepted inverse witness
    equation. -/
theorem dToC_inverse_relation_iff {x y : RBOMA} :
    rMulCandidate x y = rOne ↔ RCInvRel (dToC x) (dToC y) := by
  unfold RCInvRel
  constructor
  · intro h
    have hm := congrArg dToC h
    rw [dToC_mul, dToC_one] at hm
    exact hm
  · intro h
    have hm :
        dToC (rMulCandidate x y) = dToC rOne := by
      rw [dToC_mul, dToC_one]
      exact h
    have hi := congrArg cToD hm
    simpa only [cToD_dToC] using hi

/-- Every nonzero Cauchy inverse witness transports to an accepted Dedekind
    inverse witness without selecting any new element. -/
theorem cToD_inverse_witness
    {x y : RCBOMA}
    (hx : x ≠ rCZero)
    (hy : RCInvRel x y) :
    cToD x ≠ rZero ∧
      rMulCandidate (cToD x) (cToD y) = rOne := by
  exact ⟨(cToD_ne_zero_iff).2 hx, (cToD_inverse_relation_iff).1 hy⟩

/-- Every accepted Dedekind inverse witness transports to a Cauchy inverse
    witness without selecting any new element. -/
theorem dToC_inverse_witness
    {x y : RBOMA}
    (hx : x ≠ rZero)
    (hy : rMulCandidate x y = rOne) :
    dToC x ≠ rCZero ∧ RCInvRel (dToC x) (dToC y) := by
  exact ⟨(dToC_ne_zero_iff).2 hx, (dToC_inverse_relation_iff).1 hy⟩

/-- Existence of the accepted inverse witness is exactly transported from the
    independent Cauchy route. -/
theorem cToD_inverse_exists_of_nonzero
    (x : RCBOMA) (hx : x ≠ rCZero) :
    ∃ y : RBOMA,
      rMulCandidate (cToD x) y = rOne := by
  rcases rC_inverse_exists x hx with ⟨y, hy⟩
  exact ⟨cToD y, (cToD_inverse_relation_iff).1 hy⟩

/-- Conversely, accepted inverse existence transports to the independent
    Cauchy route through the reverse comparison map. -/
theorem dToC_inverse_exists_of_nonzero
    (x : RBOMA) (hx : x ≠ rZero) :
    ∃ y : RCBOMA, RCInvRel (dToC x) y := by
  rcases r_inverse_exists_nonzero x hx with ⟨y, hy⟩
  exact ⟨dToC y, (dToC_inverse_relation_iff).1 hy⟩

/-- Final machine-checkable H5 field-isomorphism package.

    This is a BOMA theorem-level certificate rather than a new carrier or a
    standard-library field instance.  It records exactly the structures that
    the explicit mutually inverse comparison maps preserve. -/
structure DedekindCauchyFieldIsomorphismCertificate where
  multiplicative : DedekindCauchyMultiplicativePreservationCertificate
  forwardMap : RCBOMA → RBOMA
  reverseMap : RBOMA → RCBOMA
  leftInverse : ∀ x : RCBOMA, reverseMap (forwardMap x) = x
  rightInverse : ∀ x : RBOMA, forwardMap (reverseMap x) = x
  rationalPreservation : ∀ q : BOMA.Q.Quotient001.QBOMA,
    forwardMap (rCOfQ q) = rOfQ q
  orderIff : ∀ {x y : RCBOMA},
    BOMA.R.DedekindQuotient001.rLE (forwardMap x) (forwardMap y) ↔
      BOMA.R.StageTwo.CauchyOrderCore003.rCLE x y
  addPreservation : ∀ x y : RCBOMA,
    forwardMap (BOMA.R.StageTwo.CauchyAdditive003.rCAdd x y) =
      BOMA.R.DedekindAddition001.rAdd (forwardMap x) (forwardMap y)
  zeroPreservation : forwardMap rCZero = rZero
  negPreservation : ∀ x : RCBOMA,
    forwardMap (BOMA.R.StageTwo.CauchyAdditive003.rCNeg x) =
      BOMA.R.DedekindNegationCandidate001.rNeg (forwardMap x)
  mulPreservation : ∀ x y : RCBOMA,
    forwardMap (BOMA.R.StageTwo.CauchyMultiplicative003.rCMul x y) =
      rMulCandidate (forwardMap x) (forwardMap y)
  onePreservation : forwardMap rCOne = rOne
  nonzeroIff : ∀ {x : RCBOMA}, forwardMap x ≠ rZero ↔ x ≠ rCZero
  inverseRelationIff : ∀ {x y : RCBOMA},
    RCInvRel x y ↔ rMulCandidate (forwardMap x) (forwardMap y) = rOne

noncomputable def dedekindCauchyFieldIsomorphismCertificate :
    DedekindCauchyFieldIsomorphismCertificate where
  multiplicative := dedekindCauchyMultiplicativePreservationCertificate
  forwardMap := cToD
  reverseMap := dToC
  leftInverse := dToC_cToD
  rightInverse := cToD_dToC
  rationalPreservation := cToD_rational
  orderIff := @cToD_order_iff
  addPreservation := cToD_add
  zeroPreservation := cToD_zero
  negPreservation := cToD_neg
  mulPreservation := cToD_mul
  onePreservation := cToD_one
  nonzeroIff := @cToD_ne_zero_iff
  inverseRelationIff := @cToD_inverse_relation_iff

end BOMA.R.StageTwo.DedekindCauchyComparison003

/- ST2-EXP-003 research-only R reconvergence Junction.

   This source is admitted only after the post-H5 Study/Act decision recorded in
   ST2-EXP-003_H5_FIELD_ISOMORPHISM_AND_JUNCTION_STUDY_001.md.  It does not
   define a new real carrier, does not replace accepted R-BLOCK-001, and does
   not alter accepted C.  Its only purpose is to expose one auditable root that
   packages the two independently completed real producers together with the
   exact H5 field/order isomorphism between them. -/
namespace BOMA.R.StageTwo.DedekindCauchyJunction003

open BOMA.R.StageIntegration002
open BOMA.R.StageTwo.CauchyLUB003
open BOMA.R.StageTwo.DedekindCauchyComparison003

/-- Research reconvergence root for the completed accepted Dedekind producer
    and independently completed Cauchy producer.  The comparison component
    already contains the explicit mutually inverse maps and preservation of
    rational embedding, order, additive and multiplicative structure,
    nonzeroness, and the witness-only inverse relation. -/
structure DedekindCauchyResearchJunctionCertificate where
  acceptedDedekindRoute : RStageIntegrationCertificate
  independentCauchyRoute : CauchyLUBCertificate
  fieldIsomorphism : DedekindCauchyFieldIsomorphismCertificate

/-- The research-only R Junction.  No additional selector is introduced here;
    all logical commitments are inherited from the two completed routes and
    the already verified H5 comparison. -/
noncomputable def dedekindCauchyResearchJunctionCertificate :
    DedekindCauchyResearchJunctionCertificate where
  acceptedDedekindRoute := rStageIntegrationCertificate
  independentCauchyRoute := cauchyLUBCertificate
  fieldIsomorphism := dedekindCauchyFieldIsomorphismCertificate

end BOMA.R.StageTwo.DedekindCauchyJunction003

/- ST2-EXP-015 Gate D: external comparisons after both native gates pass.
The vertical maps use the fixed H5 scalar maps only in this external assembly. -/
namespace BOMA.C.StageTwo.RouteSquare015

open BOMA.R.StageTwo.CauchyQuotient003
open BOMA.R.StageTwo.CauchyAdditive003
open BOMA.R.StageTwo.CauchyMultiplicative003
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.R.StageTwo.DedekindCauchyComparison003
open BOMA.C.PairCore001
open BOMA.C.StageTwo.CauchyQuadratic003
open BOMA.C.StageTwo.QQuotientField015
open BOMA.C.StageTwo.NativePQ015

abbrev DQ := BOMA.C.StageTwo.QQuotientField002.QBOMA
abbrev dqZero  : DQ := BOMA.C.StageTwo.QQuotientField002.qZero 
abbrev dqOne  : DQ := BOMA.C.StageTwo.QQuotientField002.qOne 
abbrev dqI  : DQ := BOMA.C.StageTwo.QQuotientField002.qI 
abbrev dqNeg (z : DQ) : DQ := BOMA.C.StageTwo.QQuotientField002.qNeg z
abbrev dqAdd (z w : DQ) : DQ := BOMA.C.StageTwo.QQuotientField002.qAdd z w
abbrev dqMul (z w : DQ) : DQ := BOMA.C.StageTwo.QQuotientField002.qMul z w
abbrev dqOfR (a : RBOMA) : DQ := BOMA.C.StageTwo.QQuotientField002.qOfR a
abbrev dqCoord (a b : RBOMA) : DQ := BOMA.C.StageTwo.QQuotientField002.qCoord a b
abbrev dqRe (z : DQ) : RBOMA := BOMA.C.StageTwo.QQuotientField002.qRe z
abbrev dqIm (z : DQ) : RBOMA := BOMA.C.StageTwo.QQuotientField002.qIm z

def dPQ := BOMA.C.StageTwo.PQJunction002.pqIsomorphism rStageIntegrationCertificate

def dQP := BOMA.C.QuadraticComparison001.constructiveQuadraticIsomorphism
  (BOMA.C.StageTwo.PQJunction002.quotientPresentation rStageIntegrationCertificate)
  (BOMA.C.QuadraticComparison001.selectedPresentation rStageIntegrationCertificate)
  (BOMA.C.StageTwo.PQJunction002.quotientExtractor rStageIntegrationCertificate)
  (BOMA.C.QuadraticComparison001.selectedExtractor rStageIntegrationCertificate)

def dPToQ (z : CBOMA) : DQ := dPQ.forward z
def dQToP (z : DQ) : CBOMA := dPQ.backward z

/-- The horizontal Dedekind maps are exactly the retained 002 maps. -/
theorem d_horizontal_forward_exact (z : CBOMA) :
    dPToQ z = BOMA.C.StageTwo.PQJunction002.pairToQuotient rStageIntegrationCertificate z := rfl

theorem d_horizontal_reverse_exact (z : DQ) :
    dQToP z = BOMA.C.StageTwo.PQJunction002.quotientToPair rStageIntegrationCertificate z := rfl

noncomputable def pCToD (z : CCBOMA) : CBOMA := ⟨cToD z.re, cToD z.im⟩
noncomputable def pDToC (z : CBOMA) : CCBOMA := ⟨dToC z.re, dToC z.im⟩

theorem nPQ_zero  : pToQ (ccZero) = qZero :=
  pqIsomorphism.preserveZero 

theorem nPQ_one  : pToQ (ccOne) = qOne :=
  pqIsomorphism.preserveOne 

theorem nPQ_imag  : pToQ (ccI) = qI :=
  pqIsomorphism.preserveImag 

theorem nPQ_real (a : RCBOMA) : pToQ (ccOfR a) = qOfR a :=
  pqIsomorphism.preserveReal a

theorem nPQ_neg (z : CCBOMA) : pToQ (ccNeg z) = qNeg (pToQ z) :=
  pqIsomorphism.preserveNeg z

theorem nPQ_add (z w : CCBOMA) : pToQ (ccAdd z w) = qAdd (pToQ z) (pToQ w) :=
  pqIsomorphism.preserveAdd z w

theorem nPQ_mul (z w : CCBOMA) : pToQ (ccMul z w) = qMul (pToQ z) (pToQ w) :=
  pqIsomorphism.preserveMul z w

theorem nQP_zero  : qToP (qZero) = ccZero :=
  qpIsomorphism.preserveZero 

theorem nQP_one  : qToP (qOne) = ccOne :=
  qpIsomorphism.preserveOne 

theorem nQP_imag  : qToP (qI) = ccI :=
  qpIsomorphism.preserveImag 

theorem nQP_real (a : RCBOMA) : qToP (qOfR a) = ccOfR a :=
  qpIsomorphism.preserveReal a

theorem nQP_neg (z : QBOMA) : qToP (qNeg z) = ccNeg (qToP z) :=
  qpIsomorphism.preserveNeg z

theorem nQP_add (z w : QBOMA) : qToP (qAdd z w) = ccAdd (qToP z) (qToP w) :=
  qpIsomorphism.preserveAdd z w

theorem nQP_mul (z w : QBOMA) : qToP (qMul z w) = ccMul (qToP z) (qToP w) :=
  qpIsomorphism.preserveMul z w

theorem dPQ_zero  : dPToQ (cZero) = dqZero :=
  dPQ.preserveZero 

theorem dPQ_one  : dPToQ (cOne) = dqOne :=
  dPQ.preserveOne 

theorem dPQ_imag  : dPToQ (cI) = dqI :=
  dPQ.preserveImag 

theorem dPQ_real (a : RBOMA) : dPToQ (cOfR a) = dqOfR a :=
  dPQ.preserveReal a

theorem dPQ_neg (z : CBOMA) : dPToQ (cNeg z) = dqNeg (dPToQ z) :=
  dPQ.preserveNeg z

theorem dPQ_add (z w : CBOMA) : dPToQ (cAdd z w) = dqAdd (dPToQ z) (dPToQ w) :=
  dPQ.preserveAdd z w

theorem dPQ_mul (z w : CBOMA) : dPToQ (cMul z w) = dqMul (dPToQ z) (dPToQ w) :=
  dPQ.preserveMul z w

theorem dQP_zero  : dQToP (dqZero) = cZero :=
  dQP.preserveZero 

theorem dQP_one  : dQToP (dqOne) = cOne :=
  dQP.preserveOne 

theorem dQP_imag  : dQToP (dqI) = cI :=
  dQP.preserveImag 

theorem dQP_real (a : RBOMA) : dQToP (dqOfR a) = cOfR a :=
  dQP.preserveReal a

theorem dQP_neg (z : DQ) : dQToP (dqNeg z) = cNeg (dQToP z) :=
  dQP.preserveNeg z

theorem dQP_add (z w : DQ) : dQToP (dqAdd z w) = cAdd (dQToP z) (dQToP w) :=
  dQP.preserveAdd z w

theorem dQP_mul (z w : DQ) : dQToP (dqMul z w) = cMul (dQToP z) (dQToP w) :=
  dQP.preserveMul z w

theorem native_inverse_left (z : CCBOMA) : qToP (pToQ z) = z :=
  pqIsomorphism.leftInverse z

theorem native_inverse_right (z : QBOMA) : pToQ (qToP z) = z :=
  pqIsomorphism.rightInverse z

theorem d_inverse_left (z : CBOMA) : dQToP (dPToQ z) = z := dPQ.leftInverse z
theorem d_inverse_right (z : DQ) : dPToQ (dQToP z) = z := dPQ.rightInverse z

theorem pCD_zero  : pCToD (ccZero) = cZero := by
  apply c_ext <;>
    simp only [pCToD, ccZero, cZero, BOMA.C.RoutePairProbe001.zero,
      cToD_zero]

theorem pCD_one  : pCToD (ccOne) = cOne := by
  apply c_ext <;>
    simp only [pCToD, ccOne, cOne, BOMA.C.RoutePairProbe001.one,
      cToD_zero, cToD_one]

theorem pCD_imag  : pCToD (ccI) = cI := by
  apply c_ext <;>
    simp only [pCToD, ccI, cI, BOMA.C.RoutePairProbe001.imag,
      cToD_zero, cToD_one]

theorem pCD_real (a : RCBOMA) : pCToD (ccOfR a) = cOfR (cToD a) := by
  apply c_ext <;>
    simp only [pCToD, ccOfR, cOfR, BOMA.C.RoutePairProbe001.ofR,
      cToD_zero]

theorem pCD_neg (z : CCBOMA) : pCToD (ccNeg z) = cNeg (pCToD z) := by
  apply c_ext <;>
    simp only [pCToD, ccNeg, cNeg, BOMA.C.RoutePairProbe001.neg,
      cToD_neg]

theorem pCD_add (z w : CCBOMA) : pCToD (ccAdd z w) = cAdd (pCToD z) (pCToD w) := by
  apply c_ext <;>
    simp only [pCToD, ccAdd, cAdd, BOMA.C.RoutePairProbe001.add,
      cToD_add]

theorem pCD_mul (z w : CCBOMA) : pCToD (ccMul z w) = cMul (pCToD z) (pCToD w) := by
  apply c_ext <;>
    simp only [pCToD, ccMul, cMul, BOMA.C.RoutePairProbe001.mul,
      cToD_neg, cToD_add, cToD_mul]

theorem pDC_zero  : pDToC (cZero) = ccZero := by
  apply cc_ext <;>
    simp only [pDToC, cZero, ccZero, BOMA.C.RoutePairProbe001.zero,
      dToC_zero]

theorem pDC_one  : pDToC (cOne) = ccOne := by
  apply cc_ext <;>
    simp only [pDToC, cOne, ccOne, BOMA.C.RoutePairProbe001.one,
      dToC_zero, dToC_one]

theorem pDC_imag  : pDToC (cI) = ccI := by
  apply cc_ext <;>
    simp only [pDToC, cI, ccI, BOMA.C.RoutePairProbe001.imag,
      dToC_zero, dToC_one]

theorem pDC_real (a : RBOMA) : pDToC (cOfR a) = ccOfR (dToC a) := by
  apply cc_ext <;>
    simp only [pDToC, cOfR, ccOfR, BOMA.C.RoutePairProbe001.ofR,
      dToC_zero]

theorem pDC_neg (z : CBOMA) : pDToC (cNeg z) = ccNeg (pDToC z) := by
  apply cc_ext <;>
    simp only [pDToC, cNeg, ccNeg, BOMA.C.RoutePairProbe001.neg,
      dToC_neg]

theorem pDC_add (z w : CBOMA) : pDToC (cAdd z w) = ccAdd (pDToC z) (pDToC w) := by
  apply cc_ext <;>
    simp only [pDToC, cAdd, ccAdd, BOMA.C.RoutePairProbe001.add,
      dToC_add]

theorem pDC_mul (z w : CBOMA) : pDToC (cMul z w) = ccMul (pDToC z) (pDToC w) := by
  apply cc_ext <;>
    simp only [pDToC, cMul, ccMul, BOMA.C.RoutePairProbe001.mul,
      dToC_neg, dToC_add, dToC_mul]

theorem p_inverse_left (z : CCBOMA) : pDToC (pCToD z) = z := by
  apply cc_ext <;> simp only [pDToC, pCToD, dToC_cToD]

theorem p_inverse_right (z : CBOMA) : pCToD (pDToC z) = z := by
  apply c_ext <;> simp only [pDToC, pCToD, cToD_dToC]

/-- Quotient vertical maps compare existing representations; they build neither field. -/
noncomputable def qCToD (z : QBOMA) : DQ := dPToQ (pCToD (qToP z))
noncomputable def qDToC (z : DQ) : QBOMA := pToQ (pDToC (dQToP z))

theorem qCD_coordinate_formula (z : QBOMA) :
    qCToD z = dqCoord (cToD (qRe z)) (cToD (qIm z)) := rfl

theorem qDC_coordinate_formula (z : DQ) :
    qDToC z = qCoord (dToC (dqRe z)) (dToC (dqIm z)) := rfl

theorem qCD_zero  : qCToD (qZero) = dqZero := by
  simp only [qCToD, nQP_zero, pCD_zero, dPQ_zero]

theorem qCD_one  : qCToD (qOne) = dqOne := by
  simp only [qCToD, nQP_one, pCD_one, dPQ_one]

theorem qCD_imag  : qCToD (qI) = dqI := by
  simp only [qCToD, nQP_imag, pCD_imag, dPQ_imag]

theorem qCD_real (a : RCBOMA) : qCToD (qOfR a) = dqOfR (cToD a) := by
  simp only [qCToD, nQP_real, pCD_real, dPQ_real]

theorem qCD_neg (z : QBOMA) : qCToD (qNeg z) = dqNeg (qCToD z) := by
  simp only [qCToD, nQP_neg, pCD_neg, dPQ_neg]

theorem qCD_add (z w : QBOMA) : qCToD (qAdd z w) = dqAdd (qCToD z) (qCToD w) := by
  simp only [qCToD, nQP_add, pCD_add, dPQ_add]

theorem qCD_mul (z w : QBOMA) : qCToD (qMul z w) = dqMul (qCToD z) (qCToD w) := by
  simp only [qCToD, nQP_mul, pCD_mul, dPQ_mul]

theorem qDC_zero  : qDToC (dqZero) = qZero := by
  simp only [qDToC, dQP_zero, pDC_zero, nPQ_zero]

theorem qDC_one  : qDToC (dqOne) = qOne := by
  simp only [qDToC, dQP_one, pDC_one, nPQ_one]

theorem qDC_imag  : qDToC (dqI) = qI := by
  simp only [qDToC, dQP_imag, pDC_imag, nPQ_imag]

theorem qDC_real (a : RBOMA) : qDToC (dqOfR a) = qOfR (dToC a) := by
  simp only [qDToC, dQP_real, pDC_real, nPQ_real]

theorem qDC_neg (z : DQ) : qDToC (dqNeg z) = qNeg (qDToC z) := by
  simp only [qDToC, dQP_neg, pDC_neg, nPQ_neg]

theorem qDC_add (z w : DQ) : qDToC (dqAdd z w) = qAdd (qDToC z) (qDToC w) := by
  simp only [qDToC, dQP_add, pDC_add, nPQ_add]

theorem qDC_mul (z w : DQ) : qDToC (dqMul z w) = qMul (qDToC z) (qDToC w) := by
  simp only [qDToC, dQP_mul, pDC_mul, nPQ_mul]

theorem q_inverse_left (z : QBOMA) : qDToC (qCToD z) = z := by
  simp only [qDToC, qCToD, d_inverse_left, p_inverse_left, native_inverse_right]

theorem q_inverse_right (z : DQ) : qCToD (qDToC z) = z := by
  simp only [qDToC, qCToD, native_inverse_left, p_inverse_right, d_inverse_right]

/-- Forward square: native P to Dedekind Q, for every native P element. -/
theorem square_forward (z : CCBOMA) : dPToQ (pCToD z) = qCToD (pToQ z) := by
  simp only [qCToD, native_inverse_left]

/-- Reverse square: Dedekind Q to native P, for every Dedekind Q element. -/
theorem square_reverse (z : DQ) : pDToC (dQToP z) = qToP (qDToC z) := by
  simp only [qDToC, native_inverse_left]

theorem pCD_inverse_witness {x y : CCBOMA}
    (h : ccMul x y = ccOne) : cMul (pCToD x) (pCToD y) = cOne := by
  have ht := congrArg pCToD h
  rw [pCD_mul, pCD_one] at ht
  exact ht

theorem pDC_inverse_witness {x y : CBOMA}
    (h : cMul x y = cOne) : ccMul (pDToC x) (pDToC y) = ccOne := by
  have ht := congrArg pDToC h
  rw [pDC_mul, pDC_one] at ht
  exact ht

theorem qCD_inverse_witness {x y : QBOMA}
    (h : qMul x y = qOne) : dqMul (qCToD x) (qCToD y) = dqOne := by
  have ht := congrArg qCToD h
  rw [qCD_mul, qCD_one] at ht
  exact ht

theorem qDC_inverse_witness {x y : DQ}
    (h : dqMul x y = dqOne) : qMul (qDToC x) (qDToC y) = qOne := by
  have ht := congrArg qDToC h
  rw [qDC_mul, qDC_one] at ht
  exact ht

structure RouteSquareCertificate where
  native : NativePQJunctionCertificate
  dedekind : BOMA.C.StageTwo.PQJunction002.QPairJunctionCertificate
  scalar : DedekindCauchyFieldIsomorphismCertificate
  horizontalForwardExact : ∀ z : CBOMA,
    dPToQ z = BOMA.C.StageTwo.PQJunction002.pairToQuotient rStageIntegrationCertificate z
  horizontalReverseExact : ∀ z : DQ,
    dQToP z = BOMA.C.StageTwo.PQJunction002.quotientToPair rStageIntegrationCertificate z
  pLeftInverse : ∀ z : CCBOMA, pDToC (pCToD z) = z
  pRightInverse : ∀ z : CBOMA, pCToD (pDToC z) = z
  qLeftInverse : ∀ z : QBOMA, qDToC (qCToD z) = z
  qRightInverse : ∀ z : DQ, qCToD (qDToC z) = z
  squareForward : ∀ z : CCBOMA, dPToQ (pCToD z) = qCToD (pToQ z)
  squareReverse : ∀ z : DQ, pDToC (dQToP z) = qToP (qDToC z)
  qForwardFormula : ∀ z : QBOMA, qCToD z = dqCoord (cToD (qRe z)) (cToD (qIm z))
  qReverseFormula : ∀ z : DQ, qDToC z = qCoord (dToC (dqRe z)) (dToC (dqIm z))
  pCD_zero : pCToD (ccZero) = cZero
  pCD_one : pCToD (ccOne) = cOne
  pCD_imag : pCToD (ccI) = cI
  pCD_real (a : RCBOMA) : pCToD (ccOfR a) = cOfR (cToD a)
  pCD_neg (z : CCBOMA) : pCToD (ccNeg z) = cNeg (pCToD z)
  pCD_add (z w : CCBOMA) : pCToD (ccAdd z w) = cAdd (pCToD z) (pCToD w)
  pCD_mul (z w : CCBOMA) : pCToD (ccMul z w) = cMul (pCToD z) (pCToD w)
  pCD_inverse_witness {x y : CCBOMA}
    (h : ccMul x y = ccOne) : cMul (pCToD x) (pCToD y) = cOne
  pDC_zero : pDToC (cZero) = ccZero
  pDC_one : pDToC (cOne) = ccOne
  pDC_imag : pDToC (cI) = ccI
  pDC_real (a : RBOMA) : pDToC (cOfR a) = ccOfR (dToC a)
  pDC_neg (z : CBOMA) : pDToC (cNeg z) = ccNeg (pDToC z)
  pDC_add (z w : CBOMA) : pDToC (cAdd z w) = ccAdd (pDToC z) (pDToC w)
  pDC_mul (z w : CBOMA) : pDToC (cMul z w) = ccMul (pDToC z) (pDToC w)
  pDC_inverse_witness {x y : CBOMA}
    (h : cMul x y = cOne) : ccMul (pDToC x) (pDToC y) = ccOne
  qCD_zero : qCToD (qZero) = dqZero
  qCD_one : qCToD (qOne) = dqOne
  qCD_imag : qCToD (qI) = dqI
  qCD_real (a : RCBOMA) : qCToD (qOfR a) = dqOfR (cToD a)
  qCD_neg (z : QBOMA) : qCToD (qNeg z) = dqNeg (qCToD z)
  qCD_add (z w : QBOMA) : qCToD (qAdd z w) = dqAdd (qCToD z) (qCToD w)
  qCD_mul (z w : QBOMA) : qCToD (qMul z w) = dqMul (qCToD z) (qCToD w)
  qCD_inverse_witness {x y : QBOMA}
    (h : qMul x y = qOne) : dqMul (qCToD x) (qCToD y) = dqOne
  qDC_zero : qDToC (dqZero) = qZero
  qDC_one : qDToC (dqOne) = qOne
  qDC_imag : qDToC (dqI) = qI
  qDC_real (a : RBOMA) : qDToC (dqOfR a) = qOfR (dToC a)
  qDC_neg (z : DQ) : qDToC (dqNeg z) = qNeg (qDToC z)
  qDC_add (z w : DQ) : qDToC (dqAdd z w) = qAdd (qDToC z) (qDToC w)
  qDC_mul (z w : DQ) : qDToC (dqMul z w) = qMul (qDToC z) (qDToC w)
  qDC_inverse_witness {x y : DQ}
    (h : dqMul x y = dqOne) : qMul (qDToC x) (qDToC y) = qOne

noncomputable def routeSquareCertificate : RouteSquareCertificate where
  native := nativePQJunctionCertificate
  dedekind := BOMA.C.StageTwo.PQJunction002.qPairJunctionCertificate
  scalar := dedekindCauchyFieldIsomorphismCertificate
  horizontalForwardExact := d_horizontal_forward_exact
  horizontalReverseExact := d_horizontal_reverse_exact
  pLeftInverse := p_inverse_left
  pRightInverse := p_inverse_right
  qLeftInverse := q_inverse_left
  qRightInverse := q_inverse_right
  squareForward := square_forward
  squareReverse := square_reverse
  qForwardFormula := qCD_coordinate_formula
  qReverseFormula := qDC_coordinate_formula
  pCD_zero := pCD_zero
  pCD_one := pCD_one
  pCD_imag := pCD_imag
  pCD_real := pCD_real
  pCD_neg := pCD_neg
  pCD_add := pCD_add
  pCD_mul := pCD_mul
  pCD_inverse_witness := @pCD_inverse_witness
  pDC_zero := pDC_zero
  pDC_one := pDC_one
  pDC_imag := pDC_imag
  pDC_real := pDC_real
  pDC_neg := pDC_neg
  pDC_add := pDC_add
  pDC_mul := pDC_mul
  pDC_inverse_witness := @pDC_inverse_witness
  qCD_zero := qCD_zero
  qCD_one := qCD_one
  qCD_imag := qCD_imag
  qCD_real := qCD_real
  qCD_neg := qCD_neg
  qCD_add := qCD_add
  qCD_mul := qCD_mul
  qCD_inverse_witness := @qCD_inverse_witness
  qDC_zero := qDC_zero
  qDC_one := qDC_one
  qDC_imag := qDC_imag
  qDC_real := qDC_real
  qDC_neg := qDC_neg
  qDC_add := qDC_add
  qDC_mul := qDC_mul
  qDC_inverse_witness := @qDC_inverse_witness

end BOMA.C.StageTwo.RouteSquare015

#print axioms BOMA.C.StageTwo.QPresentation015.nativeQFullCertificate
#print axioms BOMA.C.StageTwo.QQuotientField015.qFieldCertificateFromCauchyR
#print axioms BOMA.C.StageTwo.NativePQ015.nativePQJunctionCertificate
#print axioms BOMA.C.StageTwo.RouteSquare015.routeSquareCertificate
