/-
BOMA R-B N-Core candidate 001 — unified backend payload.

This file IMPLEMENTS the formal candidate N-RB-CAND-001 under
BOMA-RB-FORMAL-001 plus the V5 scope correction recorded after
PDSA-N-007-V5-FAILURE-001. It is not the canonical pre-numerical TCT
definition. It deliberately defines a fresh carrier and does not use Lean's
built-in Nat as the N-Core carrier.

Any TCTNF datatype below REPRESENTS selected TCT normal forms for backend
verification only.
-/

namespace BOMA.NCore.RB001

universe u

/-! ## Fresh R-B carrier -/

inductive BOMANat where
  | z : BOMANat
  | s : BOMANat → BOMANat

open BOMANat

/-! ## No-confusion obligations -/

theorem s_ne_z (n : BOMANat) : s n ≠ z := by
  intro h
  cases h

theorem s_injective {a b : BOMANat} (h : s a = s b) : a = b := by
  cases h
  rfl

/-! ## Dependent elimination / induction -/

/-- Sort-polymorphic eliminator: covers proposition-valued induction and
    Type-valued dependent elimination without conflating their scopes. -/
def ind {P : BOMANat → Sort u}
    (hz : P z)
    (hs : ∀ n, P n → P (s n)) :
    ∀ n, P n
  | z => hz
  | s n => hs n (ind hz hs n)

theorem induction_adequacy
    (P : BOMANat → Prop)
    (hz : P z)
    (hs : ∀ n, P n → P (s n)) :
    ∀ n, P n :=
  ind hz hs

/-! ## Nondependent recursion and pointwise uniqueness -/

def fold {X : Type u} (x0 : X) (step : X → X) : BOMANat → X
  | z => x0
  | s n => step (fold x0 step n)

@[simp] theorem fold_z {X : Type u} (x0 : X) (step : X → X) :
    fold x0 step z = x0 := rfl

@[simp] theorem fold_s {X : Type u} (x0 : X) (step : X → X) (n : BOMANat) :
    fold x0 step (s n) = step (fold x0 step n) := rfl

theorem fold_unique
    {X : Type u}
    (x0 : X)
    (step : X → X)
    (h : BOMANat → X)
    (hz : h z = x0)
    (hs : ∀ n, h (s n) = step (h n)) :
    ∀ n, h n = fold x0 step n := by
  intro n
  induction n with
  | z => exact hz
  | s n ih =>
      calc
        h (s n) = step (h n) := hs n
        _ = step (fold x0 step n) := congrArg step ih
        _ = fold x0 step (s n) := by rfl

/-! ## Backend representation of selected TCT normal forms -/

inductive TCTNFPlus where
  | unit : TCTNFPlus
  | ext : TCTNFPlus → TCTNFPlus

inductive TCTNF where
  | eps : TCTNF
  | nonempty : TCTNFPlus → TCTNF

open TCTNFPlus TCTNF

/-- REPRESENTS selected-presentation terminal extension. -/
def extU : TCTNF → TCTNF
  | eps => nonempty unit
  | nonempty p => nonempty (ext p)

/-- Formal realization of non-empty selected TCT presentation syntax. -/
def realizePlus : TCTNFPlus → BOMANat
  | unit => s z
  | ext p => s (realizePlus p)

/-- RB-B01/RB-B02 realization of selected TCT presentation syntax. -/
def realize : TCTNF → BOMANat
  | eps => z
  | nonempty p => realizePlus p

@[simp] theorem realize_eps : realize eps = z := rfl

@[simp] theorem realize_extU (a : TCTNF) :
    realize (extU a) = s (realize a) := by
  cases a <;> rfl

/-- Structural reification used to prove selected-NF bridge faithfulness. -/
def reify : BOMANat → TCTNF
  | z => eps
  | s n => extU (reify n)

@[simp] theorem realize_reify (n : BOMANat) :
    realize (reify n) = n := by
  induction n with
  | z => rfl
  | s n ih => simp [reify, ih]

@[simp] theorem reify_realizePlus (p : TCTNFPlus) :
    reify (realizePlus p) = nonempty p := by
  induction p with
  | unit => rfl
  | ext p ih => simp [realizePlus, reify, extU, ih]

@[simp] theorem reify_realize (a : TCTNF) :
    reify (realize a) = a := by
  cases a with
  | eps => rfl
  | nonempty p => exact reify_realizePlus p

theorem realize_injective {a b : TCTNF} (h : realize a = realize b) : a = b := by
  have h' := congrArg reify h
  simpa using h'

/-!
For selected normal forms only, canonical PDSA-TCT-004 proves that BR-010
structural equivalence is equivalent to selected-presentation identity.
Therefore backend equality on TCTNF represents ≈ in this restricted scope.
-/

theorem bridge_preserves_selected_identity {a b : TCTNF} (h : a = b) :
    realize a = realize b := by
  cases h
  rfl

theorem bridge_reflects_formal_identity {a b : TCTNF}
    (h : realize a = realize b) : a = b :=
  realize_injective h

/-! ## Unary-algebra initiality / recursion characterization -/

/-- Universe-polymorphic algebra record. The canonical BOMA initiality theorem
    below is intentionally specialized to Type 0 for Stage One; the generic
    comparison theorem remains same-universe polymorphic. -/
structure UnaryAlgebra where
  Carrier : Type u
  base : Carrier
  step : Carrier → Carrier

structure Hom (A B : UnaryAlgebra.{u}) where
  toFun : A.Carrier → B.Carrier
  map_base : toFun A.base = B.base
  map_step : ∀ x, toFun (A.step x) = B.step (toFun x)

/-- The formal BOMA candidate viewed as a Type-0 unary algebra. -/
def bomaAlg : UnaryAlgebra.{0} where
  Carrier := BOMANat
  base := z
  step := s

def idHom (A : UnaryAlgebra.{u}) : Hom A A where
  toFun := fun x => x
  map_base := rfl
  map_step := by intro x; rfl

def compHom {A B C : UnaryAlgebra.{u}} (g : Hom B C) (f : Hom A B) : Hom A C where
  toFun := fun x => g.toFun (f.toFun x)
  map_base := by
    calc
      g.toFun (f.toFun A.base) = g.toFun B.base := congrArg g.toFun f.map_base
      _ = C.base := g.map_base
  map_step := by
    intro x
    calc
      g.toFun (f.toFun (A.step x)) = g.toFun (B.step (f.toFun x)) :=
        congrArg g.toFun (f.map_step x)
      _ = C.step (g.toFun (f.toFun x)) := g.map_step (f.toFun x)

/-- Existence of the canonical homomorphism from the BOMA candidate to a
    Type-0 target unary algebra. -/
def foldHom (A : UnaryAlgebra.{0}) : Hom bomaAlg A where
  toFun := fold A.base A.step
  map_base := rfl
  map_step := by intro n; rfl

/-- Pointwise uniqueness of homomorphisms from the BOMA candidate in the
    selected Type-0 unary-algebra scope. -/
theorem foldHom_unique (A : UnaryAlgebra.{0}) (h : Hom bomaAlg A) :
    ∀ n, h.toFun n = (foldHom A).toFun n :=
  fold_unique A.base A.step h.toFun h.map_base h.map_step

/-- Same-universe pointwise initiality avoids requiring function extensionality. -/
def PointwiseInitial (A : UnaryAlgebra.{u}) : Prop :=
  ∀ B : UnaryAlgebra.{u},
    ∃ h : Hom A B,
      ∀ k : Hom A B, ∀ x, k.toFun x = h.toFun x

/-- Stage-One BOMA initiality is explicitly scoped to Type-0 unary algebras. -/
theorem boma_pointwise_initial : PointwiseInitial bomaAlg := by
  intro B
  refine ⟨foldHom B, ?_⟩
  intro k x
  exact foldHom_unique B k x

/-- Any two same-universe pointwise-initial unary algebras are pointwise
    inverse-isomorphic. -/
theorem pointwise_initial_unique
    (A B : UnaryAlgebra.{u})
    (hA : PointwiseInitial A)
    (hB : PointwiseInitial B) :
    ∃ f : Hom A B, ∃ g : Hom B A,
      (∀ x, g.toFun (f.toFun x) = x) ∧
      (∀ y, f.toFun (g.toFun y) = y) := by
  obtain ⟨f, _hf⟩ := hA B
  obtain ⟨g, _hg⟩ := hB A
  refine ⟨f, g, ?_, ?_⟩
  · obtain ⟨hAA, huniqA⟩ := hA A
    intro x
    have hcomp := huniqA (compHom g f) x
    have hid := huniqA (idHom A) x
    exact hcomp.trans hid.symm
  · obtain ⟨hBB, huniqB⟩ := hB B
    intro y
    have hcomp := huniqB (compHom f g) y
    have hid := huniqB (idHom B) y
    exact hcomp.trans hid.symm

end BOMA.NCore.RB001

/- Route R fragment: concatenate after NCoreRB001.lean. -/
namespace BOMA.NArithmetic.Addition001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

def addR (a b : BOMANat) : BOMANat := fold a s b

@[simp] theorem addR_z (a : BOMANat) : addR a z = a := rfl
@[simp] theorem addR_s (a b : BOMANat) : addR a (s b) = s (addR a b) := rfl

end BOMA.NArithmetic.Addition001

/- Route L fragment: concatenate after NCoreRB001.lean. Independent of AddRight. -/
namespace BOMA.NArithmetic.Addition001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

def addL (a b : BOMANat) : BOMANat := fold b s a

@[simp] theorem addL_z (b : BOMANat) : addL z b = b := rfl
@[simp] theorem addL_s (a b : BOMANat) : addL (s a) b = s (addL a b) := rfl

end BOMA.NArithmetic.Addition001

/- Convergence fragment: concatenate after NCore + AddRight + AddLeft. -/
namespace BOMA.NArithmetic.Addition001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

/-- Opposite-side zero equation for Route R, derived rather than definitional. -/
theorem addR_z_left (b : BOMANat) : addR z b = b := by
  induction b with
  | z => rfl
  | s b ih =>
      change s (addR z b) = s b
      exact congrArg s ih

/-- Opposite-side successor equation for Route R. -/
theorem addR_s_left (a b : BOMANat) : addR (s a) b = s (addR a b) := by
  induction b with
  | z => rfl
  | s b ih =>
      change s (addR (s a) b) = s (s (addR a b))
      exact congrArg s ih

/-- N-ADD-J-001 mathematical convergence theorem. -/
theorem add_routes_converge (a b : BOMANat) : addL a b = addR a b := by
  induction a with
  | z =>
      change b = addR z b
      exact (addR_z_left b).symm
  | s a ih =>
      change s (addL a b) = addR (s a) b
      rw [addR_s_left]
      exact congrArg s ih

end BOMA.NArithmetic.Addition001

/- Canonical addition laws: concatenate after NCore + both routes + convergence. -/
namespace BOMA.NArithmetic.Addition001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

/-- Canonical spelling selected after route equivalence. -/
def add : BOMANat → BOMANat → BOMANat := addR

@[simp] theorem add_z_right (a : BOMANat) : add a z = a := rfl
@[simp] theorem add_z_left (a : BOMANat) : add z a = a := addR_z_left a
@[simp] theorem add_s_right (a b : BOMANat) : add a (s b) = s (add a b) := rfl
@[simp] theorem add_s_left (a b : BOMANat) : add (s a) b = s (add a b) := addR_s_left a b

theorem add_comm (a b : BOMANat) : add a b = add b a := by
  change addR a b = addR b a
  simpa [addL, addR] using add_routes_converge b a

theorem add_assoc (a b c : BOMANat) : add (add a b) c = add a (add b c) := by
  induction c with
  | z => rfl
  | s c ih =>
      change s (add (add a b) c) = s (add a (add b c))
      exact congrArg s ih

theorem add_right_cancel (a b c : BOMANat) : add a c = add b c → a = b := by
  induction c with
  | z =>
      intro h
      exact h
  | s c ih =>
      intro h
      apply ih
      exact s_injective h

theorem add_left_cancel (c a b : BOMANat) : add c a = add c b → a = b := by
  intro h
  apply add_right_cancel a b c
  calc
    add a c = add c a := add_comm a c
    _ = add c b := h
    _ = add b c := (add_comm b c).symm

end BOMA.NArithmetic.Addition001

/- Route R fragment: concatenate after NCore + accepted addition fragments. -/
namespace BOMA.NArithmetic.Multiplication001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

def mulR (a b : BOMANat) : BOMANat := fold z (fun x => add x a) b

@[simp] theorem mulR_z (a : BOMANat) : mulR a z = z := rfl
@[simp] theorem mulR_s (a b : BOMANat) : mulR a (s b) = add (mulR a b) a := rfl

end BOMA.NArithmetic.Multiplication001

/- Route L fragment: independent of MulRight. -/
namespace BOMA.NArithmetic.Multiplication001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

def mulL (a b : BOMANat) : BOMANat := fold z (fun x => add x b) a

@[simp] theorem mulL_z (b : BOMANat) : mulL z b = z := rfl
@[simp] theorem mulL_s (a b : BOMANat) : mulL (s a) b = add (mulL a b) b := rfl

end BOMA.NArithmetic.Multiplication001

/- Convergence fragment: after NCore + all addition + MulRight + MulLeft. -/
namespace BOMA.NArithmetic.Multiplication001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

/-- Zero on the opposite side of Route R. -/
theorem mulR_z_left (b : BOMANat) : mulR z b = z := by
  induction b with
  | z => rfl
  | s b ih =>
      change add (mulR z b) z = z
      rw [ih]
      exact add_z_right z

/-- Successor on the opposite side of Route R. -/
theorem mulR_s_left (a b : BOMANat) : mulR (s a) b = add (mulR a b) b := by
  induction b with
  | z => rfl
  | s b ih =>
      calc
        mulR (s a) (s b) = add (mulR (s a) b) (s a) := rfl
        _ = add (add (mulR a b) b) (s a) := congrArg (fun x => add x (s a)) ih
        _ = s (add (add (mulR a b) b) a) := add_s_right (add (mulR a b) b) a
        _ = s (add (mulR a b) (add b a)) := congrArg s (add_assoc (mulR a b) b a)
        _ = s (add (mulR a b) (add a b)) := congrArg s (congrArg (fun x => add (mulR a b) x) (add_comm b a))
        _ = s (add (add (mulR a b) a) b) := congrArg s (add_assoc (mulR a b) a b).symm
        _ = add (add (mulR a b) a) (s b) := (add_s_right (add (mulR a b) a) b).symm
        _ = add (mulR a (s b)) (s b) := by rfl

/-- N-MUL-J-001 convergence theorem. -/
theorem mul_routes_converge (a b : BOMANat) : mulL a b = mulR a b := by
  induction a with
  | z =>
      change z = mulR z b
      exact (mulR_z_left b).symm
  | s a ih =>
      change add (mulL a b) b = mulR (s a) b
      rw [mulR_s_left]
      exact congrArg (fun x => add x b) ih

end BOMA.NArithmetic.Multiplication001

/- Canonical multiplication laws: after routes + convergence. -/
namespace BOMA.NArithmetic.Multiplication001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

def one : BOMANat := s z
def mul : BOMANat → BOMANat → BOMANat := mulR

@[simp] theorem mul_z_right (a : BOMANat) : mul a z = z := rfl
@[simp] theorem mul_z_left (a : BOMANat) : mul z a = z := mulR_z_left a
@[simp] theorem mul_s_right (a b : BOMANat) : mul a (s b) = add (mul a b) a := rfl
@[simp] theorem mul_s_left (a b : BOMANat) : mul (s a) b = add (mul a b) b := mulR_s_left a b

theorem mul_comm (a b : BOMANat) : mul a b = mul b a := by
  change mulR a b = mulR b a
  simpa [mulL, mulR] using mul_routes_converge b a

@[simp] theorem mul_one_right (a : BOMANat) : mul a one = a := by
  change add z a = a
  exact add_z_left a

@[simp] theorem mul_one_left (a : BOMANat) : mul one a = a := by
  calc
    mul one a = mul a one := mul_comm one a
    _ = a := mul_one_right a

/-- Right distributivity over addition in the recursive multiplier argument. -/
theorem mul_add_right (a b c : BOMANat) :
    mul a (add b c) = add (mul a b) (mul a c) := by
  induction c with
  | z => rfl
  | s c ih =>
      change add (mul a (add b c)) a = add (mul a b) (add (mul a c) a)
      rw [ih]
      exact add_assoc (mul a b) (mul a c) a

/-- Left distributivity follows by multiplication commutativity. -/
theorem mul_add_left (a b c : BOMANat) :
    mul (add a b) c = add (mul a c) (mul b c) := by
  calc
    mul (add a b) c = mul c (add a b) := mul_comm (add a b) c
    _ = add (mul c a) (mul c b) := mul_add_right c a b
    _ = add (mul a c) (mul b c) := by rw [mul_comm c a, mul_comm c b]

theorem mul_assoc (a b c : BOMANat) : mul (mul a b) c = mul a (mul b c) := by
  induction c with
  | z => rfl
  | s c ih =>
      change add (mul (mul a b) c) (mul a b) = mul a (add (mul b c) b)
      rw [mul_add_right]
      rw [ih]

end BOMA.NArithmetic.Multiplication001

/- Additive-witness order route. Requires accepted addition; independent of LEInd. -/
namespace BOMA.NArithmetic.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

def LEAdd (a b : BOMANat) : Prop := ∃ k, add a k = b

theorem leAdd_refl (a : BOMANat) : LEAdd a a := ⟨z, rfl⟩

theorem leAdd_trans {a b c : BOMANat} (hab : LEAdd a b) (hbc : LEAdd b c) : LEAdd a c := by
  rcases hab with ⟨k, hk⟩
  rcases hbc with ⟨l, hl⟩
  refine ⟨add k l, ?_⟩
  calc
    add a (add k l) = add (add a k) l := (add_assoc a k l).symm
    _ = add b l := congrArg (fun x => add x l) hk
    _ = c := hl

theorem leAdd_z (b : BOMANat) : LEAdd z b := ⟨b, add_z_left b⟩

theorem leAdd_s {a b : BOMANat} (h : LEAdd a b) : LEAdd (s a) (s b) := by
  rcases h with ⟨k, hk⟩
  refine ⟨k, ?_⟩
  calc
    add (s a) k = s (add a k) := add_s_left a k
    _ = s b := congrArg s hk

end BOMA.NArithmetic.Order001

/- Structural order route. Concatenate after NCore only; no arithmetic dependency. -/
namespace BOMA.NArithmetic.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

inductive LEInd : BOMANat → BOMANat → Prop where
  | z (b : BOMANat) : LEInd z b
  | s {a b : BOMANat} : LEInd a b → LEInd (s a) (s b)

theorem leInd_refl : ∀ a : BOMANat, LEInd a a
  | z => LEInd.z z
  | s a => LEInd.s (leInd_refl a)

theorem leInd_succ_right {a b : BOMANat} : LEInd a b → LEInd a (s b)
  | LEInd.z _ => LEInd.z _
  | LEInd.s h => LEInd.s (leInd_succ_right h)

theorem leInd_trans {a b c : BOMANat} (hab : LEInd a b) (hbc : LEInd b c) : LEInd a c := by
  induction hab generalizing c with
  | z b => exact LEInd.z c
  | s hab ih =>
      cases hbc with
      | s hbc' => exact LEInd.s (ih hbc')

theorem leInd_antisymm {a b : BOMANat} (hab : LEInd a b) (hba : LEInd b a) : a = b := by
  induction a generalizing b with
  | z =>
      cases b with
      | z => rfl
      | s b => cases hba
  | s a ih =>
      cases b with
      | z => cases hab
      | s b =>
          cases hab with
          | s hab' =>
              cases hba with
              | s hba' => exact congrArg s (ih hab' hba')

theorem leInd_total (a b : BOMANat) : LEInd a b ∨ LEInd b a := by
  induction a generalizing b with
  | z => exact Or.inl (LEInd.z b)
  | s a ih =>
      cases b with
      | z => exact Or.inr (LEInd.z (s a))
      | s b =>
          cases ih b with
          | inl h => exact Or.inl (LEInd.s h)
          | inr h => exact Or.inr (LEInd.s h)

theorem leInd_s_iff {a b : BOMANat} : LEInd (s a) (s b) ↔ LEInd a b := by
  constructor
  · intro h
    cases h with
    | s h' => exact h'
  · exact LEInd.s

end BOMA.NArithmetic.Order001

/- Convergence: after NCore + addition + OrderAdditive + OrderInductive. -/
namespace BOMA.NArithmetic.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

theorem leInd_to_leAdd {a b : BOMANat} (h : LEInd a b) : LEAdd a b := by
  induction h with
  | z b => exact ⟨b, add_z_left b⟩
  | s h ih =>
      rcases ih with ⟨k, hk⟩
      refine ⟨k, ?_⟩
      simpa using congrArg s hk

theorem leInd_add_right (a k : BOMANat) : LEInd a (add a k) := by
  induction k with
  | z => simpa using leInd_refl a
  | s k ih =>
      change LEInd a (s (add a k))
      exact leInd_succ_right ih

theorem leAdd_to_leInd {a b : BOMANat} (h : LEAdd a b) : LEInd a b := by
  rcases h with ⟨k, hk⟩
  have hi : LEInd a (add a k) := leInd_add_right a k
  rw [hk] at hi
  exact hi

theorem order_routes_converge (a b : BOMANat) : LEAdd a b ↔ LEInd a b :=
  ⟨leAdd_to_leInd, leInd_to_leAdd⟩

end BOMA.NArithmetic.Order001

/- Canonical order laws after route convergence. Requires accepted arithmetic packages. -/
namespace BOMA.NArithmetic.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001

def LE : BOMANat → BOMANat → Prop := LEAdd

theorem le_refl (a : BOMANat) : LE a a := leAdd_refl a

theorem le_trans {a b c : BOMANat} : LE a b → LE b c → LE a c := leAdd_trans

theorem le_antisymm {a b : BOMANat} (hab : LE a b) (hba : LE b a) : a = b :=
  leInd_antisymm (leAdd_to_leInd hab) (leAdd_to_leInd hba)

theorem le_total (a b : BOMANat) : LE a b ∨ LE b a := by
  cases leInd_total a b with
  | inl h => exact Or.inl (leInd_to_leAdd h)
  | inr h => exact Or.inr (leInd_to_leAdd h)

@[simp] theorem z_le (b : BOMANat) : LE z b := leAdd_z b

theorem not_s_le_z (a : BOMANat) : ¬ LE (s a) z := by
  intro h
  have hi := leAdd_to_leInd h
  cases hi

theorem le_s_iff {a b : BOMANat} : LE (s a) (s b) ↔ LE a b := by
  constructor
  · intro h
    have hi := leAdd_to_leInd h
    have hp : LEInd a b := (leInd_s_iff).mp hi
    exact leInd_to_leAdd hp
  · intro h
    exact leAdd_s h

theorem add_mono_right {a b : BOMANat} (h : LE a b) (c : BOMANat) : LE (add a c) (add b c) := by
  rcases h with ⟨k, hk⟩
  refine ⟨k, ?_⟩
  calc
    add (add a c) k = add a (add c k) := add_assoc a c k
    _ = add a (add k c) := congrArg (fun x => add a x) (add_comm c k)
    _ = add (add a k) c := (add_assoc a k c).symm
    _ = add b c := congrArg (fun x => add x c) hk

theorem add_mono_left {a b : BOMANat} (h : LE a b) (c : BOMANat) : LE (add c a) (add c b) := by
  have hr := add_mono_right h c
  simpa [add_comm c a, add_comm c b] using hr

theorem mul_mono_right {a b : BOMANat} (h : LE a b) (c : BOMANat) : LE (mul a c) (mul b c) := by
  rcases h with ⟨k, hk⟩
  refine ⟨mul k c, ?_⟩
  calc
    add (mul a c) (mul k c) = mul (add a k) c := (mul_add_left a k c).symm
    _ = mul b c := congrArg (fun x => mul x c) hk

theorem mul_mono_left {a b : BOMANat} (h : LE a b) (c : BOMANat) : LE (mul c a) (mul c b) := by
  have hr := mul_mono_right h c
  simpa [mul_comm c a, mul_comm c b] using hr

end BOMA.NArithmetic.Order001

/- Signed integer representation route. Concatenate after NCore only. -/
namespace BOMA.Z.Rep001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat

inductive ZSigned where
  | zero : ZSigned
  | pos : BOMANat → ZSigned
  | neg : BOMANat → ZSigned

open ZSigned

def embedN : BOMANat → ZSigned
  | z => zero
  | s n => pos n

def zneg : ZSigned → ZSigned
  | zero => zero
  | pos n => neg n
  | neg n => pos n

/-- Structural difference without integer subtraction or numeric depth. -/
def diff : BOMANat → BOMANat → ZSigned
  | z, z => zero
  | s a, z => pos a
  | z, s b => neg b
  | s a, s b => diff a b

@[simp] theorem zneg_involutive (x : ZSigned) : zneg (zneg x) = x := by
  cases x <;> rfl

theorem embedN_injective {a b : BOMANat} (h : embedN a = embedN b) : a = b := by
  cases a <;> cases b <;> simp_all [embedN]

end BOMA.Z.Rep001

/- Difference-pair route. Requires accepted natural addition. -/
namespace BOMA.Z.Rep001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001

structure ZPair where
  p : BOMANat
  n : BOMANat

/-- (a,b) ~ (c,d) iff a+d=c+b. -/
def ZEquiv (x y : ZPair) : Prop := add x.p y.n = add y.p x.n

theorem zeq_refl (x : ZPair) : ZEquiv x x := rfl

theorem zeq_symm {x y : ZPair} (h : ZEquiv x y) : ZEquiv y x := h.symm

theorem zeq_trans {x y w : ZPair} (hxy : ZEquiv x y) (hyw : ZEquiv y w) : ZEquiv x w := by
  cases x with
  | mk a b =>
    cases y with
    | mk c d =>
      cases w with
      | mk e f =>
        apply add_right_cancel (add a f) (add e b) d
        calc
          add (add a f) d = add a (add f d) := add_assoc a f d
          _ = add a (add d f) := congrArg (fun q => add a q) (add_comm f d)
          _ = add (add a d) f := (add_assoc a d f).symm
          _ = add (add c b) f := congrArg (fun q => add q f) hxy
          _ = add c (add b f) := add_assoc c b f
          _ = add c (add f b) := congrArg (fun q => add c q) (add_comm b f)
          _ = add (add c f) b := (add_assoc c f b).symm
          _ = add (add e d) b := congrArg (fun q => add q b) hyw
          _ = add e (add d b) := add_assoc e d b
          _ = add e (add b d) := congrArg (fun q => add e q) (add_comm d b)
          _ = add (add e b) d := (add_assoc e b d).symm

end BOMA.Z.Rep001

/- Representation convergence after signed + pair routes. -/
namespace BOMA.Z.Rep001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open ZSigned


def pairOfSigned : ZSigned → ZPair
  | zero => ⟨z, z⟩
  | pos n => ⟨s n, z⟩
  | neg n => ⟨z, s n⟩

def normalizePair (x : ZPair) : ZSigned := diff x.p x.n

@[simp] theorem signed_roundtrip (x : ZSigned) : normalizePair (pairOfSigned x) = x := by
  cases x <;> rfl

/-- Adding one common successor to both coordinates preserves the represented difference. -/
theorem zeq_common_s {q : ZPair} {a b : BOMANat}
    (h : ZEquiv q ⟨a,b⟩) : ZEquiv q ⟨s a, s b⟩ := by
  cases q with
  | mk p n =>
    calc
      add p (s b) = s (add p b) := add_s_right p b
      _ = s (add a n) := congrArg s h
      _ = add (s a) n := (add_s_left a n).symm

/-- Every pair normalizes to a canonical signed representative equivalent to it. -/
theorem pair_roundtrip (x : ZPair) : ZEquiv (pairOfSigned (normalizePair x)) x := by
  cases x with
  | mk p n =>
    induction p generalizing n with
    | z =>
        cases n <;> rfl
    | s p ih =>
        cases n with
        | z => rfl
        | s n =>
            exact zeq_common_s (ih n)

/-- Distinct signed normal forms cannot have equivalent canonical pairs. -/
theorem canonical_pair_separates {x y : ZSigned}
    (h : ZEquiv (pairOfSigned x) (pairOfSigned y)) : x = y := by
  cases x <;> cases y <;> simp_all [ZEquiv, pairOfSigned]

/-- Pair equivalence implies equality of signed normal forms. -/
theorem normalize_eq_of_equiv {x y : ZPair} (h : ZEquiv x y) :
    normalizePair x = normalizePair y := by
  apply canonical_pair_separates
  exact zeq_trans (zeq_trans (pair_roundtrip x) h) (zeq_symm (pair_roundtrip y))

/-- Equality of normal forms implies pair equivalence. -/
theorem equiv_of_normalize_eq {x y : ZPair}
    (h : normalizePair x = normalizePair y) : ZEquiv x y := by
  have hx : ZEquiv x (pairOfSigned (normalizePair x)) := zeq_symm (pair_roundtrip x)
  have hy : ZEquiv (pairOfSigned (normalizePair y)) y := pair_roundtrip y
  have hc : ZEquiv (pairOfSigned (normalizePair x)) (pairOfSigned (normalizePair y)) := by
    rw [h]
    exact zeq_refl _
  exact zeq_trans (zeq_trans hx hc) hy

theorem representation_converges (x y : ZPair) :
    ZEquiv x y ↔ normalizePair x = normalizePair y :=
  ⟨normalize_eq_of_equiv, equiv_of_normalize_eq⟩

end BOMA.Z.Rep001

/- Difference-pair arithmetic used as a retained semantic/producer route.
   This file does not create a quotient carrier. -/
namespace BOMA.Z.Rep001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001

/-- Useful commutative-monoid reassociation lemmas for the accepted N addition. -/
theorem z_add_left_comm (a b c : BOMANat) : add a (add b c) = add b (add a c) := by
  calc
    add a (add b c) = add (add a b) c := (add_assoc a b c).symm
    _ = add (add b a) c := congrArg (fun t => add t c) (add_comm a b)
    _ = add b (add a c) := add_assoc b a c

theorem z_add4_swap_middle (a b c d : BOMANat) :
    add (add a b) (add c d) = add (add a c) (add b d) := by
  calc
    add (add a b) (add c d) = add a (add b (add c d)) := add_assoc a b (add c d)
    _ = add a (add c (add b d)) := congrArg (fun t => add a t) (z_add_left_comm b c d)
    _ = add (add a c) (add b d) := (add_assoc a c (add b d)).symm

theorem z_add4_swap_last (a b c d : BOMANat) :
    add (add a b) (add c d) = add (add a d) (add b c) := by
  calc
    add (add a b) (add c d) = add (add a b) (add d c) :=
      congrArg (fun t => add (add a b) t) (add_comm c d)
    _ = add (add a d) (add b c) := z_add4_swap_middle a b d c

/-- Left commutativity for accepted N multiplication, made explicit so the
proof backend can normalize triple products without guessing an AC normal form. -/
theorem z_mul_left_comm (a b c : BOMANat) : mul a (mul b c) = mul b (mul a c) := by
  calc
    mul a (mul b c) = mul (mul a b) c := (mul_assoc a b c).symm
    _ = mul (mul b a) c := congrArg (fun t => mul t c) (mul_comm a b)
    _ = mul b (mul a c) := mul_assoc b a c

def pairZero : ZPair := ⟨z, z⟩
def pairOne : ZPair := ⟨s z, z⟩
def pairNeg (x : ZPair) : ZPair := ⟨x.n, x.p⟩
def pairAdd (x y : ZPair) : ZPair := ⟨add x.p y.p, add x.n y.n⟩
def pairMul (x y : ZPair) : ZPair :=
  ⟨add (mul x.p y.p) (mul x.n y.n),
   add (mul x.p y.n) (mul x.n y.p)⟩

@[simp] theorem pairAdd_zero_left (x : ZPair) : pairAdd pairZero x = x := by
  cases x <;> simp [pairAdd, pairZero]

@[simp] theorem pairAdd_zero_right (x : ZPair) : pairAdd x pairZero = x := by
  cases x <;> simp [pairAdd, pairZero]

theorem pairAdd_comm (x y : ZPair) : pairAdd x y = pairAdd y x := by
  cases x <;> cases y <;> simp [pairAdd, add_comm]

theorem pairAdd_assoc (x y w : ZPair) : pairAdd (pairAdd x y) w = pairAdd x (pairAdd y w) := by
  cases x <;> cases y <;> cases w <;> simp [pairAdd, add_assoc]

@[simp] theorem pairNeg_involutive (x : ZPair) : pairNeg (pairNeg x) = x := by
  cases x <;> rfl

theorem pairNeg_respects {x y : ZPair} (h : ZEquiv x y) : ZEquiv (pairNeg x) (pairNeg y) := by
  change add x.n y.p = add y.n x.p
  calc
    add x.n y.p = add y.p x.n := add_comm _ _
    _ = add x.p y.n := h.symm
    _ = add y.n x.p := add_comm _ _

/-- Pair addition is well-defined modulo the explicit difference relation. -/
theorem pairAdd_respects {x x' y y' : ZPair}
    (hx : ZEquiv x x') (hy : ZEquiv y y') :
    ZEquiv (pairAdd x y) (pairAdd x' y') := by
  cases x with
  | mk a b =>
    cases x' with
    | mk c d =>
      cases y with
      | mk e f =>
        cases y' with
        | mk g h =>
          change add (add a e) (add d h) = add (add c g) (add b f)
          calc
            add (add a e) (add d h) = add (add a d) (add e h) :=
              z_add4_swap_middle a e d h
            _ = add (add c b) (add e h) := congrArg (fun t => add t (add e h)) hx
            _ = add (add c b) (add g f) := congrArg (fun t => add (add c b) t) hy
            _ = add (add c g) (add b f) := z_add4_swap_middle c b g f

/-- Multiplication on pairs is exactly commutative before quotienting. -/
theorem pairMul_comm (x y : ZPair) : pairMul x y = pairMul y x := by
  cases x <;> cases y <;>
    simp [pairMul, mul_comm, add_comm]

/-- Respect of multiplication in the first representative argument. -/
theorem pairMul_respects_left {x x' y : ZPair}
    (hx : ZEquiv x x') : ZEquiv (pairMul x y) (pairMul x' y) := by
  cases x with
  | mk a b =>
    cases x' with
    | mk c d =>
      cases y with
      | mk e f =>
        have he : add (mul a e) (mul d e) = add (mul c e) (mul b e) := by
          calc
            add (mul a e) (mul d e) = mul (add a d) e := (mul_add_left a d e).symm
            _ = mul (add c b) e := congrArg (fun t => mul t e) hx
            _ = add (mul c e) (mul b e) := mul_add_left c b e
        have hf : add (mul a f) (mul d f) = add (mul c f) (mul b f) := by
          calc
            add (mul a f) (mul d f) = mul (add a d) f := (mul_add_left a d f).symm
            _ = mul (add c b) f := congrArg (fun t => mul t f) hx
            _ = add (mul c f) (mul b f) := mul_add_left c b f
        have hf' : add (mul b f) (mul c f) = add (mul d f) (mul a f) := by
          calc
            add (mul b f) (mul c f) = add (mul c f) (mul b f) := add_comm _ _
            _ = add (mul a f) (mul d f) := hf.symm
            _ = add (mul d f) (mul a f) := add_comm _ _
        change
          add (add (mul a e) (mul b f)) (add (mul c f) (mul d e)) =
          add (add (mul c e) (mul d f)) (add (mul a f) (mul b e))
        calc
          add (add (mul a e) (mul b f)) (add (mul c f) (mul d e)) =
              add (add (mul a e) (mul d e)) (add (mul b f) (mul c f)) :=
            z_add4_swap_last (mul a e) (mul b f) (mul c f) (mul d e)
          _ = add (add (mul c e) (mul b e)) (add (mul b f) (mul c f)) :=
            congrArg (fun t => add t (add (mul b f) (mul c f))) he
          _ = add (add (mul c e) (mul b e)) (add (mul d f) (mul a f)) :=
            congrArg (fun t => add (add (mul c e) (mul b e)) t) hf'
          _ = add (add (mul c e) (mul d f)) (add (mul b e) (mul a f)) :=
            z_add4_swap_middle (mul c e) (mul b e) (mul d f) (mul a f)
          _ = add (add (mul c e) (mul d f)) (add (mul a f) (mul b e)) :=
            congrArg (fun t => add (add (mul c e) (mul d f)) t) (add_comm _ _)

/-- Respect in the second argument follows from exact pair multiplication commutativity. -/
theorem pairMul_respects_right {x y y' : ZPair}
    (hy : ZEquiv y y') : ZEquiv (pairMul x y) (pairMul x y') := by
  rw [pairMul_comm x y, pairMul_comm x y']
  exact pairMul_respects_left hy

theorem pairMul_respects {x x' y y' : ZPair}
    (hx : ZEquiv x x') (hy : ZEquiv y y') :
    ZEquiv (pairMul x y) (pairMul x' y') := by
  exact zeq_trans (pairMul_respects_left hx) (pairMul_respects_right hy)

/-- Raw pair multiplication is associative by the accepted N commutative-semiring laws. -/
theorem pairMul_assoc (x y w : ZPair) : pairMul (pairMul x y) w = pairMul x (pairMul y w) := by
  cases x <;> cases y <;> cases w <;>
    simp [pairMul, mul_add_left, mul_add_right, mul_assoc, mul_comm, z_mul_left_comm,
      add_assoc, add_comm, z_add_left_comm]

/-- Raw pair multiplication distributes over raw pair addition. -/
theorem pairMul_add_right (x y w : ZPair) :
    pairMul x (pairAdd y w) = pairAdd (pairMul x y) (pairMul x w) := by
  cases x <;> cases y <;> cases w <;>
    simp [pairMul, pairAdd, mul_add_left, mul_add_right, mul_assoc, mul_comm, z_mul_left_comm,
      add_assoc, add_comm, z_add_left_comm]

/-- Additive inverse is represented by coordinate swap. -/
theorem pair_add_neg_equiv_zero (x : ZPair) : ZEquiv (pairAdd x (pairNeg x)) pairZero := by
  cases x with
  | mk a b =>
    change add (add a b) z = add z (add b a)
    simpa [add_comm]

end BOMA.Z.Rep001

/- Direct arithmetic route on the selected signed normal-form carrier. -/
namespace BOMA.Z.Arithmetic001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- Structural difference of equal naturals is canonical integer zero. -/
theorem diff_self (n : BOMANat) : diff n n = zero := by
  induction n with
  | z => rfl
  | s n ih => exact ih

/-- Difference against zero is exactly the natural embedding. -/
theorem diff_nat_zero (n : BOMANat) : diff n z = embedN n := by
  cases n <;> rfl

/-- Zero minus a natural is the negation of the natural embedding. -/
theorem diff_zero_nat (n : BOMANat) : diff z n = zneg (embedN n) := by
  cases n <;> rfl

/-- Direct sign-case addition. Cross-sign cases use only the already-defined
structural natural difference, not any external integer subtraction. -/
def zaddD : ZSigned → ZSigned → ZSigned
  | zero, y => y
  | x, zero => x
  | pos a, pos b => pos (add a (s b))
  | neg a, neg b => neg (add a (s b))
  | pos a, neg b => diff (s a) (s b)
  | neg a, pos b => diff (s b) (s a)

/-- Direct sign-case multiplication. Magnitudes use accepted N multiplication. -/
def zmulD : ZSigned → ZSigned → ZSigned
  | zero, _ => zero
  | _, zero => zero
  | pos a, pos b => embedN (mul (s a) (s b))
  | pos a, neg b => zneg (embedN (mul (s a) (s b)))
  | neg a, pos b => zneg (embedN (mul (s a) (s b)))
  | neg a, neg b => embedN (mul (s a) (s b))

@[simp] theorem zaddD_zero_left (x : ZSigned) : zaddD zero x = x := rfl
@[simp] theorem zaddD_zero_right (x : ZSigned) : zaddD x zero = x := by
  cases x <;> rfl

@[simp] theorem zmulD_zero_left (x : ZSigned) : zmulD zero x = zero := rfl
@[simp] theorem zmulD_zero_right (x : ZSigned) : zmulD x zero = zero := by
  cases x <;> rfl

end BOMA.Z.Arithmetic001

/- Pair-mediated arithmetic route on the selected signed normal-form carrier. -/
namespace BOMA.Z.Arithmetic001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- Add canonical signed integers by translating to retained difference pairs,
performing raw pair addition, then normalizing back. -/
def zaddP (x y : ZSigned) : ZSigned :=
  normalizePair (pairAdd (pairOfSigned x) (pairOfSigned y))

/-- Multiply canonical signed integers by the retained pair product and normalize. -/
def zmulP (x y : ZSigned) : ZSigned :=
  normalizePair (pairMul (pairOfSigned x) (pairOfSigned y))

end BOMA.Z.Arithmetic001

/- Cross-route convergence for signed integer addition and multiplication. -/
namespace BOMA.Z.Arithmetic001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- The direct and pair-mediated addition routes agree pointwise. -/
theorem zadd_routes_converge (x y : ZSigned) : zaddD x y = zaddP x y := by
  cases x <;> cases y <;>
    simp [zaddD, zaddP, pairAdd, pairOfSigned, normalizePair,
      diff, embedN, add_s_left, add_s_right]

/-- Pair normalization of a natural product against zero is the direct embedded product. -/
theorem normalize_positive_pair (n : BOMANat) :
    normalizePair ⟨n, z⟩ = embedN n := by
  exact diff_nat_zero n

/-- Pair normalization of zero against a natural is its signed negation. -/
theorem normalize_negative_pair (n : BOMANat) :
    normalizePair ⟨z, n⟩ = zneg (embedN n) := by
  exact diff_zero_nat n

/-- The direct and pair-mediated multiplication routes agree pointwise. -/
theorem zmul_routes_converge (x y : ZSigned) : zmulD x y = zmulP x y := by
  cases x <;> cases y <;>
    simp [zmulD, zmulP, pairMul, pairOfSigned, normalizePair,
      normalize_positive_pair, normalize_negative_pair,
      diff_nat_zero, diff_zero_nat, embedN]

end BOMA.Z.Arithmetic001

/- Canonical integer arithmetic laws after direct/pair route convergence. -/
namespace BOMA.Z.Arithmetic001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- Canonical arithmetic spellings on the selected signed carrier.
The direct route is selected as the executable spelling only after route convergence. -/
def zadd : ZSigned → ZSigned → ZSigned := zaddD
def zmul : ZSigned → ZSigned → ZSigned := zmulD
def zzero : ZSigned := zero
def zone : ZSigned := embedN (s z)

/-- Semantic certificate for canonical addition in the retained pair model. -/
theorem zadd_pair_semantics (x y : ZSigned) :
    ZEquiv (pairOfSigned (zadd x y)) (pairAdd (pairOfSigned x) (pairOfSigned y)) := by
  unfold zadd
  rw [zadd_routes_converge]
  exact pair_roundtrip (pairAdd (pairOfSigned x) (pairOfSigned y))

/-- Semantic certificate for canonical multiplication in the retained pair model. -/
theorem zmul_pair_semantics (x y : ZSigned) :
    ZEquiv (pairOfSigned (zmul x y)) (pairMul (pairOfSigned x) (pairOfSigned y)) := by
  unfold zmul
  rw [zmul_routes_converge]
  exact pair_roundtrip (pairMul (pairOfSigned x) (pairOfSigned y))

/-- Equality of pair semantics gives equality on the selected canonical carrier. -/
theorem signed_eq_of_pair_equiv {x y : ZSigned}
    (h : ZEquiv (pairOfSigned x) (pairOfSigned y)) : x = y :=
  canonical_pair_separates h

@[simp] theorem zadd_zero_left (x : ZSigned) : zadd zzero x = x := by
  cases x <;> rfl

@[simp] theorem zadd_zero_right (x : ZSigned) : zadd x zzero = x := by
  cases x <;> rfl

theorem zadd_comm (x y : ZSigned) : zadd x y = zadd y x := by
  apply signed_eq_of_pair_equiv
  exact zeq_trans
    (zadd_pair_semantics x y)
    (zeq_trans
      (by rw [pairAdd_comm (pairOfSigned x) (pairOfSigned y)]; exact zeq_refl _)
      (zeq_symm (zadd_pair_semantics y x)))

theorem zadd_assoc (x y w : ZSigned) : zadd (zadd x y) w = zadd x (zadd y w) := by
  apply signed_eq_of_pair_equiv
  have hxy : ZEquiv (pairOfSigned (zadd x y))
      (pairAdd (pairOfSigned x) (pairOfSigned y)) := zadd_pair_semantics x y
  have hyw : ZEquiv (pairOfSigned (zadd y w))
      (pairAdd (pairOfSigned y) (pairOfSigned w)) := zadd_pair_semantics y w
  have hL : ZEquiv
      (pairAdd (pairOfSigned (zadd x y)) (pairOfSigned w))
      (pairAdd (pairAdd (pairOfSigned x) (pairOfSigned y)) (pairOfSigned w)) :=
    pairAdd_respects hxy (zeq_refl _)
  have hA : ZEquiv
      (pairAdd (pairAdd (pairOfSigned x) (pairOfSigned y)) (pairOfSigned w))
      (pairAdd (pairOfSigned x) (pairAdd (pairOfSigned y) (pairOfSigned w))) := by
    rw [pairAdd_assoc]
    exact zeq_refl _
  have hR : ZEquiv
      (pairAdd (pairOfSigned x) (pairAdd (pairOfSigned y) (pairOfSigned w)))
      (pairAdd (pairOfSigned x) (pairOfSigned (zadd y w))) :=
    pairAdd_respects (zeq_refl _) (zeq_symm hyw)
  exact zeq_trans (zadd_pair_semantics (zadd x y) w)
    (zeq_trans hL (zeq_trans hA (zeq_trans hR (zeq_symm (zadd_pair_semantics x (zadd y w))))))

@[simp] theorem zadd_neg_right (x : ZSigned) : zadd x (zneg x) = zzero := by
  cases x with
  | zero => rfl
  | pos n =>
      change diff (s n) (s n) = zero
      exact diff_self (s n)
  | neg n =>
      change diff (s n) (s n) = zero
      exact diff_self (s n)

@[simp] theorem zadd_neg_left (x : ZSigned) : zadd (zneg x) x = zzero := by
  rw [zadd_comm]
  exact zadd_neg_right x

/-- Natural one is preserved by the selected signed embedding. -/
@[simp] theorem zone_def : zone = pos z := rfl

@[simp] theorem zmul_zero_left (x : ZSigned) : zmul zzero x = zzero := by
  cases x <;> rfl

@[simp] theorem zmul_zero_right (x : ZSigned) : zmul x zzero = zzero := by
  cases x <;> rfl

theorem zmul_comm (x y : ZSigned) : zmul x y = zmul y x := by
  apply signed_eq_of_pair_equiv
  exact zeq_trans
    (zmul_pair_semantics x y)
    (zeq_trans
      (by rw [pairMul_comm (pairOfSigned x) (pairOfSigned y)]; exact zeq_refl _)
      (zeq_symm (zmul_pair_semantics y x)))

theorem zmul_assoc (x y w : ZSigned) : zmul (zmul x y) w = zmul x (zmul y w) := by
  apply signed_eq_of_pair_equiv
  have hxy := zmul_pair_semantics x y
  have hyw := zmul_pair_semantics y w
  have hL := pairMul_respects hxy (zeq_refl (pairOfSigned w))
  have hA : ZEquiv
      (pairMul (pairMul (pairOfSigned x) (pairOfSigned y)) (pairOfSigned w))
      (pairMul (pairOfSigned x) (pairMul (pairOfSigned y) (pairOfSigned w))) := by
    rw [pairMul_assoc]
    exact zeq_refl _
  have hR := pairMul_respects (zeq_refl (pairOfSigned x)) (zeq_symm hyw)
  exact zeq_trans (zmul_pair_semantics (zmul x y) w)
    (zeq_trans hL (zeq_trans hA (zeq_trans hR (zeq_symm (zmul_pair_semantics x (zmul y w))))))

@[simp] theorem zmul_one_right (x : ZSigned) : zmul x zone = x := by
  cases x with
  | zero => rfl
  | pos n =>
      simp [zmul, zmulD, zone, embedN, mul_one_right]
  | neg n =>
      simp [zmul, zmulD, zone, embedN, zneg, mul_one_right]

@[simp] theorem zmul_one_left (x : ZSigned) : zmul zone x = x := by
  rw [zmul_comm]
  exact zmul_one_right x

/-- Right distributivity is transferred through the retained pair semantics. -/
theorem zmul_add_right (x y w : ZSigned) :
    zmul x (zadd y w) = zadd (zmul x y) (zmul x w) := by
  apply signed_eq_of_pair_equiv
  have hyw := zadd_pair_semantics y w
  have hxy := zmul_pair_semantics x y
  have hxw := zmul_pair_semantics x w
  have h1 := pairMul_respects (zeq_refl (pairOfSigned x)) hyw
  have h2 : ZEquiv
      (pairMul (pairOfSigned x) (pairAdd (pairOfSigned y) (pairOfSigned w)))
      (pairAdd (pairMul (pairOfSigned x) (pairOfSigned y))
               (pairMul (pairOfSigned x) (pairOfSigned w))) := by
    rw [pairMul_add_right]
    exact zeq_refl _
  have h3 := pairAdd_respects (zeq_symm hxy) (zeq_symm hxw)
  exact zeq_trans (zmul_pair_semantics x (zadd y w))
    (zeq_trans h1 (zeq_trans h2 (zeq_trans h3
      (zeq_symm (zadd_pair_semantics (zmul x y) (zmul x w))))))

theorem zmul_add_left (x y w : ZSigned) :
    zmul (zadd x y) w = zadd (zmul x w) (zmul y w) := by
  calc
    zmul (zadd x y) w = zmul w (zadd x y) := zmul_comm _ _
    _ = zadd (zmul w x) (zmul w y) := zmul_add_right w x y
    _ = zadd (zmul x w) (zmul y w) := by rw [zmul_comm w x, zmul_comm w y]

/-- The accepted N embedding preserves zero. -/
@[simp] theorem embedN_zero : embedN z = zzero := rfl

/-- The accepted N embedding preserves one. -/
@[simp] theorem embedN_one : embedN (s z) = zone := rfl

/-- The accepted N embedding preserves addition. -/
theorem embedN_add (a b : BOMANat) : embedN (add a b) = zadd (embedN a) (embedN b) := by
  cases a with
  | z => simp [zadd, zzero, embedN]
  | s a =>
      cases b with
      | z => simp [zadd, zzero, embedN]
      | s b =>
          simp [zadd, zaddD, embedN, add_s_left, add_s_right]

/-- The accepted N embedding preserves multiplication. -/
theorem embedN_mul (a b : BOMANat) : embedN (mul a b) = zmul (embedN a) (embedN b) := by
  cases a with
  | z => simp [zmul, zzero, embedN]
  | s a =>
      cases b with
      | z => simp [zmul, zzero, embedN]
      | s b => rfl

/-- Every selected signed integer is explicitly a difference of embedded naturals. -/
theorem generated_by_natural_difference (x : ZSigned) :
    ∃ a b : BOMANat, x = zadd (embedN a) (zneg (embedN b)) := by
  cases x with
  | zero => exact ⟨z, z, rfl⟩
  | pos n => exact ⟨s n, z, rfl⟩
  | neg n => exact ⟨z, s n, rfl⟩

end BOMA.Z.Arithmetic001

/- Direct sign/magnitude order route on the selected signed carrier. -/
namespace BOMA.Z.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- Direct signed order. The payload of `pos a`/`neg a` is the predecessor
of the positive magnitude, so same-sign comparison uses the accepted N order
on those payloads; the negative case reverses it. -/
def zLEd : ZSigned → ZSigned → Prop
  | neg a, neg b => LE b a
  | neg _, zero => True
  | neg _, pos _ => True
  | zero, neg _ => False
  | zero, zero => True
  | zero, pos _ => True
  | pos _, neg _ => False
  | pos _, zero => False
  | pos a, pos b => LE a b

end BOMA.Z.Order001

/- Pair cross-sum order route. -/
namespace BOMA.Z.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001

/-- Order of represented differences: p-n ≤ q-m iff p+m ≤ q+n. -/
def pairLE (x y : ZPair) : Prop :=
  LE (add x.p y.n) (add y.p x.n)

/-- Pull the pair order back to the selected signed carrier. -/
def zLEp (x y : ZSigned) : Prop :=
  pairLE (pairOfSigned x) (pairOfSigned y)

end BOMA.Z.Order001

/- Convergence of direct signed order and pair cross-sum order. -/
namespace BOMA.Z.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned

/-- The direct sign/magnitude order and pair cross-sum order agree pointwise.

The proof is deliberately case-explicit. Earlier `simp`-based closure rewrote
Iff-valued order lemmas through proposition extensionality. Here every Iff is
consumed with `.mp`/`.mpr`, so convergence itself does not require `propext`. -/
theorem zorder_routes_converge (x y : ZSigned) : zLEd x y ↔ zLEp x y := by
  cases x with
  | zero =>
      cases y with
      | zero =>
          change True ↔ LE z z
          constructor
          · intro _
            exact le_refl z
          · intro _
            exact True.intro
      | pos b =>
          change True ↔ LE z (s b)
          constructor
          · intro _
            exact z_le (s b)
          · intro _
            exact True.intro
      | neg b =>
          change False ↔ LE (s (add z b)) z
          constructor
          · intro h
            exact False.elim h
          · intro h
            exact (not_s_le_z (add z b)) h
  | pos a =>
      cases y with
      | zero =>
          change False ↔ LE (s a) z
          constructor
          · intro h
            exact False.elim h
          · intro h
            exact (not_s_le_z a) h
      | pos b =>
          change LE a b ↔ LE (s a) (s b)
          exact le_s_iff.symm
      | neg b =>
          change False ↔ LE (s (add (s a) b)) z
          constructor
          · intro h
            exact False.elim h
          · intro h
            exact (not_s_le_z (add (s a) b)) h
  | neg a =>
      cases y with
      | zero =>
          change True ↔ LE z (s (add z a))
          constructor
          · intro _
            exact z_le (s (add z a))
          · intro _
            exact True.intro
      | pos b =>
          change True ↔ LE z (s (add (s b) a))
          constructor
          · intro _
            exact z_le (s (add (s b) a))
          · intro _
            exact True.intro
      | neg b =>
          change LE b a ↔ LE (s (add z b)) (s (add z a))
          constructor
          · intro h
            apply le_s_iff.mpr
            rw [add_z_left b, add_z_left a]
            exact h
          · intro h
            have hbase : LE (add z b) (add z a) := le_s_iff.mp h
            rw [add_z_left b, add_z_left a] at hbase
            exact hbase

end BOMA.Z.Order001

/- Canonical integer order laws after direct/pair route convergence. -/
namespace BOMA.Z.Order001
open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- Canonical integer order spelling after route convergence. -/
def zLE : ZSigned → ZSigned → Prop := zLEd

def NonNeg (x : ZSigned) : Prop := zLE zzero x

/-- Canonical order is exactly the pair cross-sum order on canonical representatives. -/
theorem zle_iff_pair (x y : ZSigned) :
    zLE x y ↔ pairLE (pairOfSigned x) (pairOfSigned y) := by
  change zLEd x y ↔ zLEp x y
  exact zorder_routes_converge x y

/-- Natural-order cancellation by a common right addend. -/
theorem n_le_cancel_right {a b c : BOMANat}
    (h : LE (add a c) (add b c)) : LE a b := by
  change LEAdd (add a c) (add b c) at h
  change LEAdd a b
  rcases h with ⟨k, hk⟩
  refine ⟨k, ?_⟩
  apply add_right_cancel (add a k) b c
  calc
    add (add a k) c = add a (add k c) := add_assoc a k c
    _ = add a (add c k) := congrArg (fun t => add a t) (add_comm k c)
    _ = add (add a c) k := (add_assoc a c k).symm
    _ = add b c := hk

/-- Pair cross-sum order is invariant when its left representative changes within `~`. -/
theorem pairLE_respects_left {x x' y : ZPair}
    (hx : ZEquiv x x') (h : pairLE x y) : pairLE x' y := by
  cases x with
  | mk a b =>
    cases x' with
    | mk c d =>
      cases y with
      | mk e f =>
        change add a d = add c b at hx
        change LE (add a f) (add e b) at h
        change LE (add c f) (add e d)
        have hm : LE (add (add a f) d) (add (add e b) d) :=
          add_mono_right h d
        have hl : add (add a f) d = add (add c f) b := by
          calc
            add (add a f) d = add a (add f d) := add_assoc a f d
            _ = add a (add d f) := congrArg (fun t => add a t) (add_comm f d)
            _ = add (add a d) f := (add_assoc a d f).symm
            _ = add (add c b) f := congrArg (fun t => add t f) hx
            _ = add c (add b f) := add_assoc c b f
            _ = add c (add f b) := congrArg (fun t => add c t) (add_comm b f)
            _ = add (add c f) b := (add_assoc c f b).symm
        have hr : add (add e b) d = add (add e d) b := by
          calc
            add (add e b) d = add e (add b d) := add_assoc e b d
            _ = add e (add d b) := congrArg (fun t => add e t) (add_comm b d)
            _ = add (add e d) b := (add_assoc e d b).symm
        rw [hl, hr] at hm
        exact n_le_cancel_right hm

/-- Negation of pair representatives reverses pair order. -/
theorem pairLE_neg_flip (x y : ZPair) :
    pairLE x y ↔ pairLE (pairNeg y) (pairNeg x) := by
  cases x with
  | mk a b =>
    cases y with
    | mk c d =>
      simp [pairLE, pairNeg, add_comm]

/-- Pair cross-sum order is invariant when its right representative changes within `~`. -/
theorem pairLE_respects_right {x y y' : ZPair}
    (hy : ZEquiv y y') (h : pairLE x y) : pairLE x y' := by
  have hflip : pairLE (pairNeg y) (pairNeg x) :=
    (pairLE_neg_flip x y).mp h
  have hchanged : pairLE (pairNeg y') (pairNeg x) :=
    pairLE_respects_left (pairNeg_respects hy) hflip
  exact (pairLE_neg_flip x y').mpr hchanged

theorem pairLE_respects {x x' y y' : ZPair}
    (hx : ZEquiv x x') (hy : ZEquiv y y') (h : pairLE x y) : pairLE x' y' :=
  pairLE_respects_right hy (pairLE_respects_left hx h)

/-- The canonical pair of an embedded natural is exactly `(n,0)`. -/
theorem pairOfSigned_embedN (n : BOMANat) :
    pairOfSigned (embedN n) = ⟨n, z⟩ := by
  cases n <;> rfl

/-- Every pair is below itself plus an embedded natural gap. -/
theorem pairLE_add_embedded (x : ZPair) (k : BOMANat) :
    pairLE x (pairAdd x (pairOfSigned (embedN k))) := by
  rw [pairOfSigned_embedN]
  cases x with
  | mk a b =>
    change LE (add a (add b z)) (add (add a k) b)
    change LEAdd (add a b) (add (add a k) b)
    refine ⟨k, ?_⟩
    calc
      add (add a b) k = add a (add b k) := add_assoc a b k
      _ = add a (add k b) := congrArg (fun t => add a t) (add_comm b k)
      _ = add (add a k) b := (add_assoc a k b).symm

/-- Pair cross-sum order itself has an explicit natural-gap witness. -/
theorem pairLE_to_gap {x y : ZSigned}
    (h : pairLE (pairOfSigned x) (pairOfSigned y)) :
    ∃ k : BOMANat, zadd x (embedN k) = y := by
  change LEAdd
    (add (pairOfSigned x).p (pairOfSigned y).n)
    (add (pairOfSigned y).p (pairOfSigned x).n) at h
  rcases h with ⟨k, hk⟩
  refine ⟨k, ?_⟩
  apply signed_eq_of_pair_equiv
  have hs := zadd_pair_semantics x (embedN k)
  have hrel : ZEquiv
      (pairAdd (pairOfSigned x) (pairOfSigned (embedN k)))
      (pairOfSigned y) := by
    rw [pairOfSigned_embedN]
    change add (add (pairOfSigned x).p k) (pairOfSigned y).n =
      add (pairOfSigned y).p (add (pairOfSigned x).n z)
    calc
      add (add (pairOfSigned x).p k) (pairOfSigned y).n =
          add (add (pairOfSigned x).p (pairOfSigned y).n) k := by
            rw [add_assoc, add_assoc]
            exact congrArg (fun t => add (pairOfSigned x).p t)
              (add_comm k (pairOfSigned y).n)
      _ = add (pairOfSigned y).p (pairOfSigned x).n := hk
      _ = add (pairOfSigned y).p (add (pairOfSigned x).n z) := by
        rw [add_z_right]
  exact zeq_trans hs hrel

/-- Integer order is equivalent to existence of an embedded natural additive gap. -/
theorem zle_iff_natural_gap (x y : ZSigned) :
    zLE x y ↔ ∃ k : BOMANat, zadd x (embedN k) = y := by
  constructor
  · intro h
    exact pairLE_to_gap ((zle_iff_pair x y).mp h)
  · rintro ⟨k, hk⟩
    have hp : pairLE (pairOfSigned x)
        (pairAdd (pairOfSigned x) (pairOfSigned (embedN k))) :=
      pairLE_add_embedded (pairOfSigned x) k
    have hs := zadd_pair_semantics x (embedN k)
    have hp' : pairLE (pairOfSigned x) (pairOfSigned (zadd x (embedN k))) :=
      pairLE_respects_right (zeq_symm hs) hp
    have hz : zLE x (zadd x (embedN k)) := (zle_iff_pair _ _).mpr hp'
    rw [hk] at hz
    exact hz

theorem zle_refl (x : ZSigned) : zLE x x := by
  apply (zle_iff_natural_gap x x).mpr
  exact ⟨z, by simp [embedN_zero]⟩

theorem zle_trans {x y w : ZSigned} (hxy : zLE x y) (hyw : zLE y w) : zLE x w := by
  rcases (zle_iff_natural_gap x y).mp hxy with ⟨k, hk⟩
  rcases (zle_iff_natural_gap y w).mp hyw with ⟨l, hl⟩
  apply (zle_iff_natural_gap x w).mpr
  refine ⟨add k l, ?_⟩
  calc
    zadd x (embedN (add k l)) = zadd x (zadd (embedN k) (embedN l)) :=
      congrArg (fun t => zadd x t) (embedN_add k l)
    _ = zadd (zadd x (embedN k)) (embedN l) := (zadd_assoc x (embedN k) (embedN l)).symm
    _ = zadd y (embedN l) := congrArg (fun t => zadd t (embedN l)) hk
    _ = w := hl

theorem zle_antisymm {x y : ZSigned} (hxy : zLE x y) (hyx : zLE y x) : x = y := by
  cases x with
  | zero =>
      cases y with
      | zero => rfl
      | pos b =>
          change False at hyx
          contradiction
      | neg b =>
          change False at hxy
          contradiction
  | pos a =>
      cases y with
      | zero =>
          change False at hxy
          contradiction
      | neg b =>
          change False at hxy
          contradiction
      | pos b =>
          change LE a b at hxy
          change LE b a at hyx
          exact congrArg pos (le_antisymm hxy hyx)
  | neg a =>
      cases y with
      | zero =>
          change False at hyx
          contradiction
      | pos b =>
          change False at hyx
          contradiction
      | neg b =>
          change LE b a at hxy
          change LE a b at hyx
          exact congrArg neg (le_antisymm hyx hxy)

theorem zle_total (x y : ZSigned) : zLE x y ∨ zLE y x := by
  cases x with
  | zero =>
      cases y with
      | zero => exact Or.inl True.intro
      | pos b => exact Or.inl True.intro
      | neg b => exact Or.inr True.intro
  | pos a =>
      cases y with
      | zero => exact Or.inr True.intro
      | neg b => exact Or.inr True.intro
      | pos b => exact le_total a b
  | neg a =>
      cases y with
      | zero => exact Or.inl True.intro
      | pos b => exact Or.inl True.intro
      | neg b => exact le_total b a

/-- The selected integer order exactly extends the accepted natural order.
The proof is case-explicit so the Iff-valued successor-order lemma is consumed
by `.mp`/`.mpr` instead of being used as a simp rewrite through `propext`. -/
theorem embedN_order (a b : BOMANat) :
    zLE (embedN a) (embedN b) ↔ LE a b := by
  cases a with
  | z =>
      cases b with
      | z =>
          change True ↔ LE z z
          constructor
          · intro _
            exact le_refl z
          · intro _
            exact True.intro
      | s b =>
          change True ↔ LE z (s b)
          constructor
          · intro _
            exact z_le (s b)
          · intro _
            exact True.intro
  | s a =>
      cases b with
      | z =>
          change False ↔ LE (s a) z
          constructor
          · intro h
            exact False.elim h
          · intro h
            exact (not_s_le_z a) h
      | s b =>
          change LE a b ↔ LE (s a) (s b)
          exact le_s_iff.symm

/-- Translation invariance / right addition monotonicity. -/
theorem zadd_mono_right {x y : ZSigned} (h : zLE x y) (c : ZSigned) :
    zLE (zadd x c) (zadd y c) := by
  rcases (zle_iff_natural_gap x y).mp h with ⟨k, hk⟩
  apply (zle_iff_natural_gap _ _).mpr
  refine ⟨k, ?_⟩
  calc
    zadd (zadd x c) (embedN k) = zadd x (zadd c (embedN k)) := zadd_assoc x c (embedN k)
    _ = zadd x (zadd (embedN k) c) :=
      congrArg (fun t => zadd x t) (zadd_comm c (embedN k))
    _ = zadd (zadd x (embedN k)) c := (zadd_assoc x (embedN k) c).symm
    _ = zadd y c := congrArg (fun t => zadd t c) hk

theorem zadd_mono_left {x y : ZSigned} (h : zLE x y) (c : ZSigned) :
    zLE (zadd c x) (zadd c y) := by
  simpa [zadd_comm c x, zadd_comm c y] using zadd_mono_right h c

/-- Negation reverses order. -/
theorem zneg_reverses {x y : ZSigned} (h : zLE x y) :
    zLE (zneg y) (zneg x) := by
  cases x <;> cases y <;> simp_all [zLE, zLEd, zneg]

/-- Nonnegative signed integers are exactly embedded naturals. -/
theorem nonneg_is_embedded (c : ZSigned) (h : NonNeg c) :
    ∃ n : BOMANat, c = embedN n := by
  cases c with
  | zero => exact ⟨z, rfl⟩
  | pos n => exact ⟨s n, rfl⟩
  | neg n =>
      change False at h
      contradiction

/-- Multiplication by a nonnegative integer preserves order on the right. -/
theorem zmul_mono_right_nonneg {x y c : ZSigned}
    (hxy : zLE x y) (hc : NonNeg c) :
    zLE (zmul x c) (zmul y c) := by
  rcases (zle_iff_natural_gap x y).mp hxy with ⟨k, hk⟩
  rcases nonneg_is_embedded c hc with ⟨m, rfl⟩
  apply (zle_iff_natural_gap _ _).mpr
  refine ⟨mul k m, ?_⟩
  calc
    zadd (zmul x (embedN m)) (embedN (mul k m)) =
        zadd (zmul x (embedN m)) (zmul (embedN k) (embedN m)) :=
      congrArg (fun t => zadd (zmul x (embedN m)) t) (embedN_mul k m)
    _ = zmul (zadd x (embedN k)) (embedN m) :=
      (zmul_add_left x (embedN k) (embedN m)).symm
    _ = zmul y (embedN m) := congrArg (fun t => zmul t (embedN m)) hk

theorem zmul_mono_left_nonneg {x y c : ZSigned}
    (hxy : zLE x y) (hc : NonNeg c) :
    zLE (zmul c x) (zmul c y) := by
  simpa [zmul_comm c x, zmul_comm c y] using zmul_mono_right_nonneg hxy hc

end BOMA.Z.Order001

/- Pre-rational gateway: derive no-zero-divisor and nonzero cancellation
   from the accepted BOMA N/Z packages before fraction equivalence is formed. -/
namespace BOMA.Q.Gateway001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- A natural sum can be zero only when both summands are zero. -/
theorem n_add_eq_zero {a b : BOMANat} (h : add a b = z) : a = z ∧ b = z := by
  cases b with
  | z =>
      change a = z at h
      exact ⟨h, rfl⟩
  | s b =>
      change s (add a b) = z at h
      exact False.elim (s_ne_z (add a b) h)

/-- No zero divisors for the accepted natural multiplication. -/
theorem n_mul_eq_zero {a b : BOMANat} (h : mul a b = z) : a = z ∨ b = z := by
  cases b with
  | z => exact Or.inr rfl
  | s b =>
      change add (mul a b) a = z at h
      exact Or.inl (n_add_eq_zero h).2

/-- A product of two natural successors is nonzero. -/
theorem n_mul_succ_succ_ne_zero (a b : BOMANat) : mul (s a) (s b) ≠ z := by
  intro h
  rcases n_mul_eq_zero h with ha | hb
  · exact s_ne_z a ha
  · exact s_ne_z b hb

/-- A nonzero natural embeds to a nonzero selected integer. -/
theorem embedN_ne_zero_of_ne {n : BOMANat} (hn : n ≠ z) : embedN n ≠ zzero := by
  cases n with
  | z => exact False.elim (hn rfl)
  | s n =>
      intro h
      cases h

/-- Its signed negation is also nonzero. -/
theorem neg_embedN_ne_zero_of_ne {n : BOMANat} (hn : n ≠ z) :
    zneg (embedN n) ≠ zzero := by
  cases n with
  | z => exact False.elim (hn rfl)
  | s n =>
      intro h
      cases h

/-- Accepted integer multiplication has no zero divisors. -/
theorem zmul_eq_zero {x y : ZSigned} (h : zmul x y = zzero) :
    x = zzero ∨ y = zzero := by
  cases x with
  | zero => exact Or.inl rfl
  | pos a =>
      cases y with
      | zero => exact Or.inr rfl
      | pos b =>
          change embedN (mul (s a) (s b)) = zzero at h
          exact False.elim (embedN_ne_zero_of_ne (n_mul_succ_succ_ne_zero a b) h)
      | neg b =>
          change zneg (embedN (mul (s a) (s b))) = zzero at h
          exact False.elim (neg_embedN_ne_zero_of_ne (n_mul_succ_succ_ne_zero a b) h)
  | neg a =>
      cases y with
      | zero => exact Or.inr rfl
      | pos b =>
          change zneg (embedN (mul (s a) (s b))) = zzero at h
          exact False.elim (neg_embedN_ne_zero_of_ne (n_mul_succ_succ_ne_zero a b) h)
      | neg b =>
          change embedN (mul (s a) (s b)) = zzero at h
          exact False.elim (embedN_ne_zero_of_ne (n_mul_succ_succ_ne_zero a b) h)

/-- Left cancellation in the accepted additive group. -/
theorem zadd_left_cancel {a b c : ZSigned}
    (h : zadd a b = zadd a c) : b = c := by
  have h' := congrArg (fun t => zadd (zneg a) t) h
  calc
    b = zadd zzero b := (zadd_zero_left b).symm
    _ = zadd (zadd (zneg a) a) b := by rw [zadd_neg_left]
    _ = zadd (zneg a) (zadd a b) := zadd_assoc (zneg a) a b
    _ = zadd (zneg a) (zadd a c) := h'
    _ = zadd (zadd (zneg a) a) c := (zadd_assoc (zneg a) a c).symm
    _ = zadd zzero c := by rw [zadd_neg_left]
    _ = c := zadd_zero_left c

/-- Right cancellation in the accepted additive group. -/
theorem zadd_right_cancel {a b c : ZSigned}
    (h : zadd a c = zadd b c) : a = b := by
  apply zadd_left_cancel (a := c)
  calc
    zadd c a = zadd a c := zadd_comm c a
    _ = zadd b c := h
    _ = zadd c b := zadd_comm b c

/-- Any additive inverse is the selected negation. -/
theorem additive_inverse_unique {x y : ZSigned}
    (h : zadd x y = zzero) : y = zneg x := by
  apply zadd_left_cancel (a := x)
  calc
    zadd x y = zzero := h
    _ = zadd x (zneg x) := (zadd_neg_right x).symm

/-- Multiplication by a negated left factor is the negation of the product. -/
theorem zmul_neg_left (x c : ZSigned) :
    zmul (zneg x) c = zneg (zmul x c) := by
  apply additive_inverse_unique (x := zmul x c)
  calc
    zadd (zmul x c) (zmul (zneg x) c) =
        zmul (zadd x (zneg x)) c := (zmul_add_left x (zneg x) c).symm
    _ = zmul zzero c := congrArg (fun t => zmul t c) (zadd_neg_right x)
    _ = zzero := zmul_zero_left c

/-- Multiplication by a negated right factor. -/
theorem zmul_neg_right (x c : ZSigned) :
    zmul x (zneg c) = zneg (zmul x c) := by
  calc
    zmul x (zneg c) = zmul (zneg c) x := zmul_comm x (zneg c)
    _ = zneg (zmul c x) := zmul_neg_left c x
    _ = zneg (zmul x c) := congrArg zneg (zmul_comm c x)

/-- QG-01: cancellation by a nonzero right integer factor. -/
theorem zmul_right_cancel_nonzero {a b c : ZSigned}
    (hc : c ≠ zzero) (h : zmul a c = zmul b c) : a = b := by
  have hzero : zmul (zadd a (zneg b)) c = zzero := by
    calc
      zmul (zadd a (zneg b)) c =
          zadd (zmul a c) (zmul (zneg b) c) := zmul_add_left a (zneg b) c
      _ = zadd (zmul a c) (zneg (zmul b c)) :=
          congrArg (fun t => zadd (zmul a c) t) (zmul_neg_left b c)
      _ = zadd (zmul b c) (zneg (zmul b c)) :=
          congrArg (fun t => zadd t (zneg (zmul b c))) h
      _ = zzero := zadd_neg_right (zmul b c)
  rcases zmul_eq_zero hzero with hab | hc0
  · apply zadd_right_cancel (c := zneg b)
    calc
      zadd a (zneg b) = zzero := hab
      _ = zadd b (zneg b) := (zadd_neg_right b).symm
  · exact False.elim (hc hc0)

/-- Left-factor cancellation follows from commutativity. -/
theorem zmul_left_cancel_nonzero {a b c : ZSigned}
    (hc : c ≠ zzero) (h : zmul c a = zmul c b) : a = b := by
  apply zmul_right_cancel_nonzero hc
  calc
    zmul a c = zmul c a := zmul_comm a c
    _ = zmul c b := h
    _ = zmul b c := zmul_comm c b

/-- Product nonzeroness, the convenient fraction-denominator form. -/
theorem zmul_ne_zero {a b : ZSigned} (ha : a ≠ zzero) (hb : b ≠ zzero) :
    zmul a b ≠ zzero := by
  intro h
  rcases zmul_eq_zero h with ha0 | hb0
  · exact ha ha0
  · exact hb hb0

end BOMA.Q.Gateway001

/- Rational Route F: raw integer fractions with structurally positive natural denominators.
   No quotient carrier is formed in this file. -/
namespace BOMA.Q.Fraction001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Q.Gateway001

/-- A denominator is positive by syntax: its natural value is always `s pred`.
This avoids a proof-bearing `d ≠ 0` field and prevents signed-denominator duplication. -/
structure PosDen where
  pred : BOMANat

/-- Positive natural denominator value. -/
def denNat (d : PosDen) : BOMANat := s d.pred

/-- Denominator interpreted in the accepted integer carrier. -/
def denZ (d : PosDen) : ZSigned := embedN (denNat d)

/-- Every structurally positive denominator is nonzero in Z. -/
theorem denZ_ne_zero (d : PosDen) : denZ d ≠ zzero := by
  apply embedN_ne_zero_of_ne
  exact s_ne_z d.pred

/-- Raw valid fraction representation. -/
structure RawFrac where
  num : ZSigned
  den : PosDen

/-- Cross-product representation equivalence. -/
def FracEquiv (x y : RawFrac) : Prop :=
  zmul x.num (denZ y.den) = zmul y.num (denZ x.den)

/-- Swap the last two factors in a triple product. -/
theorem zmul_swap_last (a b c : ZSigned) :
    zmul (zmul a b) c = zmul (zmul a c) b := by
  calc
    zmul (zmul a b) c = zmul a (zmul b c) := zmul_assoc a b c
    _ = zmul a (zmul c b) := congrArg (fun t => zmul a t) (zmul_comm b c)
    _ = zmul (zmul a c) b := (zmul_assoc a c b).symm

theorem frac_refl (x : RawFrac) : FracEquiv x x := rfl

theorem frac_symm {x y : RawFrac} (h : FracEquiv x y) : FracEquiv y x :=
  h.symm

/-- Transitivity is exactly where the pre-rational nonzero cancellation gateway
is consumed. It is not a free property of cross multiplication. -/
theorem frac_trans {x y w : RawFrac}
    (hxy : FracEquiv x y) (hyw : FracEquiv y w) : FracEquiv x w := by
  change zmul x.num (denZ y.den) = zmul y.num (denZ x.den) at hxy
  change zmul y.num (denZ w.den) = zmul w.num (denZ y.den) at hyw
  change zmul x.num (denZ w.den) = zmul w.num (denZ x.den)
  have h1 := congrArg (fun t => zmul t (denZ w.den)) hxy
  have h2 := congrArg (fun t => zmul t (denZ x.den)) hyw
  apply zmul_right_cancel_nonzero (denZ_ne_zero y.den)
  calc
    zmul (zmul x.num (denZ w.den)) (denZ y.den) =
        zmul (zmul x.num (denZ y.den)) (denZ w.den) :=
      (zmul_swap_last x.num (denZ y.den) (denZ w.den)).symm
    _ = zmul (zmul y.num (denZ x.den)) (denZ w.den) := h1
    _ = zmul (zmul y.num (denZ w.den)) (denZ x.den) :=
      zmul_swap_last y.num (denZ x.den) (denZ w.den)
    _ = zmul (zmul w.num (denZ y.den)) (denZ x.den) := h2
    _ = zmul (zmul w.num (denZ x.den)) (denZ y.den) :=
      zmul_swap_last w.num (denZ y.den) (denZ x.den)

/-- Integer embedding into raw fractions uses denominator 1. -/
def oneDen : PosDen := ⟨z⟩

def fracOfZ (a : ZSigned) : RawFrac := ⟨a, oneDen⟩

@[simp] theorem denNat_one : denNat oneDen = s z := rfl
@[simp] theorem denZ_one : denZ oneDen = zone := rfl

/-- The raw-fraction embedding is faithful modulo fraction equivalence. -/
theorem fracOfZ_reflects {a b : ZSigned}
    (h : FracEquiv (fracOfZ a) (fracOfZ b)) : a = b := by
  change zmul a zone = zmul b zone at h
  calc
    a = zmul a zone := (zmul_one_right a).symm
    _ = zmul b zone := h
    _ = b := zmul_one_right b

/-- Exact preservation of equality by the raw-fraction embedding. -/
theorem fracOfZ_preserves {a b : ZSigned} (h : a = b) :
    FracEquiv (fracOfZ a) (fracOfZ b) := by
  cases h
  exact frac_refl _

end BOMA.Q.Fraction001

/- Arithmetic on raw valid rational fractions, before any quotient identity commitment. -/
namespace BOMA.Q.Fraction001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.NArithmetic.Multiplication001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- Multiplication of structurally positive denominators remains structurally positive. -/
def denMul (d e : PosDen) : PosDen :=
  ⟨add (mul (s d.pred) e.pred) d.pred⟩

/-- The denominator syntax computes exactly to natural multiplication. -/
theorem denNat_mul (d e : PosDen) :
    denNat (denMul d e) = mul (denNat d) (denNat e) := by
  rfl

/-- Integer interpretation of denominator multiplication. -/
theorem denZ_mul (d e : PosDen) :
    denZ (denMul d e) = zmul (denZ d) (denZ e) := by
  change embedN (denNat (denMul d e)) = zmul (embedN (denNat d)) (embedN (denNat e))
  rw [denNat_mul]
  exact embedN_mul (denNat d) (denNat e)

/-- Raw rational zero and one. -/
def rawZero : RawFrac := fracOfZ zzero
def rawOne : RawFrac := fracOfZ zone

/-- Raw negation. -/
def rawNeg (x : RawFrac) : RawFrac := ⟨zneg x.num, x.den⟩

/-- Standard cross-denominator raw addition. -/
def rawAdd (x y : RawFrac) : RawFrac :=
  ⟨zadd (zmul x.num (denZ y.den))
         (zmul y.num (denZ x.den)),
   denMul x.den y.den⟩

/-- Standard raw multiplication. -/
def rawMul (x y : RawFrac) : RawFrac :=
  ⟨zmul x.num y.num, denMul x.den y.den⟩

/-- Four-factor interchange in the accepted commutative multiplication. -/
theorem zmul4_swap_middle (a b c d : ZSigned) :
    zmul (zmul a b) (zmul c d) =
    zmul (zmul a c) (zmul b d) := by
  calc
    zmul (zmul a b) (zmul c d) = zmul a (zmul b (zmul c d)) :=
      zmul_assoc a b (zmul c d)
    _ = zmul a (zmul (zmul b c) d) :=
      congrArg (fun t => zmul a t) (zmul_assoc b c d).symm
    _ = zmul a (zmul (zmul c b) d) :=
      congrArg (fun t => zmul a (zmul t d)) (zmul_comm b c)
    _ = zmul a (zmul c (zmul b d)) :=
      congrArg (fun t => zmul a t) (zmul_assoc c b d)
    _ = zmul (zmul a c) (zmul b d) :=
      (zmul_assoc a c (zmul b d)).symm

/-- Raw negation respects fraction equivalence. -/
theorem rawNeg_respects {x y : RawFrac} (h : FracEquiv x y) :
    FracEquiv (rawNeg x) (rawNeg y) := by
  change zmul (zneg x.num) (denZ y.den) =
    zmul (zneg y.num) (denZ x.den)
  calc
    zmul (zneg x.num) (denZ y.den) = zneg (zmul x.num (denZ y.den)) :=
      BOMA.Q.Gateway001.zmul_neg_left x.num (denZ y.den)
    _ = zneg (zmul y.num (denZ x.den)) := congrArg zneg h
    _ = zmul (zneg y.num) (denZ x.den) :=
      (BOMA.Q.Gateway001.zmul_neg_left y.num (denZ x.den)).symm

/-- Raw multiplication respects fraction equivalence in both arguments. -/
theorem rawMul_respects {x x' y y' : RawFrac}
    (hx : FracEquiv x x') (hy : FracEquiv y y') :
    FracEquiv (rawMul x y) (rawMul x' y') := by
  change zmul x.num (denZ x'.den) = zmul x'.num (denZ x.den) at hx
  change zmul y.num (denZ y'.den) = zmul y'.num (denZ y.den) at hy
  change
    zmul (zmul x.num y.num) (denZ (denMul x'.den y'.den)) =
    zmul (zmul x'.num y'.num) (denZ (denMul x.den y.den))
  rw [denZ_mul, denZ_mul]
  calc
    zmul (zmul x.num y.num) (zmul (denZ x'.den) (denZ y'.den)) =
        zmul (zmul x.num (denZ x'.den)) (zmul y.num (denZ y'.den)) :=
      zmul4_swap_middle x.num y.num (denZ x'.den) (denZ y'.den)
    _ = zmul (zmul x'.num (denZ x.den)) (zmul y.num (denZ y'.den)) :=
      congrArg (fun t => zmul t (zmul y.num (denZ y'.den))) hx
    _ = zmul (zmul x'.num (denZ x.den)) (zmul y'.num (denZ y.den)) :=
      congrArg (fun t => zmul (zmul x'.num (denZ x.den)) t) hy
    _ = zmul (zmul x'.num y'.num) (zmul (denZ x.den) (denZ y.den)) :=
      zmul4_swap_middle x'.num (denZ x.den) y'.num (denZ y.den)

/-- First scaled numerator term used in addition well-definedness. -/
theorem rawAdd_term_left {x x' y y' : RawFrac}
    (hx : FracEquiv x x') :
    zmul (zmul x.num (denZ y.den))
      (zmul (denZ x'.den) (denZ y'.den)) =
    zmul (zmul x'.num (denZ y'.den))
      (zmul (denZ x.den) (denZ y.den)) := by
  change zmul x.num (denZ x'.den) = zmul x'.num (denZ x.den) at hx
  calc
    zmul (zmul x.num (denZ y.den))
        (zmul (denZ x'.den) (denZ y'.den)) =
      zmul (zmul x.num (denZ x'.den))
        (zmul (denZ y.den) (denZ y'.den)) :=
      zmul4_swap_middle x.num (denZ y.den) (denZ x'.den) (denZ y'.den)
    _ = zmul (zmul x'.num (denZ x.den))
        (zmul (denZ y.den) (denZ y'.den)) :=
      congrArg (fun t => zmul t (zmul (denZ y.den) (denZ y'.den))) hx
    _ = zmul (zmul x'.num (denZ x.den))
        (zmul (denZ y'.den) (denZ y.den)) :=
      congrArg (fun t => zmul (zmul x'.num (denZ x.den)) t)
        (zmul_comm (denZ y.den) (denZ y'.den))
    _ = zmul (zmul x'.num (denZ y'.den))
        (zmul (denZ x.den) (denZ y.den)) :=
      zmul4_swap_middle x'.num (denZ x.den) (denZ y'.den) (denZ y.den)

/-- Second scaled numerator term used in addition well-definedness. -/
theorem rawAdd_term_right {x x' y y' : RawFrac}
    (hy : FracEquiv y y') :
    zmul (zmul y.num (denZ x.den))
      (zmul (denZ x'.den) (denZ y'.den)) =
    zmul (zmul y'.num (denZ x'.den))
      (zmul (denZ x.den) (denZ y.den)) := by
  change zmul y.num (denZ y'.den) = zmul y'.num (denZ y.den) at hy
  calc
    zmul (zmul y.num (denZ x.den))
        (zmul (denZ x'.den) (denZ y'.den)) =
      zmul (zmul y.num (denZ x.den))
        (zmul (denZ y'.den) (denZ x'.den)) :=
      congrArg (fun t => zmul (zmul y.num (denZ x.den)) t)
        (zmul_comm (denZ x'.den) (denZ y'.den))
    _ = zmul (zmul y.num (denZ y'.den))
        (zmul (denZ x.den) (denZ x'.den)) :=
      zmul4_swap_middle y.num (denZ x.den) (denZ y'.den) (denZ x'.den)
    _ = zmul (zmul y'.num (denZ y.den))
        (zmul (denZ x.den) (denZ x'.den)) :=
      congrArg (fun t => zmul t (zmul (denZ x.den) (denZ x'.den))) hy
    _ = zmul (zmul y'.num (denZ y.den))
        (zmul (denZ x'.den) (denZ x.den)) :=
      congrArg (fun t => zmul (zmul y'.num (denZ y.den)) t)
        (zmul_comm (denZ x.den) (denZ x'.den))
    _ = zmul (zmul y'.num (denZ x'.den))
        (zmul (denZ y.den) (denZ x.den)) :=
      zmul4_swap_middle y'.num (denZ y.den) (denZ x'.den) (denZ x.den)
    _ = zmul (zmul y'.num (denZ x'.den))
        (zmul (denZ x.den) (denZ y.den)) :=
      congrArg (fun t => zmul (zmul y'.num (denZ x'.den)) t)
        (zmul_comm (denZ y.den) (denZ x.den))

/-- Raw addition respects fraction equivalence in both arguments. -/
theorem rawAdd_respects {x x' y y' : RawFrac}
    (hx : FracEquiv x x') (hy : FracEquiv y y') :
    FracEquiv (rawAdd x y) (rawAdd x' y') := by
  change
    zmul
      (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
      (denZ (denMul x'.den y'.den)) =
    zmul
      (zadd (zmul x'.num (denZ y'.den)) (zmul y'.num (denZ x'.den)))
      (denZ (denMul x.den y.den))
  rw [denZ_mul, denZ_mul]
  calc
    zmul
        (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
        (zmul (denZ x'.den) (denZ y'.den)) =
      zadd
        (zmul (zmul x.num (denZ y.den))
          (zmul (denZ x'.den) (denZ y'.den)))
        (zmul (zmul y.num (denZ x.den))
          (zmul (denZ x'.den) (denZ y'.den))) :=
      zmul_add_left
        (zmul x.num (denZ y.den))
        (zmul y.num (denZ x.den))
        (zmul (denZ x'.den) (denZ y'.den))
    _ = zadd
        (zmul (zmul x'.num (denZ y'.den))
          (zmul (denZ x.den) (denZ y.den)))
        (zmul (zmul y.num (denZ x.den))
          (zmul (denZ x'.den) (denZ y'.den))) :=
      congrArg
        (fun t => zadd t
          (zmul (zmul y.num (denZ x.den))
            (zmul (denZ x'.den) (denZ y'.den))))
        (rawAdd_term_left hx)
    _ = zadd
        (zmul (zmul x'.num (denZ y'.den))
          (zmul (denZ x.den) (denZ y.den)))
        (zmul (zmul y'.num (denZ x'.den))
          (zmul (denZ x.den) (denZ y.den))) :=
      congrArg
        (fun t => zadd
          (zmul (zmul x'.num (denZ y'.den))
            (zmul (denZ x.den) (denZ y.den))) t)
        (rawAdd_term_right hy)
    _ = zmul
        (zadd (zmul x'.num (denZ y'.den)) (zmul y'.num (denZ x'.den)))
        (zmul (denZ x.den) (denZ y.den)) :=
      (zmul_add_left
        (zmul x'.num (denZ y'.den))
        (zmul y'.num (denZ x'.den))
        (zmul (denZ x.den) (denZ y.den))).symm

end BOMA.Q.Fraction001

/- Additive laws on raw fractions modulo FracEquiv, before quotient lifting. -/
namespace BOMA.Q.Fraction001

open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- Raw zero is a left additive identity modulo fraction equivalence. -/
theorem rawAdd_zero_left_equiv (x : RawFrac) :
    FracEquiv (rawAdd rawZero x) x := by
  change
    zmul
      (zadd (zmul zzero (denZ x.den)) (zmul x.num zone))
      (denZ x.den) =
    zmul x.num (denZ (denMul oneDen x.den))
  rw [zmul_zero_left, zmul_one_right, zadd_zero_left, denZ_mul, denZ_one, zmul_one_left]

/-- Raw zero is a right identity modulo equivalence. -/
theorem rawAdd_zero_right_equiv (x : RawFrac) :
    FracEquiv (rawAdd x rawZero) x := by
  change
    zmul
      (zadd (zmul x.num zone) (zmul zzero (denZ x.den)))
      (denZ x.den) =
    zmul x.num (denZ (denMul x.den oneDen))
  rw [zmul_one_right, zmul_zero_left, zadd_zero_right, denZ_mul, denZ_one, zmul_one_right]

/-- Raw addition is commutative modulo equivalence. -/
theorem rawAdd_comm_equiv (x y : RawFrac) :
    FracEquiv (rawAdd x y) (rawAdd y x) := by
  change
    zmul
      (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
      (denZ (denMul y.den x.den)) =
    zmul
      (zadd (zmul y.num (denZ x.den)) (zmul x.num (denZ y.den)))
      (denZ (denMul x.den y.den))
  rw [denZ_mul, denZ_mul]
  rw [zadd_comm (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den))]
  rw [zmul_comm (denZ y.den) (denZ x.den)]

/-- Raw addition is associative modulo equivalence. -/
theorem rawAdd_assoc_equiv (x y w : RawFrac) :
    FracEquiv (rawAdd (rawAdd x y) w) (rawAdd x (rawAdd y w)) := by
  have hxTerm :
      zmul (zmul x.num (denZ y.den)) (denZ w.den) =
      zmul x.num (zmul (denZ y.den) (denZ w.den)) :=
    zmul_assoc x.num (denZ y.den) (denZ w.den)

  have hyTerm :
      zmul (zmul y.num (denZ x.den)) (denZ w.den) =
      zmul (zmul y.num (denZ w.den)) (denZ x.den) :=
    zmul_swap_last y.num (denZ x.den) (denZ w.den)

  have hwTerm :
      zmul w.num (zmul (denZ x.den) (denZ y.den)) =
      zmul (zmul w.num (denZ y.den)) (denZ x.den) := by
    calc
      zmul w.num (zmul (denZ x.den) (denZ y.den)) =
          zmul (zmul w.num (denZ x.den)) (denZ y.den) :=
        (zmul_assoc w.num (denZ x.den) (denZ y.den)).symm
      _ = zmul (zmul w.num (denZ y.den)) (denZ x.den) :=
        zmul_swap_last w.num (denZ x.den) (denZ y.den)

  have hxyTerms :
      zadd
        (zmul (zmul x.num (denZ y.den)) (denZ w.den))
        (zmul (zmul y.num (denZ x.den)) (denZ w.den)) =
      zadd
        (zmul x.num (zmul (denZ y.den) (denZ w.den)))
        (zmul (zmul y.num (denZ w.den)) (denZ x.den)) := by
    calc
      zadd
          (zmul (zmul x.num (denZ y.den)) (denZ w.den))
          (zmul (zmul y.num (denZ x.den)) (denZ w.den)) =
        zadd
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zmul (zmul y.num (denZ x.den)) (denZ w.den)) :=
        congrArg
          (fun t => zadd t (zmul (zmul y.num (denZ x.den)) (denZ w.den)))
          hxTerm
      _ = zadd
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zmul (zmul y.num (denZ w.den)) (denZ x.den)) :=
        congrArg
          (fun t => zadd (zmul x.num (zmul (denZ y.den) (denZ w.den))) t)
          hyTerm

  have hnum :
      zadd
        (zmul
          (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
          (denZ w.den))
        (zmul w.num (zmul (denZ x.den) (denZ y.den))) =
      zadd
        (zmul x.num (zmul (denZ y.den) (denZ w.den)))
        (zmul
          (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
          (denZ x.den)) := by
    calc
      zadd
          (zmul
            (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
            (denZ w.den))
          (zmul w.num (zmul (denZ x.den) (denZ y.den))) =
        zadd
          (zadd
            (zmul (zmul x.num (denZ y.den)) (denZ w.den))
            (zmul (zmul y.num (denZ x.den)) (denZ w.den)))
          (zmul w.num (zmul (denZ x.den) (denZ y.den))) :=
        congrArg
          (fun t => zadd t (zmul w.num (zmul (denZ x.den) (denZ y.den))))
          (zmul_add_left
            (zmul x.num (denZ y.den))
            (zmul y.num (denZ x.den))
            (denZ w.den))
      _ = zadd
          (zadd
            (zmul x.num (zmul (denZ y.den) (denZ w.den)))
            (zmul (zmul y.num (denZ w.den)) (denZ x.den)))
          (zmul w.num (zmul (denZ x.den) (denZ y.den))) :=
        congrArg
          (fun t => zadd t (zmul w.num (zmul (denZ x.den) (denZ y.den))))
          hxyTerms
      _ = zadd
          (zadd
            (zmul x.num (zmul (denZ y.den) (denZ w.den)))
            (zmul (zmul y.num (denZ w.den)) (denZ x.den)))
          (zmul (zmul w.num (denZ y.den)) (denZ x.den)) :=
        congrArg
          (fun t => zadd
            (zadd
              (zmul x.num (zmul (denZ y.den) (denZ w.den)))
              (zmul (zmul y.num (denZ w.den)) (denZ x.den))) t)
          hwTerm
      _ = zadd
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zadd
            (zmul (zmul y.num (denZ w.den)) (denZ x.den))
            (zmul (zmul w.num (denZ y.den)) (denZ x.den))) :=
        zadd_assoc
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zmul (zmul y.num (denZ w.den)) (denZ x.den))
          (zmul (zmul w.num (denZ y.den)) (denZ x.den))
      _ = zadd
          (zmul x.num (zmul (denZ y.den) (denZ w.den)))
          (zmul
            (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
            (denZ x.den)) :=
        congrArg
          (fun t => zadd (zmul x.num (zmul (denZ y.den) (denZ w.den))) t)
          (zmul_add_left
            (zmul y.num (denZ w.den))
            (zmul w.num (denZ y.den))
            (denZ x.den)).symm

  have hden :
      denZ (denMul (denMul x.den y.den) w.den) =
      denZ (denMul x.den (denMul y.den w.den)) := by
    rw [denZ_mul, denZ_mul, denZ_mul, denZ_mul]
    exact zmul_assoc (denZ x.den) (denZ y.den) (denZ w.den)

  change
    zmul
      (zadd
        (zmul
          (zadd (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den)))
          (denZ w.den))
        (zmul w.num (denZ (denMul x.den y.den))))
      (denZ (denMul x.den (denMul y.den w.den))) =
    zmul
      (zadd
        (zmul x.num (denZ (denMul y.den w.den)))
        (zmul
          (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
          (denZ x.den)))
      (denZ (denMul (denMul x.den y.den) w.den))
  rw [denZ_mul x.den y.den, denZ_mul y.den w.den]
  rw [hnum, hden]

/-- Raw negation supplies additive inverse modulo equivalence. -/
theorem rawAdd_neg_equiv_zero (x : RawFrac) :
    FracEquiv (rawAdd x (rawNeg x)) rawZero := by
  let a := zmul x.num (denZ x.den)
  change
    zmul
      (zadd a (zmul (zneg x.num) (denZ x.den)))
      zone =
    zmul zzero (denZ (denMul x.den x.den))
  calc
    zmul
        (zadd a (zmul (zneg x.num) (denZ x.den)))
        zone =
      zmul (zadd a (zneg a)) zone :=
        congrArg
          (fun t => zmul (zadd a t) zone)
          (BOMA.Q.Gateway001.zmul_neg_left x.num (denZ x.den))
    _ = zmul zzero zone :=
      congrArg (fun t => zmul t zone) (zadd_neg_right a)
    _ = zzero := zmul_zero_left zone
    _ = zmul zzero (denZ (denMul x.den x.den)) :=
      (zmul_zero_left (denZ (denMul x.den x.den))).symm

end BOMA.Q.Fraction001

/- Multiplicative laws on raw fractions modulo FracEquiv, before quotient lifting. -/
namespace BOMA.Q.Fraction001

open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- Raw zero absorbs multiplication on the left modulo equivalence. -/
theorem rawMul_zero_left_equiv (x : RawFrac) :
    FracEquiv (rawMul rawZero x) rawZero := by
  change
    zmul (zmul zzero x.num) zone =
    zmul zzero (denZ (denMul oneDen x.den))
  rw [zmul_zero_left, zmul_zero_left, zmul_zero_left]

/-- Raw zero absorbs multiplication on the right modulo equivalence. -/
theorem rawMul_zero_right_equiv (x : RawFrac) :
    FracEquiv (rawMul x rawZero) rawZero := by
  change
    zmul (zmul x.num zzero) zone =
    zmul zzero (denZ (denMul x.den oneDen))
  rw [zmul_zero_right, zmul_zero_left, zmul_zero_left]

/-- Raw one is a left multiplicative identity modulo equivalence. -/
theorem rawMul_one_left_equiv (x : RawFrac) :
    FracEquiv (rawMul rawOne x) x := by
  change
    zmul (zmul zone x.num) (denZ x.den) =
    zmul x.num (denZ (denMul oneDen x.den))
  rw [zmul_one_left, denZ_mul, denZ_one, zmul_one_left]

/-- Raw one is a right multiplicative identity modulo equivalence. -/
theorem rawMul_one_right_equiv (x : RawFrac) :
    FracEquiv (rawMul x rawOne) x := by
  change
    zmul (zmul x.num zone) (denZ x.den) =
    zmul x.num (denZ (denMul x.den oneDen))
  rw [zmul_one_right, denZ_mul, denZ_one, zmul_one_right]

/-- Raw multiplication is commutative modulo equivalence. -/
theorem rawMul_comm_equiv (x y : RawFrac) :
    FracEquiv (rawMul x y) (rawMul y x) := by
  change
    zmul (zmul x.num y.num) (denZ (denMul y.den x.den)) =
    zmul (zmul y.num x.num) (denZ (denMul x.den y.den))
  rw [denZ_mul, denZ_mul]
  rw [zmul_comm x.num y.num]
  rw [zmul_comm (denZ y.den) (denZ x.den)]

/-- Raw multiplication is associative modulo equivalence. -/
theorem rawMul_assoc_equiv (x y w : RawFrac) :
    FracEquiv (rawMul (rawMul x y) w) (rawMul x (rawMul y w)) := by
  have hnum :
      zmul (zmul x.num y.num) w.num =
      zmul x.num (zmul y.num w.num) :=
    zmul_assoc x.num y.num w.num
  have hden :
      denZ (denMul (denMul x.den y.den) w.den) =
      denZ (denMul x.den (denMul y.den w.den)) := by
    rw [denZ_mul, denZ_mul, denZ_mul, denZ_mul]
    exact zmul_assoc (denZ x.den) (denZ y.den) (denZ w.den)
  change
    zmul
      (zmul (zmul x.num y.num) w.num)
      (denZ (denMul x.den (denMul y.den w.den))) =
    zmul
      (zmul x.num (zmul y.num w.num))
      (denZ (denMul (denMul x.den y.den) w.den))
  rw [hnum, hden]

end BOMA.Q.Fraction001

/- Right distributivity on raw fractions modulo FracEquiv. -/
namespace BOMA.Q.Fraction001

open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001

/-- The raw numerator on the expanded side is the left raw numerator multiplied
by the common denominator factor from x. -/
theorem raw_distrib_num_factor (x y w : RawFrac) :
    zadd
      (zmul (zmul x.num y.num) (zmul (denZ x.den) (denZ w.den)))
      (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))) =
    zmul (denZ x.den)
      (zmul x.num
        (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))) := by
  calc
    zadd
        (zmul (zmul x.num y.num) (zmul (denZ x.den) (denZ w.den)))
        (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))) =
      zadd
        (zmul (zmul x.num (denZ x.den)) (zmul y.num (denZ w.den)))
        (zmul (zmul x.num (denZ x.den)) (zmul w.num (denZ y.den))) := by
      have h1 :=
        zmul4_swap_middle x.num y.num (denZ x.den) (denZ w.den)
      have h2 :=
        zmul4_swap_middle x.num w.num (denZ x.den) (denZ y.den)
      calc
        zadd
            (zmul (zmul x.num y.num) (zmul (denZ x.den) (denZ w.den)))
            (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))) =
          zadd
            (zmul (zmul x.num (denZ x.den)) (zmul y.num (denZ w.den)))
            (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))) :=
          congrArg
            (fun t => zadd t
              (zmul (zmul x.num w.num) (zmul (denZ x.den) (denZ y.den))))
            h1
        _ = zadd
            (zmul (zmul x.num (denZ x.den)) (zmul y.num (denZ w.den)))
            (zmul (zmul x.num (denZ x.den)) (zmul w.num (denZ y.den))) :=
          congrArg
            (fun t => zadd
              (zmul (zmul x.num (denZ x.den)) (zmul y.num (denZ w.den))) t)
            h2
    _ = zmul (zmul x.num (denZ x.den))
        (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den))) :=
      (zmul_add_right
        (zmul x.num (denZ x.den))
        (zmul y.num (denZ w.den))
        (zmul w.num (denZ y.den))).symm
    _ = zmul (denZ x.den)
        (zmul x.num
          (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))) := by
      calc
        zmul (zmul x.num (denZ x.den))
            (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den))) =
          zmul x.num
            (zmul (denZ x.den)
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))) :=
          zmul_assoc x.num (denZ x.den) _
        _ = zmul x.num
            (zmul
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
              (denZ x.den)) :=
          congrArg (fun t => zmul x.num t)
            (zmul_comm (denZ x.den)
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den))))
        _ = zmul
            (zmul x.num
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den))))
            (denZ x.den) :=
          (zmul_assoc x.num _ (denZ x.den)).symm
        _ = zmul (denZ x.den)
            (zmul x.num
              (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))) :=
          zmul_comm _ _

/-- The expanded denominator carries the same extra x-denominator factor. -/
theorem raw_distrib_den_factor (x y w : RawFrac) :
    denZ (denMul (denMul x.den y.den) (denMul x.den w.den)) =
    zmul (denZ x.den)
      (denZ (denMul x.den (denMul y.den w.den))) := by
  rw [denZ_mul, denZ_mul, denZ_mul, denZ_mul, denZ_mul]
  calc
    zmul (zmul (denZ x.den) (denZ y.den))
        (zmul (denZ x.den) (denZ w.den)) =
      zmul (zmul (denZ x.den) (denZ x.den))
        (zmul (denZ y.den) (denZ w.den)) :=
      zmul4_swap_middle
        (denZ x.den) (denZ y.den) (denZ x.den) (denZ w.den)
    _ = zmul (denZ x.den)
        (zmul (denZ x.den) (zmul (denZ y.den) (denZ w.den))) :=
      zmul_assoc (denZ x.den) (denZ x.den)
        (zmul (denZ y.den) (denZ w.den))

/-- Raw multiplication distributes over raw addition modulo fraction equivalence. -/
theorem rawMul_add_right_equiv (x y w : RawFrac) :
    FracEquiv
      (rawMul x (rawAdd y w))
      (rawAdd (rawMul x y) (rawMul x w)) := by
  let nL :=
    zmul x.num
      (zadd (zmul y.num (denZ w.den)) (zmul w.num (denZ y.den)))
  let dL := denZ (denMul x.den (denMul y.den w.den))
  let nR :=
    zadd
      (zmul (zmul x.num y.num) (denZ (denMul x.den w.den)))
      (zmul (zmul x.num w.num) (denZ (denMul x.den y.den)))
  let dR := denZ (denMul (denMul x.den y.den) (denMul x.den w.den))

  have hn : nR = zmul (denZ x.den) nL := by
    unfold nR nL
    rw [denZ_mul, denZ_mul]
    exact raw_distrib_num_factor x y w

  have hd : dR = zmul (denZ x.den) dL := by
    unfold dR dL
    exact raw_distrib_den_factor x y w

  change zmul nL dR = zmul nR dL
  rw [hn, hd]
  calc
    zmul nL (zmul (denZ x.den) dL) =
      zmul (zmul nL (denZ x.den)) dL :=
      (zmul_assoc nL (denZ x.den) dL).symm
    _ = zmul (zmul (denZ x.den) nL) dL :=
      congrArg (fun t => zmul t dL) (zmul_comm nL (denZ x.den))

end BOMA.Q.Fraction001

/- Stage-One rational formal identity: explicit quotient of verified raw fractions.
   This is the first accepted number-stage candidate to use quotient carrier formation. -/
namespace BOMA.Q.Quotient001

open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Q.Fraction001

/-- The verified fraction equivalence packaged as a formal Setoid. -/
def fracSetoid : Setoid RawFrac where
  r := FracEquiv
  iseqv := ⟨frac_refl, @frac_symm, @frac_trans⟩

/-- Candidate Stage-One rational carrier. -/
def QBOMA : Type := Quotient fracSetoid

/-- Canonical injection of a raw valid fraction into the quotient carrier. -/
def qmk (x : RawFrac) : QBOMA := Quotient.mk fracSetoid x

/-- Representation-equivalent raw fractions become formally equal in QBOMA. -/
theorem qmk_sound {x y : RawFrac} (h : FracEquiv x y) : qmk x = qmk y :=
  Quotient.sound h

/-- Conversely, quotient equality reflects the verified raw equivalence. -/
theorem qmk_eq_iff {x y : RawFrac} : qmk x = qmk y ↔ FracEquiv x y := by
  constructor
  · intro h
    exact Quotient.exact h
  · exact qmk_sound

/-- Lift raw negation through the verified respect proof. -/
def qNeg : QBOMA → QBOMA :=
  Quotient.lift
    (fun a => qmk (rawNeg a))
    (fun _ _ h => qmk_sound (rawNeg_respects h))

/-- Lift raw addition through the verified binary respect proof. -/
def qAdd : QBOMA → QBOMA → QBOMA :=
  Quotient.lift₂
    (fun a b => qmk (rawAdd a b))
    (fun _ _ _ _ ha hb => qmk_sound (rawAdd_respects ha hb))

/-- Lift raw multiplication through the verified binary respect proof. -/
def qMul : QBOMA → QBOMA → QBOMA :=
  Quotient.lift₂
    (fun a b => qmk (rawMul a b))
    (fun _ _ _ _ ha hb => qmk_sound (rawMul_respects ha hb))

/-- Quotient zero and one. -/
def qZero : QBOMA := qmk rawZero
def qOne : QBOMA := qmk rawOne

/-- Accepted integer embedding into the quotient rational carrier. -/
def qOfZ (a : ZSigned) : QBOMA := qmk (fracOfZ a)

/-- Integer embedding remains injective after quotienting. -/
theorem qOfZ_injective {a b : ZSigned} (h : qOfZ a = qOfZ b) : a = b := by
  apply fracOfZ_reflects
  exact Quotient.exact h

/-- Quotient operations compute on raw representatives exactly as intended. -/
@[simp] theorem qNeg_mk (x : RawFrac) : qNeg (qmk x) = qmk (rawNeg x) := rfl

@[simp] theorem qAdd_mk (x y : RawFrac) :
    qAdd (qmk x) (qmk y) = qmk (rawAdd x y) := rfl

@[simp] theorem qMul_mk (x y : RawFrac) :
    qMul (qmk x) (qmk y) = qmk (rawMul x y) := rfl

end BOMA.Q.Quotient001

/- Lift the already-proved raw additive laws to formal QBOMA equality. -/
namespace BOMA.Q.Quotient001

open BOMA.Q.Fraction001

@[simp] theorem qAdd_zero_left (x : QBOMA) : qAdd qZero x = x := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawAdd rawZero a) = qmk a
  exact qmk_sound (rawAdd_zero_left_equiv a)

@[simp] theorem qAdd_zero_right (x : QBOMA) : qAdd x qZero = x := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawAdd a rawZero) = qmk a
  exact qmk_sound (rawAdd_zero_right_equiv a)

theorem qAdd_comm (x y : QBOMA) : qAdd x y = qAdd y x := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  change qmk (rawAdd a b) = qmk (rawAdd b a)
  exact qmk_sound (rawAdd_comm_equiv a b)

theorem qAdd_assoc (x y w : QBOMA) :
    qAdd (qAdd x y) w = qAdd x (qAdd y w) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn w ?_
  intro c
  change qmk (rawAdd (rawAdd a b) c) = qmk (rawAdd a (rawAdd b c))
  exact qmk_sound (rawAdd_assoc_equiv a b c)

@[simp] theorem qAdd_neg_right (x : QBOMA) : qAdd x (qNeg x) = qZero := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawAdd a (rawNeg a)) = qmk rawZero
  exact qmk_sound (rawAdd_neg_equiv_zero a)

@[simp] theorem qAdd_neg_left (x : QBOMA) : qAdd (qNeg x) x = qZero := by
  rw [qAdd_comm]
  exact qAdd_neg_right x

end BOMA.Q.Quotient001

/- Lift the already-proved raw multiplicative laws to formal QBOMA equality. -/
namespace BOMA.Q.Quotient001

open BOMA.Q.Fraction001

@[simp] theorem qMul_zero_left (x : QBOMA) : qMul qZero x = qZero := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawMul rawZero a) = qmk rawZero
  exact qmk_sound (rawMul_zero_left_equiv a)

@[simp] theorem qMul_zero_right (x : QBOMA) : qMul x qZero = qZero := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawMul a rawZero) = qmk rawZero
  exact qmk_sound (rawMul_zero_right_equiv a)

@[simp] theorem qMul_one_left (x : QBOMA) : qMul qOne x = x := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawMul rawOne a) = qmk a
  exact qmk_sound (rawMul_one_left_equiv a)

@[simp] theorem qMul_one_right (x : QBOMA) : qMul x qOne = x := by
  refine Quotient.inductionOn x ?_
  intro a
  change qmk (rawMul a rawOne) = qmk a
  exact qmk_sound (rawMul_one_right_equiv a)

theorem qMul_comm (x y : QBOMA) : qMul x y = qMul y x := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  change qmk (rawMul a b) = qmk (rawMul b a)
  exact qmk_sound (rawMul_comm_equiv a b)

theorem qMul_assoc (x y w : QBOMA) :
    qMul (qMul x y) w = qMul x (qMul y w) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn w ?_
  intro c
  change qmk (rawMul (rawMul a b) c) = qmk (rawMul a (rawMul b c))
  exact qmk_sound (rawMul_assoc_equiv a b c)

end BOMA.Q.Quotient001

/- Lift verified raw distributivity to formal QBOMA equality. -/
namespace BOMA.Q.Quotient001

open BOMA.Q.Fraction001

/-- Right distributivity on the selected quotient carrier. -/
theorem qMul_add_right (x y w : QBOMA) :
    qMul x (qAdd y w) = qAdd (qMul x y) (qMul x w) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  refine Quotient.inductionOn w ?_
  intro c
  change qmk (rawMul a (rawAdd b c)) =
    qmk (rawAdd (rawMul a b) (rawMul a c))
  exact qmk_sound (rawMul_add_right_equiv a b c)

/-- Left distributivity follows from quotient multiplication commutativity. -/
theorem qMul_add_left (x y w : QBOMA) :
    qMul (qAdd x y) w = qAdd (qMul x w) (qMul y w) := by
  calc
    qMul (qAdd x y) w = qMul w (qAdd x y) := qMul_comm _ _
    _ = qAdd (qMul w x) (qMul w y) := qMul_add_right w x y
    _ = qAdd (qMul x w) (qMul y w) := by
      rw [qMul_comm w x, qMul_comm w y]

end BOMA.Q.Quotient001

/- Nonzero rational inverses as unique witnesses, avoiding any Choice commitment. -/
namespace BOMA.Q.Inverse001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Q.Gateway001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001

/-- A raw positive-denominator fraction is equivalent to zero exactly when its
integer numerator is zero. -/
theorem raw_equiv_zero_iff_num_zero (x : RawFrac) :
    FracEquiv x rawZero ↔ x.num = zzero := by
  constructor
  · intro h
    change zmul x.num zone = zmul zzero (denZ x.den) at h
    rw [zmul_one_right, zmul_zero_left] at h
    exact h
  · intro h
    change zmul x.num zone = zmul zzero (denZ x.den)
    rw [h, zmul_zero_left, zmul_zero_left]

/-- Reciprocal raw witness for a positive signed numerator `+(n+1)`. -/
def rawRecipPos (d : PosDen) (n : BOMANat) : RawFrac :=
  ⟨denZ d, ⟨n⟩⟩

/-- Reciprocal raw witness for a negative signed numerator `-(n+1)`. -/
def rawRecipNeg (d : PosDen) (n : BOMANat) : RawFrac :=
  ⟨zneg (denZ d), ⟨n⟩⟩

/-- A positive raw fraction times its reciprocal witness is one modulo FracEquiv. -/
theorem rawMul_recip_pos_equiv_one (d : PosDen) (n : BOMANat) :
    FracEquiv
      (rawMul ⟨pos n, d⟩ (rawRecipPos d n))
      rawOne := by
  change
    zmul (zmul (pos n) (denZ d)) zone =
    zmul zone (denZ (denMul d ⟨n⟩))
  rw [zmul_one_right, zmul_one_left, denZ_mul]
  change zmul (pos n) (denZ d) = zmul (denZ d) (pos n)
  exact zmul_comm _ _

/-- A negative raw fraction times its sign-normalized reciprocal witness is one. -/
theorem rawMul_recip_neg_equiv_one (d : PosDen) (n : BOMANat) :
    FracEquiv
      (rawMul ⟨neg n, d⟩ (rawRecipNeg d n))
      rawOne := by
  change
    zmul (zmul (neg n) (zneg (denZ d))) zone =
    zmul zone (denZ (denMul d ⟨n⟩))
  rw [zmul_one_right, zmul_one_left, denZ_mul]
  change zmul (neg n) (zneg (denZ d)) = zmul (denZ d) (pos n)
  calc
    zmul (neg n) (zneg (denZ d)) =
        zneg (zmul (pos n) (zneg (denZ d))) :=
      zmul_neg_left (pos n) (zneg (denZ d))
    _ = zneg (zneg (zmul (pos n) (denZ d))) :=
      congrArg zneg (zmul_neg_right (pos n) (denZ d))
    _ = zmul (pos n) (denZ d) := zneg_involutive _
    _ = zmul (denZ d) (pos n) := zmul_comm _ _

/-- Quotient-level multiplicative-inverse relation. -/
def QInvRel (q r : QBOMA) : Prop := qMul q r = qOne

/-- Every nonzero quotient rational has an explicitly constructed inverse witness.
The proof eliminates the quotient only into a proposition, so it requires no
representative-choice axiom. -/
theorem q_inverse_exists (q : QBOMA) (hq : q ≠ qZero) :
    ∃ r : QBOMA, QInvRel q r := by
  refine Quotient.inductionOn q ?_ hq
  intro x hx
  have hnum : x.num ≠ zzero := by
    intro hzero
    apply hx
    exact qmk_sound ((raw_equiv_zero_iff_num_zero x).2 hzero)
  cases x with
  | mk num den =>
      cases num with
      | zero => exact False.elim (hnum rfl)
      | pos n =>
          refine ⟨qmk (rawRecipPos den n), ?_⟩
          change qmk (rawMul ⟨pos n, den⟩ (rawRecipPos den n)) = qmk rawOne
          exact qmk_sound (rawMul_recip_pos_equiv_one den n)
      | neg n =>
          refine ⟨qmk (rawRecipNeg den n), ?_⟩
          change qmk (rawMul ⟨neg n, den⟩ (rawRecipNeg den n)) = qmk rawOne
          exact qmk_sound (rawMul_recip_neg_equiv_one den n)

/-- Multiplicative inverse witnesses are unique in the commutative monoid. -/
theorem q_inverse_unique {q r s : QBOMA}
    (hr : QInvRel q r) (hs : QInvRel q s) : r = s := by
  unfold QInvRel at hr hs
  calc
    r = qMul qOne r := (qMul_one_left r).symm
    _ = qMul (qMul q s) r := congrArg (fun t => qMul t r) hs.symm
    _ = qMul q (qMul s r) := qMul_assoc q s r
    _ = qMul q (qMul r s) := congrArg (fun t => qMul q t) (qMul_comm s r)
    _ = qMul (qMul q r) s := (qMul_assoc q r s).symm
    _ = qMul qOne s := congrArg (fun t => qMul t s) hr
    _ = s := qMul_one_left s

/-- QA-09 constructive interface: each nonzero rational has one inverse witness,
and every inverse witness is equal to it. This avoids `∃!` notation and any
Choice-based global selector. -/
theorem q_inverse_exists_unique (q : QBOMA) (hq : q ≠ qZero) :
    ∃ r : QBOMA, QInvRel q r ∧ ∀ s : QBOMA, QInvRel q s → s = r := by
  rcases q_inverse_exists q hq with ⟨r, hr⟩
  refine ⟨r, hr, ?_⟩
  intro s hs
  exact q_inverse_unique hs hr

end BOMA.Q.Inverse001

/- Preservation laws for the accepted Z embedding into the rational quotient carrier. -/
namespace BOMA.Q.Embedding001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001

@[simp] theorem qOfZ_zero : qOfZ zzero = qZero := rfl

@[simp] theorem qOfZ_one : qOfZ zone = qOne := rfl

/-- Integer negation is preserved exactly by the quotient embedding. -/
theorem qOfZ_neg (a : ZSigned) : qOfZ (zneg a) = qNeg (qOfZ a) := by
  rfl

/-- Integer addition is preserved by the rational embedding. -/
theorem qOfZ_add (a b : ZSigned) :
    qOfZ (zadd a b) = qAdd (qOfZ a) (qOfZ b) := by
  apply qmk_sound
  change
    zmul (zadd a b) (denZ (denMul oneDen oneDen)) =
    zmul (zadd (zmul a zone) (zmul b zone)) zone
  calc
    zmul (zadd a b) (denZ (denMul oneDen oneDen)) =
        zmul (zadd a b) (zmul zone zone) :=
      congrArg (fun t => zmul (zadd a b) t) (denZ_mul oneDen oneDen)
    _ = zmul (zadd a b) zone := by rw [zmul_one_left]
    _ = zadd a b := zmul_one_right (zadd a b)
    _ = zadd (zmul a zone) (zmul b zone) := by
      rw [zmul_one_right a, zmul_one_right b]
    _ = zmul (zadd (zmul a zone) (zmul b zone)) zone :=
      (zmul_one_right _).symm

/-- Integer multiplication is preserved by the rational embedding. -/
theorem qOfZ_mul (a b : ZSigned) :
    qOfZ (zmul a b) = qMul (qOfZ a) (qOfZ b) := by
  apply qmk_sound
  change
    zmul (zmul a b) (denZ (denMul oneDen oneDen)) =
    zmul (zmul a b) zone
  rw [denZ_mul, denZ_one, zmul_one_left, zmul_one_right]

/-- The only Stage-One natural embedding into Q is the documented composition
N_BOMA -> Z_BOMA -> QBOMA. -/
def qOfN (n : BOMANat) : QBOMA := qOfZ (embedN n)

/-- Coherence with the direct fraction spelling `n/1`. -/
theorem qOfN_fraction (n : BOMANat) :
    qOfN n = qmk (fracOfZ (embedN n)) := rfl

@[simp] theorem qOfN_zero : qOfN z = qZero := rfl

@[simp] theorem qOfN_one : qOfN (s z) = qOne := rfl

/-- The composed natural embedding preserves accepted natural addition. -/
theorem qOfN_add (a b : BOMANat) :
    qOfN (BOMA.NArithmetic.Addition001.add a b) =
    qAdd (qOfN a) (qOfN b) := by
  unfold qOfN
  rw [BOMA.Z.Arithmetic001.embedN_add]
  exact qOfZ_add (embedN a) (embedN b)

/-- The composed natural embedding preserves accepted natural multiplication. -/
theorem qOfN_mul (a b : BOMANat) :
    qOfN (BOMA.NArithmetic.Multiplication001.mul a b) =
    qMul (qOfN a) (qOfN b) := by
  unfold qOfN
  rw [BOMA.Z.Arithmetic001.embedN_mul]
  exact qOfZ_mul (embedN a) (embedN b)

end BOMA.Q.Embedding001

/- Stage-One rational order from positive-denominator cross products. -/
namespace BOMA.Q.Order001

open BOMA.Z.Rep001
open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Gateway001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001

/-- Every selected rational denominator is nonnegative in accepted Z. -/
theorem denZ_nonneg (d : PosDen) : NonNeg (denZ d) := by
  unfold NonNeg denZ denNat
  exact (embedN_order BOMA.NCore.RB001.BOMANat.z
    (BOMA.NCore.RB001.BOMANat.s d.pred)).2
    (BOMA.NArithmetic.Order001.z_le _)

/-- Multiplication by a nonnegative nonzero integer reflects order. This is the
order analogue of the QG-01 cancellation gateway and is derived rather than
assumed. -/
theorem zmul_order_reflect_right_nonneg_nonzero {x y c : BOMA.Z.Rep001.ZSigned}
    (hcN : NonNeg c) (hc0 : c ≠ zzero)
    (h : zLE (zmul x c) (zmul y c)) : zLE x y := by
  rcases zle_total x y with hxy | hyx
  · exact hxy
  · have hback : zLE (zmul y c) (zmul x c) :=
      zmul_mono_right_nonneg hyx hcN
    have heq : zmul x c = zmul y c := zle_antisymm h hback
    have hxyEq : x = y := zmul_right_cancel_nonzero hc0 heq
    rw [hxyEq]
    exact zle_refl y

/-- Raw cross-product order. Positive denominator syntax fixes orientation. -/
def RawLE (x y : RawFrac) : Prop :=
  zLE (zmul x.num (denZ y.den)) (zmul y.num (denZ x.den))

/-- Changing the left fraction representative preserves raw order. -/
theorem rawLE_respects_left {x x' y : RawFrac}
    (hx : FracEquiv x x') (h : RawLE x y) : RawLE x' y := by
  change zmul x.num (denZ x'.den) =
    zmul x'.num (denZ x.den) at hx
  change zLE (zmul x.num (denZ y.den))
    (zmul y.num (denZ x.den)) at h
  change zLE (zmul x'.num (denZ y.den))
    (zmul y.num (denZ x'.den))
  have hm := zmul_mono_right_nonneg h (denZ_nonneg x'.den)
  have hleft :
      zmul (zmul x.num (denZ y.den)) (denZ x'.den) =
      zmul (zmul x'.num (denZ y.den)) (denZ x.den) := by
    calc
      zmul (zmul x.num (denZ y.den)) (denZ x'.den) =
          zmul (zmul x.num (denZ x'.den)) (denZ y.den) :=
        zmul_swap_last x.num (denZ y.den) (denZ x'.den)
      _ = zmul (zmul x'.num (denZ x.den)) (denZ y.den) :=
        congrArg (fun t => zmul t (denZ y.den)) hx
      _ = zmul (zmul x'.num (denZ y.den)) (denZ x.den) :=
        zmul_swap_last x'.num (denZ x.den) (denZ y.den)
  have hright :
      zmul (zmul y.num (denZ x.den)) (denZ x'.den) =
      zmul (zmul y.num (denZ x'.den)) (denZ x.den) :=
    zmul_swap_last y.num (denZ x.den) (denZ x'.den)
  rw [hleft, hright] at hm
  exact zmul_order_reflect_right_nonneg_nonzero
    (denZ_nonneg x.den) (denZ_ne_zero x.den) hm

/-- Changing the right fraction representative preserves raw order. -/
theorem rawLE_respects_right {x y y' : RawFrac}
    (hy : FracEquiv y y') (h : RawLE x y) : RawLE x y' := by
  change zmul y.num (denZ y'.den) =
    zmul y'.num (denZ y.den) at hy
  change zLE (zmul x.num (denZ y.den))
    (zmul y.num (denZ x.den)) at h
  change zLE (zmul x.num (denZ y'.den))
    (zmul y'.num (denZ x.den))
  have hm := zmul_mono_right_nonneg h (denZ_nonneg y'.den)
  have hleft :
      zmul (zmul x.num (denZ y.den)) (denZ y'.den) =
      zmul (zmul x.num (denZ y'.den)) (denZ y.den) :=
    zmul_swap_last x.num (denZ y.den) (denZ y'.den)
  have hright :
      zmul (zmul y.num (denZ x.den)) (denZ y'.den) =
      zmul (zmul y'.num (denZ x.den)) (denZ y.den) := by
    calc
      zmul (zmul y.num (denZ x.den)) (denZ y'.den) =
          zmul (zmul y.num (denZ y'.den)) (denZ x.den) :=
        zmul_swap_last y.num (denZ x.den) (denZ y'.den)
      _ = zmul (zmul y'.num (denZ y.den)) (denZ x.den) :=
        congrArg (fun t => zmul t (denZ x.den)) hy
      _ = zmul (zmul y'.num (denZ x.den)) (denZ y.den) :=
        zmul_swap_last y'.num (denZ y.den) (denZ x.den)
  rw [hleft, hright] at hm
  exact zmul_order_reflect_right_nonneg_nonzero
    (denZ_nonneg y.den) (denZ_ne_zero y.den) hm

theorem rawLE_respects {x x' y y' : RawFrac}
    (hx : FracEquiv x x') (hy : FracEquiv y y') (h : RawLE x y) :
    RawLE x' y' :=
  rawLE_respects_right hy (rawLE_respects_left hx h)

theorem rawLE_refl (x : RawFrac) : RawLE x x := zle_refl _

theorem rawLE_total (x y : RawFrac) : RawLE x y ∨ RawLE y x :=
  zle_total _ _

/-- Opposite raw inequalities force fraction equivalence. -/
theorem rawLE_antisymm_equiv {x y : RawFrac}
    (hxy : RawLE x y) (hyx : RawLE y x) : FracEquiv x y := by
  exact zle_antisymm hxy hyx

/-- Transitivity uses one positive middle denominator as a cancellable common
factor after multiplying the two cross inequalities. -/
theorem rawLE_trans {x y w : RawFrac}
    (hxy : RawLE x y) (hyw : RawLE y w) : RawLE x w := by
  change zLE (zmul x.num (denZ y.den))
    (zmul y.num (denZ x.den)) at hxy
  change zLE (zmul y.num (denZ w.den))
    (zmul w.num (denZ y.den)) at hyw
  change zLE (zmul x.num (denZ w.den))
    (zmul w.num (denZ x.den))
  have h1 := zmul_mono_right_nonneg hxy (denZ_nonneg w.den)
  have h2 := zmul_mono_right_nonneg hyw (denZ_nonneg x.den)
  rw [zmul_swap_last x.num (denZ y.den) (denZ w.den)] at h1
  rw [zmul_swap_last y.num (denZ x.den) (denZ w.den)] at h1
  rw [zmul_swap_last w.num (denZ y.den) (denZ x.den)] at h2
  have hcommon := zle_trans h1 h2
  exact zmul_order_reflect_right_nonneg_nonzero
    (denZ_nonneg y.den) (denZ_ne_zero y.den) hcommon

/-- Quotient order without proposition extensionality: witnesses are raw
representatives tied by formal quotient equality to the two endpoints. -/
def qLE (q r : QBOMA) : Prop :=
  ∃ x : RawFrac, ∃ y : RawFrac,
    q = qmk x ∧ r = qmk y ∧ RawLE x y

/-- On explicit quotient representatives, qLE is exactly the raw cross order. -/
theorem qLE_mk_iff (x y : RawFrac) :
    qLE (qmk x) (qmk y) ↔ RawLE x y := by
  constructor
  · rintro ⟨x', y', hxq, hyq, hle⟩
    have hx : FracEquiv x x' := (qmk_eq_iff).mp hxq
    have hy : FracEquiv y y' := (qmk_eq_iff).mp hyq
    exact rawLE_respects (frac_symm hx) (frac_symm hy) hle
  · intro h
    exact ⟨x, y, rfl, rfl, h⟩

theorem qle_refl (q : QBOMA) : qLE q q := by
  refine Quotient.inductionOn q ?_
  intro x
  exact (qLE_mk_iff x x).2 (rawLE_refl x)

theorem qle_trans {q r s : QBOMA} (hqr : qLE q r) (hrs : qLE r s) : qLE q s := by
  refine Quotient.inductionOn q ?_ hqr hrs
  intro x hxr hrs'
  refine Quotient.inductionOn r ?_ hxr hrs'
  intro y hxy hys
  refine Quotient.inductionOn s ?_ hxy hys
  intro w hxy' hyw'
  apply (qLE_mk_iff x w).2
  exact rawLE_trans ((qLE_mk_iff x y).1 hxy') ((qLE_mk_iff y w).1 hyw')

theorem qle_antisymm {q r : QBOMA} (hqr : qLE q r) (hrq : qLE r q) : q = r := by
  refine Quotient.inductionOn q ?_ hqr hrq
  intro x hxr hrx
  refine Quotient.inductionOn r ?_ hxr hrx
  intro y hxy hyx
  exact qmk_sound (rawLE_antisymm_equiv
    ((qLE_mk_iff x y).1 hxy) ((qLE_mk_iff y x).1 hyx))

theorem qle_total (q r : QBOMA) : qLE q r ∨ qLE r q := by
  refine Quotient.inductionOn q ?_
  intro x
  refine Quotient.inductionOn r ?_
  intro y
  rcases rawLE_total x y with h | h
  · exact Or.inl ((qLE_mk_iff x y).2 h)
  · exact Or.inr ((qLE_mk_iff y x).2 h)

/-- The rational order exactly extends the accepted integer order.
The representative-order Iff is composed explicitly, avoiding proposition-level
rewriting by `qLE_mk_iff`. -/
theorem qOfZ_order (a b : BOMA.Z.Rep001.ZSigned) :
    qLE (qOfZ a) (qOfZ b) ↔ zLE a b := by
  change qLE (qmk (fracOfZ a)) (qmk (fracOfZ b)) ↔ zLE a b
  have hRaw : RawLE (fracOfZ a) (fracOfZ b) ↔ zLE a b := by
    constructor
    · intro h
      change zLE (zmul a zone) (zmul b zone) at h
      rw [zmul_one_right, zmul_one_right] at h
      exact h
    · intro h
      change zLE (zmul a zone) (zmul b zone)
      rw [zmul_one_right, zmul_one_right]
      exact h
  exact (qLE_mk_iff (fracOfZ a) (fracOfZ b)).trans hRaw

end BOMA.Q.Order001

/- Additive compatibility of the Stage-One rational order. -/
namespace BOMA.Q.OrderedField001

open BOMA.Z.Rep001
open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Gateway001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001
open BOMA.Q.Order001

/-- Additive cancellation in QBOMA. -/
theorem qAdd_left_cancel {a b c : QBOMA}
    (h : qAdd a b = qAdd a c) : b = c := by
  have h' := congrArg (fun t => qAdd (qNeg a) t) h
  calc
    b = qAdd qZero b := (qAdd_zero_left b).symm
    _ = qAdd (qAdd (qNeg a) a) b := by rw [qAdd_neg_left]
    _ = qAdd (qNeg a) (qAdd a b) := qAdd_assoc (qNeg a) a b
    _ = qAdd (qNeg a) (qAdd a c) := h'
    _ = qAdd (qAdd (qNeg a) a) c := (qAdd_assoc (qNeg a) a c).symm
    _ = qAdd qZero c := by rw [qAdd_neg_left]
    _ = c := qAdd_zero_left c

/-- Any additive inverse equals the selected qNeg. -/
theorem qAdd_inverse_unique {x y : QBOMA}
    (h : qAdd x y = qZero) : y = qNeg x := by
  apply qAdd_left_cancel (a := x)
  calc
    qAdd x y = qZero := h
    _ = qAdd x (qNeg x) := (qAdd_neg_right x).symm

/-- Exchange the two middle terms of a four-term additive expression. -/
theorem qAdd_exchange (a b c d : QBOMA) :
    qAdd a (qAdd b (qAdd c d)) =
    qAdd a (qAdd c (qAdd b d)) := by
  apply congrArg (fun t => qAdd a t)
  calc
    qAdd b (qAdd c d) = qAdd (qAdd b c) d := (qAdd_assoc b c d).symm
    _ = qAdd (qAdd c b) d := congrArg (fun t => qAdd t d) (qAdd_comm b c)
    _ = qAdd c (qAdd b d) := qAdd_assoc c b d

/-- Negation distributes over addition. -/
theorem qNeg_add (x y : QBOMA) :
    qNeg (qAdd x y) = qAdd (qNeg x) (qNeg y) := by
  symm
  apply qAdd_inverse_unique (x := qAdd x y)
  calc
    qAdd (qAdd x y) (qAdd (qNeg x) (qNeg y)) =
        qAdd x (qAdd y (qAdd (qNeg x) (qNeg y))) :=
      qAdd_assoc x y (qAdd (qNeg x) (qNeg y))
    _ = qAdd x (qAdd (qNeg x) (qAdd y (qNeg y))) :=
      qAdd_exchange x y (qNeg x) (qNeg y)
    _ = qAdd x (qAdd (qNeg x) qZero) := by rw [qAdd_neg_right]
    _ = qAdd x (qNeg x) := by rw [qAdd_zero_right]
    _ = qZero := qAdd_neg_right x

/-- Ordered-additive-group bridge in accepted Z. -/
theorem zle_iff_zero_le_difference (a b : BOMA.Z.Rep001.ZSigned) :
    zLE a b ↔ zLE zzero (zadd b (zneg a)) := by
  constructor
  · intro h
    have ht := zadd_mono_left h (zneg a)
    rw [zadd_neg_left] at ht
    rw [zadd_comm (zneg a) b] at ht
    exact ht
  · intro h
    have ht := zadd_mono_left h a
    rw [zadd_zero_right] at ht
    have hright : zadd a (zadd b (zneg a)) = b := by
      calc
        zadd a (zadd b (zneg a)) = zadd (zadd a b) (zneg a) :=
          (zadd_assoc a b (zneg a)).symm
        _ = zadd (zadd b a) (zneg a) :=
          congrArg (fun t => zadd t (zneg a)) (zadd_comm a b)
        _ = zadd b (zadd a (zneg a)) := zadd_assoc b a (zneg a)
        _ = zadd b zzero := by rw [zadd_neg_right]
        _ = b := zadd_zero_right b
    rw [hright] at ht
    exact ht

/-- On an explicit fraction, nonnegativity is exactly numerator nonnegativity.
The representative-order Iff is composed explicitly rather than used as a
proposition rewrite. -/
theorem qNonNeg_mk_iff (x : RawFrac) :
    qLE qZero (qmk x) ↔ zLE zzero x.num := by
  change qLE (qmk rawZero) (qmk x) ↔ zLE zzero x.num
  have hRaw : RawLE rawZero x ↔ zLE zzero x.num := by
    constructor
    · intro h
      change
        zLE (zmul zzero (denZ x.den)) (zmul x.num zone) at h
      rw [zmul_zero_left, zmul_one_right] at h
      exact h
    · intro h
      change
        zLE (zmul zzero (denZ x.den)) (zmul x.num zone)
      rw [zmul_zero_left, zmul_one_right]
      exact h
  exact (qLE_mk_iff rawZero x).trans hRaw

/-- Rational order is equivalent to nonnegativity of y-x.
The proof composes three Iff interfaces directly, preventing `rw` from turning
those Iffs into proposition equalities through proposition extensionality. -/
theorem qle_iff_nonneg_difference (x y : QBOMA) :
    qLE x y ↔ qLE qZero (qAdd y (qNeg x)) := by
  refine Quotient.inductionOn x ?_
  intro a
  refine Quotient.inductionOn y ?_
  intro b
  change qLE (qmk a) (qmk b) ↔
    qLE qZero (qmk (rawAdd b (rawNeg a)))
  have hRaw :
      RawLE a b ↔ zLE zzero (rawAdd b (rawNeg a)).num := by
    change
      zLE (zmul a.num (denZ b.den)) (zmul b.num (denZ a.den)) ↔
      zLE zzero
        (zadd (zmul b.num (denZ a.den))
          (zmul (zneg a.num) (denZ b.den)))
    rw [BOMA.Q.Gateway001.zmul_neg_left]
    exact zle_iff_zero_le_difference
      (zmul a.num (denZ b.den))
      (zmul b.num (denZ a.den))
  have hNonNeg :
      zLE zzero (rawAdd b (rawNeg a)).num ↔
      qLE qZero (qmk (rawAdd b (rawNeg a))) :=
    (qNonNeg_mk_iff (rawAdd b (rawNeg a))).symm
  exact (qLE_mk_iff a b).trans (hRaw.trans hNonNeg)

/-- Translating both sides by the same rational leaves their difference unchanged. -/
theorem q_difference_translate (x y c : QBOMA) :
    qAdd (qAdd y c) (qNeg (qAdd x c)) = qAdd y (qNeg x) := by
  rw [qNeg_add]
  calc
    qAdd (qAdd y c) (qAdd (qNeg x) (qNeg c)) =
        qAdd y (qAdd c (qAdd (qNeg x) (qNeg c))) :=
      qAdd_assoc y c (qAdd (qNeg x) (qNeg c))
    _ = qAdd y (qAdd (qNeg x) (qAdd c (qNeg c))) :=
      qAdd_exchange y c (qNeg x) (qNeg c)
    _ = qAdd y (qAdd (qNeg x) qZero) := by rw [qAdd_neg_right]
    _ = qAdd y (qNeg x) := by rw [qAdd_zero_right]

/-- Addition monotonicity by a common right translate. -/
theorem qadd_mono_right {x y : QBOMA} (h : qLE x y) (c : QBOMA) :
    qLE (qAdd x c) (qAdd y c) := by
  apply (qle_iff_nonneg_difference (qAdd x c) (qAdd y c)).2
  have hd := (qle_iff_nonneg_difference x y).1 h
  rw [q_difference_translate x y c]
  exact hd

/-- Full addition translation invariance. -/
theorem qadd_translate_iff (x y c : QBOMA) :
    qLE (qAdd x c) (qAdd y c) ↔ qLE x y := by
  constructor
  · intro h
    have hb := qadd_mono_right h (qNeg c)
    have hx : qAdd (qAdd x c) (qNeg c) = x := by
      calc
        qAdd (qAdd x c) (qNeg c) = qAdd x (qAdd c (qNeg c)) :=
          qAdd_assoc x c (qNeg c)
        _ = qAdd x qZero := by rw [qAdd_neg_right]
        _ = x := qAdd_zero_right x
    have hy : qAdd (qAdd y c) (qNeg c) = y := by
      calc
        qAdd (qAdd y c) (qNeg c) = qAdd y (qAdd c (qNeg c)) :=
          qAdd_assoc y c (qNeg c)
        _ = qAdd y qZero := by rw [qAdd_neg_right]
        _ = y := qAdd_zero_right y
    rw [hx, hy] at hb
    exact hb
  · intro h
    exact qadd_mono_right h c

/-- Negation reverses rational order. -/
theorem qneg_reverses {x y : QBOMA} (h : qLE x y) :
    qLE (qNeg y) (qNeg x) := by
  have ht := qadd_mono_right h (qAdd (qNeg x) (qNeg y))
  have hleft : qAdd x (qAdd (qNeg x) (qNeg y)) = qNeg y := by
    calc
      qAdd x (qAdd (qNeg x) (qNeg y)) =
          qAdd (qAdd x (qNeg x)) (qNeg y) :=
        (qAdd_assoc x (qNeg x) (qNeg y)).symm
      _ = qAdd qZero (qNeg y) := by rw [qAdd_neg_right]
      _ = qNeg y := qAdd_zero_left _
  have hright : qAdd y (qAdd (qNeg x) (qNeg y)) = qNeg x := by
    calc
      qAdd y (qAdd (qNeg x) (qNeg y)) =
          qAdd y (qAdd (qNeg y) (qNeg x)) :=
        congrArg (fun t => qAdd y t) (qAdd_comm (qNeg x) (qNeg y))
      _ = qAdd (qAdd y (qNeg y)) (qNeg x) :=
        (qAdd_assoc y (qNeg y) (qNeg x)).symm
      _ = qAdd qZero (qNeg x) := by rw [qAdd_neg_right]
      _ = qNeg x := qAdd_zero_left _
  rw [hleft, hright] at ht
  exact ht

end BOMA.Q.OrderedField001

/- Multiplicative compatibility of the Stage-One rational order. -/
namespace BOMA.Q.OrderedField001

open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.Inverse001

/-- A negated left factor produces the additive inverse of the product. -/
theorem qMul_neg_left (x c : QBOMA) :
    qMul (qNeg x) c = qNeg (qMul x c) := by
  apply qAdd_inverse_unique (x := qMul x c)
  calc
    qAdd (qMul x c) (qMul (qNeg x) c) =
        qMul (qAdd x (qNeg x)) c :=
      (qMul_add_left x (qNeg x) c).symm
    _ = qMul qZero c := congrArg (fun t => qMul t c) (qAdd_neg_right x)
    _ = qZero := qMul_zero_left c

/-- Product of two nonnegative rationals is nonnegative. -/
theorem qmul_nonneg {x y : QBOMA}
    (hx : qLE qZero x) (hy : qLE qZero y) : qLE qZero (qMul x y) := by
  refine Quotient.inductionOn x ?_ hx
  intro a hxa
  refine Quotient.inductionOn y ?_ hy
  intro b hyb
  have ha : zLE zzero a.num := (qNonNeg_mk_iff a).1 hxa
  have hb : zLE zzero b.num := (qNonNeg_mk_iff b).1 hyb
  apply (qNonNeg_mk_iff (rawMul a b)).2
  change zLE zzero (zmul a.num b.num)
  have hm := zmul_mono_right_nonneg ha hb
  rw [zmul_zero_left] at hm
  exact hm

/-- Multiplication by a nonnegative rational preserves order. -/
theorem qmul_mono_right_nonneg {x y c : QBOMA}
    (hxy : qLE x y) (hc : qLE qZero c) :
    qLE (qMul x c) (qMul y c) := by
  apply (qle_iff_nonneg_difference (qMul x c) (qMul y c)).2
  have hd := (qle_iff_nonneg_difference x y).1 hxy
  have hp := qmul_nonneg hd hc
  have hEq :
      qAdd (qMul y c) (qNeg (qMul x c)) =
      qMul (qAdd y (qNeg x)) c := by
    calc
      qAdd (qMul y c) (qNeg (qMul x c)) =
          qAdd (qMul y c) (qMul (qNeg x) c) :=
        congrArg (fun t => qAdd (qMul y c) t) (qMul_neg_left x c).symm
      _ = qMul (qAdd y (qNeg x)) c :=
        (qMul_add_left y (qNeg x) c).symm
  rw [hEq]
  exact hp

/-- Multiplication by a nonnegative rational on the left. -/
theorem qmul_mono_left_nonneg {x y c : QBOMA}
    (hxy : qLE x y) (hc : qLE qZero c) :
    qLE (qMul c x) (qMul c y) := by
  rw [qMul_comm c x, qMul_comm c y]
  exact qmul_mono_right_nonneg hxy hc

/-- Rational one is nonnegative. -/
theorem qzero_le_one : qLE qZero qOne := by
  change qLE (qOfZ zzero) (qOfZ zone)
  apply (qOfZ_order zzero zone).2
  exact (embedN_order BOMA.NCore.RB001.BOMANat.z
    (BOMA.NCore.RB001.BOMANat.s BOMA.NCore.RB001.BOMANat.z)).2
    (BOMA.NArithmetic.Order001.z_le _)

/-- Rational one is distinct from zero by faithful Z embedding. -/
theorem qone_ne_zero : qOne ≠ qZero := by
  intro h
  change qOfZ zone = qOfZ zzero at h
  have hz : zone = zzero := qOfZ_injective h
  cases hz

/-- A positive rational is nonnegative and nonzero; no separate strict-order
primitive is required solely for this acceptance gate. -/
def QPositive (q : QBOMA) : Prop := qLE qZero q ∧ q ≠ qZero

/-- The unique multiplicative inverse witness of a positive rational is positive. -/
theorem inverse_of_positive_is_positive {q r : QBOMA}
    (hq : QPositive q) (hr : QInvRel q r) : QPositive r := by
  constructor
  · rcases qle_total qZero r with h0r | hr0
    · exact h0r
    · have hm := qmul_mono_right_nonneg hr0 hq.1
      have hleft : qMul r q = qOne := by
        calc
          qMul r q = qMul q r := qMul_comm r q
          _ = qOne := hr
      have hright : qMul qZero q = qZero := qMul_zero_left q
      rw [hleft, hright] at hm
      have heq : qOne = qZero := qle_antisymm hm qzero_le_one
      exact False.elim (qone_ne_zero heq)
  · intro hrzero
    unfold QInvRel at hr
    rw [hrzero, qMul_zero_right] at hr
    exact qone_ne_zero hr.symm

end BOMA.Q.OrderedField001

/- Shared pre-real order/positivity interface over accepted QBOMA. -/
namespace BOMA.R.Gateway001

open BOMA.Q.Quotient001
open BOMA.Q.Order001

/-- Strict rational order derived from the accepted total non-strict order. -/
def qLT (x y : QBOMA) : Prop := qLE x y ∧ x ≠ y

/-- Positive rational in the strict-order sense. -/
def qPos (x : QBOMA) : Prop := qLT qZero x

@[simp] theorem qlt_irrefl (x : QBOMA) : ¬ qLT x x := by
  intro h
  exact h.2 rfl

theorem qlt_of_le_of_ne {x y : QBOMA} (hxy : qLE x y) (hne : x ≠ y) : qLT x y :=
  ⟨hxy, hne⟩

theorem qlt_trans {x y z : QBOMA} (hxy : qLT x y) (hyz : qLT y z) : qLT x z := by
  refine ⟨qle_trans hxy.1 hyz.1, ?_⟩
  intro hxz
  have hzx : qLE z x := by
    rw [hxz]
    exact qle_refl z
  have hyx : qLE y x := qle_trans hyz.1 hzx
  have hy_eq_x : y = x := qle_antisymm hyx hxy.1
  apply hxy.2
  exact hy_eq_x.symm

theorem qlt_asymm {x y : QBOMA} (hxy : qLT x y) : ¬ qLT y x := by
  intro hyx
  have heq := qle_antisymm hxy.1 hyx.1
  exact hxy.2 heq

/-- Total-order trichotomy without adding a separate primitive order.
The equality split is an explicit localized classical commitment rather than an
implicit `by_cases` use of the global proposition-decidability instance. -/
theorem qlt_trichotomy (x y : QBOMA) : qLT x y ∨ x = y ∨ qLT y x := by
  rcases qle_total x y with hxy | hyx
  · rcases Classical.em (x = y) with h | h
    · exact Or.inr (Or.inl h)
    · exact Or.inl ⟨hxy, h⟩
  · rcases Classical.em (x = y) with h | h
    · exact Or.inr (Or.inl h)
    · exact Or.inr (Or.inr ⟨hyx, fun hyxEq => h hyxEq.symm⟩)

/-- Symmetric rational epsilon-closeness expressed without a primitive absolute value. -/
def qClose (eps x y : QBOMA) : Prop :=
  qLE (qNeg eps) (qAdd x (qNeg y)) ∧
  qLE (qAdd x (qNeg y)) eps

end BOMA.R.Gateway001

/- Shared Q-density gateway for real completion routes. -/
namespace BOMA.R.Gateway001

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001

/-- Strict order is preserved by a common additive translate. -/
theorem qlt_add_right {x y : QBOMA} (hxy : qLT x y) (c : QBOMA) :
    qLT (qAdd x c) (qAdd y c) := by
  refine ⟨qadd_mono_right hxy.1 c, ?_⟩
  intro heq
  have hleft : qAdd c x = qAdd c y := by
    calc
      qAdd c x = qAdd x c := qAdd_comm c x
      _ = qAdd y c := heq
      _ = qAdd c y := qAdd_comm y c
  exact hxy.2 (qAdd_left_cancel hleft)

/-- Multiplicative cancellation by a nonzero left factor, derived from the
constructive unique-inverse witness interface. -/
theorem qMul_left_cancel_nonzero {a b c : QBOMA}
    (ha : a ≠ qZero) (h : qMul a b = qMul a c) : b = c := by
  rcases q_inverse_exists a ha with ⟨r, hr⟩
  unfold QInvRel at hr
  calc
    b = qMul qOne b := (qMul_one_left b).symm
    _ = qMul (qMul a r) b := congrArg (fun t => qMul t b) hr.symm
    _ = qMul r (qMul a b) := by
      calc
        qMul (qMul a r) b = qMul a (qMul r b) := qMul_assoc a r b
        _ = qMul a (qMul b r) := congrArg (fun t => qMul a t) (qMul_comm r b)
        _ = qMul (qMul a b) r := (qMul_assoc a b r).symm
        _ = qMul r (qMul a b) := qMul_comm _ _
    _ = qMul r (qMul a c) := congrArg (fun t => qMul r t) h
    _ = qMul (qMul a r) c := by
      calc
        qMul r (qMul a c) = qMul (qMul r a) c := (qMul_assoc r a c).symm
        _ = qMul (qMul a r) c := congrArg (fun t => qMul t c) (qMul_comm r a)
    _ = qMul qOne c := congrArg (fun t => qMul t c) hr
    _ = c := qMul_one_left c

/-- Product of two nonzero rationals is nonzero. -/
theorem qMul_ne_zero {a b : QBOMA} (ha : a ≠ qZero) (hb : b ≠ qZero) :
    qMul a b ≠ qZero := by
  intro hab
  have hzero : qMul a b = qMul a qZero := by
    rw [qMul_zero_right]
    exact hab
  exact hb (qMul_left_cancel_nonzero ha hzero)

/-- Strict multiplication monotonicity by a positive left factor. -/
theorem qlt_mul_left_positive {x y c : QBOMA}
    (hxy : qLT x y) (hc : QPositive c) :
    qLT (qMul c x) (qMul c y) := by
  refine ⟨qmul_mono_left_nonneg hxy.1 hc.1, ?_⟩
  intro heq
  exact hxy.2 (qMul_left_cancel_nonzero hc.2 heq)

/-- Rational two. -/
def qTwo : QBOMA := qAdd qOne qOne

/-- Zero is strictly below one. -/
theorem qzero_lt_one : qLT qZero qOne :=
  ⟨qzero_le_one, fun h => qone_ne_zero h.symm⟩

/-- One is strictly below two. -/
theorem qone_lt_two : qLT qOne qTwo := by
  have h := qlt_add_right qzero_lt_one qOne
  change qLT (qAdd qZero qOne) qTwo at h
  rw [qAdd_zero_left] at h
  exact h

/-- Two is positive and nonzero. -/
theorem qtwo_positive : QPositive qTwo := by
  have h02 : qLT qZero qTwo := qlt_trans qzero_lt_one qone_lt_two
  exact ⟨h02.1, fun h => h02.2 h.symm⟩

/-- There exists a positive rational half strictly between zero and one, obtained
from the already-accepted unique inverse witness for two. -/
theorem rational_half_exists :
    ∃ h : QBOMA, QInvRel qTwo h ∧ qLT qZero h ∧ qLT h qOne := by
  rcases q_inverse_exists qTwo qtwo_positive.2 with ⟨h, hh⟩
  have hpos : QPositive h := inverse_of_positive_is_positive qtwo_positive hh
  have h0h : qLT qZero h := ⟨hpos.1, fun hz => hpos.2 hz.symm⟩
  have hsum : qAdd h h = qOne := by
    unfold QInvRel at hh
    calc
      qAdd h h = qAdd (qMul qOne h) h :=
        congrArg (fun t => qAdd t h) (qMul_one_left h).symm
      _ = qAdd (qMul qOne h) (qMul qOne h) :=
        congrArg (fun t => qAdd (qMul qOne h) t) (qMul_one_left h).symm
      _ = qMul (qAdd qOne qOne) h := (qMul_add_left qOne qOne h).symm
      _ = qMul qTwo h := rfl
      _ = qOne := hh
  have hlt1 : qLT h qOne := by
    have ht := qlt_add_right h0h h
    rw [qAdd_zero_left, hsum] at ht
    exact ht
  exact ⟨h, hh, h0h, hlt1⟩

/-- If x<y then the ordered-field difference y-x is positive. -/
theorem positive_difference_of_lt {x y : QBOMA} (hxy : qLT x y) :
    QPositive (qAdd y (qNeg x)) := by
  constructor
  · exact (qle_iff_nonneg_difference x y).1 hxy.1
  · intro hd0
    have hleft : qAdd (qNeg x) y = qZero := by
      calc
        qAdd (qNeg x) y = qAdd y (qNeg x) := qAdd_comm _ _
        _ = qZero := hd0
    have hright : qAdd (qNeg x) x = qZero := qAdd_neg_left x
    have hyx : y = x := qAdd_left_cancel (hleft.trans hright.symm)
    exact hxy.2 hyx.symm

/-- The accepted rational order is internally dense. This theorem is a shared
pre-real gateway and does not depend on either the Dedekind or Cauchy carrier. -/
theorem rational_order_dense {x y : QBOMA} (hxy : qLT x y) :
    ∃ m : QBOMA, qLT x m ∧ qLT m y := by
  rcases rational_half_exists with ⟨half, hhalfInv, h0half, hhalf1⟩
  let d := qAdd y (qNeg x)
  have hdpos : QPositive d := positive_difference_of_lt hxy
  let p := qMul d half
  have hhalfPos : QPositive half :=
    ⟨h0half.1, fun h => h0half.2 h.symm⟩
  have hpNonNeg : qLE qZero p := by
    unfold p
    exact qmul_nonneg hdpos.1 hhalfPos.1
  have hpNe : p ≠ qZero := by
    unfold p
    exact qMul_ne_zero hdpos.2 hhalfPos.2
  have h0p : qLT qZero p := ⟨hpNonNeg, fun h => hpNe h.symm⟩
  have hpd : qLT p d := by
    have hm := qlt_mul_left_positive hhalf1 hdpos
    unfold p
    rw [qMul_one_right] at hm
    exact hm
  let m := qAdd x p
  have hxm : qLT x m := by
    have ht := qlt_add_right h0p x
    change qLT (qAdd qZero x) (qAdd p x) at ht
    rw [qAdd_zero_left, qAdd_comm p x] at ht
    exact ht
  have hmy : qLT m y := by
    have ht := qlt_add_right hpd x
    have hdx : qAdd d x = y := by
      unfold d
      calc
        qAdd (qAdd y (qNeg x)) x = qAdd y (qAdd (qNeg x) x) :=
          qAdd_assoc y (qNeg x) x
        _ = qAdd y qZero := by rw [qAdd_neg_left]
        _ = y := qAdd_zero_right y
    change qLT (qAdd p x) (qAdd d x) at ht
    rw [qAdd_comm p x, hdx] at ht
    exact ht
  exact ⟨m, hxm, hmy⟩

end BOMA.R.Gateway001

/- Representation-only Dedekind route probe. No real carrier identity is selected here. -/
namespace BOMA.R.DedekindProbe001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001

/-- Lower Dedekind-cut syntax over accepted QBOMA.
The no-greatest-element requirement is expressed by strict rational order. -/
structure LowerCut where
  lower : QBOMA → Prop
  nonempty : ∃ q : QBOMA, lower q
  proper : ∃ q : QBOMA, ¬ lower q
  downward : ∀ {a b : QBOMA}, lower b → qLE a b → lower a
  rounded : ∀ {a : QBOMA}, lower a → ∃ b : QBOMA, lower b ∧ qLT a b

/-- Extensional representation relation for cut syntax.
This is deliberately external: the probe does not assume function/proposition
extensionality or select raw structure equality as real identity. -/
def CutEquiv (A B : LowerCut) : Prop :=
  ∀ q : QBOMA, A.lower q ↔ B.lower q

theorem cutEquiv_refl (A : LowerCut) : CutEquiv A A := by
  intro q
  exact Iff.rfl

theorem cutEquiv_symm {A B : LowerCut} (h : CutEquiv A B) : CutEquiv B A := by
  intro q
  exact (h q).symm

theorem cutEquiv_trans {A B C : LowerCut}
    (hAB : CutEquiv A B) (hBC : CutEquiv B C) : CutEquiv A C := by
  intro q
  exact Iff.trans (hAB q) (hBC q)

end BOMA.R.DedekindProbe001

/- Deeper Dedekind-route probe: principal rational lower cuts. -/
namespace BOMA.R.DedekindProbe001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001

/-- A concrete rational predecessor q-1 lies strictly below q. -/
theorem q_minus_one_lt (q : QBOMA) : qLT (qAdd q (qNeg qOne)) q := by
  have ht := qlt_add_right qzero_lt_one (qAdd q (qNeg qOne))
  have hright : qAdd qOne (qAdd q (qNeg qOne)) = q := by
    calc
      qAdd qOne (qAdd q (qNeg qOne)) =
          qAdd qOne (qAdd (qNeg qOne) q) :=
        congrArg (fun t => qAdd qOne t) (qAdd_comm q (qNeg qOne))
      _ = qAdd (qAdd qOne (qNeg qOne)) q :=
        (qAdd_assoc qOne (qNeg qOne) q).symm
      _ = qAdd qZero q := by rw [qAdd_neg_right]
      _ = q := qAdd_zero_left q
  rw [qAdd_zero_left, hright] at ht
  exact ht

/-- Principal lower cut associated with an accepted rational q. -/
def principalCut (q : QBOMA) : LowerCut where
  lower := fun a => qLT a q
  nonempty := ⟨qAdd q (qNeg qOne), q_minus_one_lt q⟩
  proper := ⟨q, qlt_irrefl q⟩
  downward := by
    intro a b hb hab
    refine ⟨qle_trans hab hb.1, ?_⟩
    intro haq
    rw [haq] at hab
    have hbq : b = q := qle_antisymm hb.1 hab
    exact hb.2 hbq
  rounded := by
    intro a ha
    rcases rational_order_dense ha with ⟨b, hab, hbq⟩
    exact ⟨b, hbq, hab⟩

/-- Principal-cut representation preserves rational equality. -/
theorem principalCut_preserves {q r : QBOMA} (h : q = r) :
    CutEquiv (principalCut q) (principalCut r) := by
  cases h
  exact cutEquiv_refl _

/-- Principal-cut representation reflects rational equality at the external
CutEquiv layer. This uses internal Q density, making the dependency explicit. -/
theorem principalCut_reflects {q r : QBOMA}
    (h : CutEquiv (principalCut q) (principalCut r)) : q = r := by
  rcases qlt_trichotomy q r with hqr | heq | hrq
  · rcases rational_order_dense hqr with ⟨m, hqm, hmr⟩
    have hmR : (principalCut r).lower m := hmr
    have hmQ : (principalCut q).lower m := (h m).2 hmR
    exact False.elim ((qlt_asymm hqm) hmQ)
  · exact heq
  · rcases rational_order_dense hrq with ⟨m, hrm, hmq⟩
    have hmQ : (principalCut q).lower m := hmq
    have hmR : (principalCut r).lower m := (h m).1 hmQ
    exact False.elim ((qlt_asymm hrm) hmR)

/-- Inclusion relation restricted to principal rational cuts. -/
def PrincipalLE (q r : QBOMA) : Prop :=
  ∀ a : QBOMA, (principalCut q).lower a → (principalCut r).lower a

/-- Principal-cut inclusion is exactly the accepted rational non-strict order.
The forward proof reuses the single explicit trichotomy gateway instead of
introducing a second implicit proposition-decidability split. -/
theorem principalLE_iff_qLE (q r : QBOMA) : PrincipalLE q r ↔ qLE q r := by
  constructor
  · intro hInc
    rcases qlt_trichotomy q r with hqr | heq | hrq
    · exact hqr.1
    · rw [heq]
      exact qle_refl r
    · rcases rational_order_dense hrq with ⟨m, hrm, hmq⟩
      have hmQ : (principalCut q).lower m := hmq
      have hmR : (principalCut r).lower m := hInc m hmQ
      exact False.elim ((qlt_asymm hrm) hmR)
  · intro hqr a haq
    refine ⟨qle_trans haq.1 hqr, ?_⟩
    intro har
    have hqa : qLE q a := by
      rw [har]
      exact hqr
    have hqaEq : q = a := qle_antisymm hqa haq.1
    exact haq.2 hqaEq.symm

end BOMA.R.DedekindProbe001

/- Dedekind-route completeness probe: supremum by union of lower cuts. -/
namespace BOMA.R.DedekindProbe001

open BOMA.Q.Quotient001

/-- Inclusion order between lower-cut representations. -/
def CutLE (A B : LowerCut) : Prop :=
  ∀ q : QBOMA, A.lower q → B.lower q

@[simp] theorem cutLE_refl (A : LowerCut) : CutLE A A := by
  intro q hq
  exact hq

theorem cutLE_trans {A B C : LowerCut}
    (hAB : CutLE A B) (hBC : CutLE B C) : CutLE A C := by
  intro q hq
  exact hBC q (hAB q hq)

/-- A family of lower cuts is bounded above by U when every member is included in U. -/
def FamilyBoundedAbove (F : LowerCut → Prop) (U : LowerCut) : Prop :=
  ∀ A : LowerCut, F A → CutLE A U

/-- Union cut of a nonempty family with an explicit upper bound. -/
def supCut
    (F : LowerCut → Prop)
    (hne : ∃ A : LowerCut, F A)
    (U : LowerCut)
    (hUB : FamilyBoundedAbove F U) : LowerCut where
  lower := fun q => ∃ A : LowerCut, F A ∧ A.lower q
  nonempty := by
    rcases hne with ⟨A, hFA⟩
    rcases A.nonempty with ⟨q, hq⟩
    exact ⟨q, A, hFA, hq⟩
  proper := by
    rcases U.proper with ⟨q, hqU⟩
    refine ⟨q, ?_⟩
    intro hqSup
    rcases hqSup with ⟨A, hFA, hqA⟩
    exact hqU (hUB A hFA q hqA)
  downward := by
    intro a b hb hab
    rcases hb with ⟨A, hFA, hbA⟩
    exact ⟨A, hFA, A.downward hbA hab⟩
  rounded := by
    intro a ha
    rcases ha with ⟨A, hFA, haA⟩
    rcases A.rounded haA with ⟨b, hbA, hab⟩
    exact ⟨b, ⟨A, hFA, hbA⟩, hab⟩

/-- Every family member lies below the union cut. -/
theorem member_le_supCut
    (F : LowerCut → Prop)
    (hne : ∃ A : LowerCut, F A)
    (U : LowerCut)
    (hUB : FamilyBoundedAbove F U)
    {A : LowerCut} (hFA : F A) :
    CutLE A (supCut F hne U hUB) := by
  intro q hq
  exact ⟨A, hFA, hq⟩

/-- The union cut is below every common upper bound, hence is least. -/
theorem supCut_le_of_upper
    (F : LowerCut → Prop)
    (hne : ∃ A : LowerCut, F A)
    (U : LowerCut)
    (hUB : FamilyBoundedAbove F U)
    (B : LowerCut)
    (hB : FamilyBoundedAbove F B) :
    CutLE (supCut F hne U hUB) B := by
  intro q hq
  rcases hq with ⟨A, hFA, hqA⟩
  exact hB A hFA q hqA

/-- Representation-level least-upper-bound certificate. -/
theorem supCut_is_lub
    (F : LowerCut → Prop)
    (hne : ∃ A : LowerCut, F A)
    (U : LowerCut)
    (hUB : FamilyBoundedAbove F U) :
    (∀ A : LowerCut, F A → CutLE A (supCut F hne U hUB)) ∧
    (∀ B : LowerCut, FamilyBoundedAbove F B → CutLE (supCut F hne U hUB) B) := by
  constructor
  · intro A hFA
    exact member_le_supCut F hne U hUB hFA
  · intro B hB
    exact supCut_le_of_upper F hne U hUB B hB

end BOMA.R.DedekindProbe001

/- Formal identity probe for the selected Dedekind route. -/
namespace BOMA.R.DedekindQuotient001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.DedekindProbe001

/-- Extensional cut identity packaged as a formal Setoid. -/
def cutSetoid : Setoid LowerCut where
  r := CutEquiv
  iseqv := ⟨cutEquiv_refl, @cutEquiv_symm, @cutEquiv_trans⟩

/-- Candidate Stage-One real carrier under identity Candidate A. -/
def RBOMA : Type := Quotient cutSetoid

/-- Injection of a lower-cut representation into the formal carrier. -/
def rmk (A : LowerCut) : RBOMA := Quotient.mk cutSetoid A

/-- Extensional-equivalent cuts become formally equal. -/
theorem rmk_sound {A B : LowerCut} (h : CutEquiv A B) : rmk A = rmk B :=
  Quotient.sound h

/-- Formal equality of explicit representatives is exactly CutEquiv. -/
theorem rmk_eq_iff {A B : LowerCut} : rmk A = rmk B ↔ CutEquiv A B := by
  constructor
  · intro h
    exact Quotient.exact h
  · exact rmk_sound

/-- Candidate rational embedding into the quotient real carrier. -/
def rOfQ (q : QBOMA) : RBOMA := rmk (principalCut q)

/-- The principal-cut rational embedding remains injective after quotienting. -/
theorem rOfQ_injective {q r : QBOMA} (h : rOfQ q = rOfQ r) : q = r := by
  apply principalCut_reflects
  exact Quotient.exact h

/-- Inclusion of cuts respects extensional identity in both endpoints. -/
theorem cutLE_respects {A A' B B' : LowerCut}
    (hA : CutEquiv A A') (hB : CutEquiv B B')
    (hLE : CutLE A B) : CutLE A' B' := by
  intro q hqA'
  have hqA : A.lower q := (hA q).mpr hqA'
  have hqB : B.lower q := hLE q hqA
  exact (hB q).mp hqB

/-- Quotient order without proposition extensionality: endpoints are witnessed
by explicit cut representatives related by inclusion. -/
def rLE (x y : RBOMA) : Prop :=
  ∃ A : LowerCut, ∃ B : LowerCut,
    x = rmk A ∧ y = rmk B ∧ CutLE A B

/-- On explicit representatives, formal real order is exactly cut inclusion. -/
theorem rLE_mk_iff (A B : LowerCut) :
    rLE (rmk A) (rmk B) ↔ CutLE A B := by
  constructor
  · rintro ⟨A', B', hAeq, hBeq, hLE⟩
    have hA : CutEquiv A A' := (rmk_eq_iff).mp hAeq
    have hB : CutEquiv B B' := (rmk_eq_iff).mp hBeq
    exact cutLE_respects (cutEquiv_symm hA) (cutEquiv_symm hB) hLE
  · intro h
    exact ⟨A, B, rfl, rfl, h⟩

/-- The quotient rational embedding preserves and reflects accepted Q order.
The Iff chain is composed directly rather than rewriting one proposition by an
Iff theorem, keeping proposition extensionality out of this proof term. -/
theorem rOfQ_order (q r : QBOMA) :
    rLE (rOfQ q) (rOfQ r) ↔ qLE q r := by
  change rLE (rmk (principalCut q)) (rmk (principalCut r)) ↔ qLE q r
  have hPrincipal :
      CutLE (principalCut q) (principalCut r) ↔ qLE q r := by
    change PrincipalLE q r ↔ qLE q r
    exact principalLE_iff_qLE q r
  exact (rLE_mk_iff (principalCut q) (principalCut r)).trans hPrincipal

end BOMA.R.DedekindQuotient001

/- Constructive core of the selected Dedekind quotient order. -/
namespace BOMA.R.DedekindOrderConstructive001

open BOMA.Q.Quotient001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001

/-- Opposite cut inclusions give extensional cut identity constructively. -/
theorem cutLE_antisymm_equiv {A B : LowerCut}
    (hAB : CutLE A B) (hBA : CutLE B A) : CutEquiv A B := by
  intro q
  constructor
  · intro hq
    exact hAB q hq
  · intro hq
    exact hBA q hq

/-- Reflexivity of quotient cut order. -/
theorem rLE_refl (x : RBOMA) : rLE x x := by
  refine Quotient.inductionOn x ?_
  intro A
  exact (rLE_mk_iff A A).2 (cutLE_refl A)

/-- Transitivity of quotient cut order. -/
theorem rLE_trans {x y z : RBOMA}
    (hxy : rLE x y) (hyz : rLE y z) : rLE x z := by
  refine Quotient.inductionOn x ?_ hxy hyz
  intro A hAy hYz
  refine Quotient.inductionOn y ?_ hAy hYz
  intro B hAB hBz
  refine Quotient.inductionOn z ?_ hAB hBz
  intro C hAB' hBC'
  apply (rLE_mk_iff A C).2
  exact cutLE_trans ((rLE_mk_iff A B).1 hAB') ((rLE_mk_iff B C).1 hBC')

/-- Antisymmetry of quotient cut order. -/
theorem rLE_antisymm {x y : RBOMA}
    (hxy : rLE x y) (hyx : rLE y x) : x = y := by
  refine Quotient.inductionOn x ?_ hxy hyx
  intro A hAy hYA
  refine Quotient.inductionOn y ?_ hAy hYA
  intro B hAB hBA
  exact rmk_sound (cutLE_antisymm_equiv
    ((rLE_mk_iff A B).1 hAB) ((rLE_mk_iff B A).1 hBA))

/-- Exact isolated interface needed for disjunctive totality. -/
def CutComparability : Prop :=
  ∀ A B : LowerCut, CutLE A B ∨ CutLE B A

/-- Totality follows from the isolated comparability interface, without using
Classical inside this theorem. -/
theorem rLE_total_of_cutComparability
    (hComp : CutComparability) (x y : RBOMA) : rLE x y ∨ rLE y x := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  rcases hComp A B with hAB | hBA
  · exact Or.inl ((rLE_mk_iff A B).2 hAB)
  · exact Or.inr ((rLE_mk_iff B A).2 hBA)

end BOMA.R.DedekindOrderConstructive001

/- Isolated classical witness for total comparability of Dedekind lower cuts. -/
namespace BOMA.R.DedekindOrderClassical001

open BOMA.Q.Order001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001

/-- Classical excluded middle supplies the isolated CutComparability interface
for lower sets of the accepted linearly ordered rational carrier. The classical
commitment is explicit in the two calls to `Classical.em`. -/
theorem cutComparability_classical : CutComparability := by
  intro A B
  cases Classical.em (CutLE A B) with
  | inl hAB =>
      exact Or.inl hAB
  | inr hNotAB =>
      apply Or.inr
      intro q hqB
      cases Classical.em (A.lower q) with
      | inl hqA =>
          exact hqA
      | inr hNotAq =>
          exfalso
          apply hNotAB
          intro r hrA
          rcases qle_total r q with hrq | hqr
          · exact B.downward hqB hrq
          · exact False.elim (hNotAq (A.downward hrA hqr))

/-- Stage-One totality candidate obtained from the localized classical witness. -/
theorem rLE_total_classical (x y : RBOMA) : rLE x y ∨ rLE y x :=
  rLE_total_of_cutComparability cutComparability_classical x y

end BOMA.R.DedekindOrderClassical001

/- Addition on selected Dedekind lower cuts and the formal RBOMA quotient. -/
namespace BOMA.R.DedekindAddition001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001

/-- Mixed non-strict/strict transitivity on accepted Q. -/
theorem qle_lt_trans {x y z : QBOMA} (hxy : qLE x y) (hyz : qLT y z) : qLT x z := by
  refine ⟨qle_trans hxy hyz.1, ?_⟩
  intro hxz
  have hzy : qLE z y := by
    have h := hxy
    rw [hxz] at h
    exact h
  have hyzEq : y = z := qle_antisymm hyz.1 hzy
  exact hyz.2 hyzEq

/-- Strict/non-strict transitivity on accepted Q. -/
theorem qlt_le_trans {x y z : QBOMA} (hxy : qLT x y) (hyz : qLE y z) : qLT x z := by
  refine ⟨qle_trans hxy.1 hyz, ?_⟩
  intro hxz
  have hyx : qLE y x := by
    have h := hyz
    rw [← hxz] at h
    exact h
  have hxyEq : x = y := qle_antisymm hxy.1 hyx
  exact hxy.2 hxyEq

/-- Addition is monotone in both accepted rational arguments. -/
theorem qadd_mono {a a' b b' : QBOMA}
    (ha : qLE a a') (hb : qLE b b') :
    qLE (qAdd a b) (qAdd a' b') := by
  have h1 : qLE (qAdd a b) (qAdd a' b) := qadd_mono_right ha b
  have h2raw : qLE (qAdd b a') (qAdd b' a') := qadd_mono_right hb a'
  have h2 : qLE (qAdd a' b) (qAdd a' b') := by
    rw [qAdd_comm a' b, qAdd_comm a' b']
    exact h2raw
  exact qle_trans h1 h2

/-- Raw Dedekind sum: q lies below A+B when it lies strictly below a+b for
some a in A and b in B. -/
def cutAdd (A B : LowerCut) : LowerCut where
  lower := fun q =>
    ∃ a b : QBOMA, A.lower a ∧ B.lower b ∧ qLT q (qAdd a b)
  nonempty := by
    rcases A.nonempty with ⟨a, ha⟩
    rcases B.nonempty with ⟨b, hb⟩
    let s := qAdd a b
    let q := qAdd s (qNeg qOne)
    refine ⟨q, a, b, ha, hb, ?_⟩
    change qLT (qAdd s (qNeg qOne)) s
    exact BOMA.R.DedekindProbe001.q_minus_one_lt s
  proper := by
    rcases A.proper with ⟨uA, huA⟩
    rcases B.proper with ⟨uB, huB⟩
    refine ⟨qAdd uA uB, ?_⟩
    intro hsum
    rcases hsum with ⟨a, b, ha, hb, hstrict⟩
    have haU : qLE a uA := by
      rcases qle_total a uA with h | h
      · exact h
      · exact False.elim (huA (A.downward ha h))
    have hbU : qLE b uB := by
      rcases qle_total b uB with h | h
      · exact h
      · exact False.elim (huB (B.downward hb h))
    have habU : qLE (qAdd a b) (qAdd uA uB) := qadd_mono haU hbU
    have heq : qAdd uA uB = qAdd a b := qle_antisymm hstrict.1 habU
    exact hstrict.2 heq
  downward := by
    intro p q hq hpq
    rcases hq with ⟨a, b, ha, hb, hqsum⟩
    exact ⟨a, b, ha, hb, qle_lt_trans hpq hqsum⟩
  rounded := by
    intro q hq
    rcases hq with ⟨a, b, ha, hb, hqsum⟩
    rcases rational_order_dense hqsum with ⟨m, hqm, hmsum⟩
    exact ⟨m, ⟨a, b, ha, hb, hmsum⟩, hqm⟩

/-- Raw cut addition respects extensional identity in both inputs. -/
theorem cutAdd_respects {A A' B B' : LowerCut}
    (hA : CutEquiv A A') (hB : CutEquiv B B') :
    CutEquiv (cutAdd A B) (cutAdd A' B') := by
  intro q
  constructor
  · intro hq
    rcases hq with ⟨a, b, ha, hb, hlt⟩
    exact ⟨a, b, (hA a).mp ha, (hB b).mp hb, hlt⟩
  · intro hq
    rcases hq with ⟨a, b, ha, hb, hlt⟩
    exact ⟨a, b, (hA a).mpr ha, (hB b).mpr hb, hlt⟩

/-- Formal real addition lifted through the verified CutEquiv respect theorem. -/
def rAdd : RBOMA → RBOMA → RBOMA :=
  Quotient.lift₂
    (fun A B => rmk (cutAdd A B))
    (fun _ _ _ _ hA hB => rmk_sound (cutAdd_respects hA hB))

@[simp] theorem rAdd_mk (A B : LowerCut) :
    rAdd (rmk A) (rmk B) = rmk (cutAdd A B) := rfl

/-- Candidate real zero and one inherited from the faithful rational embedding. -/
def rZero : RBOMA := rOfQ qZero
def rOne : RBOMA := rOfQ qOne

end BOMA.R.DedekindAddition001

/- Rational embedding preservation for selected Dedekind real addition. -/
namespace BOMA.R.DedekindAdditionEmbedding001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001

/-- Translating x < q+r by -r yields x-r < q. -/
theorem qlt_sub_right_of_lt_add {x q r : QBOMA}
    (h : qLT x (qAdd q r)) :
    qLT (qAdd x (qNeg r)) q := by
  have ht := qlt_add_right h (qNeg r)
  have hright : qAdd (qAdd q r) (qNeg r) = q := by
    calc
      qAdd (qAdd q r) (qNeg r) = qAdd q (qAdd r (qNeg r)) :=
        qAdd_assoc q r (qNeg r)
      _ = qAdd q qZero := by rw [qAdd_neg_right]
      _ = q := qAdd_zero_right q
  rw [hright] at ht
  exact ht

/-- Translating x-r < a back by r yields x < a+r. -/
theorem qlt_add_back_right {x a r : QBOMA}
    (h : qLT (qAdd x (qNeg r)) a) :
    qLT x (qAdd a r) := by
  have ht := qlt_add_right h r
  have hleft : qAdd (qAdd x (qNeg r)) r = x := by
    calc
      qAdd (qAdd x (qNeg r)) r = qAdd x (qAdd (qNeg r) r) :=
        qAdd_assoc x (qNeg r) r
      _ = qAdd x qZero := by rw [qAdd_neg_left]
      _ = x := qAdd_zero_right x
  rw [hleft] at ht
  exact ht

/-- Translating x < a+r by -a yields x-a < r. -/
theorem qlt_sub_left_of_lt_add {x a r : QBOMA}
    (h : qLT x (qAdd a r)) :
    qLT (qAdd x (qNeg a)) r := by
  have ht := qlt_add_right h (qNeg a)
  have hright : qAdd (qAdd a r) (qNeg a) = r := by
    calc
      qAdd (qAdd a r) (qNeg a) = qAdd a (qAdd r (qNeg a)) :=
        qAdd_assoc a r (qNeg a)
      _ = qAdd a (qAdd (qNeg a) r) :=
        congrArg (fun t => qAdd a t) (qAdd_comm r (qNeg a))
      _ = qAdd (qAdd a (qNeg a)) r :=
        (qAdd_assoc a (qNeg a) r).symm
      _ = qAdd qZero r := by rw [qAdd_neg_right]
      _ = r := qAdd_zero_left r
  rw [hright] at ht
  exact ht

/-- Translating x-a < b back by a yields x < a+b. -/
theorem qlt_add_back_left {x a b : QBOMA}
    (h : qLT (qAdd x (qNeg a)) b) :
    qLT x (qAdd a b) := by
  have ht := qlt_add_right h a
  have hleft : qAdd (qAdd x (qNeg a)) a = x := by
    calc
      qAdd (qAdd x (qNeg a)) a = qAdd x (qAdd (qNeg a) a) :=
        qAdd_assoc x (qNeg a) a
      _ = qAdd x qZero := by rw [qAdd_neg_left]
      _ = x := qAdd_zero_right x
  have hright : qAdd b a = qAdd a b := qAdd_comm b a
  rw [hleft, hright] at ht
  exact ht

/-- The Dedekind sum of two principal rational cuts is extensionally the
principal cut of the accepted rational sum. -/
theorem cutAdd_principal (q r : QBOMA) :
    CutEquiv
      (cutAdd (principalCut q) (principalCut r))
      (principalCut (qAdd q r)) := by
  intro x
  constructor
  · intro hx
    rcases hx with ⟨a, b, ha, hb, hxab⟩
    have hab : qLE (qAdd a b) (qAdd q r) :=
      qadd_mono ha.1 hb.1
    exact qlt_le_trans hxab hab
  · intro hx
    have hxq : qLT (qAdd x (qNeg r)) q :=
      qlt_sub_right_of_lt_add hx
    rcases rational_order_dense hxq with ⟨a, hxa, haq⟩
    have hxar : qLT x (qAdd a r) := qlt_add_back_right hxa
    have hxr : qLT (qAdd x (qNeg a)) r :=
      qlt_sub_left_of_lt_add hxar
    rcases rational_order_dense hxr with ⟨b, hxb, hbr⟩
    have hxab : qLT x (qAdd a b) := qlt_add_back_left hxb
    exact ⟨a, b, haq, hbr, hxab⟩

/-- The accepted rational embedding into RBOMA preserves addition. -/
theorem rOfQ_add (q r : QBOMA) :
    rAdd (rOfQ q) (rOfQ r) = rOfQ (qAdd q r) := by
  change
    rmk (cutAdd (principalCut q) (principalCut r)) =
    rmk (principalCut (qAdd q r))
  exact rmk_sound (cutAdd_principal q r)

/-- The real zero spelling agrees with the rational embedding of qZero. -/
@[simp] theorem rZero_eq_rOfQ_zero : rZero = rOfQ qZero := rfl

/-- The real one spelling agrees with the rational embedding of qOne. -/
@[simp] theorem rOne_eq_rOfQ_one : rOne = rOfQ qOne := rfl

end BOMA.R.DedekindAdditionEmbedding001

/- Additive laws for the selected Dedekind real operation, before negation. -/
namespace BOMA.R.DedekindAdditionLaws001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionEmbedding001

/-- Raw Dedekind addition is commutative up to extensional cut identity. -/
theorem cutAdd_comm_equiv (A B : LowerCut) :
    CutEquiv (cutAdd A B) (cutAdd B A) := by
  intro x
  constructor
  · rintro ⟨a, b, ha, hb, hxab⟩
    have hxba : qLT x (qAdd b a) := by
      rw [qAdd_comm b a]
      exact hxab
    exact ⟨b, a, hb, ha, hxba⟩
  · rintro ⟨b, a, hb, ha, hxba⟩
    have hxab : qLT x (qAdd a b) := by
      rw [qAdd_comm a b]
      exact hxba
    exact ⟨a, b, ha, hb, hxab⟩

/-- The principal zero cut is a left identity for raw Dedekind addition. -/
theorem cutAdd_zero_left_equiv (A : LowerCut) :
    CutEquiv (cutAdd (principalCut qZero) A) A := by
  intro x
  constructor
  · rintro ⟨a, b, ha0, hb, hxab⟩
    have hab : qLE (qAdd a b) b := by
      have hmono := qadd_mono ha0.1 (qle_refl b)
      rw [qAdd_zero_left] at hmono
      exact hmono
    have hxb : qLT x b := qlt_le_trans hxab hab
    exact A.downward hb hxb.1
  · intro hxA
    rcases A.rounded hxA with ⟨b, hbA, hxb⟩
    have hx0 : qLT (qAdd x (qNeg b)) qZero := by
      have ht : qLT (qAdd x (qNeg b)) qZero := by
        have hz : qAdd qZero b = b := qAdd_zero_left b
        have h0 := qlt_sub_right_of_lt_add (q := qZero) (r := b) (by
          rw [hz]
          exact hxb)
        exact h0
      exact ht
    rcases rational_order_dense hx0 with ⟨a, hxa, ha0⟩
    have hxab : qLT x (qAdd a b) := qlt_add_back_right hxa
    exact ⟨a, b, ha0, hbA, hxab⟩

/-- The principal zero cut is also a right identity. -/
theorem cutAdd_zero_right_equiv (A : LowerCut) :
    CutEquiv (cutAdd A (principalCut qZero)) A := by
  exact cutEquiv_trans
    (cutAdd_comm_equiv A (principalCut qZero))
    (cutAdd_zero_left_equiv A)

/-- Raw Dedekind addition is associative up to extensional cut identity. -/
theorem cutAdd_assoc_equiv (A B C : LowerCut) :
    CutEquiv (cutAdd (cutAdd A B) C) (cutAdd A (cutAdd B C)) := by
  intro x
  constructor
  · rintro ⟨s, c, hsAB, hc, hxsc⟩
    rcases hsAB with ⟨a, b, ha, hb, hsab⟩
    have hscABC : qLT (qAdd s c) (qAdd a (qAdd b c)) := by
      have ht := qlt_add_right hsab c
      rw [qAdd_assoc a b c] at ht
      exact ht
    have hxABC : qLT x (qAdd a (qAdd b c)) := qlt_trans hxsc hscABC
    have hxbc : qLT (qAdd x (qNeg a)) (qAdd b c) :=
      qlt_sub_left_of_lt_add hxABC
    rcases rational_order_dense hxbc with ⟨t, hxt, htbc⟩
    have htBC : (cutAdd B C).lower t := ⟨b, c, hb, hc, htbc⟩
    have hxat : qLT x (qAdd a t) := qlt_add_back_left hxt
    exact ⟨a, t, ha, htBC, hxat⟩
  · rintro ⟨a, t, ha, htBC, hxat⟩
    rcases htBC with ⟨b, c, hb, hc, htbc⟩
    have hatABC : qLT (qAdd a t) (qAdd a (qAdd b c)) := by
      have ht := qlt_add_right htbc a
      have hleft : qAdd t a = qAdd a t := qAdd_comm t a
      have hright : qAdd (qAdd b c) a = qAdd a (qAdd b c) :=
        qAdd_comm (qAdd b c) a
      rw [hleft, hright] at ht
      exact ht
    have hxABC : qLT x (qAdd a (qAdd b c)) := qlt_trans hxat hatABC
    have hxAssoc : qLT x (qAdd (qAdd a b) c) := by
      rw [qAdd_assoc a b c]
      exact hxABC
    have hxab : qLT (qAdd x (qNeg c)) (qAdd a b) :=
      qlt_sub_right_of_lt_add hxAssoc
    rcases rational_order_dense hxab with ⟨s, hxs, hsab⟩
    have hsAB : (cutAdd A B).lower s := ⟨a, b, ha, hb, hsab⟩
    have hxsc : qLT x (qAdd s c) := qlt_add_back_right hxs
    exact ⟨s, c, hsAB, hc, hxsc⟩

/-- Formal real addition is commutative. -/
theorem rAdd_comm (x y : RBOMA) : rAdd x y = rAdd y x := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  change rmk (cutAdd A B) = rmk (cutAdd B A)
  exact rmk_sound (cutAdd_comm_equiv A B)

/-- Formal real addition is associative. -/
theorem rAdd_assoc (x y z : RBOMA) :
    rAdd (rAdd x y) z = rAdd x (rAdd y z) := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  refine Quotient.inductionOn z ?_
  intro C
  change rmk (cutAdd (cutAdd A B) C) = rmk (cutAdd A (cutAdd B C))
  exact rmk_sound (cutAdd_assoc_equiv A B C)

/-- Formal real zero is a left additive identity. -/
@[simp] theorem rAdd_zero_left (x : RBOMA) : rAdd rZero x = x := by
  refine Quotient.inductionOn x ?_
  intro A
  change rmk (cutAdd (principalCut qZero) A) = rmk A
  exact rmk_sound (cutAdd_zero_left_equiv A)

/-- Formal real zero is a right additive identity. -/
@[simp] theorem rAdd_zero_right (x : RBOMA) : rAdd x rZero = x := by
  calc
    rAdd x rZero = rAdd rZero x := rAdd_comm x rZero
    _ = x := rAdd_zero_left x

end BOMA.R.DedekindAdditionLaws001

/- Additive compatibility of the selected Dedekind real order. -/
namespace BOMA.R.DedekindOrderAdditive001

open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001

/-- Cut addition is monotone under cut inclusion in both arguments. -/
theorem cutAdd_mono
    {A A' B B' : LowerCut}
    (hA : CutLE A A')
    (hB : CutLE B B') :
    CutLE (cutAdd A B) (cutAdd A' B') := by
  intro q hq
  rcases hq with ⟨a, b, ha, hb, hqab⟩
  exact ⟨a, b, hA a ha, hB b hb, hqab⟩

/-- Formal real addition is monotone in both arguments. -/
theorem rAdd_mono
    {x x' y y' : RBOMA}
    (hx : rLE x x')
    (hy : rLE y y') :
    rLE (rAdd x y) (rAdd x' y') := by
  rcases hx with ⟨A, A', hxA, hxA', hAA'⟩
  rcases hy with ⟨B, B', hyB, hyB', hBB'⟩
  refine ⟨cutAdd A B, cutAdd A' B', ?_, ?_, cutAdd_mono hAA' hBB'⟩
  · rw [hxA, hyB]
    rfl
  · rw [hxA', hyB']
    rfl

/-- Addition by a common right translate preserves order. -/
theorem rAdd_mono_right {x y : RBOMA}
    (hxy : rLE x y) (c : RBOMA) :
    rLE (rAdd x c) (rAdd y c) :=
  rAdd_mono hxy (rLE_refl c)

/-- Addition by a common left translate preserves order. -/
theorem rAdd_mono_left {x y : RBOMA}
    (hxy : rLE x y) (c : RBOMA) :
    rLE (rAdd c x) (rAdd c y) :=
  rAdd_mono (rLE_refl c) hxy

/-- The sum of two nonnegative reals is nonnegative. -/
theorem rAdd_nonneg
    {x y : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y) :
    rLE rZero (rAdd x y) := by
  have h := rAdd_mono h0x h0y
  rw [rAdd_zero_left] at h
  exact h

/-- The sum of two nonpositive reals is nonpositive. -/
theorem rAdd_nonpos
    {x y : RBOMA}
    (hx0 : rLE x rZero)
    (hy0 : rLE y rZero) :
    rLE (rAdd x y) rZero := by
  have h := rAdd_mono hx0 hy0
  rw [rAdd_zero_left] at h
  exact h

end BOMA.R.DedekindOrderAdditive001

/- Negation candidate on selected Dedekind lower cuts, before additive-inverse certification. -/
namespace BOMA.R.DedekindNegationCandidate001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001

/-- Rational negation is involutive on the accepted quotient carrier. -/
theorem qNeg_involutive (x : QBOMA) : qNeg (qNeg x) = x := by
  symm
  exact qAdd_inverse_unique
    (x := qNeg x)
    (y := x)
    (qAdd_neg_left x)

/-- Rational negation is injective. -/
theorem qNeg_injective {x y : QBOMA} (h : qNeg x = qNeg y) : x = y := by
  calc
    x = qNeg (qNeg x) := (qNeg_involutive x).symm
    _ = qNeg (qNeg y) := congrArg qNeg h
    _ = y := qNeg_involutive y

/-- Strict rational order reverses under negation. -/
theorem qneg_strict_reverses {x y : QBOMA} (h : qLT x y) :
    qLT (qNeg y) (qNeg x) := by
  refine ⟨qneg_reverses h.1, ?_⟩
  intro hneg
  have hyx : y = x := qNeg_injective hneg
  exact h.2 hyx.symm

/-- Dedekind negation candidate.
A rational q lies in -A when it lies strictly below -r for some rational r
outside A. This formulation does not require selecting a boundary point. -/
def cutNeg (A : LowerCut) : LowerCut where
  lower := fun q =>
    ∃ r : QBOMA, ¬ A.lower r ∧ qLT q (qNeg r)
  nonempty := by
    rcases A.proper with ⟨r, hr⟩
    let q := qAdd (qNeg r) (qNeg qOne)
    refine ⟨q, r, hr, ?_⟩
    change qLT (qAdd (qNeg r) (qNeg qOne)) (qNeg r)
    exact BOMA.R.DedekindProbe001.q_minus_one_lt (qNeg r)
  proper := by
    rcases A.nonempty with ⟨a, ha⟩
    refine ⟨qNeg a, ?_⟩
    rintro ⟨r, hrOut, hlt⟩
    have hraNeg : qLT (qNeg (qNeg r)) (qNeg (qNeg a)) :=
      qneg_strict_reverses hlt
    have hra : qLT r a := by
      rw [qNeg_involutive r, qNeg_involutive a] at hraNeg
      exact hraNeg
    exact hrOut (A.downward ha hra.1)
  downward := by
    intro p q hq hpq
    rcases hq with ⟨r, hrOut, hqr⟩
    exact ⟨r, hrOut, qle_lt_trans hpq hqr⟩
  rounded := by
    intro q hq
    rcases hq with ⟨r, hrOut, hqr⟩
    rcases rational_order_dense hqr with ⟨m, hqm, hmr⟩
    exact ⟨m, ⟨r, hrOut, hmr⟩, hqm⟩

/-- The negation candidate respects extensional cut identity. -/
theorem cutNeg_respects {A B : LowerCut} (hAB : CutEquiv A B) :
    CutEquiv (cutNeg A) (cutNeg B) := by
  intro q
  constructor
  · rintro ⟨r, hrA, hqr⟩
    have hrB : ¬ B.lower r := by
      intro hBr
      exact hrA ((hAB r).mpr hBr)
    exact ⟨r, hrB, hqr⟩
  · rintro ⟨r, hrB, hqr⟩
    have hrA : ¬ A.lower r := by
      intro hAr
      exact hrB ((hAB r).mp hAr)
    exact ⟨r, hrA, hqr⟩

/-- Formal negation candidate lifted to RBOMA after the respect theorem. -/
def rNeg : RBOMA → RBOMA :=
  Quotient.lift
    (fun A => rmk (cutNeg A))
    (fun _ _ h => rmk_sound (cutNeg_respects h))

@[simp] theorem rNeg_mk (A : LowerCut) :
    rNeg (rmk A) = rmk (cutNeg A) := rfl

/-- The negation of a principal rational cut is the principal cut of the
accepted rational negation. The order comparison is routed through the shared
trichotomy theorem, avoiding a second implicit `by_cases`/propDecidable site. -/
theorem cutNeg_principal (q : QBOMA) :
    CutEquiv (cutNeg (principalCut q)) (principalCut (qNeg q)) := by
  intro x
  constructor
  · rintro ⟨r, hrNot, hxr⟩
    have hqr : qLE q r := by
      rcases qlt_trichotomy q r with hlt | heq | hgt
      · exact hlt.1
      · rw [heq]
        exact qle_refl r
      · exact False.elim (hrNot hgt)
    have hneg : qLE (qNeg r) (qNeg q) := qneg_reverses hqr
    exact qlt_le_trans hxr hneg
  · intro hx
    exact ⟨q, qlt_irrefl q, hx⟩

/-- The accepted rational embedding preserves the negation candidate. -/
theorem rOfQ_neg (q : QBOMA) :
    rNeg (rOfQ q) = rOfQ (qNeg q) := by
  change rmk (cutNeg (principalCut q)) = rmk (principalCut (qNeg q))
  exact rmk_sound (cutNeg_principal q)

end BOMA.R.DedekindNegationCandidate001

/- First reusable Archimedean probe for accepted QBOMA: every rational has a natural upper bound. -/
namespace BOMA.R.QArchimedeanUpperBound001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Order001
open BOMA.Z.Rep001
open BOMA.Z.Rep001.ZSigned
open BOMA.Z.Arithmetic001
open BOMA.Z.Order001
open BOMA.Q.Fraction001
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001

/-- Every structurally positive rational denominator is at least integer one. -/
theorem denZ_ge_one (d : PosDen) : zLE zone (denZ d) := by
  unfold denZ denNat
  change zLE (embedN (s z)) (embedN (s d.pred))
  exact (embedN_order (s z) (s d.pred)).2
    ((le_s_iff).2 (z_le d.pred))

/-- Every raw fraction lies below a canonically embedded natural.
For a positive numerator, the numerator magnitude itself is enough because
the denominator is at least one. Zero and negative numerators are bounded by 0. -/
theorem rawFrac_le_natural (x : RawFrac) :
    ∃ n : BOMANat, RawLE x (fracOfZ (embedN n)) := by
  cases x with
  | mk num den =>
      cases num with
      | zero =>
          refine ⟨z, ?_⟩
          change zLE (zmul zzero zone) (zmul (embedN z) (denZ den))
          rw [zmul_zero_left, embedN_zero, zmul_zero_left]
          exact zle_refl zzero
      | neg p =>
          refine ⟨z, ?_⟩
          change zLE (zmul (neg p) zone) (zmul (embedN z) (denZ den))
          rw [zmul_one_right, embedN_zero, zmul_zero_left]
          change True
          exact True.intro
      | pos p =>
          refine ⟨s p, ?_⟩
          change zLE (zmul (pos p) zone)
            (zmul (embedN (s p)) (denZ den))
          rw [zmul_one_right]
          have hnum : NonNeg (embedN (s p)) := by
            unfold NonNeg
            exact (embedN_order z (s p)).2 (z_le (s p))
          have hm := zmul_mono_left_nonneg (denZ_ge_one den) hnum
          rw [zmul_one_right] at hm
          exact hm

/-- Reusable Archimedean upper-bound interface on the accepted quotient rational carrier. -/
theorem q_le_natural_upper (q : QBOMA) :
    ∃ n : BOMANat, qLE q (qOfN n) := by
  refine Quotient.inductionOn q ?_
  intro x
  rcases rawFrac_le_natural x with ⟨n, hn⟩
  refine ⟨n, ?_⟩
  change qLE (qmk x) (qmk (fracOfZ (embedN n)))
  exact (qLE_mk_iff x (fracOfZ (embedN n))).2 hn

end BOMA.R.QArchimedeanUpperBound001

/- Reusable Archimedean scaling consequence on accepted QBOMA. -/
namespace BOMA.R.QArchimedeanScaling001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.Q.Inverse001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QArchimedeanUpperBound001

/-- Every rational gap is bounded above by a natural multiple of any positive
rational step. The inverse is consumed as an existential witness; no global
inverse selector or Choice principle is introduced. -/
theorem q_archimedean_scale (gap delta : QBOMA) (hdelta : qLT qZero delta) :
    ∃ n : BOMANat, qLE gap (qMul (qOfN n) delta) := by
  have hdeltaNZ : delta ≠ qZero := hdelta.2.symm
  rcases q_inverse_exists delta hdeltaNZ with ⟨rinv, hrinv⟩
  have hdeltaPos : QPositive delta := ⟨hdelta.1, hdeltaNZ⟩
  have hrinvPos : QPositive rinv :=
    inverse_of_positive_is_positive hdeltaPos hrinv
  rcases q_le_natural_upper (qMul gap rinv) with ⟨n, hn⟩
  have hm := qmul_mono_left_nonneg hn hdelta.1
  have hleft : qMul delta (qMul gap rinv) = gap := by
    calc
      qMul delta (qMul gap rinv) = qMul (qMul delta gap) rinv :=
        (qMul_assoc delta gap rinv).symm
      _ = qMul (qMul gap delta) rinv :=
        congrArg (fun t => qMul t rinv) (qMul_comm delta gap)
      _ = qMul gap (qMul delta rinv) := qMul_assoc gap delta rinv
      _ = qMul gap qOne := congrArg (fun t => qMul gap t) hrinv
      _ = gap := qMul_one_right gap
  have hright : qMul delta (qOfN n) = qMul (qOfN n) delta :=
    qMul_comm delta (qOfN n)
  rw [hleft, hright] at hm
  exact ⟨n, hm⟩

end BOMA.R.QArchimedeanScaling001

/- Constructive rational grid consequences of the accepted Archimedean scaling theorem. -/
namespace BOMA.R.QArchimedeanGrid001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.NArithmetic.Addition001
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.QArchimedeanScaling001

/-- Successor compatibility of the accepted N -> Q embedding. -/
theorem qOfN_succ (n : BOMANat) :
    qOfN (s n) = qAdd (qOfN n) qOne := by
  have h := qOfN_add n (s z)
  simpa using h

/-- Rational grid based at a with positive step delta. -/
def qGrid (a delta : QBOMA) (n : BOMANat) : QBOMA :=
  qAdd a (qMul (qOfN n) delta)

@[simp] theorem qGrid_zero (a delta : QBOMA) : qGrid a delta z = a := by
  unfold qGrid
  rw [qOfN_zero, qMul_zero_left, qAdd_zero_right]

/-- Advancing the natural index advances the grid by exactly one delta. -/
theorem qGrid_succ (a delta : QBOMA) (n : BOMANat) :
    qGrid a delta (s n) = qAdd (qGrid a delta n) delta := by
  unfold qGrid
  rw [qOfN_succ, qMul_add_left, qMul_one_left]
  exact (qAdd_assoc a (qMul (qOfN n) delta) delta).symm

/-- A bound on the translated gap u-a gives a bound of u by the corresponding grid point. -/
theorem qle_grid_of_gap_bound {a u delta : QBOMA} {n : BOMANat}
    (h : qLE (qAdd u (qNeg a)) (qMul (qOfN n) delta)) :
    qLE u (qGrid a delta n) := by
  have ht := qadd_mono_right h a
  have hleft : qAdd (qAdd u (qNeg a)) a = u := by
    calc
      qAdd (qAdd u (qNeg a)) a = qAdd u (qAdd (qNeg a) a) :=
        qAdd_assoc u (qNeg a) a
      _ = qAdd u qZero := by rw [qAdd_neg_left]
      _ = u := qAdd_zero_right u
  have hright : qAdd (qMul (qOfN n) delta) a = qGrid a delta n := by
    unfold qGrid
    exact qAdd_comm (qMul (qOfN n) delta) a
  rw [hleft, hright] at ht
  exact ht

/-- From any base point a and any known outside point u of a proper lower cut,
a positive rational step eventually reaches a grid point outside the cut.
The base point need not itself be known inside for this purely crossing/bounding statement.
No membership decision or Classical.em is used here. -/
theorem qGrid_eventually_outside
    (A : LowerCut) (a u delta : QBOMA)
    (hu : ¬ A.lower u)
    (hdelta : qLT qZero delta) :
    ∃ n : BOMANat, ¬ A.lower (qGrid a delta n) := by
  rcases q_archimedean_scale (qAdd u (qNeg a)) delta hdelta with ⟨n, hn⟩
  refine ⟨n, ?_⟩
  intro hgrid
  apply hu
  exact A.downward hgrid (qle_grid_of_gap_bound hn)

end BOMA.R.QArchimedeanGrid001

/- Isolated logical search over a finite rational grid.
The arithmetic grid and eventual crossing are proved constructively elsewhere. -/
namespace BOMA.R.DedekindFiniteExit001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Q.Quotient001
open BOMA.R.DedekindProbe001
open BOMA.R.QArchimedeanGrid001

/-- Given an inside base point and a finite grid endpoint known outside,
there is an adjacent inside/outside pair along the grid.

The only nonconstructive ingredient is the explicit proposition-level
`Classical.em` used to decide membership of the predecessor grid point. -/
theorem qGrid_first_exit
    (A : LowerCut) (a delta : QBOMA)
    (ha : A.lower a) :
    ∀ n : BOMANat,
      ¬ A.lower (qGrid a delta n) →
      ∃ b r : QBOMA,
        A.lower b ∧
        ¬ A.lower r ∧
        r = qAdd b delta := by
  intro n
  induction n with
  | z =>
      intro hout
      have hbase : A.lower (qGrid a delta z) := by
        simpa using ha
      exact False.elim (hout hbase)
  | s n ih =>
      intro hout
      rcases Classical.em (A.lower (qGrid a delta n)) with hprev | hprev
      · refine ⟨qGrid a delta n, qGrid a delta (s n), hprev, hout, ?_⟩
        exact qGrid_succ a delta n
      · exact ih hprev

end BOMA.R.DedekindFiniteExit001

/- Arbitrarily fine inside/outside rational bracketing for selected Dedekind cuts.
Arithmetic Archimedean scaling and finite predicate search remain separate dependencies. -/
namespace BOMA.R.DedekindCutBracket001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.QArchimedeanGrid001
open BOMA.R.DedekindFiniteExit001

/-- Every positive rational epsilon admits an inside/outside bracket around an
arbitrary Dedekind lower cut whose rational width is positive and strictly
smaller than epsilon.

The arithmetic growth is inherited from the constructive Q Archimedean route.
The only predicate-membership search is inherited from the isolated finite-exit theorem. -/
theorem cut_bracket_approx
    (A : LowerCut) (eps : QBOMA)
    (heps : qLT qZero eps) :
    ∃ b r : QBOMA,
      A.lower b ∧
      ¬ A.lower r ∧
      qLT qZero (qAdd r (qNeg b)) ∧
      qLT (qAdd r (qNeg b)) eps := by
  rcases rational_order_dense heps with ⟨delta, h0delta, hdeltaeps⟩
  rcases A.nonempty with ⟨a, ha⟩
  rcases A.proper with ⟨u, hu⟩
  rcases qGrid_eventually_outside A a u delta hu h0delta with ⟨n, hout⟩
  rcases qGrid_first_exit A a delta ha n hout with ⟨b, r, hb, hr, hstep⟩
  have hwidth : qAdd r (qNeg b) = delta := by
    calc
      qAdd r (qNeg b) = qAdd (qAdd b delta) (qNeg b) :=
        congrArg (fun t => qAdd t (qNeg b)) hstep
      _ = qAdd b (qAdd delta (qNeg b)) :=
        qAdd_assoc b delta (qNeg b)
      _ = qAdd b (qAdd (qNeg b) delta) :=
        congrArg (fun t => qAdd b t) (qAdd_comm delta (qNeg b))
      _ = qAdd (qAdd b (qNeg b)) delta :=
        (qAdd_assoc b (qNeg b) delta).symm
      _ = qAdd qZero delta := by rw [qAdd_neg_right]
      _ = delta := qAdd_zero_left delta
  refine ⟨b, r, hb, hr, ?_, ?_⟩
  · rw [hwidth]
    exact h0delta
  · rw [hwidth]
    exact hdeltaeps

end BOMA.R.DedekindCutBracket001

/- Additive-inverse certification for the verified Dedekind negation candidate. -/
namespace BOMA.R.DedekindAdditiveInverse001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionEmbedding001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindCutBracket001

/-- Rational negation fixes zero. -/
theorem qNeg_zero : qNeg qZero = qZero := by
  have h : qZero = qNeg qZero :=
    qAdd_inverse_unique (x := qZero) (y := qZero) (qAdd_zero_left qZero)
  exact h.symm

/-- Any member of A + (-A) is strictly below rational zero. This direction
uses no Archimedean bracketing theorem. -/
theorem cutAdd_neg_to_zero (A : LowerCut) {x : QBOMA}
    (hx : (cutAdd A (cutNeg A)).lower x) :
    (principalCut qZero).lower x := by
  rcases hx with ⟨a, b, ha, hbNeg, hxab⟩
  rcases hbNeg with ⟨r, hrOut, hbr⟩
  have har : qLE a r := by
    rcases qle_total a r with har | hra
    · exact har
    · exact False.elim (hrOut (A.downward ha hra))
  have habar : qLT (qAdd a b) (qAdd a (qNeg r)) := by
    have ht := qlt_add_right hbr a
    rw [qAdd_comm b a, qAdd_comm (qNeg r) a] at ht
    exact ht
  have har0 : qLE (qAdd a (qNeg r)) qZero := by
    have ht := qadd_mono_right har (qNeg r)
    rw [qAdd_neg_right] at ht
    exact ht
  exact qlt_le_trans (qlt_trans hxab habar) har0

/-- If x is strictly below zero, the fine cut-bracketing theorem supplies
witnesses showing x belongs to A + (-A). This is the direction that consumes
R-QARCH-BLOCK-001 through cut_bracket_approx. -/
theorem zero_to_cutAdd_neg (A : LowerCut) {x : QBOMA}
    (hx : (principalCut qZero).lower x) :
    (cutAdd A (cutNeg A)).lower x := by
  have hposNegX : qLT qZero (qNeg x) := by
    have ht := qneg_strict_reverses hx
    rw [qNeg_zero] at ht
    exact ht
  rcases cut_bracket_approx A (qNeg x) hposNegX with
    ⟨b, r, hb, hrOut, _hwidthPos, hwidthLt⟩
  have hx_bminusr : qLT x (qAdd b (qNeg r)) := by
    have ht := qneg_strict_reverses hwidthLt
    have hleft : qNeg (qNeg x) = x := qNeg_involutive x
    have hright : qNeg (qAdd r (qNeg b)) = qAdd b (qNeg r) := by
      rw [qNeg_add, qNeg_involutive]
      exact qAdd_comm (qNeg r) b
    rw [hleft, hright] at ht
    exact ht
  have hxb_negr : qLT (qAdd x (qNeg b)) (qNeg r) := by
    have ht := qlt_add_right hx_bminusr (qNeg b)
    have hright : qAdd (qAdd b (qNeg r)) (qNeg b) = qNeg r := by
      calc
        qAdd (qAdd b (qNeg r)) (qNeg b) =
            qAdd b (qAdd (qNeg r) (qNeg b)) :=
          qAdd_assoc b (qNeg r) (qNeg b)
        _ = qAdd b (qAdd (qNeg b) (qNeg r)) :=
          congrArg (fun t => qAdd b t) (qAdd_comm (qNeg r) (qNeg b))
        _ = qAdd (qAdd b (qNeg b)) (qNeg r) :=
          (qAdd_assoc b (qNeg b) (qNeg r)).symm
        _ = qAdd qZero (qNeg r) := by rw [qAdd_neg_right]
        _ = qNeg r := qAdd_zero_left _
    rw [hright] at ht
    exact ht
  rcases rational_order_dense hxb_negr with ⟨c, hxc, hcr⟩
  have hcNeg : (cutNeg A).lower c := ⟨r, hrOut, hcr⟩
  have hxsum : qLT x (qAdd b c) := qlt_add_back_left hxc
  exact ⟨b, c, hb, hcNeg, hxsum⟩

/-- Raw Dedekind addition with the verified negation candidate is extensionally
exactly the principal zero cut. -/
theorem cutAdd_neg_equiv_zero (A : LowerCut) :
    CutEquiv (cutAdd A (cutNeg A)) (principalCut qZero) := by
  intro x
  constructor
  · exact cutAdd_neg_to_zero A
  · exact zero_to_cutAdd_neg A

/-- The verified negation candidate is a right additive inverse on formal RBOMA. -/
theorem rAdd_neg_right (x : RBOMA) :
    rAdd x (rNeg x) = rZero := by
  refine Quotient.inductionOn x ?_
  intro A
  change rmk (cutAdd A (cutNeg A)) = rmk (principalCut qZero)
  exact rmk_sound (cutAdd_neg_equiv_zero A)

/-- By commutativity, it is also a left additive inverse. -/
theorem rAdd_neg_left (x : RBOMA) :
    rAdd (rNeg x) x = rZero := by
  calc
    rAdd (rNeg x) x = rAdd x (rNeg x) := rAdd_comm (rNeg x) x
    _ = rZero := rAdd_neg_right x

/-- Additive cancellation is now available on RBOMA. -/
theorem rAdd_left_cancel {a b c : RBOMA}
    (h : rAdd a b = rAdd a c) : b = c := by
  have h' := congrArg (fun t => rAdd (rNeg a) t) h
  calc
    b = rAdd rZero b := (rAdd_zero_left b).symm
    _ = rAdd (rAdd (rNeg a) a) b := by rw [rAdd_neg_left]
    _ = rAdd (rNeg a) (rAdd a b) := rAdd_assoc (rNeg a) a b
    _ = rAdd (rNeg a) (rAdd a c) := h'
    _ = rAdd (rAdd (rNeg a) a) c := (rAdd_assoc (rNeg a) a c).symm
    _ = rAdd rZero c := by rw [rAdd_neg_left]
    _ = c := rAdd_zero_left c

/-- Additive inverses are unique on the accepted real additive group. -/
theorem rAdd_inverse_unique {x y : RBOMA}
    (h : rAdd x y = rZero) : y = rNeg x := by
  apply rAdd_left_cancel (a := x)
  calc
    rAdd x y = rZero := h
    _ = rAdd x (rNeg x) := (rAdd_neg_right x).symm

/-- Real negation is involutive after inverse certification. -/
theorem rNeg_involutive (x : RBOMA) : rNeg (rNeg x) = x := by
  symm
  exact rAdd_inverse_unique
    (x := rNeg x)
    (y := x)
    (rAdd_neg_left x)

end BOMA.R.DedekindAdditiveInverse001

/- Reusable identities derived from the certified additive group on RBOMA. -/
namespace BOMA.R.DedekindAdditiveDerived001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001

/-- Exchange the middle two terms in a four-term additive expression. -/
theorem rAdd_exchange (a b c d : RBOMA) :
    rAdd a (rAdd b (rAdd c d)) =
    rAdd a (rAdd c (rAdd b d)) := by
  apply congrArg (fun t => rAdd a t)
  calc
    rAdd b (rAdd c d) = rAdd (rAdd b c) d := (rAdd_assoc b c d).symm
    _ = rAdd (rAdd c b) d :=
      congrArg (fun t => rAdd t d) (rAdd_comm b c)
    _ = rAdd c (rAdd b d) := rAdd_assoc c b d

/-- Negation distributes over formal real addition. -/
theorem rNeg_add (x y : RBOMA) :
    rNeg (rAdd x y) = rAdd (rNeg x) (rNeg y) := by
  symm
  apply rAdd_inverse_unique (x := rAdd x y)
  calc
    rAdd (rAdd x y) (rAdd (rNeg x) (rNeg y)) =
        rAdd x (rAdd y (rAdd (rNeg x) (rNeg y))) :=
      rAdd_assoc x y (rAdd (rNeg x) (rNeg y))
    _ = rAdd x (rAdd (rNeg x) (rAdd y (rNeg y))) :=
      rAdd_exchange x y (rNeg x) (rNeg y)
    _ = rAdd x (rAdd (rNeg x) rZero) := by rw [rAdd_neg_right]
    _ = rAdd x (rNeg x) := by rw [rAdd_zero_right]
    _ = rZero := rAdd_neg_right x

/-- Cancel a right summand by adding its inverse. -/
theorem rAdd_sub_right (x y : RBOMA) :
    rAdd (rAdd x y) (rNeg y) = x := by
  calc
    rAdd (rAdd x y) (rNeg y) = rAdd x (rAdd y (rNeg y)) :=
      rAdd_assoc x y (rNeg y)
    _ = rAdd x rZero := by rw [rAdd_neg_right]
    _ = x := rAdd_zero_right x

/-- Cancel a left negative translation. -/
theorem rAdd_sub_left (x y : RBOMA) :
    rAdd (rAdd x (rNeg y)) y = x := by
  calc
    rAdd (rAdd x (rNeg y)) y = rAdd x (rAdd (rNeg y) y) :=
      rAdd_assoc x (rNeg y) y
    _ = rAdd x rZero := by rw [rAdd_neg_left]
    _ = x := rAdd_zero_right x

/-- Subtracting a sum from its first summand gives the inverse of the second. -/
theorem rAdd_neg_sum_cancel_left (x y : RBOMA) :
    rAdd x (rNeg (rAdd x y)) = rNeg y := by
  rw [rNeg_add]
  calc
    rAdd x (rAdd (rNeg x) (rNeg y)) =
        rAdd (rAdd x (rNeg x)) (rNeg y) :=
      (rAdd_assoc x (rNeg x) (rNeg y)).symm
    _ = rAdd rZero (rNeg y) := by rw [rAdd_neg_right]
    _ = rNeg y := rAdd_zero_left _

/-- Subtracting a sum from its second summand gives the inverse of the first. -/
theorem rAdd_neg_sum_cancel_right (x y : RBOMA) :
    rAdd y (rNeg (rAdd x y)) = rNeg x := by
  rw [rAdd_comm x y]
  exact rAdd_neg_sum_cancel_left y x

end BOMA.R.DedekindAdditiveDerived001

/- Nonnegative envelope for Dedekind reals, built without sign case-splitting. -/
namespace BOMA.R.DedekindPositivePart001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001

/-- Positive/nonnegative envelope of a cut: union with the principal zero cut.
This is the cut-level max(A,0), defined without deciding the sign of A. -/
def cutPosPart (A : LowerCut) : LowerCut where
  lower := fun q => A.lower q ∨ qLT q qZero
  nonempty := by
    rcases A.nonempty with ⟨a, ha⟩
    exact ⟨a, Or.inl ha⟩
  proper := by
    rcases A.proper with ⟨u, hu⟩
    rcases qle_total qZero u with h0u | hu0
    · refine ⟨u, ?_⟩
      intro h
      rcases h with huA | huNeg
      · exact hu huA
      · have heq : qZero = u := qle_antisymm h0u huNeg.1
        exact huNeg.2 heq.symm
    · refine ⟨qZero, ?_⟩
      intro h
      rcases h with h0A | h00
      · exact hu (A.downward h0A hu0)
      · exact qlt_irrefl qZero h00
  downward := by
    intro p q hq hpq
    rcases hq with hqA | hq0
    · exact Or.inl (A.downward hqA hpq)
    · exact Or.inr (BOMA.R.DedekindAddition001.qle_lt_trans hpq hq0)
  rounded := by
    intro q hq
    rcases hq with hqA | hq0
    · rcases A.rounded hqA with ⟨r, hrA, hqr⟩
      exact ⟨r, Or.inl hrA, hqr⟩
    · rcases rational_order_dense hq0 with ⟨r, hqr, hr0⟩
      exact ⟨r, Or.inr hr0, hqr⟩

/-- The positive-part construction respects extensional cut identity. -/
theorem cutPosPart_respects {A B : LowerCut} (hAB : CutEquiv A B) :
    CutEquiv (cutPosPart A) (cutPosPart B) := by
  intro q
  constructor
  · intro h
    rcases h with hA | h0
    · exact Or.inl ((hAB q).mp hA)
    · exact Or.inr h0
  · intro h
    rcases h with hB | h0
    · exact Or.inl ((hAB q).mpr hB)
    · exact Or.inr h0

/-- Formal nonnegative envelope lifted to RBOMA. -/
def rPosPart : RBOMA → RBOMA :=
  Quotient.lift
    (fun A => rmk (cutPosPart A))
    (fun _ _ h => rmk_sound (cutPosPart_respects h))

@[simp] theorem rPosPart_mk (A : LowerCut) :
    rPosPart (rmk A) = rmk (cutPosPart A) := rfl

/-- The zero cut is included in every positive-part envelope. -/
theorem cutZero_le_posPart (A : LowerCut) :
    CutLE (principalCut qZero) (cutPosPart A) := by
  intro q hq
  exact Or.inr hq

/-- Every cut is included in its positive-part envelope. -/
theorem cut_le_posPart (A : LowerCut) : CutLE A (cutPosPart A) := by
  intro q hq
  exact Or.inl hq

/-- If a cut is already nonnegative, taking the positive part changes nothing
up to extensional identity. -/
theorem cutPosPart_of_nonneg {A : LowerCut}
    (h0A : CutLE (principalCut qZero) A) :
    CutEquiv (cutPosPart A) A := by
  intro q
  constructor
  · intro h
    rcases h with hA | h0
    · exact hA
    · exact h0A q h0
  · intro hA
    exact Or.inl hA

/-- Formal positive part lies above zero. -/
theorem rZero_le_rPosPart (x : RBOMA) : rLE rZero (rPosPart x) := by
  refine Quotient.inductionOn x ?_
  intro A
  change rLE (rmk (principalCut qZero)) (rmk (cutPosPart A))
  exact (rLE_mk_iff (principalCut qZero) (cutPosPart A)).2
    (cutZero_le_posPart A)

/-- Formal positive part lies above the original real. -/
theorem rLE_rPosPart (x : RBOMA) : rLE x (rPosPart x) := by
  refine Quotient.inductionOn x ?_
  intro A
  change rLE (rmk A) (rmk (cutPosPart A))
  exact (rLE_mk_iff A (cutPosPart A)).2 (cut_le_posPart A)

/-- Negative magnitude candidate, still defined without a sign case split. -/
def rNegPart (x : RBOMA) : RBOMA := rPosPart (rNeg x)

end BOMA.R.DedekindPositivePart001

/- Positive/negative-envelope decomposition on selected Dedekind reals.
The envelope definitions are sign-case-free; the final decomposition theorem
uses the already-isolated classical total-comparability witness explicitly. -/
namespace BOMA.R.DedekindPositiveDecomposition001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositivePart001

/-- If A is below zero, its positive envelope is exactly zero. -/
theorem cutPosPart_of_nonpos {A : LowerCut}
    (hA0 : CutLE A (principalCut qZero)) :
    CutEquiv (cutPosPart A) (principalCut qZero) := by
  intro q
  constructor
  · intro hq
    rcases hq with hA | h0
    · exact hA0 q hA
    · exact h0
  · intro h0
    exact Or.inr h0

/-- Any rational outside a cut known to contain the zero cut is nonnegative. -/
theorem outside_of_nonnegative_cut_is_nonneg
    {A : LowerCut} {r : QBOMA}
    (h0A : CutLE (principalCut qZero) A)
    (hrOut : ¬ A.lower r) :
    qLE qZero r := by
  rcases qlt_trichotomy r qZero with hr0 | heq | h0r
  · exact False.elim (hrOut (h0A r hr0))
  · rw [heq]
    exact qle_refl qZero
  · exact h0r.1

/-- Negation of a nonnegative cut is below zero. -/
theorem cutNeg_le_zero_of_zero_le
    {A : LowerCut}
    (h0A : CutLE (principalCut qZero) A) :
    CutLE (cutNeg A) (principalCut qZero) := by
  intro q hq
  rcases hq with ⟨r, hrOut, hqnegr⟩
  have h0r : qLE qZero r :=
    outside_of_nonnegative_cut_is_nonneg h0A hrOut
  have hneg : qLE (qNeg r) (qNeg qZero) := qneg_reverses h0r
  rw [qNeg_zero] at hneg
  exact qlt_le_trans hqnegr hneg

/-- Negation of a nonpositive cut contains the zero cut. -/
theorem cutZero_le_neg_of_le_zero
    {A : LowerCut}
    (hA0 : CutLE A (principalCut qZero)) :
    CutLE (principalCut qZero) (cutNeg A) := by
  intro q hq0
  have h0negq : qLT qZero (qNeg q) := by
    have ht := qneg_strict_reverses hq0
    rw [qNeg_zero] at ht
    exact ht
  rcases rational_order_dense h0negq with ⟨r, h0r, hrnegq⟩
  have hrOut : ¬ A.lower r := by
    intro hrA
    have hr0 : qLT r qZero := hA0 r hrA
    exact (qlt_asymm h0r) hr0
  have hqnegr : qLT q (qNeg r) := by
    have ht := qneg_strict_reverses hrnegq
    rw [qNeg_involutive q] at ht
    exact ht
  exact ⟨r, hrOut, hqnegr⟩

/-- Formal positive part is fixed on nonnegative reals. -/
theorem rPosPart_of_nonneg {x : RBOMA}
    (h0x : rLE rZero x) :
    rPosPart x = x := by
  refine Quotient.inductionOn x ?_ h0x
  intro A h0A
  change rmk (cutPosPart A) = rmk A
  apply rmk_sound
  apply cutPosPart_of_nonneg
  change rLE (rmk (principalCut qZero)) (rmk A) at h0A
  exact (rLE_mk_iff (principalCut qZero) A).1 h0A

/-- Formal positive part collapses to zero on nonpositive reals. -/
theorem rPosPart_of_nonpos {x : RBOMA}
    (hx0 : rLE x rZero) :
    rPosPart x = rZero := by
  refine Quotient.inductionOn x ?_ hx0
  intro A hA0
  change rmk (cutPosPart A) = rmk (principalCut qZero)
  apply rmk_sound
  apply cutPosPart_of_nonpos
  change rLE (rmk A) (rmk (principalCut qZero)) at hA0
  exact (rLE_mk_iff A (principalCut qZero)).1 hA0

/-- Real negation sends a nonnegative real to a nonpositive real. -/
theorem rNeg_nonpos_of_nonneg {x : RBOMA}
    (h0x : rLE rZero x) :
    rLE (rNeg x) rZero := by
  refine Quotient.inductionOn x ?_ h0x
  intro A h0A
  change rLE (rmk (cutNeg A)) (rmk (principalCut qZero))
  apply (rLE_mk_iff (cutNeg A) (principalCut qZero)).2
  apply cutNeg_le_zero_of_zero_le
  change rLE (rmk (principalCut qZero)) (rmk A) at h0A
  exact (rLE_mk_iff (principalCut qZero) A).1 h0A

/-- Real negation sends a nonpositive real to a nonnegative real. -/
theorem rNeg_nonneg_of_nonpos {x : RBOMA}
    (hx0 : rLE x rZero) :
    rLE rZero (rNeg x) := by
  refine Quotient.inductionOn x ?_ hx0
  intro A hA0
  change rLE (rmk (principalCut qZero)) (rmk (cutNeg A))
  apply (rLE_mk_iff (principalCut qZero) (cutNeg A)).2
  apply cutZero_le_neg_of_le_zero
  change rLE (rmk A) (rmk (principalCut qZero)) at hA0
  exact (rLE_mk_iff A (principalCut qZero)).1 hA0

/-- Formal real negation fixes zero. -/
@[simp] theorem rNeg_zero : rNeg rZero = rZero := by
  symm
  exact rAdd_inverse_unique
    (x := rZero)
    (y := rZero)
    (rAdd_zero_left rZero)

/-- For a nonnegative real, the negative envelope is zero. -/
theorem rNegPart_of_nonneg {x : RBOMA}
    (h0x : rLE rZero x) :
    rNegPart x = rZero := by
  unfold rNegPart
  exact rPosPart_of_nonpos (rNeg_nonpos_of_nonneg h0x)

/-- For a nonpositive real, the negative envelope is exactly -x. -/
theorem rNegPart_of_nonpos {x : RBOMA}
    (hx0 : rLE x rZero) :
    rNegPart x = rNeg x := by
  unfold rNegPart
  exact rPosPart_of_nonneg (rNeg_nonneg_of_nonpos hx0)

/-- Signed decomposition of every selected Dedekind real.
The only sign split occurs here through the isolated classical total-order witness. -/
theorem rPosNeg_decomposition (x : RBOMA) :
    rAdd (rPosPart x) (rNeg (rNegPart x)) = x := by
  rcases rLE_total_classical rZero x with h0x | hx0
  · rw [rPosPart_of_nonneg h0x, rNegPart_of_nonneg h0x,
      rNeg_zero, rAdd_zero_right]
  · rw [rPosPart_of_nonpos hx0, rNegPart_of_nonpos hx0,
      rNeg_involutive, rAdd_zero_left]

end BOMA.R.DedekindPositiveDecomposition001

/- Multiplication kernel for nonnegative Dedekind envelopes.
This is not yet the final signed real multiplication. -/
namespace BOMA.R.DedekindNonnegativeMul001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositivePart001

/-- Any point outside max(A,0) is rationally nonnegative. -/
theorem outside_posPart_nonneg (A : LowerCut) {u : QBOMA}
    (hu : ¬ (cutPosPart A).lower u) : qLE qZero u := by
  rcases qlt_trichotomy u qZero with hneg | heq | hpos
  · exact False.elim (hu (Or.inr hneg))
  · rw [heq]
    exact qle_refl qZero
  · exact hpos.1

/-- Every member of a lower cut lies below every point known outside it. -/
theorem member_le_outside {P : LowerCut} {a u : QBOMA}
    (ha : P.lower a) (hu : ¬ P.lower u) : qLE a u := by
  rcases qle_total a u with hau | hua
  · exact hau
  · exact False.elim (hu (P.downward ha hua))

/-- Positive-envelope product.
Negative rationals are included automatically; nonnegative content is generated
strictly below products of positive witnesses from the two positive envelopes. -/
def cutMulNonnegEnvelope (A B : LowerCut) : LowerCut where
  lower := fun q =>
    qLT q qZero ∨
    ∃ a b : QBOMA,
      (cutPosPart A).lower a ∧
      (cutPosPart B).lower b ∧
      qLT qZero a ∧
      qLT qZero b ∧
      qLT q (qMul a b)
  nonempty := by
    let m := qAdd qZero (qNeg qOne)
    refine ⟨m, Or.inl ?_⟩
    exact BOMA.R.DedekindProbe001.q_minus_one_lt qZero
  proper := by
    rcases (cutPosPart A).proper with ⟨uA, huA⟩
    rcases (cutPosPart B).proper with ⟨uB, huB⟩
    let U := qAdd uA qOne
    let V := qAdd uB qOne
    let M := qAdd (qMul U V) qOne
    have h0uA : qLE qZero uA := outside_posPart_nonneg A huA
    have h0uB : qLE qZero uB := outside_posPart_nonneg B huB
    have huA_U : qLE uA U := by
      have h := qadd_mono_right qzero_le_one uA
      change qLE (qAdd qZero uA) (qAdd qOne uA) at h
      rw [qAdd_zero_left, qAdd_comm qOne uA] at h
      exact h
    have huB_V : qLE uB V := by
      have h := qadd_mono_right qzero_le_one uB
      change qLE (qAdd qZero uB) (qAdd qOne uB) at h
      rw [qAdd_zero_left, qAdd_comm qOne uB] at h
      exact h
    have h0U : qLE qZero U := qle_trans h0uA huA_U
    have h0V : qLE qZero V := qle_trans h0uB huB_V
    have h0UV : qLE qZero (qMul U V) := qmul_nonneg h0U h0V
    have hUV_M : qLT (qMul U V) M := by
      have h := qlt_add_right qzero_lt_one (qMul U V)
      change qLT (qAdd qZero (qMul U V)) (qAdd qOne (qMul U V)) at h
      rw [qAdd_zero_left, qAdd_comm qOne (qMul U V)] at h
      exact h
    have h0M : qLT qZero M :=
      BOMA.R.DedekindAddition001.qle_lt_trans h0UV hUV_M
    refine ⟨M, ?_⟩
    intro hM
    rcases hM with hMneg | hMprod
    · exact qlt_asymm h0M hMneg
    · rcases hMprod with ⟨a, b, ha, hb, h0a, h0b, hMab⟩
      have ha_uA : qLE a uA := member_le_outside ha huA
      have hb_uB : qLE b uB := member_le_outside hb huB
      have haU : qLE a U := qle_trans ha_uA huA_U
      have hbV : qLE b V := qle_trans hb_uB huB_V
      have hab_Ub : qLE (qMul a b) (qMul U b) := by
        have h := qmul_mono_left_nonneg haU h0b.1
        rw [qMul_comm b a, qMul_comm b U] at h
        exact h
      have hUb_UV : qLE (qMul U b) (qMul U V) :=
        qmul_mono_left_nonneg hbV h0U
      have hab_UV : qLE (qMul a b) (qMul U V) :=
        qle_trans hab_Ub hUb_UV
      have hMUV : qLT M (qMul U V) :=
        BOMA.R.DedekindAddition001.qlt_le_trans hMab hab_UV
      exact qlt_asymm hUV_M hMUV
  downward := by
    intro p q hq hpq
    rcases hq with hqNeg | hqProd
    · exact Or.inl (BOMA.R.DedekindAddition001.qle_lt_trans hpq hqNeg)
    · rcases hqProd with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      exact Or.inr ⟨a, b, ha, hb, h0a, h0b,
        BOMA.R.DedekindAddition001.qle_lt_trans hpq hq⟩
  rounded := by
    intro q hq
    rcases hq with hqNeg | hqProd
    · rcases rational_order_dense hqNeg with ⟨r, hqr, hr0⟩
      exact ⟨r, Or.inl hr0, hqr⟩
    · rcases hqProd with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      rcases rational_order_dense hq with ⟨r, hqr, hrab⟩
      exact ⟨r, Or.inr ⟨a, b, ha, hb, h0a, h0b, hrab⟩, hqr⟩

/-- The nonnegative-envelope product respects extensional identity. -/
theorem cutMulNonnegEnvelope_respects
    {A A' B B' : LowerCut}
    (hA : CutEquiv A A') (hB : CutEquiv B B') :
    CutEquiv
      (cutMulNonnegEnvelope A B)
      (cutMulNonnegEnvelope A' B') := by
  intro q
  constructor
  · intro hq
    rcases hq with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      have hPA := cutPosPart_respects hA
      have hPB := cutPosPart_respects hB
      exact Or.inr ⟨a, b, (hPA a).mp ha, (hPB b).mp hb, h0a, h0b, hq⟩
  · intro hq
    rcases hq with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      have hPA := cutPosPart_respects hA
      have hPB := cutPosPart_respects hB
      exact Or.inr ⟨a, b, (hPA a).mpr ha, (hPB b).mpr hb, h0a, h0b, hq⟩

/-- Symmetry of the nonnegative multiplication kernel. -/
theorem cutMulNonnegEnvelope_comm (A B : LowerCut) :
    CutEquiv (cutMulNonnegEnvelope A B) (cutMulNonnegEnvelope B A) := by
  intro q
  constructor
  · intro hq
    rcases hq with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨a, b, ha, hb, h0a, h0b, hq⟩
      have hq' : qLT q (qMul b a) := by
        rw [qMul_comm b a]
        exact hq
      exact Or.inr ⟨b, a, hb, ha, h0b, h0a, hq'⟩
  · intro hq
    rcases hq with hneg | hprod
    · exact Or.inl hneg
    · rcases hprod with ⟨b, a, hb, ha, h0b, h0a, hq⟩
      have hq' : qLT q (qMul a b) := by
        rw [qMul_comm a b]
        exact hq
      exact Or.inr ⟨a, b, ha, hb, h0a, h0b, hq'⟩

/-- Quotient lift of the nonnegative-envelope kernel. This is an intermediate
operation, not yet the final signed real multiplication. -/
def rMulNonnegEnvelope : RBOMA → RBOMA → RBOMA :=
  Quotient.lift₂
    (fun A B => rmk (cutMulNonnegEnvelope A B))
    (fun _ _ _ _ hA hB => rmk_sound (cutMulNonnegEnvelope_respects hA hB))

@[simp] theorem rMulNonnegEnvelope_mk (A B : LowerCut) :
    rMulNonnegEnvelope (rmk A) (rmk B) = rmk (cutMulNonnegEnvelope A B) := rfl

/-- The intermediate kernel is commutative. -/
theorem rMulNonnegEnvelope_comm (x y : RBOMA) :
    rMulNonnegEnvelope x y = rMulNonnegEnvelope y x := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  change rmk (cutMulNonnegEnvelope A B) = rmk (cutMulNonnegEnvelope B A)
  exact rmk_sound (cutMulNonnegEnvelope_comm A B)

end BOMA.R.DedekindNonnegativeMul001

/- Strict positive multiplication and inner approximation on accepted QBOMA.
This is a Q-level contribution used by the selected Dedekind multiplication route. -/
namespace BOMA.R.QPositiveMultiplicativeApprox001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.Inverse001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001

/-- Right cancellation by a nonzero rational, derived from the existential
inverse interface rather than a global inverse selector. -/
theorem qmul_right_cancel_nonzero {x y c : QBOMA}
    (hc : c ≠ qZero)
    (h : qMul x c = qMul y c) : x = y := by
  rcases q_inverse_exists c hc with ⟨cinv, hcinv⟩
  have h' := congrArg (fun t => qMul t cinv) h
  calc
    x = qMul x qOne := (qMul_one_right x).symm
    _ = qMul x (qMul c cinv) :=
      congrArg (fun t => qMul x t) hcinv.symm
    _ = qMul (qMul x c) cinv := (qMul_assoc x c cinv).symm
    _ = qMul (qMul y c) cinv := h'
    _ = qMul y (qMul c cinv) := qMul_assoc y c cinv
    _ = qMul y qOne := congrArg (fun t => qMul y t) hcinv
    _ = y := qMul_one_right y

/-- Left cancellation by a nonzero rational. -/
theorem qmul_left_cancel_nonzero {x y c : QBOMA}
    (hc : c ≠ qZero)
    (h : qMul c x = qMul c y) : x = y := by
  apply qmul_right_cancel_nonzero hc
  rw [qMul_comm x c, qMul_comm y c]
  exact h

/-- Multiplication on the right by a strictly positive rational preserves strict order. -/
theorem qmul_lt_right_positive {x y c : QBOMA}
    (hxy : qLT x y) (hc : qLT qZero c) :
    qLT (qMul x c) (qMul y c) := by
  refine ⟨qmul_mono_right_nonneg hxy.1 hc.1, ?_⟩
  intro heq
  have hcNZ : c ≠ qZero := by
    intro hc0
    exact hc.2 hc0.symm
  exact hxy.2 (qmul_right_cancel_nonzero hcNZ heq)

/-- Multiplication on the left by a strictly positive rational preserves strict order. -/
theorem qmul_lt_left_positive {x y c : QBOMA}
    (hxy : qLT x y) (hc : qLT qZero c) :
    qLT (qMul c x) (qMul c y) := by
  rw [qMul_comm c x, qMul_comm c y]
  exact qmul_lt_right_positive hxy hc

/-- If 0 ≤ u < v, then v is strictly positive. -/
theorem qlt_zero_of_nonneg_lt {u v : QBOMA}
    (h0u : qLE qZero u) (huv : qLT u v) : qLT qZero v := by
  refine ⟨qle_trans h0u huv.1, ?_⟩
  intro h0v
  have hu0 : qLE u qZero := by
    rw [h0v]
    exact huv.1
  have hueq0 : u = qZero := qle_antisymm hu0 h0u
  apply huv.2
  calc
    u = qZero := hueq0
    _ = v := h0v

/-- The existential inverse witness of a strictly positive rational is strictly positive. -/
theorem qlt_zero_inverse {q r : QBOMA}
    (hq : qLT qZero q) (hr : QInvRel q r) : qLT qZero r := by
  have hp : QPositive r :=
    inverse_of_positive_is_positive ⟨hq.1, fun hq0 => hq.2 hq0.symm⟩ hr
  exact ⟨hp.1, fun h0r => hp.2 h0r.symm⟩

/-- Dividing a strict inequality x < q*r by positive r on the right. -/
theorem qlt_mul_div_right {x q r rinv : QBOMA}
    (h : qLT x (qMul q r))
    (hr : qLT qZero r)
    (hrinv : QInvRel r rinv) :
    qLT (qMul x rinv) q := by
  have hrinvPos : qLT qZero rinv := qlt_zero_inverse hr hrinv
  have ht := qmul_lt_right_positive h hrinvPos
  have hright : qMul (qMul q r) rinv = q := by
    calc
      qMul (qMul q r) rinv = qMul q (qMul r rinv) := qMul_assoc q r rinv
      _ = qMul q qOne := congrArg (fun t => qMul q t) hrinv
      _ = q := qMul_one_right q
  rw [hright] at ht
  exact ht

/-- Recompose after dividing on the right. -/
theorem qlt_mul_recompose_right {x a r rinv : QBOMA}
    (h : qLT (qMul x rinv) a)
    (hr : qLT qZero r)
    (hrinv : QInvRel r rinv) :
    qLT x (qMul a r) := by
  have ht := qmul_lt_right_positive h hr
  have hleft : qMul (qMul x rinv) r = x := by
    have hri : qMul rinv r = qOne := by
      calc
        qMul rinv r = qMul r rinv := qMul_comm rinv r
        _ = qOne := hrinv
    calc
      qMul (qMul x rinv) r = qMul x (qMul rinv r) := qMul_assoc x rinv r
      _ = qMul x qOne := congrArg (fun t => qMul x t) hri
      _ = x := qMul_one_right x
  rw [hleft] at ht
  exact ht

/-- Divide x < a*r by positive a on the left. -/
theorem qlt_mul_div_left {x a r ainv : QBOMA}
    (h : qLT x (qMul a r))
    (ha : qLT qZero a)
    (hainv : QInvRel a ainv) :
    qLT (qMul ainv x) r := by
  have hainvPos : qLT qZero ainv := qlt_zero_inverse ha hainv
  have ht := qmul_lt_left_positive h hainvPos
  have hright : qMul ainv (qMul a r) = r := by
    have hia : qMul ainv a = qOne := by
      calc
        qMul ainv a = qMul a ainv := qMul_comm ainv a
        _ = qOne := hainv
    calc
      qMul ainv (qMul a r) = qMul (qMul ainv a) r := (qMul_assoc ainv a r).symm
      _ = qMul qOne r := congrArg (fun t => qMul t r) hia
      _ = r := qMul_one_left r
  rw [hright] at ht
  exact ht

/-- Recompose after dividing on the left. -/
theorem qlt_mul_recompose_left {x a b ainv : QBOMA}
    (h : qLT (qMul ainv x) b)
    (ha : qLT qZero a)
    (hainv : QInvRel a ainv) :
    qLT x (qMul a b) := by
  have ht := qmul_lt_left_positive h ha
  have hleft : qMul a (qMul ainv x) = x := by
    calc
      qMul a (qMul ainv x) = qMul (qMul a ainv) x := (qMul_assoc a ainv x).symm
      _ = qMul qOne x := congrArg (fun t => qMul t x) hainv
      _ = x := qMul_one_left x
  rw [hleft] at ht
  exact ht

/-- Inner-product approximation below positive r.
If x is nonnegative and x < q*r while r is positive, then positivity of q is
forced by the inequality itself; no separate q>0 assumption is required. -/
theorem q_positive_product_inner_approx
    {x q r : QBOMA}
    (hx : qLE qZero x)
    (hr : qLT qZero r)
    (hprod : qLT x (qMul q r)) :
    ∃ a b : QBOMA,
      qLT qZero a ∧
      qLT a q ∧
      qLT qZero b ∧
      qLT b r ∧
      qLT x (qMul a b) := by
  have hrNZ : r ≠ qZero := by
    intro hr0
    exact hr.2 hr0.symm
  rcases q_inverse_exists r hrNZ with ⟨rinv, hrinv⟩
  have hrinvPos : qLT qZero rinv := qlt_zero_inverse hr hrinv
  have hxdivq : qLT (qMul x rinv) q :=
    qlt_mul_div_right hprod hr hrinv
  have h0xrinv : qLE qZero (qMul x rinv) :=
    qmul_nonneg hx hrinvPos.1
  rcases rational_order_dense hxdivq with ⟨a, hxa, haq⟩
  have haPos : qLT qZero a := qlt_zero_of_nonneg_lt h0xrinv hxa
  have hxar : qLT x (qMul a r) :=
    qlt_mul_recompose_right hxa hr hrinv
  have haNZ : a ≠ qZero := by
    intro ha0
    exact haPos.2 ha0.symm
  rcases q_inverse_exists a haNZ with ⟨ainv, hainv⟩
  have hainvPos : qLT qZero ainv := qlt_zero_inverse haPos hainv
  have hxdivr : qLT (qMul ainv x) r :=
    qlt_mul_div_left hxar haPos hainv
  have h0ainvx : qLE qZero (qMul ainv x) :=
    qmul_nonneg hainvPos.1 hx
  rcases rational_order_dense hxdivr with ⟨b, hxb, hbr⟩
  have hbPos : qLT qZero b := qlt_zero_of_nonneg_lt h0ainvx hxb
  have hxab : qLT x (qMul a b) :=
    qlt_mul_recompose_left hxb haPos hainv
  exact ⟨a, b, haPos, haq, hbPos, hbr, hxab⟩

end BOMA.R.QPositiveMultiplicativeApprox001

/- Rational preservation for the nonnegative-envelope Dedekind multiplication kernel. -/
namespace BOMA.R.DedekindNonnegativeMulEmbedding001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- Principal zero inclusion into a nonnegative principal rational cut. -/
theorem principal_zero_le_principal {q : QBOMA} (hq : qLE qZero q) :
    CutLE (principalCut qZero) (principalCut q) := by
  intro x hx
  exact (principalLE_iff_qLE qZero q).2 hq x hx

/-- For a nonnegative rational q, max(principal(q),0) is just principal(q). -/
theorem cutPosPart_principal_nonneg {q : QBOMA} (hq : qLE qZero q) :
    CutEquiv (cutPosPart (principalCut q)) (principalCut q) :=
  cutPosPart_of_nonneg (principal_zero_le_principal hq)

/-- The positive-envelope multiplication kernel agrees extensionally with
ordinary rational multiplication on nonnegative principal cuts. -/
theorem cutMulNonnegEnvelope_principal
    (q r : QBOMA)
    (hq : qLE qZero q)
    (hr : qLE qZero r) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut q) (principalCut r))
      (principalCut (qMul q r)) := by
  intro x
  constructor
  · intro hx
    rcases hx with hxNeg | hxProd
    · have hqrNonNeg : qLE qZero (qMul q r) := qmul_nonneg hq hr
      exact qlt_le_trans hxNeg hqrNonNeg
    · rcases hxProd with ⟨a, b, haPosCut, hbPosCut, h0a, h0b, hxab⟩
      have haQ : qLT a q :=
        ((cutPosPart_principal_nonneg hq) a).mp haPosCut
      have hbR : qLT b r :=
        ((cutPosPart_principal_nonneg hr) b).mp hbPosCut
      have hab_qb : qLE (qMul a b) (qMul q b) :=
        qmul_mono_right_nonneg haQ.1 h0b.1
      have hqb_qr : qLE (qMul q b) (qMul q r) :=
        qmul_mono_left_nonneg hbR.1 hq
      have hab_qr : qLE (qMul a b) (qMul q r) :=
        qle_trans hab_qb hqb_qr
      exact qlt_le_trans hxab hab_qr
  · intro hx
    rcases qlt_trichotomy x qZero with hxNeg | hxEq | hxPos
    · exact Or.inl hxNeg
    · have hx0 : qLE qZero x := by
        rw [hxEq]
        exact qle_refl qZero
      have hrNZ : qZero ≠ r := by
        intro h0r
        have hprod0 : qMul q r = qZero := by
          rw [← h0r, qMul_zero_right]
        have hxlt0 : qLT x qZero := by
          rw [← hprod0]
          exact hx
        have hxeq0 : x = qZero := qle_antisymm hxlt0.1 hx0
        exact hxlt0.2 hxeq0
      have hrPos : qLT qZero r := ⟨hr, hrNZ⟩
      rcases q_positive_product_inner_approx hx0 hrPos hx with
        ⟨a, b, h0a, haq, h0b, hbr, hxab⟩
      exact Or.inr ⟨a, b, Or.inl haq, Or.inl hbr, h0a, h0b, hxab⟩
    · have hx0 : qLE qZero x := hxPos.1
      have hrNZ : qZero ≠ r := by
        intro h0r
        have hprod0 : qMul q r = qZero := by
          rw [← h0r, qMul_zero_right]
        have hxlt0 : qLT x qZero := by
          rw [← hprod0]
          exact hx
        exact (qlt_asymm hxPos) hxlt0
      have hrPos : qLT qZero r := ⟨hr, hrNZ⟩
      rcases q_positive_product_inner_approx hx0 hrPos hx with
        ⟨a, b, h0a, haq, h0b, hbr, hxab⟩
      exact Or.inr ⟨a, b, Or.inl haq, Or.inl hbr, h0a, h0b, hxab⟩

/-- The formal nonnegative-envelope multiplication kernel preserves accepted
rational multiplication on nonnegative rational inputs. -/
theorem rMulNonnegEnvelope_rOfQ
    (q r : QBOMA)
    (hq : qLE qZero q)
    (hr : qLE qZero r) :
    rMulNonnegEnvelope (rOfQ q) (rOfQ r) = rOfQ (qMul q r) := by
  change
    rmk (cutMulNonnegEnvelope (principalCut q) (principalCut r)) =
    rmk (principalCut (qMul q r))
  exact rmk_sound (cutMulNonnegEnvelope_principal q r hq hr)

end BOMA.R.DedekindNonnegativeMulEmbedding001

/- Rational inverse-order interface used by the real reciprocal route. -/
namespace BOMA.R.QInverseOrder001

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- Existential inverse witnesses reverse strict order on positive rationals. -/
theorem q_inverse_strict_antitone
    {a b ainv binv : QBOMA}
    (h0a : qLT qZero a)
    (hab : qLT a b)
    (hainv : QInvRel a ainv)
    (hbinv : QInvRel b binv) :
    qLT binv ainv := by
  have h0b : qLT qZero b := qlt_trans h0a hab
  have h0ainv : qLT qZero ainv := qlt_zero_inverse h0a hainv
  have h0binv : qLT qZero binv := qlt_zero_inverse h0b hbinv
  have h1raw := qmul_lt_right_positive hab h0ainv
  have h1 : qLT qOne (qMul b ainv) := by
    unfold QInvRel at hainv
    rw [hainv] at h1raw
    exact h1raw
  have h2 := qmul_lt_left_positive h1 h0binv
  have hright : qMul binv (qMul b ainv) = ainv := by
    unfold QInvRel at hbinv
    calc
      qMul binv (qMul b ainv) = qMul (qMul binv b) ainv :=
        (qMul_assoc binv b ainv).symm
      _ = qMul (qMul b binv) ainv := by rw [qMul_comm binv b]
      _ = qMul qOne ainv := by rw [hbinv]
      _ = ainv := qMul_one_left ainv
  rw [qMul_one_right, hright] at h2
  exact h2

end BOMA.R.QInverseOrder001

/- Direct positive reciprocal candidate for the selected Dedekind route.
The lower predicate uses positive rational outside witnesses and their accepted
Q inverse witnesses. The source-positivity proof is consumed only by validity. -/
namespace BOMA.R.DedekindPositiveReciprocal001

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.QPositiveMultiplicativeApprox001
open BOMA.R.QInverseOrder001

/-- Local non-strict/strict transitivity used to keep this reciprocal gate
independent of later R-stage helper files. -/
theorem qle_lt_trans_recip {x y z : QBOMA}
    (hxy : qLE x y) (hyz : qLT y z) : qLT x z := by
  refine ⟨qle_trans hxy hyz.1, ?_⟩
  intro hxz
  have hzy : qLE z y := by
    rw [← hxz]
    exact hxy
  have hyzEq : y = z := qle_antisymm hyz.1 hzy
  exact hyz.2 hyzEq

/-- Representation-level witness that a lower cut contains a strictly positive rational. -/
def CutHasPositive (A : LowerCut) : Prop :=
  ∃ a : QBOMA, A.lower a ∧ qLT qZero a

/-- Any inside point of a lower cut lies strictly below any outside point. -/
theorem cut_inside_lt_outside
    {A : LowerCut} {a r : QBOMA}
    (ha : A.lower a)
    (hr : ¬ A.lower r) :
    qLT a r := by
  rcases qle_total a r with har | hra
  · refine ⟨har, ?_⟩
    intro harEq
    apply hr
    rw [← harEq]
    exact ha
  · exact False.elim (hr (A.downward ha hra))

/-- Direct reciprocal lower cut for a source cut with an explicit positive-inside witness.
The `hApos` proof does not occur in the lower predicate itself. -/
def cutRecipPos (A : LowerCut) (hApos : CutHasPositive A) : LowerCut where
  lower := fun q =>
    qLT q qZero ∨
    ∃ r rinv : QBOMA,
      ¬ A.lower r ∧
      qLT qZero r ∧
      QInvRel r rinv ∧
      qLT q rinv
  nonempty := by
    have hneg : qLT (qNeg qOne) qZero := by
      have ht := qlt_add_right qzero_lt_one (qNeg qOne)
      rw [qAdd_zero_left, qAdd_neg_right] at ht
      exact ht
    exact ⟨qNeg qOne, Or.inl hneg⟩
  proper := by
    rcases hApos with ⟨a, haA, h0a⟩
    have haNZ : a ≠ qZero := by
      intro ha0
      exact h0a.2 ha0.symm
    rcases q_inverse_exists a haNZ with ⟨ainv, hainv⟩
    refine ⟨ainv, ?_⟩
    intro hain
    rcases hain with hainNeg | ⟨r, rinv, hrOut, h0r, hrinv, hain_lt_rinv⟩
    · have h0ainv : qLT qZero ainv := qlt_zero_inverse h0a hainv
      exact (qlt_asymm h0ainv) hainNeg
    · have har : qLT a r := cut_inside_lt_outside haA hrOut
      have hrev : qLT rinv ainv :=
        q_inverse_strict_antitone h0a har hainv hrinv
      exact (qlt_asymm hain_lt_rinv) hrev
  downward := by
    intro p q hq hpq
    rcases hq with hqNeg | ⟨r, rinv, hrOut, h0r, hrinv, hqInv⟩
    · exact Or.inl (qle_lt_trans_recip hpq hqNeg)
    · exact Or.inr ⟨r, rinv, hrOut, h0r, hrinv, qle_lt_trans_recip hpq hqInv⟩
  rounded := by
    intro q hq
    rcases hq with hqNeg | ⟨r, rinv, hrOut, h0r, hrinv, hqInv⟩
    · rcases rational_order_dense hqNeg with ⟨m, hqm, hm0⟩
      exact ⟨m, Or.inl hm0, hqm⟩
    · rcases rational_order_dense hqInv with ⟨m, hqm, hmInv⟩
      exact ⟨m, Or.inr ⟨r, rinv, hrOut, h0r, hrinv, hmInv⟩, hqm⟩

/-- The reciprocal candidate is independent of which proof of source positivity is supplied. -/
theorem cutRecipPos_proof_independent
    (A : LowerCut)
    (h1 h2 : CutHasPositive A) :
    CutEquiv (cutRecipPos A h1) (cutRecipPos A h2) := by
  intro q
  rfl

/-- Extensional source identity transports the positive reciprocal candidate. -/
theorem cutRecipPos_respects
    {A B : LowerCut}
    (hAB : CutEquiv A B)
    (hApos : CutHasPositive A)
    (hBpos : CutHasPositive B) :
    CutEquiv (cutRecipPos A hApos) (cutRecipPos B hBpos) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | ⟨r, rinv, hrA, h0r, hrinv, hqinv⟩
    · exact Or.inl hqNeg
    · have hrB : ¬ B.lower r := by
        intro hBr
        exact hrA ((hAB r).mpr hBr)
      exact Or.inr ⟨r, rinv, hrB, h0r, hrinv, hqinv⟩
  · intro hq
    rcases hq with hqNeg | ⟨r, rinv, hrB, h0r, hrinv, hqinv⟩
    · exact Or.inl hqNeg
    · have hrA : ¬ A.lower r := by
        intro hAr
        exact hrB ((hAB r).mp hAr)
      exact Or.inr ⟨r, rinv, hrA, h0r, hrinv, hqinv⟩

end BOMA.R.DedekindPositiveReciprocal001

/- Rational preservation for the direct positive Dedekind reciprocal candidate. -/
namespace BOMA.R.DedekindPositiveReciprocalEmbedding001

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.QPositiveMultiplicativeApprox001
open BOMA.R.QInverseOrder001
open BOMA.R.DedekindPositiveReciprocal001

/-- A positive principal rational cut contains a strictly positive rational witness. -/
theorem principalCut_has_positive
    {q : QBOMA} (h0q : qLT qZero q) :
    CutHasPositive (principalCut q) := by
  rcases rational_order_dense h0q with ⟨a, h0a, haq⟩
  exact ⟨a, haq, h0a⟩

/-- An outside point of principalCut(q) lies at or above q. -/
theorem principal_outside_ge
    {q r : QBOMA}
    (hrOut : ¬ (principalCut q).lower r) :
    qLE q r := by
  rcases qle_total q r with hqr | hrq
  · exact hqr
  · by_cases heq : r = q
    · rw [heq]
      exact qle_refl q
    · have hrltq : qLT r q := ⟨hrq, heq⟩
      exact False.elim (hrOut hrltq)

/-- Two inverse witnesses for the same nonzero rational coincide. -/
theorem q_inverse_witness_unique
    {q a b : QBOMA}
    (hq0 : q ≠ qZero)
    (ha : QInvRel q a)
    (hb : QInvRel q b) : a = b := by
  unfold QInvRel at ha hb
  apply qMul_left_cancel_nonzero hq0
  exact ha.trans hb.symm

/-- On a positive principal rational cut, the direct reciprocal candidate is
exactly the principal cut of any accepted Q inverse witness. -/
theorem cutRecipPos_principal
    {q qinv : QBOMA}
    (h0q : qLT qZero q)
    (hqinv : QInvRel q qinv) :
    CutEquiv
      (cutRecipPos (principalCut q) (principalCut_has_positive h0q))
      (principalCut qinv) := by
  have h0qinv : qLT qZero qinv := qlt_zero_inverse h0q hqinv
  have hqNZ : q ≠ qZero := by
    intro hq0
    exact h0q.2 hq0.symm
  intro p
  constructor
  · intro hp
    rcases hp with hpNeg | ⟨r, rinv, hrOut, h0r, hrinv, hpRinv⟩
    · exact qlt_trans hpNeg h0qinv
    · have hqr : qLE q r := principal_outside_ge hrOut
      rcases qlt_trichotomy q r with hqrStrict | hEq | hrqStrict
      · have hrev : qLT rinv qinv :=
          q_inverse_strict_antitone h0q hqrStrict hqinv hrinv
        exact qlt_trans hpRinv hrev
      · have hsame : rinv = qinv := by
          have hrAsQ : QInvRel q rinv := by
            rw [hEq]
            exact hrinv
          exact q_inverse_witness_unique hqNZ hrAsQ hqinv
        rw [hsame] at hpRinv
        exact hpRinv
      · exact False.elim (hrOut hrqStrict)
  · intro hp
    rcases qlt_trichotomy p qZero with hpNeg | hpEq | h0p
    · exact Or.inl hpNeg
    · have hp0 : qLE qZero p := by
        rw [hpEq]
        exact qle_refl qZero
      rcases rational_order_dense hp with ⟨t, hpt, htqinv⟩
      have h0t : qLT qZero t := qlt_zero_of_nonneg_lt hp0 hpt
      have htNZ : t ≠ qZero := by
        intro ht0
        exact h0t.2 ht0.symm
      rcases q_inverse_exists t htNZ with ⟨r, htr⟩
      have hrt : QInvRel r t := by
        unfold QInvRel at htr ⊢
        calc
          qMul r t = qMul t r := qMul_comm r t
          _ = qOne := htr
      have hqinvq : QInvRel qinv q := by
        unfold QInvRel at hqinv ⊢
        calc
          qMul qinv q = qMul q qinv := qMul_comm qinv q
          _ = qOne := hqinv
      have hqr : qLT q r :=
        q_inverse_strict_antitone h0t htqinv htr hqinvq
      have hrOut : ¬ (principalCut q).lower r := by
        intro hrq
        exact (qlt_asymm hqr) hrq
      exact Or.inr ⟨r, t, hrOut,
        qlt_trans h0q hqr, hrt, hpt⟩
    · have hp0 : qLE qZero p := h0p.1
      rcases rational_order_dense hp with ⟨t, hpt, htqinv⟩
      have h0t : qLT qZero t := qlt_zero_of_nonneg_lt hp0 hpt
      have htNZ : t ≠ qZero := by
        intro ht0
        exact h0t.2 ht0.symm
      rcases q_inverse_exists t htNZ with ⟨r, htr⟩
      have hrt : QInvRel r t := by
        unfold QInvRel at htr ⊢
        calc
          qMul r t = qMul t r := qMul_comm r t
          _ = qOne := htr
      have hqinvq : QInvRel qinv q := by
        unfold QInvRel at hqinv ⊢
        calc
          qMul qinv q = qMul q qinv := qMul_comm qinv q
          _ = qOne := hqinv
      have hqr : qLT q r :=
        q_inverse_strict_antitone h0t htqinv htr hqinvq
      have hrOut : ¬ (principalCut q).lower r := by
        intro hrq
        exact (qlt_asymm hqr) hrq
      exact Or.inr ⟨r, t, hrOut,
        qlt_trans h0q hqr, hrt, hpt⟩

end BOMA.R.DedekindPositiveReciprocalEmbedding001

/- Anchored fine bracketing for positive Dedekind lower cuts.
This strengthens the accepted CutBracketApprox by preserving a chosen positive
inside anchor as a lower bound on the returned inside endpoint. -/
namespace BOMA.R.DedekindAnchoredBracket001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindCutBracket001
open BOMA.R.DedekindPositiveReciprocal001

/-- If a0 is inside A and a0≤b, keep b; otherwise use a0.
The resulting inside endpoint remains below the same outside r and its gap
is no larger than the original bracket gap. -/
theorem cut_bracket_approx_anchored
    (A : LowerCut)
    (a0 eps : QBOMA)
    (ha0 : A.lower a0)
    (heps : qLT qZero eps) :
    ∃ a r : QBOMA,
      A.lower a ∧
      ¬ A.lower r ∧
      qLE a0 a ∧
      qLT qZero (qAdd r (qNeg a)) ∧
      qLT (qAdd r (qNeg a)) eps := by
  rcases cut_bracket_approx A eps heps with
    ⟨b, r, hbA, hrOut, hgapPos, hgapSmall⟩
  rcases qle_total a0 b with h0b | hb0
  · exact ⟨b, r, hbA, hrOut, h0b, hgapPos, hgapSmall⟩
  · have ha0r : qLT a0 r := by
      rcases qle_total a0 r with h0r | hr0
      · refine ⟨h0r, ?_⟩
        intro heq
        apply hrOut
        rw [← heq]
        exact ha0
      · exact False.elim (hrOut (A.downward ha0 hr0))
    have hnewPosRaw : QPositive (qAdd r (qNeg a0)) :=
      positive_difference_of_lt ha0r
    have hnewPos : qLT qZero (qAdd r (qNeg a0)) :=
      ⟨hnewPosRaw.1, fun h => hnewPosRaw.2 h.symm⟩
    have hgapLE :
        qLE (qAdd r (qNeg a0)) (qAdd r (qNeg b)) := by
      have hneg : qLE (qNeg a0) (qNeg b) := qneg_reverses hb0
      have ht := qadd_mono_right hneg r
      rw [qAdd_comm (qNeg a0) r, qAdd_comm (qNeg b) r] at ht
      exact ht
    have hnewSmall : qLT (qAdd r (qNeg a0)) eps :=
      qle_lt_trans_recip hgapLE hgapSmall
    exact ⟨a0, r, ha0, hrOut, qle_refl a0, hnewPos, hnewSmall⟩

end BOMA.R.DedekindAnchoredBracket001

/- Rational reciprocal-gap estimate revision 004.
Preserves 001-003 as PDSA proof-engineering history. -/
namespace BOMA.R.QReciprocalGap004

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.QPositiveMultiplicativeApprox001

 theorem qlt_le_trans_gap {x y z : QBOMA}
    (hxy : qLT x y) (hyz : qLE y z) : qLT x z := by
  refine ⟨qle_trans hxy.1 hyz, ?_⟩
  intro hxz
  have hzy : qLE z y := by
    rw [← hxz]
    exact hxy.1
  have hyzEq : y = z := qle_antisymm hyz hzy
  have hxyEq : x = y := hxz.trans hyzEq.symm
  exact hxy.2 hxyEq

 theorem q_add_one_minus (q : QBOMA) :
    qAdd q (qAdd qOne (qNeg q)) = qOne := by
  calc
    qAdd q (qAdd qOne (qNeg q)) = qAdd qOne (qAdd q (qNeg q)) := by
      calc
        qAdd q (qAdd qOne (qNeg q)) = qAdd (qAdd q qOne) (qNeg q) :=
          (qAdd_assoc q qOne (qNeg q)).symm
        _ = qAdd (qAdd qOne q) (qNeg q) :=
          congrArg (fun t => qAdd t (qNeg q)) (qAdd_comm q qOne)
        _ = qAdd qOne (qAdd q (qNeg q)) := qAdd_assoc qOne q (qNeg q)
    _ = qAdd qOne qZero := by rw [qAdd_neg_right]
    _ = qOne := qAdd_zero_right qOne

 theorem q_add_gap (a r : QBOMA) :
    qAdd a (qAdd r (qNeg a)) = r := by
  calc
    qAdd a (qAdd r (qNeg a)) = qAdd r (qAdd a (qNeg a)) := by
      calc
        qAdd a (qAdd r (qNeg a)) = qAdd (qAdd a r) (qNeg a) :=
          (qAdd_assoc a r (qNeg a)).symm
        _ = qAdd (qAdd r a) (qNeg a) :=
          congrArg (fun t => qAdd t (qNeg a)) (qAdd_comm a r)
        _ = qAdd r (qAdd a (qNeg a)) := qAdd_assoc r a (qNeg a)
    _ = qAdd r qZero := by rw [qAdd_neg_right]
    _ = r := qAdd_zero_right r

 theorem q_lt_mul_inverse_of_small_gap
    {q a0 a r rinv : QBOMA}
    (h0q : qLE qZero q)
    (hq1 : qLT q qOne)
    (h0a0 : qLT qZero a0)
    (ha0a : qLE a0 a)
    (h0r : qLT qZero r)
    (hgapPos : qLT qZero (qAdd r (qNeg a)))
    (hgapSmall : qLT (qAdd r (qNeg a)) (qMul (qAdd qOne (qNeg q)) a0))
    (hrinv : QInvRel r rinv) :
    qLT q (qMul a rinv) := by
  let g := qAdd r (qNeg a)
  let omq := qAdd qOne (qNeg q)
  have homqPos : QPositive omq := by
    unfold omq
    exact positive_difference_of_lt hq1
  have hgapPos' : qLT qZero g := hgapPos
  have hgapSmall' : qLT g (qMul omq a0) := hgapSmall
  have hbound : qLE (qMul omq a0) (qMul omq a) :=
    qmul_mono_left_nonneg ha0a homqPos.1
  have hgapToA : qLT g (qMul omq a) :=
    qlt_le_trans_gap hgapSmall' hbound
  have hqg : qLT (qMul q g) g := by
    have ht := qmul_lt_right_positive hq1 hgapPos'
    rw [qMul_one_left] at ht
    exact ht
  have hqa_qag :
      qLT (qAdd (qMul q a) (qMul q g)) (qAdd (qMul q a) g) := by
    have ht := qlt_add_right hqg (qMul q a)
    rw [qAdd_comm (qMul q g) (qMul q a), qAdd_comm g (qMul q a)] at ht
    exact ht
  have hqag_final :
      qLT (qAdd (qMul q a) g) (qAdd (qMul q a) (qMul omq a)) := by
    have ht := qlt_add_right hgapToA (qMul q a)
    rw [qAdd_comm g (qMul q a), qAdd_comm (qMul omq a) (qMul q a)] at ht
    exact ht
  have hsumA : qAdd (qMul q a) (qMul omq a) = a := by
    calc
      qAdd (qMul q a) (qMul omq a) = qMul (qAdd q omq) a :=
        (qMul_add_left q omq a).symm
      _ = qMul qOne a := by rw [q_add_one_minus]
      _ = a := qMul_one_left a
  have hqexpand : qMul q r = qAdd (qMul q a) (qMul q g) := by
    have hrag : qAdd a g = r := by
      unfold g
      exact q_add_gap a r
    calc
      qMul q r = qMul q (qAdd a g) := by rw [hrag]
      _ = qAdd (qMul q a) (qMul q g) := qMul_add_right q a g
  have hmid :
      qLT (qAdd (qMul q a) (qMul q g))
          (qAdd (qMul q a) (qMul omq a)) :=
    qlt_trans hqa_qag hqag_final
  have hqr : qLT (qMul q r) a := by
    have ht := hmid
    rw [← hqexpand, hsumA] at ht
    exact ht
  have h0rinv : qLT qZero rinv := qlt_zero_inverse h0r hrinv
  have ht := qmul_lt_right_positive hqr h0rinv
  have hleft : qMul (qMul q r) rinv = q := by
    calc
      qMul (qMul q r) rinv = qMul q (qMul r rinv) := qMul_assoc q r rinv
      _ = qMul q qOne := by rw [hrinv]
      _ = q := qMul_one_right q
  rw [hleft] at ht
  exact ht

end BOMA.R.QReciprocalGap004

/- Positive inverse-product revision 004.
Preserves earlier revisions; fixes only proof-witness scope after destructuring. -/
namespace BOMA.R.DedekindPositiveInverseProduct004

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.QPositiveMultiplicativeApprox001
open BOMA.R.DedekindPositiveReciprocal001
open BOMA.R.DedekindAnchoredBracket001
open BOMA.R.QReciprocalGap004

 theorem principal_one_mem_mul_recip_of_nonneg
    (A : LowerCut)
    (hApos : CutHasPositive A)
    {q : QBOMA}
    (h0q : qLE qZero q)
    (hq1 : qLT q qOne) :
    (cutMulNonnegEnvelope A (cutRecipPos A hApos)).lower q := by
  have hAposOrig : CutHasPositive A := hApos
  rcases hApos with ⟨a0, ha0A, h0a0⟩
  let omq := qAdd qOne (qNeg q)
  have homqRaw : QPositive omq := by
    unfold omq
    exact positive_difference_of_lt hq1
  have homq : qLT qZero omq :=
    ⟨homqRaw.1, fun hz => homqRaw.2 hz.symm⟩
  let eps := qMul omq a0
  have heps : qLT qZero eps := by
    have ht := qmul_lt_right_positive homq h0a0
    unfold eps
    rw [qMul_zero_left] at ht
    exact ht
  rcases cut_bracket_approx_anchored A a0 eps ha0A heps with
    ⟨a, r, haA, hrOut, ha0a, hgapPos, hgapSmall⟩
  have h0a : qLT qZero a := qlt_le_trans_gap h0a0 ha0a
  have har : qLT a r := cut_inside_lt_outside haA hrOut
  have h0r : qLT qZero r := qlt_trans h0a har
  have hrNZ : r ≠ qZero := by
    intro hr0
    exact h0r.2 hr0.symm
  rcases q_inverse_exists r hrNZ with ⟨rinv, hrinv⟩
  have hratio : qLT q (qMul a rinv) := by
    apply q_lt_mul_inverse_of_small_gap h0q hq1 h0a0 ha0a h0r hgapPos
    · unfold eps omq at hgapSmall
      exact hgapSmall
    · exact hrinv
  have h0rinv : qLT qZero rinv := qlt_zero_inverse h0r hrinv
  rcases q_positive_product_inner_approx h0q h0rinv hratio with
    ⟨a', b, h0a', ha'a, h0b, hbInv, hqab⟩
  have ha'A : A.lower a' := A.downward haA ha'a.1
  have hLocalPos : CutHasPositive A := ⟨a0, ha0A, h0a0⟩
  have hbLocal : (cutRecipPos A hLocalPos).lower b :=
    Or.inr ⟨r, rinv, hrOut, h0r, hrinv, hbInv⟩
  have hProofEq : CutEquiv (cutRecipPos A hLocalPos) (cutRecipPos A hAposOrig) :=
    cutRecipPos_proof_independent A hLocalPos hAposOrig
  have hbRecip : (cutRecipPos A hAposOrig).lower b := (hProofEq b).mp hbLocal
  exact Or.inr ⟨a', b, Or.inl ha'A, Or.inl hbRecip, h0a', h0b, hqab⟩

 theorem cutMul_recipPos_equiv_one
    (A : LowerCut)
    (hApos : CutHasPositive A) :
    CutEquiv (cutMulNonnegEnvelope A (cutRecipPos A hApos)) (principalCut qOne) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact qlt_trans hqNeg qzero_lt_one
    · rcases hqProd with ⟨a, b, haPos, hbPos, h0a, h0b, hqab⟩
      have haA : A.lower a := by
        rcases haPos with haA | haNeg
        · exact haA
        · exact False.elim ((qlt_asymm h0a) haNeg)
      have hbRecip : (cutRecipPos A hApos).lower b := by
        rcases hbPos with hbRecip | hbNeg
        · exact hbRecip
        · exact False.elim ((qlt_asymm h0b) hbNeg)
      rcases hbRecip with hbNeg | ⟨r, rinv, hrOut, h0r, hrinv, hbInv⟩
      · exact False.elim ((qlt_asymm h0b) hbNeg)
      · have har : qLT a r := cut_inside_lt_outside haA hrOut
        have h0rinv : qLT qZero rinv := qlt_zero_inverse h0r hrinv
        have hab_arinv : qLT (qMul a b) (qMul a rinv) := qmul_lt_left_positive hbInv h0a
        have har_rinv : qLT (qMul a rinv) (qMul r rinv) := qmul_lt_right_positive har h0rinv
        have hab1 : qLT (qMul a b) qOne := by
          have ht := qlt_trans hab_arinv har_rinv
          unfold QInvRel at hrinv
          rw [hrinv] at ht
          exact ht
        exact qlt_trans hqab hab1
  · intro hq1
    rcases qlt_trichotomy q qZero with hqNeg | hqEq | h0qStrict
    · exact Or.inl hqNeg
    · have h0q : qLE qZero q := by
        rw [hqEq]
        exact qle_refl qZero
      exact principal_one_mem_mul_recip_of_nonneg A hApos h0q hq1
    · exact principal_one_mem_mul_recip_of_nonneg A hApos h0qStrict.1 hq1

end BOMA.R.DedekindPositiveInverseProduct004

/- Corrected positive representative witnesses for nonzero nonnegative selected reals.
Revision 002 preserves revision 001 as a proof-engineering learning artifact. -/
namespace BOMA.R.DedekindPositiveRepresentative002

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositiveReciprocal001

/-- A cut containing one positive rational contains the entire principal zero cut. -/
theorem cut_zero_le_of_has_positive
    {A : LowerCut}
    (hApos : CutHasPositive A) :
    CutLE (principalCut qZero) A := by
  rcases hApos with ⟨a, haA, h0a⟩
  intro q hq0
  exact A.downward haA (qlt_trans hq0 h0a).1

/-- A nonnegative cut that is not extensionally zero must contain a positive rational.
The witness extraction uses Classical.byContradiction explicitly. -/
theorem cut_has_positive_of_nonneg_ne_zero
    {A : LowerCut}
    (h0A : CutLE (principalCut qZero) A)
    (hne : ¬ CutEquiv A (principalCut qZero)) :
    CutHasPositive A := by
  apply Classical.byContradiction
  intro hNoPos
  apply hne
  intro q
  constructor
  · intro hqA
    rcases qlt_trichotomy q qZero with hq0 | heq | h0q
    · exact hq0
    · rcases A.rounded hqA with ⟨b, hbA, hqb⟩
      have h0b : qLT qZero b := by
        rw [heq] at hqb
        exact hqb
      exact False.elim (hNoPos ⟨b, hbA, h0b⟩)
    · exact False.elim (hNoPos ⟨q, hqA, h0q⟩)
  · intro hq0
    exact h0A q hq0

/-- Every nonzero nonnegative formal real has a representative with an explicit
positive rational inside witness. -/
theorem r_nonneg_nonzero_positive_rep
    {x : RBOMA}
    (h0x : rLE rZero x)
    (hx0 : x ≠ rZero) :
    ∃ A : LowerCut, ∃ hApos : CutHasPositive A,
      x = rmk A := by
  refine Quotient.inductionOn x ?_ h0x hx0
  intro A h0A hAne
  have h0Acut : CutLE (principalCut qZero) A := by
    change rLE (rmk (principalCut qZero)) (rmk A) at h0A
    exact (rLE_mk_iff (principalCut qZero) A).1 h0A
  have hneCut : ¬ CutEquiv A (principalCut qZero) := by
    intro hEq
    apply hAne
    change rmk A = rmk (principalCut qZero)
    exact rmk_sound hEq
  have hApos : CutHasPositive A :=
    cut_has_positive_of_nonneg_ne_zero h0Acut hneCut
  exact ⟨A, hApos, rfl⟩

end BOMA.R.DedekindPositiveRepresentative002

/- Signed Dedekind multiplication candidate built compositionally from positive envelopes.
The operation definition contains no sign-case `if`; sign analysis appears only in proofs. -/
namespace BOMA.R.DedekindSignedMulCandidate001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulEmbedding001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- If a principal rational cut is nonpositive, its positive envelope is the zero cut. -/
theorem cutPosPart_principal_nonpos {q : QBOMA} (hq : qLE q qZero) :
    CutEquiv (cutPosPart (principalCut q)) (principalCut qZero) := by
  intro x
  constructor
  · intro hx
    rcases hx with hxq | hx0
    · exact qlt_le_trans hxq hq
    · exact hx0
  · intro hx0
    exact Or.inr hx0

/-- If the left rational input is nonpositive, the nonnegative-envelope kernel is zero. -/
theorem cutMulNonnegEnvelope_principal_left_nonpos
    (q r : QBOMA) (hq : qLE q qZero) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut q) (principalCut r))
      (principalCut qZero) := by
  intro x
  constructor
  · intro hx
    rcases hx with hxNeg | hxProd
    · exact hxNeg
    · rcases hxProd with ⟨a, b, ha, _hb, h0a, _h0b, _hxab⟩
      have ha0 : qLT a qZero :=
        ((cutPosPart_principal_nonpos hq) a).mp ha
      exact False.elim ((qlt_asymm h0a) ha0)
  · intro hx0
    exact Or.inl hx0

/-- If the right rational input is nonpositive, the kernel is zero. -/
theorem cutMulNonnegEnvelope_principal_right_nonpos
    (q r : QBOMA) (hr : qLE r qZero) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut q) (principalCut r))
      (principalCut qZero) := by
  exact cutEquiv_trans
    (cutMulNonnegEnvelope_comm (principalCut q) (principalCut r))
    (cutMulNonnegEnvelope_principal_left_nonpos r q hr)

/-- Quotient form of left nonpositive annihilation on rational inputs. -/
theorem rMulNonnegEnvelope_rOfQ_left_nonpos
    (q r : QBOMA) (hq : qLE q qZero) :
    rMulNonnegEnvelope (rOfQ q) (rOfQ r) = rZero := by
  change
    rmk (cutMulNonnegEnvelope (principalCut q) (principalCut r)) =
    rmk (principalCut qZero)
  exact rmk_sound (cutMulNonnegEnvelope_principal_left_nonpos q r hq)

/-- Quotient form of right nonpositive annihilation on rational inputs. -/
theorem rMulNonnegEnvelope_rOfQ_right_nonpos
    (q r : QBOMA) (hr : qLE r qZero) :
    rMulNonnegEnvelope (rOfQ q) (rOfQ r) = rZero := by
  change
    rmk (cutMulNonnegEnvelope (principalCut q) (principalCut r)) =
    rmk (principalCut qZero)
  exact rmk_sound (cutMulNonnegEnvelope_principal_right_nonpos q r hr)

/-- Negation sends nonnegative rationals to nonpositive rationals. -/
theorem qneg_nonpos_of_nonneg {q : QBOMA} (hq : qLE qZero q) :
    qLE (qNeg q) qZero := by
  have h := qneg_reverses hq
  rw [qNeg_zero] at h
  exact h

/-- Negation sends nonpositive rationals to nonnegative rationals. -/
theorem qneg_nonneg_of_nonpos {q : QBOMA} (hq : qLE q qZero) :
    qLE qZero (qNeg q) := by
  have h := qneg_reverses hq
  rw [qNeg_zero] at h
  exact h

/-- Multiplying a negated left factor negates the rational product. -/
theorem qMul_neg_left (q r : QBOMA) :
    qMul (qNeg q) r = qNeg (qMul q r) := by
  apply qAdd_inverse_unique
  calc
    qAdd (qMul q r) (qMul (qNeg q) r) =
        qMul (qAdd q (qNeg q)) r := (qMul_add_left q (qNeg q) r).symm
    _ = qMul qZero r := by rw [qAdd_neg_right]
    _ = qZero := qMul_zero_left r

/-- Multiplying a negated right factor negates the rational product. -/
theorem qMul_neg_right (q r : QBOMA) :
    qMul q (qNeg r) = qNeg (qMul q r) := by
  calc
    qMul q (qNeg r) = qMul (qNeg r) q := qMul_comm q (qNeg r)
    _ = qNeg (qMul r q) := qMul_neg_left r q
    _ = qNeg (qMul q r) := congrArg qNeg (qMul_comm r q)

/-- Product of two rational negatives is the original product. -/
theorem qMul_neg_neg (q r : QBOMA) :
    qMul (qNeg q) (qNeg r) = qMul q r := by
  calc
    qMul (qNeg q) (qNeg r) = qNeg (qMul q (qNeg r)) :=
      qMul_neg_left q (qNeg r)
    _ = qNeg (qNeg (qMul q r)) := congrArg qNeg (qMul_neg_right q r)
    _ = qMul q r := qNeg_involutive (qMul q r)

/-- Zero is fixed by formal real negation. -/
@[simp] theorem rNeg_zero : rNeg rZero = rZero := by
  symm
  exact rAdd_inverse_unique
    (x := rZero)
    (y := rZero)
    (rAdd_zero_left rZero)

/-- Candidate A: signed multiplication obtained by bilinear positive/negative-part expansion.
`rMulNonnegEnvelope` internally applies positive envelopes to its inputs.
No proposition-valued sign decision occurs in this definition. -/
def rMulCandidate (x y : RBOMA) : RBOMA :=
  rAdd
    (rAdd
      (rMulNonnegEnvelope x y)
      (rMulNonnegEnvelope (rNeg x) (rNeg y)))
    (rNeg
      (rAdd
        (rMulNonnegEnvelope x (rNeg y))
        (rMulNonnegEnvelope (rNeg x) y)))

/-- Candidate A preserves accepted rational multiplication for all rational signs.
Sign splitting is confined to this proof; the operation definition itself is sign-case-free. -/
theorem rMulCandidate_rOfQ (q r : QBOMA) :
    rMulCandidate (rOfQ q) (rOfQ r) = rOfQ (qMul q r) := by
  rcases qle_total qZero q with hqNonNeg | hqNonPos
  · rcases qle_total qZero r with hrNonNeg | hrNonPos
    · have hnq : qLE (qNeg q) qZero := qneg_nonpos_of_nonneg hqNonNeg
      have hnr : qLE (qNeg r) qZero := qneg_nonpos_of_nonneg hrNonNeg
      have hPP := rMulNonnegEnvelope_rOfQ q r hqNonNeg hrNonNeg
      have hNN := rMulNonnegEnvelope_rOfQ_left_nonpos (qNeg q) (qNeg r) hnq
      have hPN := rMulNonnegEnvelope_rOfQ_right_nonpos q (qNeg r) hnr
      have hNP := rMulNonnegEnvelope_rOfQ_left_nonpos (qNeg q) r hnq
      unfold rMulCandidate
      rw [rOfQ_neg q, rOfQ_neg r, hPP, hNN, hPN, hNP]
      rw [rAdd_zero_right, rAdd_zero_left, rNeg_zero, rAdd_zero_right]
    · have hnq : qLE (qNeg q) qZero := qneg_nonpos_of_nonneg hqNonNeg
      have hnr : qLE qZero (qNeg r) := qneg_nonneg_of_nonpos hrNonPos
      have hPP := rMulNonnegEnvelope_rOfQ_right_nonpos q r hrNonPos
      have hNN := rMulNonnegEnvelope_rOfQ_left_nonpos (qNeg q) (qNeg r) hnq
      have hPN := rMulNonnegEnvelope_rOfQ q (qNeg r) hqNonNeg hnr
      have hNP := rMulNonnegEnvelope_rOfQ_left_nonpos (qNeg q) r hnq
      unfold rMulCandidate
      rw [rOfQ_neg q, rOfQ_neg r, hPP, hNN, hPN, hNP]
      rw [rAdd_zero_left, rAdd_zero_right]
      rw [rOfQ_neg]
      rw [rAdd_zero_left]
      apply congrArg rOfQ
      calc
        qNeg (qMul q (qNeg r)) = qNeg (qNeg (qMul q r)) :=
          congrArg qNeg (qMul_neg_right q r)
        _ = qMul q r := qNeg_involutive _
  · rcases qle_total qZero r with hrNonNeg | hrNonPos
    · have hnq : qLE qZero (qNeg q) := qneg_nonneg_of_nonpos hqNonPos
      have hnr : qLE (qNeg r) qZero := qneg_nonpos_of_nonneg hrNonNeg
      have hPP := rMulNonnegEnvelope_rOfQ_left_nonpos q r hqNonPos
      have hNN := rMulNonnegEnvelope_rOfQ_right_nonpos (qNeg q) (qNeg r) hnr
      have hPN := rMulNonnegEnvelope_rOfQ_left_nonpos q (qNeg r) hqNonPos
      have hNP := rMulNonnegEnvelope_rOfQ (qNeg q) r hnq hrNonNeg
      unfold rMulCandidate
      rw [rOfQ_neg q, rOfQ_neg r, hPP, hNN, hPN, hNP]
      rw [rAdd_zero_left, rAdd_zero_left]
      rw [rAdd_zero_left]
      rw [rOfQ_neg]
      apply congrArg rOfQ
      calc
        qNeg (qMul (qNeg q) r) = qNeg (qNeg (qMul q r)) :=
          congrArg qNeg (qMul_neg_left q r)
        _ = qMul q r := qNeg_involutive _
    · have hnq : qLE qZero (qNeg q) := qneg_nonneg_of_nonpos hqNonPos
      have hnr : qLE qZero (qNeg r) := qneg_nonneg_of_nonpos hrNonPos
      have hPP := rMulNonnegEnvelope_rOfQ_left_nonpos q r hqNonPos
      have hNN := rMulNonnegEnvelope_rOfQ (qNeg q) (qNeg r) hnq hnr
      have hPN := rMulNonnegEnvelope_rOfQ_left_nonpos q (qNeg r) hqNonPos
      have hNP := rMulNonnegEnvelope_rOfQ_right_nonpos (qNeg q) r hrNonPos
      unfold rMulCandidate
      rw [rOfQ_neg q, rOfQ_neg r, hPP, hNN, hPN, hNP]
      rw [rAdd_zero_left, rAdd_zero_right, rNeg_zero, rAdd_zero_right]
      apply congrArg rOfQ
      exact qMul_neg_neg q r

end BOMA.R.DedekindSignedMulCandidate001

/- Algebraic laws for the nonnegative-envelope Dedekind multiplication kernel.
These laws are proved before lifting the selected signed multiplication candidate. -/
namespace BOMA.R.DedekindNonnegativeMulLaws001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- The principal zero cut is included in every nonnegative multiplication kernel. -/
theorem cutZero_le_mulNonneg (A B : LowerCut) :
    CutLE (principalCut qZero) (cutMulNonnegEnvelope A B) := by
  intro q hq
  exact Or.inl hq

/-- A nonnegative multiplication kernel is already fixed by positive-envelope closure. -/
theorem cutPosPart_mulNonneg (A B : LowerCut) :
    CutEquiv
      (cutPosPart (cutMulNonnegEnvelope A B))
      (cutMulNonnegEnvelope A B) :=
  cutPosPart_of_nonneg (cutZero_le_mulNonneg A B)

/-- Zero annihilates the nonnegative kernel on the left. -/
theorem cutMulNonnegEnvelope_zero_left (A : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut qZero) A)
      (principalCut qZero) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact hqNeg
    · rcases hqProd with ⟨a, _b, ha, _hb, h0a, _h0b, _hq⟩
      have haNeg : qLT a qZero := by
        rcases ha with ha0 | ha0
        · exact ha0
        · exact ha0
      exact False.elim ((qlt_asymm h0a) haNeg)
  · intro hq
    exact Or.inl hq

/-- Zero annihilates the nonnegative kernel on the right. -/
theorem cutMulNonnegEnvelope_zero_right (A : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope A (principalCut qZero))
      (principalCut qZero) :=
  cutEquiv_trans
    (cutMulNonnegEnvelope_comm A (principalCut qZero))
    (cutMulNonnegEnvelope_zero_left A)

@[simp] theorem rMulNonnegEnvelope_zero_left (x : RBOMA) :
    rMulNonnegEnvelope rZero x = rZero := by
  refine Quotient.inductionOn x ?_
  intro A
  change
    rmk (cutMulNonnegEnvelope (principalCut qZero) A) =
    rmk (principalCut qZero)
  exact rmk_sound (cutMulNonnegEnvelope_zero_left A)

@[simp] theorem rMulNonnegEnvelope_zero_right (x : RBOMA) :
    rMulNonnegEnvelope x rZero = rZero := by
  rw [rMulNonnegEnvelope_comm]
  exact rMulNonnegEnvelope_zero_left x

/-- A rational is either strictly negative or nonnegative. This packages the
sign split needed only inside proof logic, not in the multiplication definition. -/
theorem qlt_zero_or_nonneg (q : QBOMA) :
    qLT q qZero ∨ qLE qZero q := by
  rcases qlt_trichotomy q qZero with hneg | heq | hpos
  · exact Or.inl hneg
  · right
    rw [heq]
    exact qle_refl qZero
  · exact Or.inr hpos.1

/-- Multiplying the principal one cut by an arbitrary input returns the
positive envelope of that input. This is the correct unit law for the
nonnegative kernel before the signed decomposition is reassembled. -/
theorem cutMulNonnegEnvelope_one_left (A : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut qOne) A)
      (cutPosPart A) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact Or.inr hqNeg
    · rcases hqProd with ⟨a, b, ha, hb, h0a, h0b, hqab⟩
      have ha1 : qLT a qOne := by
        rcases ha with ha1 | ha0
        · exact ha1
        · exact qlt_trans ha0 qzero_lt_one
      have hab_b : qLT (qMul a b) b := by
        have ht := qmul_lt_right_positive ha1 h0b
        rw [qMul_one_left] at ht
        exact ht
      have hqb : qLT q b := qlt_trans hqab hab_b
      exact (cutPosPart A).downward hb hqb.1
  · intro hq
    rcases qlt_zero_or_nonneg q with hqNeg | h0q
    · exact Or.inl hqNeg
    · rcases (cutPosPart A).rounded hq with ⟨b, hb, hqb⟩
      have h0b : qLT qZero b := qlt_zero_of_nonneg_lt h0q hqb
      have hq1b : qLT q (qMul qOne b) := by
        rw [qMul_one_left]
        exact hqb
      rcases q_positive_product_inner_approx h0q h0b hq1b with
        ⟨a, b', h0a, ha1, h0b', hb'b, hqab'⟩
      have ha : (cutPosPart (principalCut qOne)).lower a :=
        Or.inl ha1
      have hb' : (cutPosPart A).lower b' :=
        (cutPosPart A).downward hb hb'b.1
      exact Or.inr ⟨a, b', ha, hb', h0a, h0b', hqab'⟩

/-- Right one law for the nonnegative kernel. -/
theorem cutMulNonnegEnvelope_one_right (A : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope A (principalCut qOne))
      (cutPosPart A) :=
  cutEquiv_trans
    (cutMulNonnegEnvelope_comm A (principalCut qOne))
    (cutMulNonnegEnvelope_one_left A)

theorem rMulNonnegEnvelope_one_left (x : RBOMA) :
    rMulNonnegEnvelope rOne x = rPosPart x := by
  refine Quotient.inductionOn x ?_
  intro A
  change
    rmk (cutMulNonnegEnvelope (principalCut qOne) A) =
    rmk (cutPosPart A)
  exact rmk_sound (cutMulNonnegEnvelope_one_left A)

theorem rMulNonnegEnvelope_one_right (x : RBOMA) :
    rMulNonnegEnvelope x rOne = rPosPart x := by
  rw [rMulNonnegEnvelope_comm]
  exact rMulNonnegEnvelope_one_left x

/-- Associativity of the nonnegative-envelope kernel.
The strict witness semantics requires a fresh interior witness when reassociating;
that witness is supplied by the previously certified Q multiplicative-approximation interface. -/
theorem cutMulNonnegEnvelope_assoc (A B C : LowerCut) :
    CutEquiv
      (cutMulNonnegEnvelope (cutMulNonnegEnvelope A B) C)
      (cutMulNonnegEnvelope A (cutMulNonnegEnvelope B C)) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact Or.inl hqNeg
    · rcases hqProd with ⟨u, c, huPosPart, hc, h0u, h0c, hquc⟩
      have huK : (cutMulNonnegEnvelope A B).lower u :=
        ((cutPosPart_mulNonneg A B) u).mp huPosPart
      rcases huK with huNeg | huProd
      · exact False.elim ((qlt_asymm h0u) huNeg)
      · rcases huProd with ⟨a, b, ha, hb, h0a, h0b, huab⟩
        have huc_abc : qLT (qMul u c) (qMul (qMul a b) c) :=
          qmul_lt_right_positive huab h0c
        have hq_abc0 : qLT q (qMul (qMul a b) c) :=
          qlt_trans hquc huc_abc
        have hq_abc : qLT q (qMul a (qMul b c)) := by
          rw [← qMul_assoc a b c]
          exact hq_abc0
        rcases qlt_zero_or_nonneg q with hq0 | h0q
        · exact Or.inl hq0
        · have hbcPos : qLT qZero (qMul b c) := by
            have ht := qmul_lt_right_positive h0b h0c
            rw [qMul_zero_left] at ht
            exact ht
          rcases q_positive_product_inner_approx h0q hbcPos hq_abc with
            ⟨a', w, h0a', ha'a, h0w, hwbc, hqaw⟩
          have ha' : (cutPosPart A).lower a' :=
            (cutPosPart A).downward ha ha'a.1
          have hwK : (cutMulNonnegEnvelope B C).lower w :=
            Or.inr ⟨b, c, hb, hc, h0b, h0c, hwbc⟩
          have hwPosPart :
              (cutPosPart (cutMulNonnegEnvelope B C)).lower w :=
            Or.inl hwK
          exact Or.inr ⟨a', w, ha', hwPosPart, h0a', h0w, hqaw⟩
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact Or.inl hqNeg
    · rcases hqProd with ⟨a, v, ha, hvPosPart, h0a, h0v, hqav⟩
      have hvK : (cutMulNonnegEnvelope B C).lower v :=
        ((cutPosPart_mulNonneg B C) v).mp hvPosPart
      rcases hvK with hvNeg | hvProd
      · exact False.elim ((qlt_asymm h0v) hvNeg)
      · rcases hvProd with ⟨b, c, hb, hc, h0b, h0c, hvbc⟩
        have hav_abc : qLT (qMul a v) (qMul a (qMul b c)) :=
          qmul_lt_left_positive hvbc h0a
        have hq_abc0 : qLT q (qMul a (qMul b c)) :=
          qlt_trans hqav hav_abc
        have hq_abc : qLT q (qMul (qMul a b) c) := by
          rw [qMul_assoc a b c]
          exact hq_abc0
        rcases qlt_zero_or_nonneg q with hq0 | h0q
        · exact Or.inl hq0
        · rcases q_positive_product_inner_approx h0q h0c hq_abc with
            ⟨u, c', h0u, huab, h0c', hc'c, hquc'⟩
          have huK : (cutMulNonnegEnvelope A B).lower u :=
            Or.inr ⟨a, b, ha, hb, h0a, h0b, huab⟩
          have huPosPart :
              (cutPosPart (cutMulNonnegEnvelope A B)).lower u :=
            Or.inl huK
          have hc' : (cutPosPart C).lower c' :=
            (cutPosPart C).downward hc hc'c.1
          exact Or.inr ⟨u, c', huPosPart, hc', h0u, h0c', hquc'⟩

/-- Quotient associativity of the nonnegative multiplication kernel. -/
theorem rMulNonnegEnvelope_assoc (x y z : RBOMA) :
    rMulNonnegEnvelope (rMulNonnegEnvelope x y) z =
    rMulNonnegEnvelope x (rMulNonnegEnvelope y z) := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  refine Quotient.inductionOn z ?_
  intro C
  change
    rmk (cutMulNonnegEnvelope (cutMulNonnegEnvelope A B) C) =
    rmk (cutMulNonnegEnvelope A (cutMulNonnegEnvelope B C))
  exact rmk_sound (cutMulNonnegEnvelope_assoc A B C)

end BOMA.R.DedekindNonnegativeMulLaws001

/- Distributivity of the nonnegative-envelope multiplication kernel over
addition on nonnegative right inputs. -/
namespace BOMA.R.DedekindNonnegativeMulDistributivity001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionEmbedding001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulLaws001
open BOMA.R.QPositiveMultiplicativeApprox001

/-- Strict addition monotonicity in both arguments. -/
theorem qadd_lt_mono {a a' b b' : QBOMA}
    (ha : qLT a a') (hb : qLT b b') :
    qLT (qAdd a b) (qAdd a' b') := by
  have h1 : qLT (qAdd a b) (qAdd a' b) := qlt_add_right ha b
  have h2raw : qLT (qAdd b a') (qAdd b' a') := qlt_add_right hb a'
  have h2 : qLT (qAdd a' b) (qAdd a' b') := by
    rw [qAdd_comm a' b, qAdd_comm a' b']
    exact h2raw
  exact qlt_trans h1 h2

/-- Any strict inequality below a sum admits two strictly interior summands. -/
theorem q_sum_inner_approx {q u v : QBOMA}
    (h : qLT q (qAdd u v)) :
    ∃ u' v' : QBOMA,
      qLT u' u ∧ qLT v' v ∧ qLT q (qAdd u' v') := by
  have hqu : qLT (qAdd q (qNeg v)) u := qlt_sub_right_of_lt_add h
  rcases rational_order_dense hqu with ⟨u', hqvu, hu'u⟩
  have hquv : qLT q (qAdd u' v) := qlt_add_back_right hqvu
  have hqv : qLT (qAdd q (qNeg u')) v := qlt_sub_left_of_lt_add hquv
  rcases rational_order_dense hqv with ⟨v', hqu'v, hv'v⟩
  have hsum : qLT q (qAdd u' v') := qlt_add_back_left hqu'v
  exact ⟨u', v', hu'u, hv'v, hsum⟩

/-- If the left summand cut contains zero, adding it contains the right cut. -/
theorem cut_le_add_of_zero_le_left
    (B C : LowerCut)
    (h0B : CutLE (principalCut qZero) B) :
    CutLE C (cutAdd B C) := by
  intro q hqC
  rcases C.rounded hqC with ⟨c, hcC, hqc⟩
  have hdiff0 : qLT (qAdd q (qNeg c)) qZero := by
    have ht := qlt_add_right hqc (qNeg c)
    rw [qAdd_neg_right] at ht
    exact ht
  rcases rational_order_dense hdiff0 with ⟨b, hdiffb, hb0⟩
  have hbB : B.lower b := h0B b hb0
  have hqbc : qLT q (qAdd b c) := qlt_add_back_right hdiffb
  exact ⟨b, c, hbB, hcC, hqbc⟩

/-- If the right summand cut contains zero, adding it contains the left cut. -/
theorem cut_le_add_of_zero_le_right
    (B C : LowerCut)
    (h0C : CutLE (principalCut qZero) C) :
    CutLE B (cutAdd B C) := by
  intro q hqB
  have hqCB : (cutAdd C B).lower q :=
    cut_le_add_of_zero_le_left C B h0C q hqB
  exact (cutAdd_comm_equiv C B q).mp hqCB

/-- Sum of two nonnegative cuts is nonnegative. -/
theorem cutAdd_nonneg
    (B C : LowerCut)
    (h0B : CutLE (principalCut qZero) B)
    (h0C : CutLE (principalCut qZero) C) :
    CutLE (principalCut qZero) (cutAdd B C) :=
  cutLE_trans h0B (cut_le_add_of_zero_le_right B C h0C)

/-- Any rational strictly below a positive-factor product belongs to the kernel;
if the second factor is nonpositive the rational is automatically negative,
and if it is positive the explicit product witness is used. -/
theorem below_product_mem_kernel
    {A B : LowerCut} {a b t : QBOMA}
    (ha : (cutPosPart A).lower a)
    (hb : (cutPosPart B).lower b)
    (h0a : qLT qZero a)
    (ht : qLT t (qMul a b)) :
    (cutMulNonnegEnvelope A B).lower t := by
  rcases qlt_trichotomy b qZero with hb0 | hbeq | h0b
  · have hp0 : qLE (qMul a b) qZero := by
      have hm := qmul_mono_left_nonneg hb0.1 h0a.1
      rw [qMul_zero_right] at hm
      exact hm
    exact Or.inl (qlt_le_trans ht hp0)
  · have ht0 : qLT t qZero := by
      rw [hbeq, qMul_zero_right] at ht
      exact ht
    exact Or.inl ht0
  · exact Or.inr ⟨a, b, ha, hb, h0a, h0b, ht⟩

/-- A sum of two strict negatives is strict negative. -/
theorem qadd_lt_zero_of_neg {u v : QBOMA}
    (hu : qLT u qZero) (hv : qLT v qZero) :
    qLT (qAdd u v) qZero := by
  have h := qadd_lt_mono hu hv
  rw [qAdd_zero_left] at h
  exact h

/-- A sum of two positive rationals is positive. -/
theorem qzero_lt_add_of_pos {u v : QBOMA}
    (hu : qLT qZero u) (hv : qLT qZero v) :
    qLT qZero (qAdd u v) := by
  have h := qadd_lt_mono hu hv
  rw [qAdd_zero_left] at h
  exact h

/-- A positive sum witness b+c actually belongs to B+C when b∈B and c∈C,
using roundedness to create the strict witness required by cutAdd. -/
theorem sum_member_cutAdd
    {B C : LowerCut} {b c : QBOMA}
    (hb : B.lower b) (hc : C.lower c) :
    (cutAdd B C).lower (qAdd b c) := by
  rcases B.rounded hb with ⟨b', hb'B, hbb'⟩
  rcases C.rounded hc with ⟨c', hc'C, hcc'⟩
  have hsum : qLT (qAdd b c) (qAdd b' c') := qadd_lt_mono hbb' hcc'
  exact ⟨b', c', hb'B, hc'C, hsum⟩

/-- Distributivity of the nonnegative-envelope kernel in the right input,
provided both summand cuts are nonnegative. -/
theorem cutMulNonnegEnvelope_add_right_of_nonneg
    (A B C : LowerCut)
    (h0B : CutLE (principalCut qZero) B)
    (h0C : CutLE (principalCut qZero) C) :
    CutEquiv
      (cutMulNonnegEnvelope A (cutAdd B C))
      (cutAdd (cutMulNonnegEnvelope A B) (cutMulNonnegEnvelope A C)) := by
  have hBC0 : CutLE (principalCut qZero) (cutAdd B C) :=
    cutAdd_nonneg B C h0B h0C
  have hBpos : CutEquiv (cutPosPart B) B := cutPosPart_of_nonneg h0B
  have hCpos : CutEquiv (cutPosPart C) C := cutPosPart_of_nonneg h0C
  have hBCpos : CutEquiv (cutPosPart (cutAdd B C)) (cutAdd B C) :=
    cutPosPart_of_nonneg hBC0
  have hRHS0 :
      CutLE (principalCut qZero)
        (cutAdd (cutMulNonnegEnvelope A B) (cutMulNonnegEnvelope A C)) :=
    cutAdd_nonneg
      (cutMulNonnegEnvelope A B)
      (cutMulNonnegEnvelope A C)
      (cutZero_le_mulNonneg A B)
      (cutZero_le_mulNonneg A C)
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact hRHS0 q hqNeg
    · rcases hqProd with ⟨a, d, ha, hdPos, h0a, h0d, hqad⟩
      have hd : (cutAdd B C).lower d := (hBCpos d).mp hdPos
      rcases hd with ⟨b, c, hb, hc, hdbc⟩
      have hadsum : qLT (qMul a d) (qAdd (qMul a b) (qMul a c)) := by
        have hm := qmul_lt_left_positive hdbc h0a
        rw [qMul_add_right] at hm
        exact hm
      have hqsum : qLT q (qAdd (qMul a b) (qMul a c)) :=
        qlt_trans hqad hadsum
      rcases q_sum_inner_approx hqsum with ⟨u, v, hu, hv, hquv⟩
      have huK : (cutMulNonnegEnvelope A B).lower u :=
        below_product_mem_kernel ha (Or.inl hb) h0a hu
      have hvK : (cutMulNonnegEnvelope A C).lower v :=
        below_product_mem_kernel ha (Or.inl hc) h0a hv
      exact ⟨u, v, huK, hvK, hquv⟩
  · intro hq
    rcases hq with ⟨u, v, huK, hvK, hquv⟩
    rcases huK with huNeg | huProd
    · rcases hvK with hvNeg | hvProd
      · have huv0 : qLT (qAdd u v) qZero := qadd_lt_zero_of_neg huNeg hvNeg
        exact Or.inl (qlt_trans hquv huv0)
      · rcases hvProd with ⟨a, c, ha, hcPos, h0a, h0c, hvac⟩
        have hcC : C.lower c := (hCpos c).mp hcPos
        have hcBC : (cutAdd B C).lower c :=
          cut_le_add_of_zero_le_left B C h0B c hcC
        have huv_v : qLT (qAdd u v) v := by
          have ht := qlt_add_right huNeg v
          rw [qAdd_zero_left] at ht
          exact ht
        have hqac : qLT q (qMul a c) :=
          qlt_trans hquv (qlt_trans huv_v hvac)
        exact Or.inr ⟨a, c, ha, Or.inl hcBC, h0a, h0c, hqac⟩
    · rcases huProd with ⟨a1, b, ha1, hbPos, h0a1, h0b, huab⟩
      rcases hvK with hvNeg | hvProd
      · have hbB : B.lower b := (hBpos b).mp hbPos
        have hbBC : (cutAdd B C).lower b :=
          cut_le_add_of_zero_le_right B C h0C b hbB
        have huv_u : qLT (qAdd u v) u := by
          have ht := qlt_add_right hvNeg u
          rw [qAdd_zero_left, qAdd_comm v u] at ht
          exact ht
        have hqab : qLT q (qMul a1 b) :=
          qlt_trans hquv (qlt_trans huv_u huab)
        exact Or.inr ⟨a1, b, ha1, Or.inl hbBC, h0a1, h0b, hqab⟩
      · rcases hvProd with ⟨a2, c, ha2, hcPos, h0a2, h0c, hvac⟩
        have hbB : B.lower b := (hBpos b).mp hbPos
        have hcC : C.lower c := (hCpos c).mp hcPos
        rcases qle_total a1 a2 with h12 | h21
        · rcases (cutPosPart A).rounded ha2 with ⟨a, ha, ha2a⟩
          have ha1a : qLT a1 a := qle_lt_trans h12 ha2a
          have h0a : qLT qZero a := qlt_trans h0a1 ha1a
          have huab' : qLT u (qMul a b) :=
            qlt_trans huab (qmul_lt_right_positive ha1a h0b)
          have hvac' : qLT v (qMul a c) :=
            qlt_trans hvac (qmul_lt_right_positive ha2a h0c)
          have hquv' : qLT q (qAdd (qMul a b) (qMul a c)) :=
            qlt_trans hquv (qadd_lt_mono huab' hvac')
          have hqprod : qLT q (qMul a (qAdd b c)) := by
            rw [qMul_add_right]
            exact hquv'
          have hbc : (cutAdd B C).lower (qAdd b c) :=
            sum_member_cutAdd hbB hcC
          have h0bc : qLT qZero (qAdd b c) := qzero_lt_add_of_pos h0b h0c
          exact Or.inr ⟨a, qAdd b c, ha, Or.inl hbc, h0a, h0bc, hqprod⟩
        · rcases (cutPosPart A).rounded ha1 with ⟨a, ha, ha1a⟩
          have ha2a : qLT a2 a := qle_lt_trans h21 ha1a
          have h0a : qLT qZero a := qlt_trans h0a2 ha2a
          have huab' : qLT u (qMul a b) :=
            qlt_trans huab (qmul_lt_right_positive ha1a h0b)
          have hvac' : qLT v (qMul a c) :=
            qlt_trans hvac (qmul_lt_right_positive ha2a h0c)
          have hquv' : qLT q (qAdd (qMul a b) (qMul a c)) :=
            qlt_trans hquv (qadd_lt_mono huab' hvac')
          have hqprod : qLT q (qMul a (qAdd b c)) := by
            rw [qMul_add_right]
            exact hquv'
          have hbc : (cutAdd B C).lower (qAdd b c) :=
            sum_member_cutAdd hbB hcC
          have h0bc : qLT qZero (qAdd b c) := qzero_lt_add_of_pos h0b h0c
          exact Or.inr ⟨a, qAdd b c, ha, Or.inl hbc, h0a, h0bc, hqprod⟩

/-- Quotient distributive interface on nonnegative right inputs. -/
theorem rMulNonnegEnvelope_add_right_of_nonneg
    (x y z : RBOMA)
    (h0y : rLE rZero y)
    (h0z : rLE rZero z) :
    rMulNonnegEnvelope x (rAdd y z) =
    rAdd (rMulNonnegEnvelope x y) (rMulNonnegEnvelope x z) := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_ h0y
  intro B h0B
  refine Quotient.inductionOn z ?_ h0z
  intro C h0C
  have hBcut : CutLE (principalCut qZero) B := by
    change rLE (rmk (principalCut qZero)) (rmk B) at h0B
    exact (rLE_mk_iff (principalCut qZero) B).1 h0B
  have hCcut : CutLE (principalCut qZero) C := by
    change rLE (rmk (principalCut qZero)) (rmk C) at h0C
    exact (rLE_mk_iff (principalCut qZero) C).1 h0C
  change
    rmk (cutMulNonnegEnvelope A (cutAdd B C)) =
    rmk (cutAdd (cutMulNonnegEnvelope A B) (cutMulNonnegEnvelope A C))
  exact rmk_sound (cutMulNonnegEnvelope_add_right_of_nonneg A B C hBcut hCcut)

end BOMA.R.DedekindNonnegativeMulDistributivity001

/- Basic laws for the selected sign-case-free signed Dedekind multiplication. -/
namespace BOMA.R.DedekindSignedMulBasicLaws001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.Q.OrderedField001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulLaws001
open BOMA.R.DedekindSignedMulCandidate001

/-- The selected signed multiplication is commutative before any distributive law is used. -/
theorem rMulCandidate_comm (x y : RBOMA) :
    rMulCandidate x y = rMulCandidate y x := by
  unfold rMulCandidate
  have hPP : rMulNonnegEnvelope x y = rMulNonnegEnvelope y x :=
    rMulNonnegEnvelope_comm x y
  have hNN :
      rMulNonnegEnvelope (rNeg x) (rNeg y) =
      rMulNonnegEnvelope (rNeg y) (rNeg x) :=
    rMulNonnegEnvelope_comm (rNeg x) (rNeg y)
  have hPN :
      rMulNonnegEnvelope x (rNeg y) =
      rMulNonnegEnvelope (rNeg y) x :=
    rMulNonnegEnvelope_comm x (rNeg y)
  have hNP :
      rMulNonnegEnvelope (rNeg x) y =
      rMulNonnegEnvelope y (rNeg x) :=
    rMulNonnegEnvelope_comm (rNeg x) y
  rw [hPP, hNN, hPN, hNP]
  apply congrArg (fun t => rAdd (rAdd
    (rMulNonnegEnvelope y x)
    (rMulNonnegEnvelope (rNeg y) (rNeg x))) (rNeg t))
  exact rAdd_comm
    (rMulNonnegEnvelope (rNeg y) x)
    (rMulNonnegEnvelope y (rNeg x))

/-- Zero annihilates the selected signed multiplication on the left. -/
@[simp] theorem rMulCandidate_zero_left (x : RBOMA) :
    rMulCandidate rZero x = rZero := by
  unfold rMulCandidate
  rw [BOMA.R.DedekindSignedMulCandidate001.rNeg_zero]
  simp only [rMulNonnegEnvelope_zero_left, rAdd_zero_left,
    BOMA.R.DedekindSignedMulCandidate001.rNeg_zero]

/-- Zero annihilates the selected signed multiplication on the right. -/
@[simp] theorem rMulCandidate_zero_right (x : RBOMA) :
    rMulCandidate x rZero = rZero := by
  rw [rMulCandidate_comm]
  exact rMulCandidate_zero_left x

/-- A nonpositive principal rational factor annihilates the nonnegative kernel,
even when the second input is an arbitrary real representative. -/
theorem cutMulNonnegEnvelope_principal_nonpos_left
    (q : QBOMA) (A : LowerCut) (hq : qLE q qZero) :
    CutEquiv
      (cutMulNonnegEnvelope (principalCut q) A)
      (principalCut qZero) := by
  intro t
  constructor
  · intro ht
    rcases ht with htNeg | htProd
    · exact htNeg
    · rcases htProd with ⟨a, _b, ha, _hb, h0a, _h0b, _ht⟩
      have ha0 : qLT a qZero :=
        ((cutPosPart_principal_nonpos hq) a).mp ha
      exact False.elim ((qlt_asymm h0a) ha0)
  · intro ht0
    exact Or.inl ht0

/-- Quotient form of arbitrary-right annihilation by a nonpositive rational factor. -/
theorem rMulNonnegEnvelope_rOfQ_nonpos_left
    (q : QBOMA) (x : RBOMA) (hq : qLE q qZero) :
    rMulNonnegEnvelope (rOfQ q) x = rZero := by
  refine Quotient.inductionOn x ?_
  intro A
  change
    rmk (cutMulNonnegEnvelope (principalCut q) A) =
    rmk (principalCut qZero)
  exact rmk_sound (cutMulNonnegEnvelope_principal_nonpos_left q A hq)

/-- The nonnegative kernel sees the formal real -1 as zero on its left input. -/
theorem rMulNonnegEnvelope_negOne_left (x : RBOMA) :
    rMulNonnegEnvelope (rNeg rOne) x = rZero := by
  change rMulNonnegEnvelope (rNeg (rOfQ qOne)) x = rZero
  rw [rOfQ_neg qOne]
  apply rMulNonnegEnvelope_rOfQ_nonpos_left
  exact qneg_nonpos_of_nonneg qzero_le_one

/-- One is a left identity for the selected signed multiplication.
The kernel one law reduces the expression to x⁺-x⁻, then the separately
verified positive/negative decomposition theorem closes the proof. -/
theorem rMulCandidate_one_left (x : RBOMA) :
    rMulCandidate rOne x = x := by
  unfold rMulCandidate
  rw [rMulNonnegEnvelope_one_left x]
  rw [rMulNonnegEnvelope_negOne_left (rNeg x)]
  rw [rMulNonnegEnvelope_one_left (rNeg x)]
  rw [rMulNonnegEnvelope_negOne_left x]
  rw [rAdd_zero_right, rAdd_zero_right]
  change rAdd (rPosPart x) (rNeg (rNegPart x)) = x
  exact rPosNeg_decomposition x

/-- One is also a right identity by commutativity. -/
theorem rMulCandidate_one_right (x : RBOMA) :
    rMulCandidate x rOne = x := by
  rw [rMulCandidate_comm]
  exact rMulCandidate_one_left x

end BOMA.R.DedekindSignedMulBasicLaws001

/- Sign-quadrant simplifications for the selected signed Dedekind multiplication.
Sign comparison is proof-level; the operation definition remains sign-case-free. -/
namespace BOMA.R.DedekindSignedMulSignLaws001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulLaws001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001

/-- Any nonpositive real factor is annihilated by the nonnegative-envelope kernel. -/
theorem cutMulNonnegEnvelope_left_nonpos
    {A : LowerCut} (B : LowerCut)
    (hA0 : CutLE A (principalCut qZero)) :
    CutEquiv
      (cutMulNonnegEnvelope A B)
      (principalCut qZero) := by
  intro q
  constructor
  · intro hq
    rcases hq with hqNeg | hqProd
    · exact hqNeg
    · rcases hqProd with ⟨a, _b, ha, _hb, h0a, _h0b, _hqab⟩
      have ha0 : qLT a qZero :=
        ((cutPosPart_of_nonpos hA0) a).mp ha
      exact False.elim ((qlt_asymm h0a) ha0)
  · intro hq0
    exact Or.inl hq0

/-- Quotient-level left annihilation for an arbitrary nonpositive real. -/
theorem rMulNonnegEnvelope_left_nonpos
    {x : RBOMA} (y : RBOMA)
    (hx0 : rLE x rZero) :
    rMulNonnegEnvelope x y = rZero := by
  refine Quotient.inductionOn x ?_ hx0
  intro A hA0
  refine Quotient.inductionOn y ?_
  intro B
  change
    rmk (cutMulNonnegEnvelope A B) =
    rmk (principalCut qZero)
  apply rmk_sound
  apply cutMulNonnegEnvelope_left_nonpos B
  change rLE (rmk A) (rmk (principalCut qZero)) at hA0
  exact (rLE_mk_iff A (principalCut qZero)).1 hA0

/-- Right annihilation follows from kernel commutativity. -/
theorem rMulNonnegEnvelope_right_nonpos
    (x : RBOMA) {y : RBOMA}
    (hy0 : rLE y rZero) :
    rMulNonnegEnvelope x y = rZero := by
  rw [rMulNonnegEnvelope_comm]
  exact rMulNonnegEnvelope_left_nonpos x hy0

/-- If x is nonnegative, -x is kernel-nonpositive. -/
theorem rMulNonnegEnvelope_neg_left_of_nonneg
    {x : RBOMA} (y : RBOMA)
    (h0x : rLE rZero x) :
    rMulNonnegEnvelope (rNeg x) y = rZero :=
  rMulNonnegEnvelope_left_nonpos y (rNeg_nonpos_of_nonneg h0x)

/-- If y is nonnegative, -y is kernel-nonpositive on the right. -/
theorem rMulNonnegEnvelope_neg_right_of_nonneg
    (x : RBOMA) {y : RBOMA}
    (h0y : rLE rZero y) :
    rMulNonnegEnvelope x (rNeg y) = rZero :=
  rMulNonnegEnvelope_right_nonpos x (rNeg_nonpos_of_nonneg h0y)

/-- Positive-positive quadrant: signed multiplication is the nonnegative kernel. -/
theorem rMulCandidate_of_nonneg_nonneg
    {x y : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y) :
    rMulCandidate x y = rMulNonnegEnvelope x y := by
  unfold rMulCandidate
  rw [rMulNonnegEnvelope_neg_left_of_nonneg (rNeg y) h0x]
  rw [rMulNonnegEnvelope_neg_right_of_nonneg x h0y]
  rw [rMulNonnegEnvelope_neg_left_of_nonneg y h0x]
  rw [rAdd_zero_right, rAdd_zero_left,
      BOMA.R.DedekindSignedMulCandidate001.rNeg_zero, rAdd_zero_right]

/-- Positive-negative quadrant: signed multiplication is minus the kernel of x and -y. -/
theorem rMulCandidate_of_nonneg_nonpos
    {x y : RBOMA}
    (h0x : rLE rZero x)
    (hy0 : rLE y rZero) :
    rMulCandidate x y = rNeg (rMulNonnegEnvelope x (rNeg y)) := by
  unfold rMulCandidate
  rw [rMulNonnegEnvelope_right_nonpos x hy0]
  rw [rMulNonnegEnvelope_neg_left_of_nonneg (rNeg y) h0x]
  rw [rMulNonnegEnvelope_neg_left_of_nonneg y h0x]
  simp only [rAdd_zero_left, rAdd_zero_right]

/-- Negative-positive quadrant. -/
theorem rMulCandidate_of_nonpos_nonneg
    {x y : RBOMA}
    (hx0 : rLE x rZero)
    (h0y : rLE rZero y) :
    rMulCandidate x y = rNeg (rMulNonnegEnvelope (rNeg x) y) := by
  calc
    rMulCandidate x y = rMulCandidate y x := rMulCandidate_comm x y
    _ = rNeg (rMulNonnegEnvelope y (rNeg x)) :=
      rMulCandidate_of_nonneg_nonpos h0y hx0
    _ = rNeg (rMulNonnegEnvelope (rNeg x) y) := by
      rw [rMulNonnegEnvelope_comm]

/-- Negative-negative quadrant: signed multiplication is the kernel of the negated inputs. -/
theorem rMulCandidate_of_nonpos_nonpos
    {x y : RBOMA}
    (hx0 : rLE x rZero)
    (hy0 : rLE y rZero) :
    rMulCandidate x y = rMulNonnegEnvelope (rNeg x) (rNeg y) := by
  unfold rMulCandidate
  rw [rMulNonnegEnvelope_left_nonpos y hx0]
  rw [rMulNonnegEnvelope_left_nonpos (rNeg y) hx0]
  rw [rMulNonnegEnvelope_right_nonpos (rNeg x) hy0]
  rw [rAdd_zero_left, rAdd_zero_left,
      BOMA.R.DedekindSignedMulCandidate001.rNeg_zero, rAdd_zero_right]

end BOMA.R.DedekindSignedMulSignLaws001

/- Associativity of the selected signed Dedekind multiplication.
The proof classifies signs with the isolated classical total-order witness and
reduces all eight quadrants to the certified nonnegative-kernel associativity. -/
namespace BOMA.R.DedekindSignedMulAssociativity001

open BOMA.Q.Quotient001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulLaws001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulSignLaws001

/-- Every nonnegative-envelope kernel value is nonnegative. -/
theorem rMulNonnegEnvelope_nonneg (x y : RBOMA) :
    rLE rZero (rMulNonnegEnvelope x y) := by
  refine Quotient.inductionOn x ?_
  intro A
  refine Quotient.inductionOn y ?_
  intro B
  change
    rLE (rmk (principalCut qZero))
      (rmk (cutMulNonnegEnvelope A B))
  exact (rLE_mk_iff (principalCut qZero) (cutMulNonnegEnvelope A B)).2
    (cutZero_le_mulNonneg A B)

/-- Associativity of the selected signed multiplication. -/
theorem rMulCandidate_assoc (x y z : RBOMA) :
    rMulCandidate (rMulCandidate x y) z =
    rMulCandidate x (rMulCandidate y z) := by
  rcases rLE_total_classical rZero x with h0x | hx0
  · rcases rLE_total_classical rZero y with h0y | hy0
    · rcases rLE_total_classical rZero z with h0z | hz0
      · -- + + +
        have hxy := rMulCandidate_of_nonneg_nonneg h0x h0y
        have hyz := rMulCandidate_of_nonneg_nonneg h0y h0z
        have h0xy : rLE rZero (rMulCandidate x y) := by
          rw [hxy]
          exact rMulNonnegEnvelope_nonneg x y
        have h0yz : rLE rZero (rMulCandidate y z) := by
          rw [hyz]
          exact rMulNonnegEnvelope_nonneg y z
        calc
          rMulCandidate (rMulCandidate x y) z =
              rMulNonnegEnvelope (rMulCandidate x y) z :=
            rMulCandidate_of_nonneg_nonneg h0xy h0z
          _ = rMulNonnegEnvelope (rMulNonnegEnvelope x y) z := by rw [hxy]
          _ = rMulNonnegEnvelope x (rMulNonnegEnvelope y z) :=
            rMulNonnegEnvelope_assoc x y z
          _ = rMulNonnegEnvelope x (rMulCandidate y z) := by rw [hyz]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonneg_nonneg h0x h0yz).symm
      · -- + + -
        have hxy := rMulCandidate_of_nonneg_nonneg h0x h0y
        have hyz := rMulCandidate_of_nonneg_nonpos h0y hz0
        have h0xy : rLE rZero (rMulCandidate x y) := by
          rw [hxy]
          exact rMulNonnegEnvelope_nonneg x y
        have hyz0 : rLE (rMulCandidate y z) rZero := by
          rw [hyz]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg y (rNeg z))
        calc
          rMulCandidate (rMulCandidate x y) z =
              rNeg (rMulNonnegEnvelope (rMulCandidate x y) (rNeg z)) :=
            rMulCandidate_of_nonneg_nonpos h0xy hz0
          _ = rNeg (rMulNonnegEnvelope (rMulNonnegEnvelope x y) (rNeg z)) := by
            rw [hxy]
          _ = rNeg (rMulNonnegEnvelope x
                (rMulNonnegEnvelope y (rNeg z))) := by
            rw [rMulNonnegEnvelope_assoc]
          _ = rNeg (rMulNonnegEnvelope x (rNeg (rMulCandidate y z))) := by
            rw [hyz, rNeg_involutive]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonneg_nonpos h0x hyz0).symm
    · rcases rLE_total_classical rZero z with h0z | hz0
      · -- + - +
        have hxy := rMulCandidate_of_nonneg_nonpos h0x hy0
        have hyz := rMulCandidate_of_nonpos_nonneg hy0 h0z
        have hxy0 : rLE (rMulCandidate x y) rZero := by
          rw [hxy]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg x (rNeg y))
        have hyz0 : rLE (rMulCandidate y z) rZero := by
          rw [hyz]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg (rNeg y) z)
        calc
          rMulCandidate (rMulCandidate x y) z =
              rNeg (rMulNonnegEnvelope (rNeg (rMulCandidate x y)) z) :=
            rMulCandidate_of_nonpos_nonneg hxy0 h0z
          _ = rNeg (rMulNonnegEnvelope
                (rMulNonnegEnvelope x (rNeg y)) z) := by
            rw [hxy, rNeg_involutive]
          _ = rNeg (rMulNonnegEnvelope x
                (rMulNonnegEnvelope (rNeg y) z)) := by
            rw [rMulNonnegEnvelope_assoc]
          _ = rNeg (rMulNonnegEnvelope x (rNeg (rMulCandidate y z))) := by
            rw [hyz, rNeg_involutive]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonneg_nonpos h0x hyz0).symm
      · -- + - -
        have hxy := rMulCandidate_of_nonneg_nonpos h0x hy0
        have hyz := rMulCandidate_of_nonpos_nonpos hy0 hz0
        have hxy0 : rLE (rMulCandidate x y) rZero := by
          rw [hxy]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg x (rNeg y))
        have h0yz : rLE rZero (rMulCandidate y z) := by
          rw [hyz]
          exact rMulNonnegEnvelope_nonneg (rNeg y) (rNeg z)
        calc
          rMulCandidate (rMulCandidate x y) z =
              rMulNonnegEnvelope (rNeg (rMulCandidate x y)) (rNeg z) :=
            rMulCandidate_of_nonpos_nonpos hxy0 hz0
          _ = rMulNonnegEnvelope (rMulNonnegEnvelope x (rNeg y)) (rNeg z) := by
            rw [hxy, rNeg_involutive]
          _ = rMulNonnegEnvelope x
                (rMulNonnegEnvelope (rNeg y) (rNeg z)) :=
            rMulNonnegEnvelope_assoc x (rNeg y) (rNeg z)
          _ = rMulNonnegEnvelope x (rMulCandidate y z) := by rw [hyz]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonneg_nonneg h0x h0yz).symm
  · rcases rLE_total_classical rZero y with h0y | hy0
    · rcases rLE_total_classical rZero z with h0z | hz0
      · -- - + +
        have hxy := rMulCandidate_of_nonpos_nonneg hx0 h0y
        have hyz := rMulCandidate_of_nonneg_nonneg h0y h0z
        have hxy0 : rLE (rMulCandidate x y) rZero := by
          rw [hxy]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg (rNeg x) y)
        have h0yz : rLE rZero (rMulCandidate y z) := by
          rw [hyz]
          exact rMulNonnegEnvelope_nonneg y z
        calc
          rMulCandidate (rMulCandidate x y) z =
              rNeg (rMulNonnegEnvelope (rNeg (rMulCandidate x y)) z) :=
            rMulCandidate_of_nonpos_nonneg hxy0 h0z
          _ = rNeg (rMulNonnegEnvelope
                (rMulNonnegEnvelope (rNeg x) y) z) := by
            rw [hxy, rNeg_involutive]
          _ = rNeg (rMulNonnegEnvelope (rNeg x)
                (rMulNonnegEnvelope y z)) := by
            rw [rMulNonnegEnvelope_assoc]
          _ = rNeg (rMulNonnegEnvelope (rNeg x) (rMulCandidate y z)) := by
            rw [hyz]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonpos_nonneg hx0 h0yz).symm
      · -- - + -
        have hxy := rMulCandidate_of_nonpos_nonneg hx0 h0y
        have hyz := rMulCandidate_of_nonneg_nonpos h0y hz0
        have hxy0 : rLE (rMulCandidate x y) rZero := by
          rw [hxy]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg (rNeg x) y)
        have hyz0 : rLE (rMulCandidate y z) rZero := by
          rw [hyz]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg y (rNeg z))
        calc
          rMulCandidate (rMulCandidate x y) z =
              rMulNonnegEnvelope (rNeg (rMulCandidate x y)) (rNeg z) :=
            rMulCandidate_of_nonpos_nonpos hxy0 hz0
          _ = rMulNonnegEnvelope (rMulNonnegEnvelope (rNeg x) y) (rNeg z) := by
            rw [hxy, rNeg_involutive]
          _ = rMulNonnegEnvelope (rNeg x)
                (rMulNonnegEnvelope y (rNeg z)) :=
            rMulNonnegEnvelope_assoc (rNeg x) y (rNeg z)
          _ = rMulNonnegEnvelope (rNeg x) (rNeg (rMulCandidate y z)) := by
            rw [hyz, rNeg_involutive]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonpos_nonpos hx0 hyz0).symm
    · rcases rLE_total_classical rZero z with h0z | hz0
      · -- - - +
        have hxy := rMulCandidate_of_nonpos_nonpos hx0 hy0
        have hyz := rMulCandidate_of_nonpos_nonneg hy0 h0z
        have h0xy : rLE rZero (rMulCandidate x y) := by
          rw [hxy]
          exact rMulNonnegEnvelope_nonneg (rNeg x) (rNeg y)
        have hyz0 : rLE (rMulCandidate y z) rZero := by
          rw [hyz]
          exact rNeg_nonpos_of_nonneg (rMulNonnegEnvelope_nonneg (rNeg y) z)
        calc
          rMulCandidate (rMulCandidate x y) z =
              rMulNonnegEnvelope (rMulCandidate x y) z :=
            rMulCandidate_of_nonneg_nonneg h0xy h0z
          _ = rMulNonnegEnvelope
                (rMulNonnegEnvelope (rNeg x) (rNeg y)) z := by rw [hxy]
          _ = rMulNonnegEnvelope (rNeg x)
                (rMulNonnegEnvelope (rNeg y) z) :=
            rMulNonnegEnvelope_assoc (rNeg x) (rNeg y) z
          _ = rMulNonnegEnvelope (rNeg x) (rNeg (rMulCandidate y z)) := by
            rw [hyz, rNeg_involutive]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonpos_nonpos hx0 hyz0).symm
      · -- - - -
        have hxy := rMulCandidate_of_nonpos_nonpos hx0 hy0
        have hyz := rMulCandidate_of_nonpos_nonpos hy0 hz0
        have h0xy : rLE rZero (rMulCandidate x y) := by
          rw [hxy]
          exact rMulNonnegEnvelope_nonneg (rNeg x) (rNeg y)
        have h0yz : rLE rZero (rMulCandidate y z) := by
          rw [hyz]
          exact rMulNonnegEnvelope_nonneg (rNeg y) (rNeg z)
        calc
          rMulCandidate (rMulCandidate x y) z =
              rNeg (rMulNonnegEnvelope (rMulCandidate x y) (rNeg z)) :=
            rMulCandidate_of_nonneg_nonpos h0xy hz0
          _ = rNeg (rMulNonnegEnvelope
                (rMulNonnegEnvelope (rNeg x) (rNeg y)) (rNeg z)) := by rw [hxy]
          _ = rNeg (rMulNonnegEnvelope (rNeg x)
                (rMulNonnegEnvelope (rNeg y) (rNeg z))) := by
            rw [rMulNonnegEnvelope_assoc]
          _ = rNeg (rMulNonnegEnvelope (rNeg x) (rMulCandidate y z)) := by rw [hyz]
          _ = rMulCandidate x (rMulCandidate y z) :=
            (rMulCandidate_of_nonpos_nonneg hx0 h0yz).symm

end BOMA.R.DedekindSignedMulAssociativity001

/- Distributivity of the selected signed Dedekind multiplication.
The proof reduces to the certified nonnegative-kernel distributivity plus
additive-group identities and localized sign classification. -/
namespace BOMA.R.DedekindSignedMulDistributivity001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindOrderAdditive001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindAdditiveDerived001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindNonnegativeMulDistributivity001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindSignedMulSignLaws001

/-- Distributivity for a nonnegative left factor and two nonnegative summands. -/
theorem rMulCandidate_add_right_nonneg_nonneg
    {x y z : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y)
    (h0z : rLE rZero z) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  have h0sum : rLE rZero (rAdd y z) := rAdd_nonneg h0y h0z
  calc
    rMulCandidate x (rAdd y z) =
        rMulNonnegEnvelope x (rAdd y z) :=
      rMulCandidate_of_nonneg_nonneg h0x h0sum
    _ = rAdd (rMulNonnegEnvelope x y) (rMulNonnegEnvelope x z) :=
      rMulNonnegEnvelope_add_right_of_nonneg x y z h0y h0z
    _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
      rw [rMulCandidate_of_nonneg_nonneg h0x h0y,
          rMulCandidate_of_nonneg_nonneg h0x h0z]

/-- Distributivity for a nonnegative left factor and two nonpositive summands. -/
theorem rMulCandidate_add_right_nonpos_nonpos
    {x y z : RBOMA}
    (h0x : rLE rZero x)
    (hy0 : rLE y rZero)
    (hz0 : rLE z rZero) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  have hsum0 : rLE (rAdd y z) rZero := rAdd_nonpos hy0 hz0
  have h0ny : rLE rZero (rNeg y) := rNeg_nonneg_of_nonpos hy0
  have h0nz : rLE rZero (rNeg z) := rNeg_nonneg_of_nonpos hz0
  calc
    rMulCandidate x (rAdd y z) =
        rNeg (rMulNonnegEnvelope x (rNeg (rAdd y z))) :=
      rMulCandidate_of_nonneg_nonpos h0x hsum0
    _ = rNeg (rMulNonnegEnvelope x (rAdd (rNeg y) (rNeg z))) := by
      rw [rNeg_add]
    _ = rNeg (rAdd
          (rMulNonnegEnvelope x (rNeg y))
          (rMulNonnegEnvelope x (rNeg z))) := by
      rw [rMulNonnegEnvelope_add_right_of_nonneg x (rNeg y) (rNeg z) h0ny h0nz]
    _ = rAdd
          (rNeg (rMulNonnegEnvelope x (rNeg y)))
          (rNeg (rMulNonnegEnvelope x (rNeg z))) :=
      rNeg_add _ _
    _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
      rw [rMulCandidate_of_nonneg_nonpos h0x hy0,
          rMulCandidate_of_nonneg_nonpos h0x hz0]

/-- Mixed-sign distributivity for nonnegative x, nonnegative y, nonpositive z. -/
theorem rMulCandidate_add_right_nonneg_nonpos
    {x y z : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y)
    (hz0 : rLE z rZero) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  have h0nz : rLE rZero (rNeg z) := rNeg_nonneg_of_nonpos hz0
  rcases rLE_total_classical rZero (rAdd y z) with h0sum | hsum0
  · -- y+z remains nonnegative: y=(y+z)+(-z)
    have hK := rMulNonnegEnvelope_add_right_of_nonneg
      x (rAdd y z) (rNeg z) h0sum h0nz
    rw [rAdd_sub_right y z] at hK
    have hsolve :
        rMulNonnegEnvelope x (rAdd y z) =
        rAdd (rMulNonnegEnvelope x y)
          (rNeg (rMulNonnegEnvelope x (rNeg z))) := by
      calc
        rMulNonnegEnvelope x (rAdd y z) =
            rAdd (rMulNonnegEnvelope x (rAdd y z)) rZero :=
          (rAdd_zero_right _).symm
        _ = rAdd (rMulNonnegEnvelope x (rAdd y z))
              (rAdd (rMulNonnegEnvelope x (rNeg z))
                (rNeg (rMulNonnegEnvelope x (rNeg z)))) := by
          exact congrArg
            (fun t => rAdd (rMulNonnegEnvelope x (rAdd y z)) t)
            (rAdd_neg_right (rMulNonnegEnvelope x (rNeg z))).symm
        _ = rAdd
              (rAdd (rMulNonnegEnvelope x (rAdd y z))
                (rMulNonnegEnvelope x (rNeg z)))
              (rNeg (rMulNonnegEnvelope x (rNeg z))) :=
          (rAdd_assoc _ _ _).symm
        _ = rAdd (rMulNonnegEnvelope x y)
              (rNeg (rMulNonnegEnvelope x (rNeg z))) := by
          rw [← hK]
    calc
      rMulCandidate x (rAdd y z) =
          rMulNonnegEnvelope x (rAdd y z) :=
        rMulCandidate_of_nonneg_nonneg h0x h0sum
      _ = rAdd (rMulNonnegEnvelope x y)
            (rNeg (rMulNonnegEnvelope x (rNeg z))) := hsolve
      _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
        rw [rMulCandidate_of_nonneg_nonneg h0x h0y,
            rMulCandidate_of_nonneg_nonpos h0x hz0]
  · -- y+z is nonpositive: -z = y + (-(y+z))
    have h0nsum : rLE rZero (rNeg (rAdd y z)) :=
      rNeg_nonneg_of_nonpos hsum0
    have hK := rMulNonnegEnvelope_add_right_of_nonneg
      x y (rNeg (rAdd y z)) h0y h0nsum
    rw [rAdd_neg_sum_cancel_left y z] at hK
    have hsolve :
        rNeg (rMulNonnegEnvelope x (rNeg (rAdd y z))) =
        rAdd (rMulNonnegEnvelope x y)
          (rNeg (rMulNonnegEnvelope x (rNeg z))) := by
      calc
        rNeg (rMulNonnegEnvelope x (rNeg (rAdd y z))) =
            rAdd (rMulNonnegEnvelope x y)
              (rNeg (rAdd
                (rMulNonnegEnvelope x y)
                (rMulNonnegEnvelope x (rNeg (rAdd y z))))) :=
          (rAdd_neg_sum_cancel_left
            (rMulNonnegEnvelope x y)
            (rMulNonnegEnvelope x (rNeg (rAdd y z)))).symm
        _ = rAdd (rMulNonnegEnvelope x y)
              (rNeg (rMulNonnegEnvelope x (rNeg z))) := by
          rw [← hK]
    calc
      rMulCandidate x (rAdd y z) =
          rNeg (rMulNonnegEnvelope x (rNeg (rAdd y z))) :=
        rMulCandidate_of_nonneg_nonpos h0x hsum0
      _ = rAdd (rMulNonnegEnvelope x y)
            (rNeg (rMulNonnegEnvelope x (rNeg z))) := hsolve
      _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
        rw [rMulCandidate_of_nonneg_nonneg h0x h0y,
            rMulCandidate_of_nonneg_nonpos h0x hz0]

/-- Full right distributivity for any nonnegative left factor. -/
theorem rMulCandidate_add_right_of_nonneg_left
    {x : RBOMA}
    (h0x : rLE rZero x)
    (y z : RBOMA) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  rcases rLE_total_classical rZero y with h0y | hy0
  · rcases rLE_total_classical rZero z with h0z | hz0
    · exact rMulCandidate_add_right_nonneg_nonneg h0x h0y h0z
    · exact rMulCandidate_add_right_nonneg_nonpos h0x h0y hz0
  · rcases rLE_total_classical rZero z with h0z | hz0
    · calc
        rMulCandidate x (rAdd y z) = rMulCandidate x (rAdd z y) := by
          rw [rAdd_comm y z]
        _ = rAdd (rMulCandidate x z) (rMulCandidate x y) :=
          rMulCandidate_add_right_nonneg_nonpos h0x h0z hy0
        _ = rAdd (rMulCandidate x y) (rMulCandidate x z) :=
          rAdd_comm _ _
    · exact rMulCandidate_add_right_nonpos_nonpos h0x hy0 hz0

/-- For a nonpositive left factor, multiplication equals the negative of
multiplication by its nonnegative opposite. -/
theorem rMulCandidate_nonpos_left_as_neg
    {x : RBOMA}
    (hx0 : rLE x rZero)
    (y : RBOMA) :
    rMulCandidate x y = rNeg (rMulCandidate (rNeg x) y) := by
  have h0nx : rLE rZero (rNeg x) := rNeg_nonneg_of_nonpos hx0
  rcases rLE_total_classical rZero y with h0y | hy0
  · calc
      rMulCandidate x y = rNeg (rMulNonnegEnvelope (rNeg x) y) :=
        rMulCandidate_of_nonpos_nonneg hx0 h0y
      _ = rNeg (rMulCandidate (rNeg x) y) := by
        rw [rMulCandidate_of_nonneg_nonneg h0nx h0y]
  · calc
      rMulCandidate x y = rMulNonnegEnvelope (rNeg x) (rNeg y) :=
        rMulCandidate_of_nonpos_nonpos hx0 hy0
      _ = rNeg (rNeg (rMulNonnegEnvelope (rNeg x) (rNeg y))) := by
        rw [rNeg_involutive]
      _ = rNeg (rMulCandidate (rNeg x) y) := by
        rw [rMulCandidate_of_nonneg_nonpos h0nx hy0]

/-- Full right distributivity for the selected signed multiplication. -/
theorem rMulCandidate_add_right (x y z : RBOMA) :
    rMulCandidate x (rAdd y z) =
    rAdd (rMulCandidate x y) (rMulCandidate x z) := by
  rcases rLE_total_classical rZero x with h0x | hx0
  · exact rMulCandidate_add_right_of_nonneg_left h0x y z
  · have h0nx : rLE rZero (rNeg x) := rNeg_nonneg_of_nonpos hx0
    have hd := rMulCandidate_add_right_of_nonneg_left h0nx y z
    have hsum := rMulCandidate_nonpos_left_as_neg hx0 (rAdd y z)
    have hy := rMulCandidate_nonpos_left_as_neg hx0 y
    have hz := rMulCandidate_nonpos_left_as_neg hx0 z
    calc
      rMulCandidate x (rAdd y z) =
          rNeg (rMulCandidate (rNeg x) (rAdd y z)) := hsum
      _ = rNeg (rAdd
            (rMulCandidate (rNeg x) y)
            (rMulCandidate (rNeg x) z)) := by rw [hd]
      _ = rAdd
            (rNeg (rMulCandidate (rNeg x) y))
            (rNeg (rMulCandidate (rNeg x) z)) :=
        rNeg_add _ _
      _ = rAdd (rMulCandidate x y) (rMulCandidate x z) := by
        rw [← hy, ← hz]

/-- Left distributivity follows from multiplication commutativity. -/
theorem rMulCandidate_add_left (x y z : RBOMA) :
    rMulCandidate (rAdd x y) z =
    rAdd (rMulCandidate x z) (rMulCandidate y z) := by
  calc
    rMulCandidate (rAdd x y) z = rMulCandidate z (rAdd x y) :=
      rMulCandidate_comm _ _
    _ = rAdd (rMulCandidate z x) (rMulCandidate z y) :=
      rMulCandidate_add_right z x y
    _ = rAdd (rMulCandidate x z) (rMulCandidate y z) := by
      rw [rMulCandidate_comm z x, rMulCandidate_comm z y]

end BOMA.R.DedekindSignedMulDistributivity001

/- Ordered-ring compatibility for the selected Dedekind real operations.
This layer derives multiplication monotonicity from the additive difference
interface and the already-certified signed distributivity. -/
namespace BOMA.R.DedekindOrderedRing001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderAdditive001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindAdditiveDerived001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindSignedMulSignLaws001
open BOMA.R.DedekindSignedMulAssociativity001
open BOMA.R.DedekindSignedMulDistributivity001

/-- Real order is equivalent to nonnegativity of the additive difference y-x. -/
theorem rle_iff_nonneg_difference (x y : RBOMA) :
    rLE x y ↔ rLE rZero (rAdd y (rNeg x)) := by
  constructor
  · intro hxy
    have ht := rAdd_mono_right hxy (rNeg x)
    have hx0 : rAdd x (rNeg x) = rZero := rAdd_neg_right x
    rw [hx0] at ht
    exact ht
  · intro hdiff
    have ht := rAdd_mono_right hdiff x
    have hleft : rAdd rZero x = x := rAdd_zero_left x
    have hright : rAdd (rAdd y (rNeg x)) x = y := by
      calc
        rAdd (rAdd y (rNeg x)) x = rAdd y (rAdd (rNeg x) x) :=
          rAdd_assoc y (rNeg x) x
        _ = rAdd y rZero := by rw [rAdd_neg_left]
        _ = y := rAdd_zero_right y
    rw [hleft, hright] at ht
    exact ht

/-- The product of two nonnegative selected reals is nonnegative. -/
theorem rMulCandidate_nonneg
    {x y : RBOMA}
    (h0x : rLE rZero x)
    (h0y : rLE rZero y) :
    rLE rZero (rMulCandidate x y) := by
  rw [rMulCandidate_of_nonneg_nonneg h0x h0y]
  exact rMulNonnegEnvelope_nonneg x y

/-- Multiplication of the additive inverse on the right is the additive inverse
of the product. This is derived from distributivity and inverse uniqueness. -/
theorem rMulCandidate_neg_right (x y : RBOMA) :
    rMulCandidate x (rNeg y) = rNeg (rMulCandidate x y) := by
  apply rAdd_inverse_unique (x := rMulCandidate x y)
  calc
    rAdd (rMulCandidate x y) (rMulCandidate x (rNeg y)) =
        rMulCandidate x (rAdd y (rNeg y)) :=
      (rMulCandidate_add_right x y (rNeg y)).symm
    _ = rMulCandidate x rZero := by rw [rAdd_neg_right]
    _ = rZero := rMulCandidate_zero_right x

/-- Left negation compatibility follows from multiplication commutativity. -/
theorem rMulCandidate_neg_left (x y : RBOMA) :
    rMulCandidate (rNeg x) y = rNeg (rMulCandidate x y) := by
  calc
    rMulCandidate (rNeg x) y = rMulCandidate y (rNeg x) :=
      rMulCandidate_comm _ _
    _ = rNeg (rMulCandidate y x) := rMulCandidate_neg_right y x
    _ = rNeg (rMulCandidate x y) :=
      congrArg rNeg (rMulCandidate_comm y x)

/-- A nonnegative left factor preserves formal real order. -/
theorem rMulCandidate_mono_left_nonneg
    {x y c : RBOMA}
    (hxy : rLE x y)
    (h0c : rLE rZero c) :
    rLE (rMulCandidate c x) (rMulCandidate c y) := by
  have hdiff : rLE rZero (rAdd y (rNeg x)) :=
    (rle_iff_nonneg_difference x y).1 hxy
  have hprod :
      rLE rZero (rMulCandidate c (rAdd y (rNeg x))) :=
    rMulCandidate_nonneg h0c hdiff
  have hrepr :
      rMulCandidate c (rAdd y (rNeg x)) =
      rAdd (rMulCandidate c y) (rNeg (rMulCandidate c x)) := by
    calc
      rMulCandidate c (rAdd y (rNeg x)) =
          rAdd (rMulCandidate c y) (rMulCandidate c (rNeg x)) :=
        rMulCandidate_add_right c y (rNeg x)
      _ = rAdd (rMulCandidate c y) (rNeg (rMulCandidate c x)) := by
        rw [rMulCandidate_neg_right]
  rw [hrepr] at hprod
  exact (rle_iff_nonneg_difference
    (rMulCandidate c x) (rMulCandidate c y)).2 hprod

/-- A nonnegative right factor preserves formal real order. -/
theorem rMulCandidate_mono_right_nonneg
    {x y c : RBOMA}
    (hxy : rLE x y)
    (h0c : rLE rZero c) :
    rLE (rMulCandidate x c) (rMulCandidate y c) := by
  rw [rMulCandidate_comm x c, rMulCandidate_comm y c]
  exact rMulCandidate_mono_left_nonneg hxy h0c

/-- Ordered-ring translation form: if a≤b and 0≤c then a*c≤b*c. -/
theorem rMulCandidate_order_compatible
    {a b c : RBOMA}
    (hab : rLE a b)
    (h0c : rLE rZero c) :
    rLE (rMulCandidate a c) (rMulCandidate b c) :=
  rMulCandidate_mono_right_nonneg hab h0c

end BOMA.R.DedekindOrderedRing001

/- Representative-independent positive inverse relation revision 003.
Consumes positive representative extraction 002 and the V5-passing inverse-product 004. -/
namespace BOMA.R.DedekindPositiveInverseRelation003

open BOMA.Q.Quotient001
open BOMA.Q.Inverse001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindPositivePart001
open BOMA.R.DedekindNonnegativeMul001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulSignLaws001
open BOMA.R.DedekindPositiveReciprocal001
open BOMA.R.DedekindPositiveReciprocalEmbedding001
open BOMA.R.DedekindPositiveRepresentative002
open BOMA.R.DedekindPositiveInverseProduct004

/-- Positive inverse relation with no global representative selector. -/
def RPositiveInvRel (x y : RBOMA) : Prop :=
  ∃ A : LowerCut, ∃ hApos : CutHasPositive A,
    x = rmk A ∧ y = rmk (cutRecipPos A hApos)

 theorem cut_zero_le_recipPos
    (A : LowerCut) (hApos : CutHasPositive A) :
    CutLE (principalCut qZero) (cutRecipPos A hApos) := by
  intro q hq0
  exact Or.inl hq0

 theorem rPositiveInvRel_exists
    {x : RBOMA}
    (h0x : rLE rZero x)
    (hx0 : x ≠ rZero) :
    ∃ y : RBOMA, RPositiveInvRel x y := by
  rcases r_nonneg_nonzero_positive_rep h0x hx0 with ⟨A, hApos, hxA⟩
  exact ⟨rmk (cutRecipPos A hApos), A, hApos, hxA, rfl⟩

 theorem rPositiveInvRel_unique
    {x y z : RBOMA}
    (hy : RPositiveInvRel x y)
    (hz : RPositiveInvRel x z) :
    y = z := by
  rcases hy with ⟨A, hApos, hxA, hyA⟩
  rcases hz with ⟨B, hBpos, hxB, hzB⟩
  have hmk : rmk A = rmk B := hxA.symm.trans hxB
  have hAB : CutEquiv A B := (rmk_eq_iff).1 hmk
  have hRec : CutEquiv (cutRecipPos A hApos) (cutRecipPos B hBpos) :=
    cutRecipPos_respects hAB hApos hBpos
  calc
    y = rmk (cutRecipPos A hApos) := hyA
    _ = rmk (cutRecipPos B hBpos) := rmk_sound hRec
    _ = z := hzB.symm

 theorem rPositiveInvRel_product_one
    {x y : RBOMA}
    (hxy : RPositiveInvRel x y) :
    rMulCandidate x y = rOne := by
  rcases hxy with ⟨A, hApos, hxA, hyA⟩
  rw [hxA, hyA]
  have h0A : rLE rZero (rmk A) := by
    change rLE (rmk (principalCut qZero)) (rmk A)
    exact (rLE_mk_iff (principalCut qZero) A).2
      (cut_zero_le_of_has_positive hApos)
  have h0Rec : rLE rZero (rmk (cutRecipPos A hApos)) := by
    change rLE (rmk (principalCut qZero)) (rmk (cutRecipPos A hApos))
    exact (rLE_mk_iff (principalCut qZero) (cutRecipPos A hApos)).2
      (cut_zero_le_recipPos A hApos)
  rw [rMulCandidate_of_nonneg_nonneg h0A h0Rec]
  change rmk (cutMulNonnegEnvelope A (cutRecipPos A hApos)) = rmk (principalCut qOne)
  exact rmk_sound (cutMul_recipPos_equiv_one A hApos)

 theorem rPositiveInvRel_rOfQ
    {q qinv : QBOMA}
    (h0q : qLT qZero q)
    (hqinv : QInvRel q qinv) :
    RPositiveInvRel (rOfQ q) (rOfQ qinv) := by
  let hpos : CutHasPositive (principalCut q) := principalCut_has_positive h0q
  refine ⟨principalCut q, hpos, rfl, ?_⟩
  change rmk (principalCut qinv) = rmk (cutRecipPos (principalCut q) hpos)
  exact (rmk_sound (cutRecipPos_principal h0q hqinv)).symm

end BOMA.R.DedekindPositiveInverseRelation003

/- Nonzero multiplicative inverse existence revision 004.
Revision 003 is preserved; this revision resolves only the ambiguous rNeg_zero provenance. -/
namespace BOMA.R.DedekindNonzeroInverse004

open BOMA.Q.Quotient001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindPositiveDecomposition001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindSignedMulAssociativity001
open BOMA.R.DedekindOrderedRing001
open BOMA.R.DedekindPositiveInverseRelation003

 theorem rNeg_ne_zero {x : RBOMA}
    (hx0 : x ≠ rZero) :
    rNeg x ≠ rZero := by
  intro hneg0
  apply hx0
  have h := congrArg rNeg hneg0
  rw [rNeg_involutive,
      BOMA.R.DedekindSignedMulCandidate001.rNeg_zero] at h
  exact h

 theorem r_inverse_exists_nonzero
    (x : RBOMA)
    (hx0 : x ≠ rZero) :
    ∃ y : RBOMA, rMulCandidate x y = rOne := by
  rcases rLE_total_classical rZero x with h0x | hxle0
  · rcases rPositiveInvRel_exists h0x hx0 with ⟨y, hyRel⟩
    exact ⟨y, rPositiveInvRel_product_one hyRel⟩
  · have h0nx : rLE rZero (rNeg x) := rNeg_nonneg_of_nonpos hxle0
    have hnx0 : rNeg x ≠ rZero := rNeg_ne_zero hx0
    rcases rPositiveInvRel_exists h0nx hnx0 with ⟨y, hyRel⟩
    have hprod : rMulCandidate (rNeg x) y = rOne :=
      rPositiveInvRel_product_one hyRel
    refine ⟨rNeg y, ?_⟩
    calc
      rMulCandidate x (rNeg y) = rNeg (rMulCandidate x y) :=
        rMulCandidate_neg_right x y
      _ = rMulCandidate (rNeg x) y :=
        (rMulCandidate_neg_left x y).symm
      _ = rOne := hprod

 theorem r_inverse_exists_nonzero_left
    (x : RBOMA)
    (hx0 : x ≠ rZero) :
    ∃ y : RBOMA, rMulCandidate y x = rOne := by
  rcases r_inverse_exists_nonzero x hx0 with ⟨y, hy⟩
  refine ⟨y, ?_⟩
  rw [rMulCandidate_comm]
  exact hy

 theorem r_inverse_witness_unique
    {x y z : RBOMA}
    (hy : rMulCandidate x y = rOne)
    (hz : rMulCandidate x z = rOne) :
    y = z := by
  calc
    y = rMulCandidate y rOne := (rMulCandidate_one_right y).symm
    _ = rMulCandidate y (rMulCandidate x z) :=
      congrArg (fun t => rMulCandidate y t) hz.symm
    _ = rMulCandidate (rMulCandidate y x) z :=
      (rMulCandidate_assoc y x z).symm
    _ = rMulCandidate (rMulCandidate x y) z := by
      rw [rMulCandidate_comm y x]
    _ = rMulCandidate rOne z := by rw [hy]
    _ = z := rMulCandidate_one_left z

end BOMA.R.DedekindNonzeroInverse004

/- Derived strict order on the selected Dedekind quotient carrier.
No new primitive order is introduced: strictness is non-strict order plus inequality. -/
namespace BOMA.R.DedekindStrictOrder001

open BOMA.Q.Quotient001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001

/-- Strict real order derived from the accepted quotient non-strict order. -/
def rLT (x y : RBOMA) : Prop := rLE x y ∧ x ≠ y

@[simp] theorem rlt_irrefl (x : RBOMA) : ¬ rLT x x := by
  intro h
  exact h.2 rfl

/-- On explicit cut representatives, strict real order is strict cut inclusion:
inclusion together with failure of extensional cut identity. -/
theorem rlt_mk_iff (A B : LowerCut) :
    rLT (rmk A) (rmk B) ↔ CutLE A B ∧ ¬ CutEquiv A B := by
  constructor
  · intro h
    refine ⟨(rLE_mk_iff A B).1 h.1, ?_⟩
    intro hEq
    exact h.2 (rmk_sound hEq)
  · intro h
    refine ⟨(rLE_mk_iff A B).2 h.1, ?_⟩
    intro hmk
    exact h.2 ((rmk_eq_iff).1 hmk)

/-- The rational embedding preserves and reflects strict order. -/
theorem rOfQ_strict_order (q r : QBOMA) :
    rLT (rOfQ q) (rOfQ r) ↔ qLT q r := by
  constructor
  · intro h
    refine ⟨(rOfQ_order q r).1 h.1, ?_⟩
    intro hqr
    apply h.2
    exact congrArg rOfQ hqr
  · intro h
    refine ⟨(rOfQ_order q r).2 h.1, ?_⟩
    intro hEq
    exact h.2 (rOfQ_injective hEq)

end BOMA.R.DedekindStrictOrder001

/- Explicit ordered-field closure laws required by the Stage-One R acceptance contract.
These are derived from already-certified RBOMA additive/order/multiplicative/inverse interfaces. -/
namespace BOMA.R.DedekindOrderedFieldClosure001

open BOMA.Q.Quotient001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindStrictOrder001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindOrderAdditive001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindAdditiveDerived001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindPositiveReciprocal001
open BOMA.R.DedekindPositiveInverseRelation003
open BOMA.R.DedekindNonzeroInverse004

/-- Nontriviality of the selected real zero and one is inherited from the
accepted rational strict order through the faithful principal-cut embedding. -/
theorem rZero_ne_rOne_field : rZero ≠ rOne := by
  have hlt : rLT rZero rOne := by
    change rLT (rOfQ qZero) (rOfQ qOne)
    exact (rOfQ_strict_order qZero qOne).2 qzero_lt_one
  exact hlt.2

/-- Addition by a common right translate is an order equivalence, not merely
one-way monotonicity. -/
theorem rLE_add_right_iff (x y c : RBOMA) :
    rLE (rAdd x c) (rAdd y c) ↔ rLE x y := by
  constructor
  · intro h
    have h' := rAdd_mono_right h (rNeg c)
    rw [rAdd_sub_right x c, rAdd_sub_right y c] at h'
    exact h'
  · intro h
    exact rAdd_mono_right h c

/-- Addition by a common left translate is likewise an order equivalence. -/
theorem rLE_add_left_iff (x y c : RBOMA) :
    rLE (rAdd c x) (rAdd c y) ↔ rLE x y := by
  rw [rAdd_comm c x, rAdd_comm c y]
  exact rLE_add_right_iff x y c

/-- Negation reverses the selected real order. -/
theorem rNeg_order_reversing {x y : RBOMA}
    (hxy : rLE x y) :
    rLE (rNeg y) (rNeg x) := by
  let c : RBOMA := rAdd (rNeg x) (rNeg y)
  have h := rAdd_mono_right hxy c
  have hx : rAdd x c = rNeg y := by
    unfold c
    calc
      rAdd x (rAdd (rNeg x) (rNeg y)) =
          rAdd (rAdd x (rNeg x)) (rNeg y) :=
        (rAdd_assoc x (rNeg x) (rNeg y)).symm
      _ = rAdd rZero (rNeg y) := by rw [rAdd_neg_right]
      _ = rNeg y := rAdd_zero_left _
  have hy : rAdd y c = rNeg x := by
    unfold c
    calc
      rAdd y (rAdd (rNeg x) (rNeg y)) =
          rAdd y (rAdd (rNeg y) (rNeg x)) := by
        rw [rAdd_comm (rNeg x) (rNeg y)]
      _ = rAdd (rAdd y (rNeg y)) (rNeg x) :=
        (rAdd_assoc y (rNeg y) (rNeg x)).symm
      _ = rAdd rZero (rNeg x) := by rw [rAdd_neg_right]
      _ = rNeg x := rAdd_zero_left _
  rw [hx, hy] at h
  exact h

/-- The selected positive reciprocal relation yields a strictly positive inverse,
not merely a nonnegative one. -/
theorem rPositiveInvRel_strict_positive
    {x y : RBOMA}
    (hxy : RPositiveInvRel x y) :
    rLT rZero y := by
  have hprod : rMulCandidate x y = rOne :=
    rPositiveInvRel_product_one hxy
  have hy0 : y ≠ rZero := by
    intro hy0
    rw [hy0, rMulCandidate_zero_right] at hprod
    exact rZero_ne_rOne_field hprod
  rcases hxy with ⟨A, hApos, hxA, hyA⟩
  have h0y : rLE rZero y := by
    rw [hyA]
    change rLE (rmk (principalCut qZero)) (rmk (cutRecipPos A hApos))
    exact (rLE_mk_iff (principalCut qZero) (cutRecipPos A hApos)).2
      (cut_zero_le_recipPos A hApos)
  exact ⟨h0y, fun h0yEq => hy0 h0yEq.symm⟩

/-- Any multiplicative inverse witness of a strictly positive real is strictly
positive. Uniqueness transports positivity from the direct positive reciprocal
witness to an arbitrary accepted inverse witness. -/
theorem rInverse_positive_of_positive
    {x y : RBOMA}
    (h0x : rLT rZero x)
    (hxy : rMulCandidate x y = rOne) :
    rLT rZero y := by
  have hx0 : x ≠ rZero := by
    intro hx0
    exact h0x.2 hx0.symm
  rcases rPositiveInvRel_exists h0x.1 hx0 with ⟨z, hz⟩
  have hzprod : rMulCandidate x z = rOne :=
    rPositiveInvRel_product_one hz
  have hyz : y = z := r_inverse_witness_unique hxy hzprod
  rw [hyz]
  exact rPositiveInvRel_strict_positive hz

end BOMA.R.DedekindOrderedFieldClosure001

/- Formal-carrier Dedekind completeness for the selected RBOMA quotient. -/
namespace BOMA.R.DedekindCompleteness001

open BOMA.Q.Quotient001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001

/-- U is an upper bound of a formal real family F. -/
def RUpperBound (F : RBOMA → Prop) (U : RBOMA) : Prop :=
  ∀ x : RBOMA, F x → rLE x U

/-- Raw lower cut formed from all rational members occurring in representatives
of a nonempty formal-real family. An explicit representative of one upper bound
is used only to prove properness; no representative selector for family elements
is introduced. -/
def supCutFromFamily
    (F : RBOMA → Prop)
    (hne : ∃ x : RBOMA, F x)
    (U : LowerCut)
    (hUB : RUpperBound F (rmk U)) : LowerCut where
  lower := fun q =>
    ∃ x : RBOMA, F x ∧ ∃ A : LowerCut, x = rmk A ∧ A.lower q
  nonempty := by
    rcases hne with ⟨x, hxF⟩
    refine Quotient.inductionOn x ?_ hxF
    intro A hAF
    rcases A.nonempty with ⟨q, hqA⟩
    exact ⟨q, rmk A, hAF, A, rfl, hqA⟩
  proper := by
    rcases U.proper with ⟨q, hqU⟩
    refine ⟨q, ?_⟩
    intro hqSup
    rcases hqSup with ⟨x, hxF, A, hxA, hqA⟩
    have hxU : rLE x (rmk U) := hUB x hxF
    rw [hxA] at hxU
    have hAU : CutLE A U := (rLE_mk_iff A U).1 hxU
    exact hqU (hAU q hqA)
  downward := by
    intro a b hb hab
    rcases hb with ⟨x, hxF, A, hxA, hbA⟩
    exact ⟨x, hxF, A, hxA, A.downward hbA hab⟩
  rounded := by
    intro a ha
    rcases ha with ⟨x, hxF, A, hxA, haA⟩
    rcases A.rounded haA with ⟨b, hbA, hab⟩
    exact ⟨b, ⟨x, hxF, A, hxA, hbA⟩, hab⟩

/-- Every member of F lies below the formal class of the union cut. -/
theorem member_le_supFamily
    (F : RBOMA → Prop)
    (hne : ∃ x : RBOMA, F x)
    (U : LowerCut)
    (hUB : RUpperBound F (rmk U))
    (x : RBOMA) (hxF : F x) :
    rLE x (rmk (supCutFromFamily F hne U hUB)) := by
  refine Quotient.inductionOn x ?_ hxF
  intro A hAF
  apply (rLE_mk_iff A (supCutFromFamily F hne U hUB)).2
  intro q hqA
  exact ⟨rmk A, hAF, A, rfl, hqA⟩

/-- The formal union cut lies below every common upper bound. -/
theorem supFamily_le_of_upper
    (F : RBOMA → Prop)
    (hne : ∃ x : RBOMA, F x)
    (U : LowerCut)
    (hUB : RUpperBound F (rmk U))
    (B : RBOMA) (hB : RUpperBound F B) :
    rLE (rmk (supCutFromFamily F hne U hUB)) B := by
  refine Quotient.inductionOn B ?_ hB
  intro C hC
  apply (rLE_mk_iff (supCutFromFamily F hne U hUB) C).2
  intro q hqSup
  rcases hqSup with ⟨x, hxF, A, hxA, hqA⟩
  have hxC : rLE x (rmk C) := hC x hxF
  rw [hxA] at hxC
  have hAC : CutLE A C := (rLE_mk_iff A C).1 hxC
  exact hAC q hqA

/-- Formal-carrier Dedekind least-upper-bound theorem.
Every nonempty family having an explicit upper bound has a least upper bound in
RBOMA. The theorem is proved without choosing representatives for the family. -/
theorem rDedekind_lub_exists
    (F : RBOMA → Prop)
    (hne : ∃ x : RBOMA, F x)
    (U : RBOMA)
    (hUB : RUpperBound F U) :
    ∃ s : RBOMA,
      (∀ x : RBOMA, F x → rLE x s) ∧
      (∀ B : RBOMA, RUpperBound F B → rLE s B) := by
  refine Quotient.inductionOn U ?_ hUB
  intro Ucut hU
  let S : RBOMA := rmk (supCutFromFamily F hne Ucut hU)
  refine ⟨S, ?_, ?_⟩
  · intro x hxF
    exact member_le_supFamily F hne Ucut hU x hxF
  · intro B hB
    exact supFamily_le_of_upper F hne Ucut hU B hB

end BOMA.R.DedekindCompleteness001

/- Rational-image density in the selected Dedekind quotient carrier.
The only new classical step is witness extraction from strict extensional cut inclusion. -/
namespace BOMA.R.DedekindRationalDensity001

open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindStrictOrder001

/-- Strict cut inclusion has an explicit rational point lying in the larger cut
and outside the smaller cut. The witness extraction from failure of extensional
identity is the localized classical step in this file. -/
theorem strict_cut_inclusion_witness
    {A B : LowerCut}
    (hAB : CutLE A B)
    (hne : ¬ CutEquiv A B) :
    ∃ b : QBOMA, B.lower b ∧ ¬ A.lower b := by
  apply Classical.byContradiction
  intro hNoWitness
  apply hne
  intro q
  constructor
  · intro hqA
    exact hAB q hqA
  · intro hqB
    cases Classical.em (A.lower q) with
    | inl hqA => exact hqA
    | inr hNotA =>
        exact False.elim (hNoWitness ⟨q, hqB, hNotA⟩)

/-- Between two strictly nested lower cuts lies a principal rational cut that is
strictly above the smaller cut and strictly below the larger cut. -/
theorem principal_cut_between_strict_cuts
    {A B : LowerCut}
    (hAB : CutLE A B)
    (hne : ¬ CutEquiv A B) :
    ∃ m : QBOMA,
      CutLE A (principalCut m) ∧
      ¬ CutEquiv A (principalCut m) ∧
      CutLE (principalCut m) B ∧
      ¬ CutEquiv (principalCut m) B := by
  rcases strict_cut_inclusion_witness hAB hne with ⟨b, hbB, hbNotA⟩
  rcases B.rounded hbB with ⟨c, hcB, hbc⟩
  rcases rational_order_dense hbc with ⟨m, hbm, hmc⟩

  have hApm : CutLE A (principalCut m) := by
    intro a haA
    change qLT a m
    have hab : qLT a b := by
      rcases qle_total a b with hab | hba
      · refine ⟨hab, ?_⟩
        intro heq
        apply hbNotA
        rw [← heq]
        exact haA
      · exact False.elim (hbNotA (A.downward haA hba))
    exact qlt_trans hab hbm

  have hmB : B.lower m := B.downward hcB hmc.1

  have hpmB : CutLE (principalCut m) B := by
    intro a haM
    exact B.downward hmB haM.1

  have hAne : ¬ CutEquiv A (principalCut m) := by
    intro hEq
    exact hbNotA ((hEq b).2 hbm)

  have hBne : ¬ CutEquiv (principalCut m) B := by
    intro hEq
    have hmm : (principalCut m).lower m := (hEq m).2 hmB
    exact (qlt_irrefl m) hmm

  exact ⟨m, hApm, hAne, hpmB, hBne⟩

/-- RA-12: the embedded accepted rationals are strictly order-dense in RBOMA. -/
theorem r_rational_image_dense
    {x y : RBOMA}
    (hxy : rLT x y) :
    ∃ q : QBOMA,
      rLT x (rOfQ q) ∧ rLT (rOfQ q) y := by
  rcases hxy.1 with ⟨A, B, hxA, hyB, hAB⟩
  have hneAB : ¬ CutEquiv A B := by
    intro hEq
    apply hxy.2
    calc
      x = rmk A := hxA
      _ = rmk B := rmk_sound hEq
      _ = y := hyB.symm
  rcases principal_cut_between_strict_cuts hAB hneAB with
    ⟨m, hApm, hAne, hpmB, hBne⟩
  refine ⟨m, ?_, ?_⟩
  · constructor
    · exact ⟨A, principalCut m, hxA, rfl, hApm⟩
    · intro hxq
      apply hAne
      have hmk : rmk A = rmk (principalCut m) := by
        calc
          rmk A = x := hxA.symm
          _ = rOfQ m := hxq
          _ = rmk (principalCut m) := rfl
      exact (rmk_eq_iff).1 hmk
  · constructor
    · exact ⟨principalCut m, B, rfl, hyB, hpmB⟩
    · intro hqy
      apply hBne
      have hmk : rmk (principalCut m) = rmk B := by
        calc
          rmk (principalCut m) = rOfQ m := rfl
          _ = y := hqy
          _ = rmk B := hyB
      exact (rmk_eq_iff).1 hmk

end BOMA.R.DedekindRationalDensity001

/- Archimedean characterization of the selected Dedekind quotient carrier.
The proof reuses only the certified rational natural-upper-bound contribution;
it does not consume finite cut-membership search or cut-bracketing. -/
namespace BOMA.R.DedekindArchimedean001

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Q.Quotient001
open BOMA.Q.Embedding001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.QArchimedeanUpperBound001
open BOMA.R.DedekindProbe001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindStrictOrder001

/-- Constructive mixed strict/non-strict transitivity used locally so the
Archimedean theorem does not inherit the real-addition payload merely for a Q helper. -/
theorem qlt_le_trans_arch {x y z : QBOMA}
    (hxy : qLT x y) (hyz : qLE y z) : qLT x z := by
  refine ⟨qle_trans hxy.1 hyz, ?_⟩
  intro hxz
  have hyx : qLE y x := by
    have h := hyz
    rw [← hxz] at h
    exact h
  have hxyEq : x = y := qle_antisymm hxy.1 hyx
  exact hxy.2 hxyEq

/-- Every selected lower cut lies strictly below some principal cut generated by
an embedded BOMA natural. -/
theorem cut_strict_below_natural_principal
    (A : LowerCut) :
    ∃ n : BOMANat,
      CutLE A (principalCut (qOfN n)) ∧
      ¬ CutEquiv A (principalCut (qOfN n)) := by
  rcases A.proper with ⟨u, huNotA⟩
  let u1 := qAdd u qOne
  have huu1 : qLT u u1 := by
    have h := qlt_add_right qzero_lt_one u
    change qLT (qAdd qZero u) (qAdd qOne u) at h
    rw [qAdd_zero_left, qAdd_comm qOne u] at h
    exact h
  rcases q_le_natural_upper u1 with ⟨n, hu1n⟩
  have hun : qLT u (qOfN n) := qlt_le_trans_arch huu1 hu1n

  have hLE : CutLE A (principalCut (qOfN n)) := by
    intro a haA
    change qLT a (qOfN n)
    have hau : qLT a u := by
      rcases qle_total a u with hau | hua
      · refine ⟨hau, ?_⟩
        intro heq
        apply huNotA
        rw [← heq]
        exact haA
      · exact False.elim (huNotA (A.downward haA hua))
    exact qlt_trans hau hun

  have hne : ¬ CutEquiv A (principalCut (qOfN n)) := by
    intro hEq
    exact huNotA ((hEq u).2 hun)

  exact ⟨n, hLE, hne⟩

/-- RA-13: every selected real lies strictly below an embedded BOMA natural. -/
theorem r_archimedean_strict_upper (x : RBOMA) :
    ∃ n : BOMANat, rLT x (rOfQ (qOfN n)) := by
  refine Quotient.inductionOn x ?_
  intro A
  rcases cut_strict_below_natural_principal A with ⟨n, hLE, hne⟩
  refine ⟨n, ?_⟩
  change rLT (rmk A) (rmk (principalCut (qOfN n)))
  exact (rlt_mk_iff A (principalCut (qOfN n))).2 ⟨hLE, hne⟩

end BOMA.R.DedekindArchimedean001

/- Stage-One real integration certificate.
This file introduces no new carrier, operation, axiom, or completeness notion.
It packages already-certified interfaces to verify that they coexist on one RBOMA. -/
namespace BOMA.R.StageIntegration002

open BOMA.NCore.RB001
open BOMA.NCore.RB001.BOMANat
open BOMA.Q.Quotient001
open BOMA.Q.Order001
open BOMA.R.Gateway001
open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindOrderClassical001
open BOMA.R.DedekindStrictOrder001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindAdditionLaws001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindAdditiveInverse001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.DedekindSignedMulBasicLaws001
open BOMA.R.DedekindSignedMulAssociativity001
open BOMA.R.DedekindSignedMulDistributivity001
open BOMA.R.DedekindOrderedRing001
open BOMA.R.DedekindNonzeroInverse004
open BOMA.R.DedekindOrderedFieldClosure001
open BOMA.R.DedekindCompleteness001
open BOMA.R.DedekindRationalDensity001
open BOMA.R.DedekindArchimedean001

/-- RA-21 machine-checkable integration surface.

The certificate deliberately keeps multiplicative inversion witness-based:
no global inverse selector is introduced. Completeness is exactly the selected
Dedekind least-upper-bound contract. -/
structure RStageIntegrationCertificate where
  qEmbeddingInjective :
    ∀ {q r : QBOMA}, rOfQ q = rOfQ r → q = r
  qOrderExact :
    ∀ q r : QBOMA, rLE (rOfQ q) (rOfQ r) ↔ qLE q r
  orderRefl :
    ∀ x : RBOMA, rLE x x
  orderTrans :
    ∀ {x y z : RBOMA}, rLE x y → rLE y z → rLE x z
  orderAntisymm :
    ∀ {x y : RBOMA}, rLE x y → rLE y x → x = y
  orderTotal :
    ∀ x y : RBOMA, rLE x y ∨ rLE y x
  strictIrrefl :
    ∀ x : RBOMA, ¬ rLT x x
  nontrivial :
    rZero ≠ rOne
  addComm :
    ∀ x y : RBOMA, rAdd x y = rAdd y x
  addAssoc :
    ∀ x y z : RBOMA, rAdd (rAdd x y) z = rAdd x (rAdd y z)
  addZeroLeft :
    ∀ x : RBOMA, rAdd rZero x = x
  addInverseRight :
    ∀ x : RBOMA, rAdd x (rNeg x) = rZero
  addTranslateOrderIff :
    ∀ x y c : RBOMA, rLE (rAdd x c) (rAdd y c) ↔ rLE x y
  negOrderReversing :
    ∀ {x y : RBOMA}, rLE x y → rLE (rNeg y) (rNeg x)
  mulComm :
    ∀ x y : RBOMA, rMulCandidate x y = rMulCandidate y x
  mulAssoc :
    ∀ x y z : RBOMA,
      rMulCandidate (rMulCandidate x y) z =
      rMulCandidate x (rMulCandidate y z)
  mulOneLeft :
    ∀ x : RBOMA, rMulCandidate rOne x = x
  distribRight :
    ∀ x y z : RBOMA,
      rMulCandidate x (rAdd y z) =
      rAdd (rMulCandidate x y) (rMulCandidate x z)
  orderMulNonneg :
    ∀ {a b c : RBOMA},
      rLE a b → rLE rZero c →
      rLE (rMulCandidate a c) (rMulCandidate b c)
  inverseExists :
    ∀ x : RBOMA, x ≠ rZero →
      ∃ y : RBOMA, rMulCandidate x y = rOne
  inverseUnique :
    ∀ {x y z : RBOMA},
      rMulCandidate x y = rOne →
      rMulCandidate x z = rOne → y = z
  positiveInverse :
    ∀ {x y : RBOMA},
      rLT rZero x → rMulCandidate x y = rOne → rLT rZero y
  dedekindLUB :
    ∀ (F : RBOMA → Prop),
      (∃ x : RBOMA, F x) →
      ∀ U : RBOMA, RUpperBound F U →
      ∃ s : RBOMA,
        (∀ x : RBOMA, F x → rLE x s) ∧
        (∀ B : RBOMA, RUpperBound F B → rLE s B)
  rationalDensity :
    ∀ {x y : RBOMA}, rLT x y →
      ∃ q : QBOMA, rLT x (rOfQ q) ∧ rLT (rOfQ q) y
  archimedeanUpper :
    ∀ x : RBOMA,
      ∃ n : BOMANat, rLT x (rOfQ (BOMA.Q.Embedding001.qOfN n))

/-- The single certificate used by R-J-002. Each field is an already-proved
Stage-One theorem instantiated on the same formal carrier and operations. -/
theorem rStageIntegrationCertificate : RStageIntegrationCertificate where
  qEmbeddingInjective := @rOfQ_injective
  qOrderExact := rOfQ_order
  orderRefl := rLE_refl
  orderTrans := @rLE_trans
  orderAntisymm := @rLE_antisymm
  orderTotal := rLE_total_classical
  strictIrrefl := rlt_irrefl
  nontrivial := rZero_ne_rOne_field
  addComm := rAdd_comm
  addAssoc := rAdd_assoc
  addZeroLeft := rAdd_zero_left
  addInverseRight := rAdd_neg_right
  addTranslateOrderIff := rLE_add_right_iff
  negOrderReversing := @rNeg_order_reversing
  mulComm := rMulCandidate_comm
  mulAssoc := rMulCandidate_assoc
  mulOneLeft := rMulCandidate_one_left
  distribRight := rMulCandidate_add_right
  orderMulNonneg := @rMulCandidate_order_compatible
  inverseExists := r_inverse_exists_nonzero
  inverseUnique := @r_inverse_witness_unique
  positiveInverse := @rInverse_positive_of_positive
  dedekindLUB := rDedekind_lub_exists
  rationalDensity := @r_rational_image_dense
  archimedeanUpper := r_archimedean_strict_upper

end BOMA.R.StageIntegration002

/- C-stage accepted-R interface sufficiency probe.

Purpose:
  derive the order facts needed by likely C constructions from an abstract
  RStageIntegrationCertificate first, then instantiate the result with the
  accepted R certificate. The abstract proof does not unfold LowerCut,
  CutEquiv, quotient representatives, or the selected Dedekind
  multiplication/inverse implementations.

This file does not construct a complex carrier and does not select C-DP-001.
-/
namespace BOMA.C.RInterfaceNoSquareProbe001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002

/-- Zero is fixed by negation, derived only from the accepted additive interface. -/
theorem neg_zero_from_interface
    (C : RStageIntegrationCertificate) :
    rNeg rZero = rZero := by
  calc
    rNeg rZero = rAdd rZero (rNeg rZero) :=
      (C.addZeroLeft (rNeg rZero)).symm
    _ = rZero := C.addInverseRight rZero

/-- Additive inverse witnesses are unique, derived from the accepted additive laws. -/
theorem add_inverse_unique_from_interface
    (C : RStageIntegrationCertificate)
    {x y : RBOMA}
    (hxy : rAdd x y = rZero) :
    y = rNeg x := by
  calc
    y = rAdd rZero y := (C.addZeroLeft y).symm
    _ = rAdd (rAdd x (rNeg x)) y := by
      rw [C.addInverseRight x]
    _ = rAdd x (rAdd (rNeg x) y) :=
      C.addAssoc x (rNeg x) y
    _ = rAdd x (rAdd y (rNeg x)) := by
      rw [C.addComm (rNeg x) y]
    _ = rAdd (rAdd x y) (rNeg x) :=
      (C.addAssoc x y (rNeg x)).symm
    _ = rAdd rZero (rNeg x) := by rw [hxy]
    _ = rNeg x := C.addZeroLeft (rNeg x)

/-- Negation is involutive, derived from accepted additive commutativity and inverse uniqueness. -/
theorem neg_involutive_from_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rNeg (rNeg x) = x := by
  have hleft : rAdd (rNeg x) x = rZero := by
    calc
      rAdd (rNeg x) x = rAdd x (rNeg x) := C.addComm (rNeg x) x
      _ = rZero := C.addInverseRight x
  exact (add_inverse_unique_from_interface C hleft).symm

/-- Right zero-annihilation follows from distributivity and the accepted additive group laws. -/
theorem mul_zero_right_from_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rMulCandidate x rZero = rZero := by
  let p : RBOMA := rMulCandidate x rZero
  have hdist := C.distribRight x rZero rZero
  have h00 : rAdd rZero rZero = rZero := C.addZeroLeft rZero
  have hp : p = rAdd p p := by
    unfold p
    rw [h00] at hdist
    exact hdist
  have hnegleft : rAdd (rNeg p) p = rZero := by
    calc
      rAdd (rNeg p) p = rAdd p (rNeg p) := C.addComm (rNeg p) p
      _ = rZero := C.addInverseRight p
  have hcancel := congrArg (fun t => rAdd (rNeg p) t) hp
  have hz_eq_p : rZero = p := by
    calc
      rZero = rAdd (rNeg p) p := hnegleft.symm
      _ = rAdd (rNeg p) (rAdd p p) := hcancel
      _ = rAdd (rAdd (rNeg p) p) p :=
        (C.addAssoc (rNeg p) p p).symm
      _ = rAdd rZero p := by rw [hnegleft]
      _ = p := C.addZeroLeft p
  exact hz_eq_p.symm

/-- Left zero-annihilation follows from accepted multiplication commutativity. -/
theorem mul_zero_left_from_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rMulCandidate rZero x = rZero := by
  calc
    rMulCandidate rZero x = rMulCandidate x rZero := C.mulComm rZero x
    _ = rZero := mul_zero_right_from_interface C x

/-- Multiplication by an additive inverse on the right negates the product. -/
theorem mul_neg_right_from_interface
    (C : RStageIntegrationCertificate)
    (x y : RBOMA) :
    rMulCandidate x (rNeg y) = rNeg (rMulCandidate x y) := by
  have hd := C.distribRight x y (rNeg y)
  have hy0 : rAdd y (rNeg y) = rZero := C.addInverseRight y
  have hsum :
      rAdd (rMulCandidate x y) (rMulCandidate x (rNeg y)) = rZero := by
    calc
      rAdd (rMulCandidate x y) (rMulCandidate x (rNeg y)) =
          rMulCandidate x (rAdd y (rNeg y)) := hd.symm
      _ = rMulCandidate x rZero := by rw [hy0]
      _ = rZero := mul_zero_right_from_interface C x
  exact add_inverse_unique_from_interface C hsum

/-- Multiplication by an additive inverse on the left negates the product. -/
theorem mul_neg_left_from_interface
    (C : RStageIntegrationCertificate)
    (x y : RBOMA) :
    rMulCandidate (rNeg x) y = rNeg (rMulCandidate x y) := by
  calc
    rMulCandidate (rNeg x) y = rMulCandidate y (rNeg x) :=
      C.mulComm (rNeg x) y
    _ = rNeg (rMulCandidate y x) := mul_neg_right_from_interface C y x
    _ = rNeg (rMulCandidate x y) := by rw [C.mulComm y x]

/-- Squaring a negated value gives the same square, using only accepted field laws. -/
theorem mul_neg_neg_same_from_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rMulCandidate (rNeg x) (rNeg x) = rMulCandidate x x := by
  calc
    rMulCandidate (rNeg x) (rNeg x) =
        rNeg (rMulCandidate x (rNeg x)) :=
      mul_neg_left_from_interface C x (rNeg x)
    _ = rNeg (rNeg (rMulCandidate x x)) := by
      rw [mul_neg_right_from_interface C x x]
    _ = rMulCandidate x x := neg_involutive_from_interface C _

/-- C-RL-001 at the abstract accepted-R interface level: every square is nonnegative.

The proof branches only on total order supplied by the certificate. The
negative branch replaces x by -x and uses identities proved above from the
same abstract interface. -/
theorem square_nonnegative_of_interface
    (C : RStageIntegrationCertificate)
    (x : RBOMA) :
    rLE rZero (rMulCandidate x x) := by
  rcases C.orderTotal rZero x with h0x | hx0
  · have h := C.orderMulNonneg (a := rZero) (b := x) (c := x) h0x h0x
    rw [mul_zero_left_from_interface C x] at h
    exact h
  · have h0nx0 := C.negOrderReversing hx0
    have h0nx : rLE rZero (rNeg x) := by
      rw [neg_zero_from_interface C] at h0nx0
      exact h0nx0
    have h := C.orderMulNonneg
      (a := rZero) (b := rNeg x) (c := rNeg x) h0nx h0nx
    rw [mul_zero_left_from_interface C (rNeg x),
        mul_neg_neg_same_from_interface C x] at h
    exact h

/-- One is nonnegative as the square of one, at the abstract interface level. -/
theorem zero_le_one_of_interface
    (C : RStageIntegrationCertificate) :
    rLE rZero rOne := by
  have h := square_nonnegative_of_interface C rOne
  rw [C.mulOneLeft rOne] at h
  exact h

/-- C-RL-002 at the abstract accepted-R interface level: -1 is not a square. -/
theorem minus_one_not_square_of_interface
    (C : RStageIntegrationCertificate) :
    ¬ ∃ x : RBOMA, rMulCandidate x x = rNeg rOne := by
  rintro ⟨x, hx⟩
  have hsq : rLE rZero (rNeg rOne) := by
    have h := square_nonnegative_of_interface C x
    rw [hx] at h
    exact h
  have h10raw := C.negOrderReversing hsq
  have h10 : rLE rOne rZero := by
    rw [neg_involutive_from_interface C rOne,
        neg_zero_from_interface C] at h10raw
    exact h10raw
  have h01 : rLE rZero rOne := zero_le_one_of_interface C
  have hEq : rZero = rOne := C.orderAntisymm h01 h10
  exact C.nontrivial hEq

/-- C-RL-001 instantiated on the accepted Stage-One R integration certificate. -/
theorem square_nonnegative_from_accepted_R (x : RBOMA) :
    rLE rZero (rMulCandidate x x) :=
  square_nonnegative_of_interface rStageIntegrationCertificate x

/-- C-RL-002 instantiated on the accepted Stage-One R integration certificate.

This is the route-neutral C boundary fact needed to prevent a future
imaginary generator from collapsing into the embedded real line. -/
theorem minus_one_not_square_from_accepted_R :
    ¬ ∃ x : RBOMA, rMulCandidate x x = rNeg rOne :=
  minus_one_not_square_of_interface rStageIntegrationCertificate

end BOMA.C.RInterfaceNoSquareProbe001

/- PDSA-C-003 Route P: noncanonical rank-two coordinate probe.

This file is an exploratory producer candidate. It does not select C-DP-001,
create an accepted C Claim, construct a full field inverse, or use the Route Q
candidate.
-/
namespace BOMA.C.RoutePairProbe001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001

/-- Route-local coordinate carrier; not the canonical BOMA complex carrier. -/
structure PairCandidate where
  re : RBOMA
  im : RBOMA

/-- Core Lean does not generate a structure extensionality theorem automatically. -/
theorem pair_ext {z w : PairCandidate}
    (hre : z.re = w.re) (him : z.im = w.im) :
    z = w := by
  cases z
  cases w
  cases hre
  cases him
  rfl

def zero : PairCandidate := ⟨rZero, rZero⟩
def one : PairCandidate := ⟨rOne, rZero⟩
def ofR (a : RBOMA) : PairCandidate := ⟨a, rZero⟩
def imag : PairCandidate := ⟨rZero, rOne⟩

def neg (z : PairCandidate) : PairCandidate :=
  ⟨rNeg z.re, rNeg z.im⟩

def add (z w : PairCandidate) : PairCandidate :=
  ⟨rAdd z.re w.re, rAdd z.im w.im⟩

def mul (z w : PairCandidate) : PairCandidate :=
  ⟨rAdd (rMulCandidate z.re w.re) (rNeg (rMulCandidate z.im w.im)),
   rAdd (rMulCandidate z.re w.im) (rMulCandidate z.im w.re)⟩

theorem add_zero_right_from_interface
    (C : RStageIntegrationCertificate) (x : RBOMA) :
    rAdd x rZero = x := by
  calc
    rAdd x rZero = rAdd rZero x := C.addComm x rZero
    _ = x := C.addZeroLeft x

theorem mul_one_right_from_interface
    (C : RStageIntegrationCertificate) (x : RBOMA) :
    rMulCandidate x rOne = x := by
  calc
    rMulCandidate x rOne = rMulCandidate rOne x := C.mulComm x rOne
    _ = x := C.mulOneLeft x

/-- P/Q-03: route-local real embedding is faithful. -/
theorem ofR_injective {a b : RBOMA}
    (h : ofR a = ofR b) : a = b :=
  congrArg PairCandidate.re h

/-- Multiplication by the route-local generator extracts an imaginary coefficient. -/
theorem embed_mul_imag
    (C : RStageIntegrationCertificate) (b : RBOMA) :
    mul (ofR b) imag = ⟨rZero, b⟩ := by
  apply pair_ext
  · change
      rAdd (rMulCandidate b rZero)
        (rNeg (rMulCandidate rZero rOne)) = rZero
    rw [mul_zero_right_from_interface C b,
        mul_zero_left_from_interface C rOne,
        neg_zero_from_interface C,
        C.addZeroLeft rZero]
  · change
      rAdd (rMulCandidate b rOne)
        (rMulCandidate rZero rZero) = b
    rw [mul_one_right_from_interface C b,
        mul_zero_left_from_interface C rZero,
        add_zero_right_from_interface C b]

/-- Normal form of a real-plus-imaginary route-local expression. -/
theorem coordinate_expression
    (C : RStageIntegrationCertificate) (a b : RBOMA) :
    add (ofR a) (mul (ofR b) imag) = ⟨a, b⟩ := by
  rw [embed_mul_imag C b]
  apply pair_ext
  · exact add_zero_right_from_interface C a
  · exact C.addZeroLeft b

/-- P/Q-06: the distinguished generator squares to negative one. -/
theorem imag_squared
    (C : RStageIntegrationCertificate) :
    mul imag imag = neg one := by
  apply pair_ext
  · change
      rAdd (rMulCandidate rZero rZero)
        (rNeg (rMulCandidate rOne rOne)) = rNeg rOne
    rw [mul_zero_left_from_interface C rZero,
        C.mulOneLeft rOne,
        C.addZeroLeft (rNeg rOne)]
  · change
      rAdd (rMulCandidate rZero rOne)
        (rMulCandidate rOne rZero) = rNeg rZero
    rw [mul_zero_left_from_interface C rOne,
        C.mulOneLeft rZero,
        C.addZeroLeft rZero,
        neg_zero_from_interface C]

/-- P/Q-07: every route-local candidate has a real/imaginary decomposition. -/
theorem decomposition
    (C : RStageIntegrationCertificate) (z : PairCandidate) :
    ∃ a b : RBOMA, z = add (ofR a) (mul (ofR b) imag) := by
  refine ⟨z.re, z.im, ?_⟩
  rw [coordinate_expression C z.re z.im]

/-- P/Q-08: real/imaginary coordinates are unique at Route P equality. -/
theorem decomposition_unique
    (C : RStageIntegrationCertificate)
    {a b a' b' : RBOMA}
    (h : add (ofR a) (mul (ofR b) imag) =
      add (ofR a') (mul (ofR b') imag)) :
    a = a' ∧ b = b' := by
  rw [coordinate_expression C a b,
      coordinate_expression C a' b'] at h
  exact ⟨congrArg PairCandidate.re h,
         congrArg PairCandidate.im h⟩

/-- P/Q-09: the imaginary generator is not in the embedded real line. -/
theorem imag_not_real
    (C : RStageIntegrationCertificate) :
    ¬ ∃ a : RBOMA, imag = ofR a := by
  rintro ⟨a, ha⟩
  have h : rOne = rZero := congrArg PairCandidate.im ha
  exact C.nontrivial h.symm

end BOMA.C.RoutePairProbe001

/- PDSA-C-004: user-selected Route P canonical complex carrier and ring core.

The canonical carrier transparently reuses the already verified Route P record.
Every non-definitional scalar law is derived from the abstract accepted real
integration certificate. This file proves a commutative-ring core only; the
nonzero multiplicative inverse belongs to a later frozen PDSA cycle.
-/
namespace BOMA.C.PairCore001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001

/-- The selected canonical carrier is exactly the verified Route P record. -/
abbrev CBOMA : Type := BOMA.C.RoutePairProbe001.PairCandidate

/-- The selected identity is Lean record equality, equivalent to coordinate equality. -/
theorem c_ext {z w : CBOMA}
    (hre : z.re = w.re) (him : z.im = w.im) : z = w :=
  BOMA.C.RoutePairProbe001.pair_ext hre him

def cZero : CBOMA := BOMA.C.RoutePairProbe001.zero
def cOne : CBOMA := BOMA.C.RoutePairProbe001.one
def cOfR (a : RBOMA) : CBOMA := BOMA.C.RoutePairProbe001.ofR a
def cI : CBOMA := BOMA.C.RoutePairProbe001.imag
def cNeg (z : CBOMA) : CBOMA := BOMA.C.RoutePairProbe001.neg z
def cAdd (z w : CBOMA) : CBOMA := BOMA.C.RoutePairProbe001.add z w
def cMul (z w : CBOMA) : CBOMA := BOMA.C.RoutePairProbe001.mul z w

/-- Scalar additive reassociation needed by the explicit equational normalizer. -/
theorem r_add_left_comm_from_interface
    (C : RStageIntegrationCertificate) (a b c : RBOMA) :
    rAdd a (rAdd b c) = rAdd b (rAdd a c) := by
  calc
    rAdd a (rAdd b c) = rAdd (rAdd a b) c := (C.addAssoc a b c).symm
    _ = rAdd (rAdd b a) c := by rw [C.addComm a b]
    _ = rAdd b (rAdd a c) := C.addAssoc b a c

/-- Scalar multiplicative reassociation needed by the explicit normalizer. -/
theorem r_mul_left_comm_from_interface
    (C : RStageIntegrationCertificate) (a b c : RBOMA) :
    rMulCandidate a (rMulCandidate b c) =
      rMulCandidate b (rMulCandidate a c) := by
  calc
    rMulCandidate a (rMulCandidate b c) =
        rMulCandidate (rMulCandidate a b) c := (C.mulAssoc a b c).symm
    _ = rMulCandidate (rMulCandidate b a) c := by rw [C.mulComm a b]
    _ = rMulCandidate b (rMulCandidate a c) := C.mulAssoc b a c

/-- Distribution in the first scalar argument is derived, not assumed. -/
theorem r_mul_add_left_from_interface
    (C : RStageIntegrationCertificate) (a b c : RBOMA) :
    rMulCandidate (rAdd a b) c =
      rAdd (rMulCandidate a c) (rMulCandidate b c) := by
  calc
    rMulCandidate (rAdd a b) c = rMulCandidate c (rAdd a b) :=
      C.mulComm (rAdd a b) c
    _ = rAdd (rMulCandidate c a) (rMulCandidate c b) :=
      C.distribRight c a b
    _ = rAdd (rMulCandidate a c) (rMulCandidate b c) := by
      rw [C.mulComm c a, C.mulComm c b]

/-- Additive inverse distributes over scalar addition using inverse uniqueness. -/
theorem r_neg_add_from_interface
    (C : RStageIntegrationCertificate) (a b : RBOMA) :
    rNeg (rAdd a b) = rAdd (rNeg a) (rNeg b) := by
  have h : rAdd (rAdd a b) (rAdd (rNeg a) (rNeg b)) = rZero := by
    calc
      rAdd (rAdd a b) (rAdd (rNeg a) (rNeg b)) =
          rAdd a (rAdd b (rAdd (rNeg a) (rNeg b))) :=
        C.addAssoc a b (rAdd (rNeg a) (rNeg b))
      _ = rAdd a (rAdd (rNeg a) (rAdd b (rNeg b))) := by
        rw [r_add_left_comm_from_interface C b (rNeg a) (rNeg b)]
      _ = rAdd (rAdd a (rNeg a)) (rAdd b (rNeg b)) :=
        (C.addAssoc a (rNeg a) (rAdd b (rNeg b))).symm
      _ = rZero := by
        rw [C.addInverseRight a, C.addInverseRight b, C.addZeroLeft rZero]
  exact (add_inverse_unique_from_interface C h).symm

/-- The canonical complex zero and unit remain distinct. -/
theorem c_zero_ne_one (C : RStageIntegrationCertificate) :
    cZero ≠ cOne := by
  intro h
  exact C.nontrivial (congrArg BOMA.C.RoutePairProbe001.PairCandidate.re h)

/-- The selected real embedding is faithful. -/
theorem c_ofR_injective {a b : RBOMA} (h : cOfR a = cOfR b) : a = b :=
  BOMA.C.RoutePairProbe001.ofR_injective h

theorem c_add_comm (C : RStageIntegrationCertificate) (z w : CBOMA) :
    cAdd z w = cAdd w z := by
  apply c_ext
  · exact C.addComm z.re w.re
  · exact C.addComm z.im w.im

theorem c_add_assoc
    (C : RStageIntegrationCertificate) (z w v : CBOMA) :
    cAdd (cAdd z w) v = cAdd z (cAdd w v) := by
  apply c_ext
  · exact C.addAssoc z.re w.re v.re
  · exact C.addAssoc z.im w.im v.im

theorem c_add_zero_left (C : RStageIntegrationCertificate) (z : CBOMA) :
    cAdd cZero z = z := by
  apply c_ext
  · exact C.addZeroLeft z.re
  · exact C.addZeroLeft z.im

theorem c_add_zero_right (C : RStageIntegrationCertificate) (z : CBOMA) :
    cAdd z cZero = z := by
  rw [c_add_comm C z cZero, c_add_zero_left C z]

theorem c_add_neg_right (C : RStageIntegrationCertificate) (z : CBOMA) :
    cAdd z (cNeg z) = cZero := by
  apply c_ext
  · exact C.addInverseRight z.re
  · exact C.addInverseRight z.im

theorem c_add_neg_left (C : RStageIntegrationCertificate) (z : CBOMA) :
    cAdd (cNeg z) z = cZero := by
  rw [c_add_comm C (cNeg z) z, c_add_neg_right C z]

theorem c_neg_involutive (C : RStageIntegrationCertificate) (z : CBOMA) :
    cNeg (cNeg z) = z := by
  apply c_ext
  · exact neg_involutive_from_interface C z.re
  · exact neg_involutive_from_interface C z.im

theorem c_mul_comm (C : RStageIntegrationCertificate) (z w : CBOMA) :
    cMul z w = cMul w z := by
  cases z <;> cases w <;>
    simp [cMul, BOMA.C.RoutePairProbe001.mul, C.mulComm, C.addComm]

/-- Associativity is an explicit consequence of the accepted real ring laws. -/
theorem c_mul_assoc
    (C : RStageIntegrationCertificate) (z w v : CBOMA) :
    cMul (cMul z w) v = cMul z (cMul w v) := by
  cases z <;> cases w <;> cases v <;>
    simp [cMul, BOMA.C.RoutePairProbe001.mul,
      r_mul_add_left_from_interface C, C.distribRight,
      mul_neg_left_from_interface C, mul_neg_right_from_interface C,
      r_neg_add_from_interface C, neg_involutive_from_interface C,
      C.mulAssoc, C.mulComm, r_mul_left_comm_from_interface C,
      C.addAssoc, C.addComm, r_add_left_comm_from_interface C]

theorem c_mul_one_left (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul cOne z = z := by
  apply c_ext
  · change
      rAdd (rMulCandidate rOne z.re)
        (rNeg (rMulCandidate rZero z.im)) = z.re
    rw [C.mulOneLeft z.re, mul_zero_left_from_interface C z.im,
      neg_zero_from_interface C,
      BOMA.C.RoutePairProbe001.add_zero_right_from_interface C z.re]
  · change
      rAdd (rMulCandidate rOne z.im)
        (rMulCandidate rZero z.re) = z.im
    rw [C.mulOneLeft z.im, mul_zero_left_from_interface C z.re,
      BOMA.C.RoutePairProbe001.add_zero_right_from_interface C z.im]

theorem c_mul_one_right (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul z cOne = z := by
  rw [c_mul_comm C z cOne, c_mul_one_left C z]

/-- Right distribution is proved independently from the abstract real interface. -/
theorem c_mul_add_right
    (C : RStageIntegrationCertificate) (z w v : CBOMA) :
    cMul z (cAdd w v) = cAdd (cMul z w) (cMul z v) := by
  cases z <;> cases w <;> cases v <;>
    simp [cMul, cAdd, BOMA.C.RoutePairProbe001.mul,
      BOMA.C.RoutePairProbe001.add,
      r_mul_add_left_from_interface C, C.distribRight,
      mul_neg_left_from_interface C, mul_neg_right_from_interface C,
      r_neg_add_from_interface C, neg_involutive_from_interface C,
      C.mulAssoc, C.mulComm, r_mul_left_comm_from_interface C,
      C.addAssoc, C.addComm, r_add_left_comm_from_interface C]

theorem c_mul_add_left
    (C : RStageIntegrationCertificate) (z w v : CBOMA) :
    cMul (cAdd z w) v = cAdd (cMul z v) (cMul w v) := by
  calc
    cMul (cAdd z w) v = cMul v (cAdd z w) :=
      c_mul_comm C (cAdd z w) v
    _ = cAdd (cMul v z) (cMul v w) := c_mul_add_right C v z w
    _ = cAdd (cMul z v) (cMul w v) := by
      rw [c_mul_comm C v z, c_mul_comm C v w]

theorem c_mul_zero_left (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul cZero z = cZero := by
  apply c_ext
  · change
      rAdd (rMulCandidate rZero z.re)
        (rNeg (rMulCandidate rZero z.im)) = rZero
    rw [mul_zero_left_from_interface C z.re,
      mul_zero_left_from_interface C z.im,
      neg_zero_from_interface C, C.addZeroLeft rZero]
  · change
      rAdd (rMulCandidate rZero z.im)
        (rMulCandidate rZero z.re) = rZero
    rw [mul_zero_left_from_interface C z.im,
      mul_zero_left_from_interface C z.re, C.addZeroLeft rZero]

theorem c_mul_zero_right (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul z cZero = cZero := by
  rw [c_mul_comm C z cZero, c_mul_zero_left C z]

theorem c_ofR_zero : cOfR rZero = cZero := rfl

theorem c_ofR_one : cOfR rOne = cOne := rfl

theorem c_ofR_neg (C : RStageIntegrationCertificate) (a : RBOMA) :
    cOfR (rNeg a) = cNeg (cOfR a) := by
  apply c_ext
  · rfl
  · exact (neg_zero_from_interface C).symm

theorem c_ofR_add (C : RStageIntegrationCertificate) (a b : RBOMA) :
    cOfR (rAdd a b) = cAdd (cOfR a) (cOfR b) := by
  apply c_ext
  · rfl
  · exact (C.addZeroLeft rZero).symm

theorem c_ofR_mul (C : RStageIntegrationCertificate) (a b : RBOMA) :
    cOfR (rMulCandidate a b) = cMul (cOfR a) (cOfR b) := by
  apply c_ext
  · change
      rMulCandidate a b =
        rAdd (rMulCandidate a b) (rNeg (rMulCandidate rZero rZero))
    rw [mul_zero_left_from_interface C rZero,
      neg_zero_from_interface C,
      BOMA.C.RoutePairProbe001.add_zero_right_from_interface C
        (rMulCandidate a b)]
  · change
      rZero = rAdd (rMulCandidate a rZero) (rMulCandidate rZero b)
    rw [mul_zero_right_from_interface C a,
      mul_zero_left_from_interface C b, C.addZeroLeft rZero]

theorem c_i_squared (C : RStageIntegrationCertificate) :
    cMul cI cI = cNeg cOne :=
  BOMA.C.RoutePairProbe001.imag_squared C

theorem c_generation (C : RStageIntegrationCertificate) (z : CBOMA) :
    ∃ a b : RBOMA, z = cAdd (cOfR a) (cMul (cOfR b) cI) :=
  BOMA.C.RoutePairProbe001.decomposition C z

theorem c_coordinate_unique
    (C : RStageIntegrationCertificate) {a b a' b' : RBOMA}
    (h : cAdd (cOfR a) (cMul (cOfR b) cI) =
      cAdd (cOfR a') (cMul (cOfR b') cI)) :
    a = a' ∧ b = b' :=
  BOMA.C.RoutePairProbe001.decomposition_unique C h

theorem c_i_not_real (C : RStageIntegrationCertificate) :
    ¬ ∃ a : RBOMA, cI = cOfR a :=
  BOMA.C.RoutePairProbe001.imag_not_real C

/-- Precisely scoped selected-route integration surface: ring, not field. -/
structure CPairRingCoreCertificate where
  nontrivial : cZero ≠ cOne
  embeddingInjective : ∀ {a b : RBOMA}, cOfR a = cOfR b → a = b
  addComm : ∀ z w : CBOMA, cAdd z w = cAdd w z
  addAssoc : ∀ z w v : CBOMA, cAdd (cAdd z w) v = cAdd z (cAdd w v)
  addZeroLeft : ∀ z : CBOMA, cAdd cZero z = z
  addInverseRight : ∀ z : CBOMA, cAdd z (cNeg z) = cZero
  mulComm : ∀ z w : CBOMA, cMul z w = cMul w z
  mulAssoc : ∀ z w v : CBOMA, cMul (cMul z w) v = cMul z (cMul w v)
  mulOneLeft : ∀ z : CBOMA, cMul cOne z = z
  distribRight : ∀ z w v : CBOMA,
    cMul z (cAdd w v) = cAdd (cMul z w) (cMul z v)
  mulZeroRight : ∀ z : CBOMA, cMul z cZero = cZero
  embeddingZero : cOfR rZero = cZero
  embeddingOne : cOfR rOne = cOne
  embeddingNeg : ∀ a : RBOMA, cOfR (rNeg a) = cNeg (cOfR a)
  embeddingAdd : ∀ a b : RBOMA,
    cOfR (rAdd a b) = cAdd (cOfR a) (cOfR b)
  embeddingMul : ∀ a b : RBOMA,
    cOfR (rMulCandidate a b) = cMul (cOfR a) (cOfR b)
  imagSquared : cMul cI cI = cNeg cOne
  generation : ∀ z : CBOMA,
    ∃ a b : RBOMA, z = cAdd (cOfR a) (cMul (cOfR b) cI)
  coordinateUnique : ∀ {a b a' b' : RBOMA},
    cAdd (cOfR a) (cMul (cOfR b) cI) =
      cAdd (cOfR a') (cMul (cOfR b') cI) → a = a' ∧ b = b'
  imagNotReal : ¬ ∃ a : RBOMA, cI = cOfR a

/-- Abstract real-interface construction; no real representation is unfolded. -/
theorem cPairRingCoreCertificate
    (C : RStageIntegrationCertificate) : CPairRingCoreCertificate where
  nontrivial := c_zero_ne_one C
  embeddingInjective := @c_ofR_injective
  addComm := c_add_comm C
  addAssoc := c_add_assoc C
  addZeroLeft := c_add_zero_left C
  addInverseRight := c_add_neg_right C
  mulComm := c_mul_comm C
  mulAssoc := c_mul_assoc C
  mulOneLeft := c_mul_one_left C
  distribRight := c_mul_add_right C
  mulZeroRight := c_mul_zero_right C
  embeddingZero := c_ofR_zero
  embeddingOne := c_ofR_one
  embeddingNeg := c_ofR_neg C
  embeddingAdd := c_ofR_add C
  embeddingMul := c_ofR_mul C
  imagSquared := c_i_squared C
  generation := c_generation C
  coordinateUnique := @c_coordinate_unique C
  imagNotReal := c_i_not_real C

/-- Instantiate the ring-core certificate on the accepted Stage-One real export. -/
theorem cPairRingCoreCertificateFromAcceptedR : CPairRingCoreCertificate :=
  cPairRingCoreCertificate rStageIntegrationCertificate

end BOMA.C.PairCore001

/- PDSA-C-005: selected Route P conjugate, norm, and inverse witnesses.

Zero norm yields only double-negated zero coordinates at the abstract real
interface. That weaker constructive result suffices to contradict a supplied
nonzero complex hypothesis; no equality decision or inverse selector is needed.
-/
namespace BOMA.C.PairNormInverse001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindOrderConstructive001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.RInterfaceNoSquareProbe001
open BOMA.C.PairCore001

/-- Conjugation reverses the selected imaginary coordinate. -/
def cConj (z : CBOMA) : CBOMA := ⟨z.re, rNeg z.im⟩

/-- The real-valued selected-coordinate norm is the sum of two squares. -/
def cNorm (z : CBOMA) : RBOMA :=
  rAdd (rMulCandidate z.re z.re) (rMulCandidate z.im z.im)

theorem c_conj_involutive
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    cConj (cConj z) = z := by
  apply c_ext
  · rfl
  · exact neg_involutive_from_interface C z.im

theorem c_conj_ofR
    (C : RStageIntegrationCertificate) (a : RBOMA) :
    cConj (cOfR a) = cOfR a := by
  apply c_ext
  · rfl
  · exact neg_zero_from_interface C

theorem c_conj_add
    (C : RStageIntegrationCertificate) (z w : CBOMA) :
    cConj (cAdd z w) = cAdd (cConj z) (cConj w) := by
  apply c_ext
  · rfl
  · exact r_neg_add_from_interface C z.im w.im

theorem c_norm_conj
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    cNorm (cConj z) = cNorm z := by
  change
    rAdd (rMulCandidate z.re z.re)
      (rMulCandidate (rNeg z.im) (rNeg z.im)) =
    rAdd (rMulCandidate z.re z.re)
      (rMulCandidate z.im z.im)
  rw [mul_neg_neg_same_from_interface C z.im]

/-- The norm product has exactly the embedded real norm and zero imaginary part. -/
theorem c_mul_conj
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul z (cConj z) = cOfR (cNorm z) := by
  apply c_ext
  · change
      rAdd (rMulCandidate z.re z.re)
        (rNeg (rMulCandidate z.im (rNeg z.im))) =
      rAdd (rMulCandidate z.re z.re) (rMulCandidate z.im z.im)
    rw [mul_neg_right_from_interface C z.im z.im,
      neg_involutive_from_interface C (rMulCandidate z.im z.im)]
  · change
      rAdd (rMulCandidate z.re (rNeg z.im))
        (rMulCandidate z.im z.re) = rZero
    rw [mul_neg_right_from_interface C z.re z.im,
      C.mulComm z.im z.re,
      C.addComm (rNeg (rMulCandidate z.re z.im))
        (rMulCandidate z.re z.im),
      C.addInverseRight (rMulCandidate z.re z.im)]

theorem c_conj_mul
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    cMul (cConj z) z = cOfR (cNorm z) := by
  rw [c_mul_comm C (cConj z) z, c_mul_conj C z]

/-- A nonnegative sum equal to zero has zero first summand. -/
theorem r_nonnegative_sum_zero_left
    (C : RStageIntegrationCertificate) {a b : RBOMA}
    (h0a : rLE rZero a) (h0b : rLE rZero b)
    (hsum : rAdd a b = rZero) : a = rZero := by
  have ha0 : rLE a rZero := by
    have h := (C.addTranslateOrderIff rZero b a).2 h0b
    rw [C.addZeroLeft a, C.addComm b a, hsum] at h
    exact h
  exact C.orderAntisymm ha0 h0a

/-- A nonnegative sum equal to zero has zero second summand. -/
theorem r_nonnegative_sum_zero_right
    (C : RStageIntegrationCertificate) {a b : RBOMA}
    (h0a : rLE rZero a) (h0b : rLE rZero b)
    (hsum : rAdd a b = rZero) : b = rZero := by
  apply r_nonnegative_sum_zero_left C h0b h0a
  rw [C.addComm b a, hsum]

theorem c_norm_nonnegative
    (C : RStageIntegrationCertificate) (z : CBOMA) :
    rLE rZero (cNorm z) := by
  have h0re := square_nonnegative_of_interface C z.re
  have h0im := square_nonnegative_of_interface C z.im
  have h :=
    (C.addTranslateOrderIff rZero
      (rMulCandidate z.im z.im) (rMulCandidate z.re z.re)).2 h0im
  rw [C.addZeroLeft (rMulCandidate z.re z.re),
    C.addComm (rMulCandidate z.im z.im)
      (rMulCandidate z.re z.re)] at h
  exact C.orderTrans h0re h

theorem c_norm_zero_real_square
    (C : RStageIntegrationCertificate) (z : CBOMA)
    (hnorm : cNorm z = rZero) :
    rMulCandidate z.re z.re = rZero := by
  exact r_nonnegative_sum_zero_left C
    (square_nonnegative_of_interface C z.re)
    (square_nonnegative_of_interface C z.im) hnorm

theorem c_norm_zero_imaginary_square
    (C : RStageIntegrationCertificate) (z : CBOMA)
    (hnorm : cNorm z = rZero) :
    rMulCandidate z.im z.im = rZero := by
  exact r_nonnegative_sum_zero_right C
    (square_nonnegative_of_interface C z.re)
    (square_nonnegative_of_interface C z.im) hnorm

/-- A zero real square contradicts any proposed nonzero real witness.

The conclusion is deliberately double-negated equality, not equality; the
abstract real interface does not provide stable or decidable equality. -/
theorem r_square_zero_not_nonzero
    (C : RStageIntegrationCertificate) {a : RBOMA}
    (hsquare : rMulCandidate a a = rZero) : ¬ a ≠ rZero := by
  intro hnonzero
  rcases C.inverseExists a hnonzero with ⟨t, ht⟩
  have hzero : a = rZero := by
    calc
      a = rMulCandidate a rOne :=
        (BOMA.C.RoutePairProbe001.mul_one_right_from_interface C a).symm
      _ = rMulCandidate a (rMulCandidate a t) := by rw [ht]
      _ = rMulCandidate (rMulCandidate a a) t :=
        (C.mulAssoc a a t).symm
      _ = rMulCandidate rZero t := by rw [hsquare]
      _ = rZero := mul_zero_left_from_interface C t
  exact hnonzero hzero

/-- Zero norm entails only double-negated zero coordinates and zero complex value. -/
theorem c_norm_zero_not_nonzero
    (C : RStageIntegrationCertificate) (z : CBOMA)
    (hnorm : cNorm z = rZero) : ¬ z ≠ cZero := by
  intro hnonzero
  have hre := r_square_zero_not_nonzero C
    (c_norm_zero_real_square C z hnorm)
  have him := r_square_zero_not_nonzero C
    (c_norm_zero_imaginary_square C z hnorm)
  apply hre
  intro hzre
  apply him
  intro hzim
  apply hnonzero
  apply c_ext
  · exact hzre
  · exact hzim

/-- A supplied nonzero complex hypothesis constructively makes its norm nonzero. -/
theorem c_norm_nonzero
    (C : RStageIntegrationCertificate) {z : CBOMA}
    (hnonzero : z ≠ cZero) : cNorm z ≠ rZero := by
  intro hnorm
  exact c_norm_zero_not_nonzero C z hnorm hnonzero

/-- A real inverse witness for the norm determines a complex inverse witness. -/
theorem c_inverse_from_real_witness
    (C : RStageIntegrationCertificate) (z : CBOMA) (t : RBOMA)
    (ht : rMulCandidate (cNorm z) t = rOne) :
    cMul z (cMul (cOfR t) (cConj z)) = cOne := by
  calc
    cMul z (cMul (cOfR t) (cConj z)) =
        cMul z (cMul (cConj z) (cOfR t)) := by
      rw [c_mul_comm C (cOfR t) (cConj z)]
    _ = cMul (cMul z (cConj z)) (cOfR t) :=
      (c_mul_assoc C z (cConj z) (cOfR t)).symm
    _ = cMul (cOfR (cNorm z)) (cOfR t) := by rw [c_mul_conj C z]
    _ = cOfR (rMulCandidate (cNorm z) t) :=
      (c_ofR_mul C (cNorm z) t).symm
    _ = cOfR rOne := by rw [ht]
    _ = cOne := c_ofR_one

/-- The field interface supplies existential witnesses, never a global selector. -/
theorem c_inverse_exists
    (C : RStageIntegrationCertificate) (z : CBOMA)
    (hnonzero : z ≠ cZero) :
    ∃ w : CBOMA, cMul z w = cOne := by
  rcases C.inverseExists (cNorm z) (c_norm_nonzero C hnonzero) with ⟨t, ht⟩
  exact ⟨cMul (cOfR t) (cConj z), c_inverse_from_real_witness C z t ht⟩

theorem c_inverse_left_of_right
    (C : RStageIntegrationCertificate) {z w : CBOMA}
    (hzw : cMul z w = cOne) :
    cMul w z = cOne := by
  rw [c_mul_comm C w z, hzw]

/-- Inverse witnesses are unique by the already verified ring laws. -/
theorem c_inverse_unique
    (C : RStageIntegrationCertificate) {z w v : CBOMA}
    (hw : cMul z w = cOne)
    (hv : cMul z v = cOne) : w = v := by
  calc
    w = cMul w cOne := (c_mul_one_right C w).symm
    _ = cMul w (cMul z v) := by rw [hv]
    _ = cMul (cMul w z) v := (c_mul_assoc C w z v).symm
    _ = cMul cOne v := by rw [c_mul_comm C w z, hw]
    _ = v := c_mul_one_left C v

/-- Complete selected-route field-strength certificate with witness-only inversion. -/
structure CPairFieldCertificate where
  ring : CPairRingCoreCertificate
  normNonnegative : ∀ z : CBOMA, rLE rZero (cNorm z)
  normNonzero : ∀ z : CBOMA, z ≠ cZero → cNorm z ≠ rZero
  conjugateProduct : ∀ z : CBOMA, cMul z (cConj z) = cOfR (cNorm z)
  inverseExists : ∀ z : CBOMA, z ≠ cZero → ∃ w : CBOMA, cMul z w = cOne
  inverseUnique : ∀ {z w v : CBOMA},
    cMul z w = cOne → cMul z v = cOne → w = v

/-- Field closure is derived from the abstract accepted real certificate alone. -/
theorem cPairFieldCertificate
    (C : RStageIntegrationCertificate) : CPairFieldCertificate where
  ring := cPairRingCoreCertificate C
  normNonnegative := c_norm_nonnegative C
  normNonzero := fun _ h => c_norm_nonzero C h
  conjugateProduct := c_mul_conj C
  inverseExists := c_inverse_exists C
  inverseUnique := @c_inverse_unique C

/-- Instantiate the witness-field certificate on the accepted real export. -/
theorem cPairFieldCertificateFromAcceptedR : CPairFieldCertificate :=
  cPairFieldCertificate rStageIntegrationCertificate

end BOMA.C.PairNormInverse001

/- PDSA-C-006: representation-neutral quadratic-field comparison.

Every accepted quadratic presentation has a canonical, total, single-valued,
invertible algebra-equivalence graph. Genuine inverse functions are obtained
only when both candidates provide constructive coordinate extractors as data.
-/
namespace BOMA.C.QuadraticComparison001

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.PairCore001
open BOMA.C.PairNormInverse001

/-- Common mathematical quadratic-field interface, independent of carrier identity. -/
structure QuadraticFieldPresentation (R : RStageIntegrationCertificate) where
  carrier : Type
  zero : carrier
  one : carrier
  neg : carrier → carrier
  add : carrier → carrier → carrier
  mul : carrier → carrier → carrier
  ofR : RBOMA → carrier
  imag : carrier
  coord : RBOMA → RBOMA → carrier
  nontrivial : zero ≠ one
  addComm : ∀ x y : carrier, add x y = add y x
  addAssoc : ∀ x y z : carrier, add (add x y) z = add x (add y z)
  addZeroLeft : ∀ x : carrier, add zero x = x
  addInverseRight : ∀ x : carrier, add x (neg x) = zero
  mulComm : ∀ x y : carrier, mul x y = mul y x
  mulAssoc : ∀ x y z : carrier, mul (mul x y) z = mul x (mul y z)
  mulOneLeft : ∀ x : carrier, mul one x = x
  distribRight : ∀ x y z : carrier, mul x (add y z) = add (mul x y) (mul x z)
  inverseExists : ∀ x : carrier, x ≠ zero → ∃ y : carrier, mul x y = one
  inverseUnique : ∀ {x y z : carrier}, mul x y = one → mul x z = one → y = z
  embeddingInjective : ∀ {a b : RBOMA}, ofR a = ofR b → a = b
  embeddingZero : ofR rZero = zero
  embeddingOne : ofR rOne = one
  embeddingNeg : ∀ a : RBOMA, ofR (rNeg a) = neg (ofR a)
  embeddingAdd : ∀ a b : RBOMA, ofR (rAdd a b) = add (ofR a) (ofR b)
  embeddingMul : ∀ a b : RBOMA,
    ofR (rMulCandidate a b) = mul (ofR a) (ofR b)
  imagSquared : mul imag imag = neg one
  coordinateExpression : ∀ a b : RBOMA,
    coord a b = add (ofR a) (mul (ofR b) imag)
  coordinateGeneration : ∀ x : carrier, ∃ a b : RBOMA, x = coord a b
  coordinateUnique : ∀ {a b c d : RBOMA},
    coord a b = coord c d → a = c ∧ b = d
  coordinateZero : coord rZero rZero = zero
  coordinateOne : coord rOne rZero = one
  coordinateReal : ∀ a : RBOMA, coord a rZero = ofR a
  coordinateImag : coord rZero rOne = imag
  coordinateNeg : ∀ a b : RBOMA,
    neg (coord a b) = coord (rNeg a) (rNeg b)
  coordinateAdd : ∀ a b c d : RBOMA,
    add (coord a b) (coord c d) = coord (rAdd a c) (rAdd b d)
  coordinateMul : ∀ a b c d : RBOMA,
    mul (coord a b) (coord c d) =
      coord
        (rAdd (rMulCandidate a c) (rNeg (rMulCandidate b d)))
        (rAdd (rMulCandidate a d) (rMulCandidate b c))

/-- The selected Route P field instantiates the carrier-neutral common contract. -/
def selectedPresentation
    (R : RStageIntegrationCertificate) : QuadraticFieldPresentation R where
  carrier := CBOMA
  zero := cZero
  one := cOne
  neg := cNeg
  add := cAdd
  mul := cMul
  ofR := cOfR
  imag := cI
  coord := fun a b => ⟨a, b⟩
  nontrivial := c_zero_ne_one R
  addComm := c_add_comm R
  addAssoc := c_add_assoc R
  addZeroLeft := c_add_zero_left R
  addInverseRight := c_add_neg_right R
  mulComm := c_mul_comm R
  mulAssoc := c_mul_assoc R
  mulOneLeft := c_mul_one_left R
  distribRight := c_mul_add_right R
  inverseExists := c_inverse_exists R
  inverseUnique := @c_inverse_unique R
  embeddingInjective := @c_ofR_injective
  embeddingZero := c_ofR_zero
  embeddingOne := c_ofR_one
  embeddingNeg := c_ofR_neg R
  embeddingAdd := c_ofR_add R
  embeddingMul := c_ofR_mul R
  imagSquared := c_i_squared R
  coordinateExpression := by
    intro a b
    exact (BOMA.C.RoutePairProbe001.coordinate_expression R a b).symm
  coordinateGeneration := by
    intro z
    exact ⟨z.re, z.im, by cases z; rfl⟩
  coordinateUnique := by
    intro a b c d h
    exact ⟨congrArg BOMA.C.RoutePairProbe001.PairCandidate.re h,
      congrArg BOMA.C.RoutePairProbe001.PairCandidate.im h⟩
  coordinateZero := rfl
  coordinateOne := rfl
  coordinateReal := by intro a; rfl
  coordinateImag := rfl
  coordinateNeg := by intro a b; rfl
  coordinateAdd := by intro a b c d; rfl
  coordinateMul := by intro a b c d; rfl

/-- Same accepted-real coefficients define the canonical comparison graph. -/
def Related {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (x : A.carrier) (y : B.carrier) : Prop :=
  ∃ a b : RBOMA, x = A.coord a b ∧ y = B.coord a b

theorem related_total_left {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (x : A.carrier) :
    ∃ y : B.carrier, Related A B x y := by
  rcases A.coordinateGeneration x with ⟨a, b, hx⟩
  exact ⟨B.coord a b, a, b, hx, rfl⟩

theorem related_total_right {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (y : B.carrier) :
    ∃ x : A.carrier, Related A B x y := by
  rcases B.coordinateGeneration y with ⟨a, b, hy⟩
  exact ⟨A.coord a b, a, b, rfl, hy⟩

theorem related_right_unique {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x : A.carrier} {y z : B.carrier}
    (hy : Related A B x y) (hz : Related A B x z) : y = z := by
  rcases hy with ⟨a, b, hxa, hya⟩
  rcases hz with ⟨c, d, hxc, hzc⟩
  rcases A.coordinateUnique (hxa.symm.trans hxc) with ⟨hac, hbd⟩
  cases hac
  cases hbd
  exact hya.trans hzc.symm

theorem related_left_unique {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x z : A.carrier} {y : B.carrier}
    (hx : Related A B x y) (hz : Related A B z y) : x = z := by
  rcases hx with ⟨a, b, hxa, hya⟩
  rcases hz with ⟨c, d, hzc, hyc⟩
  rcases B.coordinateUnique (hya.symm.trans hyc) with ⟨hac, hbd⟩
  cases hac
  cases hbd
  exact hxa.trans hzc.symm

theorem related_symm {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x : A.carrier} {y : B.carrier}
    (h : Related A B x y) : Related B A y x := by
  rcases h with ⟨a, b, hx, hy⟩
  exact ⟨a, b, hy, hx⟩

theorem related_zero {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) :
    Related A B A.zero B.zero :=
  ⟨rZero, rZero, A.coordinateZero.symm, B.coordinateZero.symm⟩

theorem related_one {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) :
    Related A B A.one B.one :=
  ⟨rOne, rZero, A.coordinateOne.symm, B.coordinateOne.symm⟩

theorem related_real {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (a : RBOMA) :
    Related A B (A.ofR a) (B.ofR a) :=
  ⟨a, rZero, (A.coordinateReal a).symm, (B.coordinateReal a).symm⟩

theorem related_imag {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) :
    Related A B A.imag B.imag :=
  ⟨rZero, rOne, A.coordinateImag.symm, B.coordinateImag.symm⟩

theorem related_neg {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x : A.carrier} {y : B.carrier}
    (h : Related A B x y) : Related A B (A.neg x) (B.neg y) := by
  rcases h with ⟨a, b, hx, hy⟩
  refine ⟨rNeg a, rNeg b, ?_, ?_⟩
  · rw [hx, A.coordinateNeg a b]
  · rw [hy, B.coordinateNeg a b]

theorem related_add {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w) :
    Related A B (A.add x z) (B.add y w) := by
  rcases hxy with ⟨a, b, hx, hy⟩
  rcases hzw with ⟨c, d, hz, hw⟩
  refine ⟨rAdd a c, rAdd b d, ?_, ?_⟩
  · rw [hx, hz, A.coordinateAdd a b c d]
  · rw [hy, hw, B.coordinateAdd a b c d]

theorem related_mul {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w) :
    Related A B (A.mul x z) (B.mul y w) := by
  rcases hxy with ⟨a, b, hx, hy⟩
  rcases hzw with ⟨c, d, hz, hw⟩
  refine ⟨rAdd (rMulCandidate a c) (rNeg (rMulCandidate b d)),
    rAdd (rMulCandidate a d) (rMulCandidate b c), ?_, ?_⟩
  · rw [hx, hz, A.coordinateMul a b c d]
  · rw [hy, hw, B.coordinateMul a b c d]

theorem related_inverse_witness {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w)
    (hxz : A.mul x z = A.one) : B.mul y w = B.one := by
  have h := related_mul A B hxy hzw
  rw [hxz] at h
  exact related_right_unique A B h (related_one A B)

/-- Universal comparison package: an invertible field/algebra graph relation. -/
structure QuadraticComparisonCertificate {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) where
  totalLeft : ∀ x : A.carrier, ∃ y : B.carrier, Related A B x y
  totalRight : ∀ y : B.carrier, ∃ x : A.carrier, Related A B x y
  uniqueRight : ∀ {x : A.carrier} {y z : B.carrier},
    Related A B x y → Related A B x z → y = z
  uniqueLeft : ∀ {x z : A.carrier} {y : B.carrier},
    Related A B x y → Related A B z y → x = z
  preserveZero : Related A B A.zero B.zero
  preserveOne : Related A B A.one B.one
  preserveReal : ∀ a : RBOMA, Related A B (A.ofR a) (B.ofR a)
  preserveImag : Related A B A.imag B.imag
  preserveNeg : ∀ {x : A.carrier} {y : B.carrier},
    Related A B x y → Related A B (A.neg x) (B.neg y)
  preserveAdd : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      Related A B (A.add x z) (B.add y w)
  preserveMul : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      Related A B (A.mul x z) (B.mul y w)
  preserveInverse : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      A.mul x z = A.one → B.mul y w = B.one

/-- Any two accepted common presentations admit a canonical algebra-equivalence graph. -/
theorem quadraticComparison
    {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) :
    QuadraticComparisonCertificate A B where
  totalLeft := related_total_left A B
  totalRight := related_total_right A B
  uniqueRight := @related_right_unique R A B
  uniqueLeft := @related_left_unique R A B
  preserveZero := related_zero A B
  preserveOne := related_one A B
  preserveReal := related_real A B
  preserveImag := related_imag A B
  preserveNeg := @related_neg R A B
  preserveAdd := @related_add R A B
  preserveMul := @related_mul R A B
  preserveInverse := @related_inverse_witness R A B

/-- Explicit constructive coordinate data; not inferred from propositional existence. -/
structure CoordinateExtractor {R : RStageIntegrationCertificate}
    (A : QuadraticFieldPresentation R) where
  re : A.carrier → RBOMA
  im : A.carrier → RBOMA
  sound : ∀ x : A.carrier, x = A.coord (re x) (im x)

/-- Route P supplies projections directly; no global selection principle is used. -/
def selectedExtractor
    (R : RStageIntegrationCertificate) :
    CoordinateExtractor (selectedPresentation R) where
  re := fun z => z.re
  im := fun z => z.im
  sound := by intro z; cases z; rfl

/-- A genuine comparison function exists when its source supplies extraction data. -/
def coordinateMap {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (E : CoordinateExtractor A) (x : A.carrier) : B.carrier :=
  B.coord (E.re x) (E.im x)

theorem coordinate_map_related {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (E : CoordinateExtractor A) (x : A.carrier) :
    Related A B x (coordinateMap A B E x) :=
  ⟨E.re x, E.im x, E.sound x, rfl⟩

theorem coordinate_map_zero {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A) :
    coordinateMap A B E A.zero = B.zero :=
  related_right_unique A B
    (coordinate_map_related A B E A.zero) (related_zero A B)

theorem coordinate_map_one {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A) :
    coordinateMap A B E A.one = B.one :=
  related_right_unique A B
    (coordinate_map_related A B E A.one) (related_one A B)

theorem coordinate_map_real {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A)
    (a : RBOMA) :
    coordinateMap A B E (A.ofR a) = B.ofR a :=
  related_right_unique A B
    (coordinate_map_related A B E (A.ofR a)) (related_real A B a)

theorem coordinate_map_imag {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A) :
    coordinateMap A B E A.imag = B.imag :=
  related_right_unique A B
    (coordinate_map_related A B E A.imag) (related_imag A B)

theorem coordinate_map_neg {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A)
    (x : A.carrier) :
    coordinateMap A B E (A.neg x) = B.neg (coordinateMap A B E x) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.neg x))
    (related_neg A B (coordinate_map_related A B E x))

theorem coordinate_map_add {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A)
    (x y : A.carrier) :
    coordinateMap A B E (A.add x y) =
      B.add (coordinateMap A B E x) (coordinateMap A B E y) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.add x y))
    (related_add A B
      (coordinate_map_related A B E x)
      (coordinate_map_related A B E y))

theorem coordinate_map_mul {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) (E : CoordinateExtractor A)
    (x y : A.carrier) :
    coordinateMap A B E (A.mul x y) =
      B.mul (coordinateMap A B E x) (coordinateMap A B E y) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.mul x y))
    (related_mul A B
      (coordinate_map_related A B E x)
      (coordinate_map_related A B E y))

theorem coordinate_maps_inverse_left {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B)
    (x : A.carrier) :
    coordinateMap B A EB (coordinateMap A B EA x) = x := by
  have hforward := coordinate_map_related A B EA x
  have hbackward :=
    related_symm B A
      (coordinate_map_related B A EB (coordinateMap A B EA x))
  exact related_left_unique A B hbackward hforward

theorem coordinate_maps_inverse_right {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B)
    (y : B.carrier) :
    coordinateMap A B EA (coordinateMap B A EB y) = y :=
  coordinate_maps_inverse_left B A EB EA y

/-- Genuine inverse algebra maps, conditional on explicit constructive extractors. -/
structure ConstructiveQuadraticIsomorphism {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R) where
  forward : A.carrier → B.carrier
  backward : B.carrier → A.carrier
  leftInverse : ∀ x : A.carrier, backward (forward x) = x
  rightInverse : ∀ y : B.carrier, forward (backward y) = y
  preserveZero : forward A.zero = B.zero
  preserveOne : forward A.one = B.one
  preserveReal : ∀ a : RBOMA, forward (A.ofR a) = B.ofR a
  preserveImag : forward A.imag = B.imag
  preserveNeg : ∀ x : A.carrier, forward (A.neg x) = B.neg (forward x)
  preserveAdd : ∀ x y : A.carrier,
    forward (A.add x y) = B.add (forward x) (forward y)
  preserveMul : ∀ x y : A.carrier,
    forward (A.mul x y) = B.mul (forward x) (forward y)

/-- Actual functional R-field isomorphism requires extractor data on both sides. -/
def constructiveQuadraticIsomorphism
    {R : RStageIntegrationCertificate}
    (A B : QuadraticFieldPresentation R)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B) :
    ConstructiveQuadraticIsomorphism A B where
  forward := coordinateMap A B EA
  backward := coordinateMap B A EB
  leftInverse := coordinate_maps_inverse_left A B EA EB
  rightInverse := coordinate_maps_inverse_right A B EA EB
  preserveZero := coordinate_map_zero A B EA
  preserveOne := coordinate_map_one A B EA
  preserveReal := coordinate_map_real A B EA
  preserveImag := coordinate_map_imag A B EA
  preserveNeg := coordinate_map_neg A B EA
  preserveAdd := coordinate_map_add A B EA
  preserveMul := coordinate_map_mul A B EA

/-- The selected presentation satisfies the universal comparison obligation. -/
theorem selectedQuadraticComparison
    (R : RStageIntegrationCertificate)
    (B : QuadraticFieldPresentation R) :
    QuadraticComparisonCertificate (selectedPresentation R) B :=
  quadraticComparison (selectedPresentation R) B

/-- Selected Route P compares functionally with every constructively coordinatized peer. -/
def selectedConstructiveQuadraticIsomorphism
    (R : RStageIntegrationCertificate)
    (B : QuadraticFieldPresentation R)
    (EB : CoordinateExtractor B) :
    ConstructiveQuadraticIsomorphism (selectedPresentation R) B :=
  constructiveQuadraticIsomorphism
    (selectedPresentation R) B (selectedExtractor R) EB

/-- The accepted-real selected presentation has a verified self-comparison. -/
theorem acceptedSelectedSelfComparison :
    QuadraticComparisonCertificate
      (selectedPresentation rStageIntegrationCertificate)
      (selectedPresentation rStageIntegrationCertificate) :=
  quadraticComparison
    (selectedPresentation rStageIntegrationCertificate)
    (selectedPresentation rStageIntegrationCertificate)

end BOMA.C.QuadraticComparison001

/- PDSA-C-007: same-carrier complex integration and quadratic comparison. -/
namespace BOMA.C.StageIntegration001

open BOMA.R.DedekindQuotient001
open BOMA.R.StageIntegration002
open BOMA.C.PairCore001
open BOMA.C.PairNormInverse001
open BOMA.C.QuadraticComparison001

/-- CA-19 packages every required component on the one selected complex carrier. -/
structure CStageIntegrationCertificate where
  field : CPairFieldCertificate
  generatorSquared : cMul cI cI = cNeg cOne
  realGeneration : ∀ z : CBOMA,
    ∃ a b : RBOMA, z = cAdd (cOfR a) (cMul (cOfR b) cI)
  coordinateUnique : ∀ {a b c d : RBOMA},
    cAdd (cOfR a) (cMul (cOfR b) cI) =
      cAdd (cOfR c) (cMul (cOfR d) cI) → a = c ∧ b = d
  imaginaryNotReal : ¬ ∃ a : RBOMA, cI = cOfR a
  comparison : ∀ (B : QuadraticFieldPresentation rStageIntegrationCertificate),
    QuadraticComparisonCertificate
      (selectedPresentation rStageIntegrationCertificate) B
  functionalComparison : ∀ (B : QuadraticFieldPresentation rStageIntegrationCertificate),
    CoordinateExtractor B →
      ConstructiveQuadraticIsomorphism
        (selectedPresentation rStageIntegrationCertificate) B

/-- Final certificate adds no carrier, operation, inverse selector, or logical commitment. -/
def cStageIntegrationCertificate : CStageIntegrationCertificate where
  field := cPairFieldCertificateFromAcceptedR
  generatorSquared := c_i_squared rStageIntegrationCertificate
  realGeneration := c_generation rStageIntegrationCertificate
  coordinateUnique := @c_coordinate_unique rStageIntegrationCertificate
  imaginaryNotReal := c_i_not_real rStageIntegrationCertificate
  comparison := selectedQuadraticComparison rStageIntegrationCertificate
  functionalComparison :=
    selectedConstructiveQuadraticIsomorphism rStageIntegrationCertificate

end BOMA.C.StageIntegration001

/- ST2-EXP-011: scalar-generic quadratic comparison core.

This research-only source extracts exactly the coordinate-level declaration
closure used by CQuadraticComparison001. It deliberately refers to no concrete
real-scalar implementation or transport route, and introduces no global
coordinate or inverse selector. Functional maps remain conditional on explicit
CoordinateExtractor data. -/
namespace BOMA.C.StageTwo.ComparisonInterface011

/-- Operations on the scalar carrier that occur syntactically in quadratic
    coordinate formulas. No field, order, completeness, or inverse law is
    bundled here. -/
structure ScalarOps where
  carrier : Type
  zero : carrier
  one : carrier
  neg : carrier → carrier
  add : carrier → carrier → carrier
  mul : carrier → carrier → carrier

/-- Minimal presentation required by the actual comparison declaration closure.
    Algebraic laws that the comparison proofs do not consume are intentionally
    absent. -/
structure QuadraticPresentation (S : ScalarOps) where
  carrier : Type
  zero : carrier
  one : carrier
  neg : carrier → carrier
  add : carrier → carrier → carrier
  mul : carrier → carrier → carrier
  ofScalar : S.carrier → carrier
  imag : carrier
  coord : S.carrier → S.carrier → carrier
  coordinateGeneration : ∀ x : carrier, ∃ a b : S.carrier, x = coord a b
  coordinateUnique : ∀ {a b c d : S.carrier},
    coord a b = coord c d → a = c ∧ b = d
  coordinateZero : coord S.zero S.zero = zero
  coordinateOne : coord S.one S.zero = one
  coordinateReal : ∀ a : S.carrier, coord a S.zero = ofScalar a
  coordinateImag : coord S.zero S.one = imag
  coordinateNeg : ∀ a b : S.carrier,
    neg (coord a b) = coord (S.neg a) (S.neg b)
  coordinateAdd : ∀ a b c d : S.carrier,
    add (coord a b) (coord c d) = coord (S.add a c) (S.add b d)
  coordinateMul : ∀ a b c d : S.carrier,
    mul (coord a b) (coord c d) =
      coord
        (S.add (S.mul a c) (S.neg (S.mul b d)))
        (S.add (S.mul a d) (S.mul b c))

/-- Same scalar coordinates define the representation-neutral graph. -/
def Related {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (x : A.carrier) (y : B.carrier) : Prop :=
  ∃ a b : S.carrier, x = A.coord a b ∧ y = B.coord a b

theorem related_total_left {S : ScalarOps}
    (A B : QuadraticPresentation S) (x : A.carrier) :
    ∃ y : B.carrier, Related A B x y := by
  rcases A.coordinateGeneration x with ⟨a, b, hx⟩
  exact ⟨B.coord a b, a, b, hx, rfl⟩

theorem related_total_right {S : ScalarOps}
    (A B : QuadraticPresentation S) (y : B.carrier) :
    ∃ x : A.carrier, Related A B x y := by
  rcases B.coordinateGeneration y with ⟨a, b, hy⟩
  exact ⟨A.coord a b, a, b, rfl, hy⟩

theorem related_right_unique {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x : A.carrier} {y z : B.carrier}
    (hy : Related A B x y) (hz : Related A B x z) : y = z := by
  rcases hy with ⟨a, b, hxa, hya⟩
  rcases hz with ⟨c, d, hxc, hzc⟩
  rcases A.coordinateUnique (hxa.symm.trans hxc) with ⟨hac, hbd⟩
  cases hac
  cases hbd
  exact hya.trans hzc.symm

theorem related_left_unique {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x z : A.carrier} {y : B.carrier}
    (hx : Related A B x y) (hz : Related A B z y) : x = z := by
  rcases hx with ⟨a, b, hxa, hya⟩
  rcases hz with ⟨c, d, hzc, hyc⟩
  rcases B.coordinateUnique (hya.symm.trans hyc) with ⟨hac, hbd⟩
  cases hac
  cases hbd
  exact hxa.trans hzc.symm

theorem related_symm {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x : A.carrier} {y : B.carrier}
    (h : Related A B x y) : Related B A y x := by
  rcases h with ⟨a, b, hx, hy⟩
  exact ⟨a, b, hy, hx⟩

theorem related_zero {S : ScalarOps}
    (A B : QuadraticPresentation S) : Related A B A.zero B.zero :=
  ⟨S.zero, S.zero, A.coordinateZero.symm, B.coordinateZero.symm⟩

theorem related_one {S : ScalarOps}
    (A B : QuadraticPresentation S) : Related A B A.one B.one :=
  ⟨S.one, S.zero, A.coordinateOne.symm, B.coordinateOne.symm⟩

theorem related_real {S : ScalarOps}
    (A B : QuadraticPresentation S) (a : S.carrier) :
    Related A B (A.ofScalar a) (B.ofScalar a) :=
  ⟨a, S.zero, (A.coordinateReal a).symm, (B.coordinateReal a).symm⟩

theorem related_imag {S : ScalarOps}
    (A B : QuadraticPresentation S) : Related A B A.imag B.imag :=
  ⟨S.zero, S.one, A.coordinateImag.symm, B.coordinateImag.symm⟩

theorem related_neg {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x : A.carrier} {y : B.carrier}
    (h : Related A B x y) : Related A B (A.neg x) (B.neg y) := by
  rcases h with ⟨a, b, hx, hy⟩
  refine ⟨S.neg a, S.neg b, ?_, ?_⟩
  · rw [hx, A.coordinateNeg a b]
  · rw [hy, B.coordinateNeg a b]

theorem related_add {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w) :
    Related A B (A.add x z) (B.add y w) := by
  rcases hxy with ⟨a, b, hx, hy⟩
  rcases hzw with ⟨c, d, hz, hw⟩
  refine ⟨S.add a c, S.add b d, ?_, ?_⟩
  · rw [hx, hz, A.coordinateAdd a b c d]
  · rw [hy, hw, B.coordinateAdd a b c d]

theorem related_mul {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w) :
    Related A B (A.mul x z) (B.mul y w) := by
  rcases hxy with ⟨a, b, hx, hy⟩
  rcases hzw with ⟨c, d, hz, hw⟩
  refine ⟨S.add (S.mul a c) (S.neg (S.mul b d)),
    S.add (S.mul a d) (S.mul b c), ?_, ?_⟩
  · rw [hx, hz, A.coordinateMul a b c d]
  · rw [hy, hw, B.coordinateMul a b c d]

/-- Preserve a supplied inverse witness. This theorem does not select, construct,
    or globally store an inverse. -/
theorem related_inverse_witness {S : ScalarOps}
    (A B : QuadraticPresentation S)
    {x z : A.carrier} {y w : B.carrier}
    (hxy : Related A B x y) (hzw : Related A B z w)
    (hxz : A.mul x z = A.one) : B.mul y w = B.one := by
  have h := related_mul A B hxy hzw
  rw [hxz] at h
  exact related_right_unique A B h (related_one A B)

/-- Relation-level comparison package. -/
structure QuadraticComparisonCertificate {S : ScalarOps}
    (A B : QuadraticPresentation S) where
  totalLeft : ∀ x : A.carrier, ∃ y : B.carrier, Related A B x y
  totalRight : ∀ y : B.carrier, ∃ x : A.carrier, Related A B x y
  uniqueRight : ∀ {x : A.carrier} {y z : B.carrier},
    Related A B x y → Related A B x z → y = z
  uniqueLeft : ∀ {x z : A.carrier} {y : B.carrier},
    Related A B x y → Related A B z y → x = z
  preserveZero : Related A B A.zero B.zero
  preserveOne : Related A B A.one B.one
  preserveReal : ∀ a : S.carrier, Related A B (A.ofScalar a) (B.ofScalar a)
  preserveImag : Related A B A.imag B.imag
  preserveNeg : ∀ {x : A.carrier} {y : B.carrier},
    Related A B x y → Related A B (A.neg x) (B.neg y)
  preserveAdd : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      Related A B (A.add x z) (B.add y w)
  preserveMul : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      Related A B (A.mul x z) (B.mul y w)
  preserveInverse : ∀ {x z : A.carrier} {y w : B.carrier},
    Related A B x y → Related A B z w →
      A.mul x z = A.one → B.mul y w = B.one

theorem quadraticComparison {S : ScalarOps}
    (A B : QuadraticPresentation S) :
    QuadraticComparisonCertificate A B where
  totalLeft := related_total_left A B
  totalRight := related_total_right A B
  uniqueRight := @related_right_unique S A B
  uniqueLeft := @related_left_unique S A B
  preserveZero := related_zero A B
  preserveOne := related_one A B
  preserveReal := related_real A B
  preserveImag := related_imag A B
  preserveNeg := @related_neg S A B
  preserveAdd := @related_add S A B
  preserveMul := @related_mul S A B
  preserveInverse := @related_inverse_witness S A B

/-- Explicit constructive coordinate data. It is never synthesized from the
    existential totality theorem. -/
structure CoordinateExtractor {S : ScalarOps}
    (A : QuadraticPresentation S) where
  re : A.carrier → S.carrier
  im : A.carrier → S.carrier
  sound : ∀ x : A.carrier, x = A.coord (re x) (im x)

/-- Functional comparison exists only after explicit extractor data is supplied. -/
def coordinateMap {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (E : CoordinateExtractor A) (x : A.carrier) : B.carrier :=
  B.coord (E.re x) (E.im x)

theorem coordinate_map_related {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (E : CoordinateExtractor A) (x : A.carrier) :
    Related A B x (coordinateMap A B E x) :=
  ⟨E.re x, E.im x, E.sound x, rfl⟩

theorem coordinate_map_zero {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A) :
    coordinateMap A B E A.zero = B.zero :=
  related_right_unique A B
    (coordinate_map_related A B E A.zero) (related_zero A B)

theorem coordinate_map_one {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A) :
    coordinateMap A B E A.one = B.one :=
  related_right_unique A B
    (coordinate_map_related A B E A.one) (related_one A B)

theorem coordinate_map_real {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A)
    (a : S.carrier) :
    coordinateMap A B E (A.ofScalar a) = B.ofScalar a :=
  related_right_unique A B
    (coordinate_map_related A B E (A.ofScalar a)) (related_real A B a)

theorem coordinate_map_imag {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A) :
    coordinateMap A B E A.imag = B.imag :=
  related_right_unique A B
    (coordinate_map_related A B E A.imag) (related_imag A B)

theorem coordinate_map_neg {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A)
    (x : A.carrier) :
    coordinateMap A B E (A.neg x) = B.neg (coordinateMap A B E x) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.neg x))
    (related_neg A B (coordinate_map_related A B E x))

theorem coordinate_map_add {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A)
    (x y : A.carrier) :
    coordinateMap A B E (A.add x y) =
      B.add (coordinateMap A B E x) (coordinateMap A B E y) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.add x y))
    (related_add A B
      (coordinate_map_related A B E x)
      (coordinate_map_related A B E y))

theorem coordinate_map_mul {S : ScalarOps}
    (A B : QuadraticPresentation S) (E : CoordinateExtractor A)
    (x y : A.carrier) :
    coordinateMap A B E (A.mul x y) =
      B.mul (coordinateMap A B E x) (coordinateMap A B E y) :=
  related_right_unique A B
    (coordinate_map_related A B E (A.mul x y))
    (related_mul A B
      (coordinate_map_related A B E x)
      (coordinate_map_related A B E y))

theorem coordinate_maps_inverse_left {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B)
    (x : A.carrier) :
    coordinateMap B A EB (coordinateMap A B EA x) = x := by
  have hforward := coordinate_map_related A B EA x
  have hbackward :=
    related_symm B A
      (coordinate_map_related B A EB (coordinateMap A B EA x))
  exact related_left_unique A B hbackward hforward

theorem coordinate_maps_inverse_right {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B)
    (y : B.carrier) :
    coordinateMap A B EA (coordinateMap B A EB y) = y :=
  coordinate_maps_inverse_left B A EB EA y

/-- Functional isomorphism package, explicitly conditional on extractor data. -/
structure ConstructiveQuadraticIsomorphism {S : ScalarOps}
    (A B : QuadraticPresentation S) where
  forward : A.carrier → B.carrier
  backward : B.carrier → A.carrier
  leftInverse : ∀ x : A.carrier, backward (forward x) = x
  rightInverse : ∀ y : B.carrier, forward (backward y) = y
  preserveZero : forward A.zero = B.zero
  preserveOne : forward A.one = B.one
  preserveReal : ∀ a : S.carrier, forward (A.ofScalar a) = B.ofScalar a
  preserveImag : forward A.imag = B.imag
  preserveNeg : ∀ x : A.carrier, forward (A.neg x) = B.neg (forward x)
  preserveAdd : ∀ x y : A.carrier,
    forward (A.add x y) = B.add (forward x) (forward y)
  preserveMul : ∀ x y : A.carrier,
    forward (A.mul x y) = B.mul (forward x) (forward y)

def constructiveQuadraticIsomorphism {S : ScalarOps}
    (A B : QuadraticPresentation S)
    (EA : CoordinateExtractor A) (EB : CoordinateExtractor B) :
    ConstructiveQuadraticIsomorphism A B where
  forward := coordinateMap A B EA
  backward := coordinateMap B A EB
  leftInverse := coordinate_maps_inverse_left A B EA EB
  rightInverse := coordinate_maps_inverse_right A B EA EB
  preserveZero := coordinate_map_zero A B EA
  preserveOne := coordinate_map_one A B EA
  preserveReal := coordinate_map_real A B EA
  preserveImag := coordinate_map_imag A B EA
  preserveNeg := coordinate_map_neg A B EA
  preserveAdd := coordinate_map_add A B EA
  preserveMul := coordinate_map_mul A B EA

end BOMA.C.StageTwo.ComparisonInterface011

/- ST2-EXP-011 Gate D: accepted-RBOMA adapter for the scalar-generic
   quadratic comparison core. The accepted CQuadraticComparison001 source is
   consumed unchanged; this file is research-only. -/
namespace BOMA.C.StageTwo.ComparisonInterface011.AcceptedRBOMA

open BOMA.R.DedekindQuotient001
open BOMA.R.DedekindAddition001
open BOMA.R.DedekindNegationCandidate001
open BOMA.R.DedekindSignedMulCandidate001
open BOMA.R.StageIntegration002
open BOMA.C.StageTwo.ComparisonInterface011

/-- The accepted real scalar operations, exposed only as the five operations
    actually occurring in the comparison coordinate formulas. -/
def rbomaScalarOps : ScalarOps where
  carrier := RBOMA
  zero := rZero
  one := rOne
  neg := rNeg
  add := rAdd
  mul := rMulCandidate

/-- Forget the comparison-irrelevant laws from the accepted presentation. -/
def fromAccepted {R : RStageIntegrationCertificate}
    (A : BOMA.C.QuadraticComparison001.QuadraticFieldPresentation R) :
    QuadraticPresentation rbomaScalarOps where
  carrier := A.carrier
  zero := A.zero
  one := A.one
  neg := A.neg
  add := A.add
  mul := A.mul
  ofScalar := A.ofR
  imag := A.imag
  coord := A.coord
  coordinateGeneration := A.coordinateGeneration
  coordinateUnique := A.coordinateUnique
  coordinateZero := A.coordinateZero
  coordinateOne := A.coordinateOne
  coordinateReal := A.coordinateReal
  coordinateImag := A.coordinateImag
  coordinateNeg := A.coordinateNeg
  coordinateAdd := A.coordinateAdd
  coordinateMul := A.coordinateMul

/-- Gate-D semantic preservation: after forgetting irrelevant fields, the new
    relation is definitionally the accepted shared-RBOMA coordinate relation. -/
theorem related_iff_accepted {R : RStageIntegrationCertificate}
    (A B : BOMA.C.QuadraticComparison001.QuadraticFieldPresentation R)
    (x : A.carrier) (y : B.carrier) :
    Related (fromAccepted A) (fromAccepted B) x y ↔
      BOMA.C.QuadraticComparison001.Related A B x y := by
  rfl

/-- Every accepted presentation pair satisfies the generic relation-level
    certificate without changing either accepted source. -/
theorem acceptedGenericComparison {R : RStageIntegrationCertificate}
    (A B : BOMA.C.QuadraticComparison001.QuadraticFieldPresentation R) :
    QuadraticComparisonCertificate (fromAccepted A) (fromAccepted B) :=
  quadraticComparison (fromAccepted A) (fromAccepted B)

/-- Accepted Route P remains a native instance of the generic comparison. -/
theorem acceptedSelectedSelfComparison :
    QuadraticComparisonCertificate
      (fromAccepted
        (BOMA.C.QuadraticComparison001.selectedPresentation
          rStageIntegrationCertificate))
      (fromAccepted
        (BOMA.C.QuadraticComparison001.selectedPresentation
          rStageIntegrationCertificate)) :=
  acceptedGenericComparison
    (BOMA.C.QuadraticComparison001.selectedPresentation
      rStageIntegrationCertificate)
    (BOMA.C.QuadraticComparison001.selectedPresentation
      rStageIntegrationCertificate)

/-- Adapt accepted explicit coordinate extractors without creating any selector. -/
def extractorFromAccepted {R : RStageIntegrationCertificate}
    {A : BOMA.C.QuadraticComparison001.QuadraticFieldPresentation R}
    (E : BOMA.C.QuadraticComparison001.CoordinateExtractor A) :
    CoordinateExtractor (fromAccepted A) where
  re := E.re
  im := E.im
  sound := E.sound

/-- The accepted selected Route-P projections remain explicit constructive
    extractor data in the generic layer. -/
def acceptedSelectedExtractor (R : RStageIntegrationCertificate) :
    CoordinateExtractor
      (fromAccepted
        (BOMA.C.QuadraticComparison001.selectedPresentation R)) :=
  extractorFromAccepted (BOMA.C.QuadraticComparison001.selectedExtractor R)

/-- Functional self-comparison is available for accepted Route P for exactly
    the old reason: its extractor is explicit data. -/
def acceptedSelectedSelfIsomorphism :
    ConstructiveQuadraticIsomorphism
      (fromAccepted
        (BOMA.C.QuadraticComparison001.selectedPresentation
          rStageIntegrationCertificate))
      (fromAccepted
        (BOMA.C.QuadraticComparison001.selectedPresentation
          rStageIntegrationCertificate)) :=
  constructiveQuadraticIsomorphism
    (fromAccepted
      (BOMA.C.QuadraticComparison001.selectedPresentation
        rStageIntegrationCertificate))
    (fromAccepted
      (BOMA.C.QuadraticComparison001.selectedPresentation
        rStageIntegrationCertificate))
    (acceptedSelectedExtractor rStageIntegrationCertificate)
    (acceptedSelectedExtractor rStageIntegrationCertificate)

end BOMA.C.StageTwo.ComparisonInterface011.AcceptedRBOMA
